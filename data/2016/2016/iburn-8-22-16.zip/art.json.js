[
    {
        "uid": "a2Id0000000cbObEAI",
        "year": 2016,
        "name": "Lord Snort",
        "url": null,
        "contact_email": "tedrickart@sbcglobal.net",
        "hometown": "Glen Ellen, CA",
        "description": "Lord Snort is a wild boar roughly 20' tall and 30' long which balances on a shaft, allowing it to rotate 360 degrees. Made of steel, it is rough and unbreakable and people can climb all over it. It will serve as a gathering point for unimagined interactions.",
        "artist": "Bryan Tedrick",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "5:45 900', Open Playa",
            "hour": 5,
            "minute": 45,
            "distance": 900,
            "category": "Open Playa",
            "gps_latitude": 40.784442253215,
            "gps_longitude": -119.208476587223
        },
        "location_string": "5:45 900', Open Playa",
        "images": [
            {
                "gallery_ref": 82828,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82828_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbObEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbOLEAY",
        "year": 2016,
        "name": "OID",
        "url": null,
        "contact_email": null,
        "hometown": "Berkeley, CA",
        "description": null,
        "artist": "Michael Christian",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "8:14 2000', Open Playa",
            "hour": 8,
            "minute": 14,
            "distance": 2000,
            "category": "Open Playa",
            "gps_latitude": 40.788442040138,
            "gps_longitude": -119.213210989851
        },
        "location_string": "8:14 2000', Open Playa",
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbOLEAY.mp3"
    },
    {
        "uid": "a2Id0000000cbOdEAI",
        "year": 2016,
        "name": "Rube Awakening Magic Bike Rack",
        "url": null,
        "contact_email": "smerko72@gmail.com",
        "hometown": "Las Vegas, NV",
        "description": "Apparent to the eye is a bike rack constructed from practical materials, however, Rube Awakening will not reach its full function without interaction and use by Black Rock City residents.  \r\nMagic Bike Rack shining bright\r\nGlowing beacon rube's delight!\r\nLock your bike by night or day, \r\nLiberate to rube's dismay.",
        "artist": "Mark Melnick",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "6:45 2300', Open Playa",
            "hour": 6,
            "minute": 45,
            "distance": 2300,
            "category": "Open Playa",
            "gps_latitude": 40.783979289042,
            "gps_longitude": -119.214178278566
        },
        "location_string": "6:45 2300', Open Playa",
        "images": [
            {
                "gallery_ref": 82829,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82829_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbNkEAI",
        "year": 2016,
        "name": "The Harmoniscope",
        "url": "http://www.harmoniscope.com",
        "contact_email": "harmoniscope@gmail.com",
        "hometown": "Seattle, WA",
        "description": "The Harmoniscope is a 20' tall mysteriously pulsing 9-sided structure that transports participants to another place in space-time. Inside is an 8-sided column containing a reactor core made up of many colorful spiraling acrylic rods, the light from which gets reflected back to the outside of the building and on to the playa. It requires participants to work together to decipher the mystery of how it works, and why it's here. Participants must decipher an unknown language, illustrated on a Rosetta Stone, using audio/visual cues, a kaleidoscopes and  controls to collectively align the reactor core. Once aligned, they will be rewarded with a dramatic sound and lighting event that energizes it, triggering the journey that will bring them to their next destination.",
        "artist": "The Harmoniscope Project",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "9:05 900', Open Playa",
            "hour": 9,
            "minute": 5,
            "distance": 900,
            "category": "Open Playa",
            "gps_latitude": 40.788213815699,
            "gps_longitude": -119.208703193541
        },
        "location_string": "9:05 900', Open Playa",
        "images": [
            {
                "gallery_ref": 82825,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82825_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbNcEAI",
        "year": 2016,
        "name": "The Koi Pond",
        "url": "http://burningkoi.com",
        "contact_email": "thekoipond2016@gmail.com",
        "hometown": "San Francisco, CA",
        "description": "The Koi Pond is a large-scale interactive installation which immerses participants in the serene setting of a Japanese garden with a high-tech twist.",
        "artist": "JoeJoe Martin",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://www.tilt.com/tilts/the-koi-pond",
        "location": {
            "string": "12:45 2300', Open Playa",
            "hour": 12,
            "minute": 45,
            "distance": 2300,
            "category": "Open Playa",
            "gps_latitude": 40.788820201988,
            "gps_longitude": -119.198821161707
        },
        "location_string": "12:45 2300', Open Playa",
        "images": [
            {
                "gallery_ref": 83250,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83250_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbNcEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbOVEAY",
        "year": 2016,
        "name": "Dust City Diner",
        "url": "http://www.dustcitydiner.com",
        "contact_email": "kinematicslab@gmail.com",
        "hometown": "Oakland, CA",
        "description": "The neon sign of the Dust City Diner beckons visitors to have a seat at its horseshoe-shaped counter. A classic coffee urn brews fresh coffee while a short order cook works the griddle, his silhouette framed by a stainless steel backsplash. Bee-hived waitresses serve up grilled cheese sandwiches and 'top off' your coffee with a bit of sass.  Every aspect of the diner – the sound of dishes clinking, the 1940's music, a flickering neon sign are designed to embody the all-night diner experience.\r\nThe Dust City Diner is moved to a different location in deep playa each evening.",
        "artist": "David Cole and Michael Brown",
        "category": "Mobile",
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "Mobile",
            "hour": null,
            "minute": null,
            "distance": null,
            "category": "Mobile",
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": "Mobile",
        "images": [
            {
                "gallery_ref": 82833,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82833_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbOVEAY.mp3"
    },
    {
        "uid": "a2Id0000000cbNzEAI",
        "year": 2016,
        "name": "Incendio e Illuminato",
        "url": "http://incendioart.org/",
        "contact_email": "info@incendioart.org",
        "hometown": "Washington, DC",
        "description": "Incendio e Illuminato is a Renaissance-inspired interactive fire garden with a reflecting pool that mirrors the sky by day and dancing flames by night. The garden is adorned with sculptures and ornate flowers that represent the principles by which humans may ascend the spiritual path to enlightenment. The geometry and symbology of the garden is based on the Kabbalah Tree of Life.\r\n\r\nRising from within the pool are larger than life flowers that represent beauty/sun, foundation/moon, and death. The flowers are brightly colored during the day and at night are transformed by fire effects. Buttons are located along the pedestals and benches to allow participants to change the strength and patterns of the flames within the pool and surrounding sculptures.",
        "artist": "Incendio Art",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.indiegogo.com/projects/incendio-e-illuminato-fire-sculpture-art-garden#/",
        "location": {
            "string": "3:45 900', Open Playa",
            "hour": 3,
            "minute": 45,
            "distance": 900,
            "category": "Open Playa",
            "gps_latitude": 40.784125019599,
            "gps_longitude": -119.205249121659
        },
        "location_string": "3:45 900', Open Playa",
        "images": [
            {
                "gallery_ref": 82478,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82478_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbPOEAY",
        "year": 2016,
        "name": "Mechan 9",
        "url": "http://www.tylerfuquacreations.com/mechan-9.html",
        "contact_email": "tyfu@me.com",
        "hometown": "Eagle Creek, OR",
        "description": "Half-buried in the dust and covered in hundreds of years worth of rust, Mechan 9 is a giant fallen robot.  It looks like it's centuries old, yet there is something very futuristic about it as well.  Sprawled out and damaged, the giant metal creature is covered in mysterious text and secret hatches.  \r\nBut where did it come from, what was it doing here, and who built it?  The answers lie in the text.  One must decipher it to reveal the answers to unlock the mystery.",
        "artist": "Tyler Fuqua of tyler fuQua creations",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "7:15 1600', Open Playa",
            "hour": 7,
            "minute": 15,
            "distance": 1600,
            "category": "Open Playa",
            "gps_latitude": 40.78582020329,
            "gps_longitude": -119.212235122289
        },
        "location_string": "7:15 1600', Open Playa",
        "images": [
            {
                "gallery_ref": 82835,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82835_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbPOEAY.mp3"
    },
    {
        "uid": "a2Id0000000cbOpEAI",
        "year": 2016,
        "name": "Adventure Vending Machine",
        "url": "http://lamearts.org",
        "contact_email": "info@lamearts.org",
        "hometown": "Oakland, CA",
        "description": "Can Burners be brave and redefine radical participation? LAME Arts, a Bay Area art collective, is creating an Adventure Vending machine that dispenses adventures created by you! Push a button: go on a community-created adventure, receive a special token, and return to unlock a community-created gift!\r\nThe Adventure Vending Machine will be in the 9 o'clock side campanile at the Man Pavilion. Use it to find the next great thing to do at Burning Man!",
        "artist": "LAME Arts",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://www.indiegogo.com/projects/adventure-vending-machine-burning-man-2016/x/14379216#/",
        "location": {
            "string": "10:30 175', Man Pavilion",
            "hour": 10,
            "minute": 30,
            "distance": 175,
            "category": "Man Pavilion",
            "gps_latitude": 40.786879160601,
            "gps_longitude": -119.20650114129
        },
        "location_string": "10:30 175', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82994,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82994_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbOpEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbS3EAI",
        "year": 2016,
        "name": "Medusa Madness",
        "url": null,
        "contact_email": "medusa@rearedinsteel.com",
        "hometown": "Petaluma, CA",
        "description": "Medusa Madness\r\nDare to stare and be mesmerized",
        "artist": "Reared In Steel, LLC",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "8:25 1340', Open Playa",
            "hour": 8,
            "minute": 25,
            "distance": 1340,
            "category": "Open Playa",
            "gps_latitude": 40.788088207222,
            "gps_longitude": -119.210802425251
        },
        "location_string": "8:25 1340', Open Playa",
        "images": [
            {
                "gallery_ref": 82386,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82386_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbS3EAI.mp3"
    },
    {
        "uid": "a2Id0000000cbPoEAI",
        "year": 2016,
        "name": "Identity Reorganization Portal",
        "url": "https://www.indiegogo.com/projects/identity-reorganization-portal--2#/",
        "contact_email": "miko111@comcast.net",
        "hometown": "Santa Cruz, CA",
        "description": "Identity Reorganization Portal is a steel gazebo-like structure. The portal's footprint  is narrow and circular with a diameter of 48\". Its total height is 11'. The entire structure, covered with thousands of small irregularly-cut mirrors, shines from a distance. Unable to avoid shiny objects, myriads of Black Rock citizens will be drawn closer only to find their own reflections scattered, reorganized and blended with the reflection of others nearby. This installation endeavors to raise important questions in the group mind about the nature of Identity. Passing through the center of the portal reveals one's reflection now compressed by the inner concave nature of these mirrored walls. Two lighted buttons inside the portal activate a random set of verbal instructions for successful identity reorganization.\r\nIdentity Reorganization Portal is designed to be a gauntlet thrown down before the apparent solidity of the assumed \"I\".",
        "artist": "Michael Emery",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://www.indiegogo.com/projects/identity-reorganization-portal--2#/",
        "location": {
            "string": "11:55 1700', Open Playa",
            "hour": 11,
            "minute": 55,
            "distance": 1700,
            "category": "Open Playa",
            "gps_latitude": 40.789837403971,
            "gps_longitude": -119.20235465929
        },
        "location_string": "11:55 1700', Open Playa",
        "images": [
            {
                "gallery_ref": 82839,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82839_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbPoEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbP5EAI",
        "year": 2016,
        "name": "Octavius",
        "url": null,
        "contact_email": "peter@peterhazel.com",
        "hometown": "Verdi, NV",
        "description": "Octavius is a giant octopus covered in a bright mosaic of hand-cut ceramic tiles in shades of orange, blue, and purple. The eyes and suckers are molded glass, and glow with the light of hundreds of LED bulbs, symbolizing enlightenment from within. Representative of the octopus spirit, Octavius inspires the participant to adapt fluidly to new or uncertain circumstances and explore deeper emotions. He also invites participants to open their hearts to the natural wonders of the world, deciphering complex puzzles and thus finding answers that may have seemed difficult or impossible at first.",
        "artist": "Peter Hazel Mosaic",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "6:30 1100', Open Playa",
            "hour": 6,
            "minute": 30,
            "distance": 1100,
            "category": "Open Playa",
            "gps_latitude": 40.784889311647,
            "gps_longitude": -119.20994129628
        },
        "location_string": "6:30 1100', Open Playa",
        "images": [
            {
                "gallery_ref": 82845,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82845_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbP5EAI.mp3"
    },
    {
        "uid": "a2Id0000000cbPdEAI",
        "year": 2016,
        "name": "Awakening",
        "url": null,
        "contact_email": "ryan@reengineering.co",
        "hometown": "Denver, CO",
        "description": "Awakening is a large scale interactive steel sculpture of a human head and two hands emerging from the ground.  The head and hands are 20ft tall and the hands are placed an \"arms\" length away from the head with palms facing inward, as if the giant being is looking at its hands for the first time.\r\nThe interior of the head is a darkened room that participants can enter and serves as a theater for viewing the outside world through the eyes of the head, as well as a control room for movement of the hands.  Using optical lenses in the eyes, the head is a stereoscopic camera obscura that focuses light from the outside and projects an image onto the back surface of the room. Participants are given 3D glasses to give the image depth with the perspective of a giant being.  The field of vision of the projected image is nearly 180 degrees vertically and horizontally, which gives the viewer a sense of immersion.  Each eye has a high-intensity spotlight to illuminate objects in its view at night.",
        "artist": "Ryan Elmendorf and Nick Geurts",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": "https://www.kickstarter.com/projects/262424680/awakening-at-burning-man-2016",
        "location": {
            "string": "12:30 3200', Open Playa",
            "hour": 12,
            "minute": 30,
            "distance": 3200,
            "category": "Open Playa",
            "gps_latitude": 40.79079414842,
            "gps_longitude": -119.196488066047
        },
        "location_string": "12:30 3200', Open Playa",
        "images": [
            {
                "gallery_ref": 82841,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82841_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbPdEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbSrEAI",
        "year": 2016,
        "name": "Shrumen Lumen",
        "url": null,
        "contact_email": "jimmychion@gmail.com",
        "hometown": "San Francisco, CA",
        "description": "Shrumen Lumen is a garden of oversized mushrooms, made of folded geometry that allows their bodies to undulate in various patterns. Building off a similar aesthetic and folding strategy as Blumen Lumen, a garden of flowers on the Playa in 2014, the new garden aims to have a more significant kinetic movement and improved lighting. People will be able to interact with the mushrooms and affect how they move simply by being present in the sculpture garden. At night, the flowers light up internally and will react to the sounds around them.",
        "artist": "Foldhaus Artist Collective",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "10:16 1550', Open Playa",
            "hour": 10,
            "minute": 16,
            "distance": 1550,
            "category": "Open Playa",
            "gps_latitude": 40.790611424987,
            "gps_longitude": -119.207193181719
        },
        "location_string": "10:16 1550', Open Playa",
        "images": [
            {
                "gallery_ref": 82850,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82850_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbSrEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbSSEAY",
        "year": 2016,
        "name": "Firmament",
        "url": "http://pbase.com/schardt/firmament",
        "contact_email": "firmament2016@schardt.org",
        "hometown": "Oakland, CA",
        "description": "A vast, overhead canopy of LEDs displays celestial, playful, psychedelic, majestic images while classical music emotionally supports an enveloping, comforting, communal environment below.",
        "artist": "Christopher Schardt",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "11:15 1700', Open Playa",
            "hour": 11,
            "minute": 15,
            "distance": 1700,
            "category": "Open Playa",
            "gps_latitude": 40.790703573497,
            "gps_longitude": -119.204157482666
        },
        "location_string": "11:15 1700', Open Playa",
        "images": [
            {
                "gallery_ref": 82851,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82851_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbSSEAY.mp3"
    },
    {
        "uid": "a2Id0000000cbSDEAY",
        "year": 2016,
        "name": "Enunciation",
        "url": "http://www.taylordeanharrison.com/enunciation/",
        "contact_email": "me@taylordeanharrison.com",
        "hometown": "Oakland, CA",
        "description": "Enunciation is a cocoon of playable light. The piece creates space for participants to interact with the sculpture and each other. It contains many layers of interaction: viewing from afar, entering, playing the light field, and finally, using the light field as an instrument. The structure is made of triangular boxes of metal. On the interior-facing side, each box is outfitted with a laser cut back lit panel. The lights take input from simple buttons mounted in the center of various panels. With input, the panel alters the lighting scheme. Each press spreads effects and color across the surrounding panels, allowing for interplay between participants. Enunciation is a meditation on learning how to articulate oneself. The sculpture's primary function is to create an instrument for shared interaction, which offers more articulation with increased input of people and their time. Enunciation offers a strange way to communicate, but with practice, much can be articulated without speaking.",
        "artist": "Taylor Dean Harrison",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://www.kickstarter.com/projects/enunciation/enunciation-burning-man-2016-honorarium-project",
        "location": {
            "string": "11:22 3200', Open Playa",
            "hour": 11,
            "minute": 22,
            "distance": 3200,
            "category": "Open Playa",
            "gps_latitude": 40.794281864606,
            "gps_longitude": -119.201445295803
        },
        "location_string": "11:22 3200', Open Playa",
        "images": [
            {
                "gallery_ref": 83017,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83017_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbSDEAY.mp3"
    },
    {
        "uid": "a2Id0000000cbShEAI",
        "year": 2016,
        "name": "TRASPARENZA",
        "url": null,
        "contact_email": "andrea@luminem.co.uk",
        "hometown": "London, United Kingdom",
        "description": "TRASPARENZA, Temple of Transparency, celebrates emerging from darkness into light. It is an experiential installation that takes a chapel-like form, that Burners can enter and enjoy both inside and out. It is a playful and whimsical tribute to the genius of Leonardo da Vinci and the glories of the Italian Renaissance, a Florentine Folly. The structure is totally transparent, made of clear cast acrylic panels exquisitely laser-cut with intricate imagery. The words 'Saper Vedere', meaning 'knowing how to see', line the entrance. This was the phrase Leonardo used to describe the dominant skill of his own genius and the transparent installation plays with this notion.TRASPARENZA is a humanist chapel celebrating human endeavour and creativity, and the artist as inventor, where Burners form a colourful congregation visible to everyone outside. At its heart stands a completely see-through sculpture, \"Vitruvia\", that explores the concept of 'Divina Proportione' using the body of a woman rather than a man.",
        "artist": "Andrea Greenlees",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "7:59 1650', Open Playa",
            "hour": 7,
            "minute": 59,
            "distance": 1650,
            "category": "Open Playa",
            "gps_latitude": 40.787523134679,
            "gps_longitude": -119.21227958206
        },
        "location_string": "7:59 1650', Open Playa",
        "images": [
            {
                "gallery_ref": 82849,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82849_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbT1EAI",
        "year": 2016,
        "name": "RotoFuego",
        "url": null,
        "contact_email": "rotofuego@leoobren.net",
        "hometown": "Oakland, CA",
        "description": "RotoFuego is a retro-future exploration of the art of sculpting in fire.  Participants create and manipulate a fire tornado.   The tornado is spun up by a fan that is mechanically driven by a stationary bicycle. Interaction transforms an ordinary propane fire into a sculpture made of fire. Participants breathe life into the fire vortex by pedaling the bike-fan. Participants can shape the vortex, alter its rotation, width, height and intensity by varying their pedaling speed and adding bursts of propane via a handlebar mounted \"booster\" button.  RotoFuego will also serve as a gathering spot on cold playa nights -- a place for comfort and conversation, an opportunity to rest, warm up and make new friends.  The fire will be surrounded by benches for folks to sit upon and interact with one another and enjoy the flaming beauty their fellow participants create.",
        "artist": "Leo O'Brien and the Lumen Crew",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "11:05 2050', Open Playa",
            "hour": 11,
            "minute": 5,
            "distance": 2050,
            "category": "Open Playa",
            "gps_latitude": 40.791756259013,
            "gps_longitude": -119.204283332314
        },
        "location_string": "11:05 2050', Open Playa",
        "images": [
            {
                "gallery_ref": 82852,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82852_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbT1EAI.mp3"
    },
    {
        "uid": "a2Id0000000cbTGEAY",
        "year": 2016,
        "name": "Fire Flower",
        "url": null,
        "contact_email": null,
        "hometown": "Austin, TX",
        "description": "A strange bloom rises towering from the playa, luminescent and wild. The petals glow with ever shifting light and fire jets from the pistil and stamens. The flower draws in the passerby, and interacts with them via showy patterns and colors, aching for cross pollination.",
        "artist": "Matt DeVay",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "5:12 1500', Open Playa",
            "hour": 5,
            "minute": 12,
            "distance": 1500,
            "category": "Open Playa",
            "gps_latitude": 40.78256302986,
            "gps_longitude": -119.208434689347
        },
        "location_string": "5:12 1500', Open Playa",
        "images": [
            {
                "gallery_ref": 82854,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82854_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbTqEAI",
        "year": 2016,
        "name": "Pulse",
        "url": "http://flaminglotus.com/pulse/",
        "contact_email": "info@flaminglotus.com",
        "hometown": "San Francisco, CA",
        "description": "Taking inspiration from Leonardo Da Vinci's anatomy sketches, Pulse is a 12' tall sculptural interpretation of the human heart with blood of fire and veins of steel! The steel structure is formed by the intricate vasculature and predominant veins and arteries of the heart. Emanating from within the heart is a dazzling demonstration of heat, light, and sound that, using biosensors, synchronizes with the participant's own heartbeat. \r\n\r\nPulse is about passion, persistence, life, and connectivity. Like Black Rock City itself, Pulse is a demonstration of what is possible when hearts are in sync!",
        "artist": "Flaming Lotus Girls",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "3:00 3200', Plaza",
            "hour": 3,
            "minute": 0,
            "distance": 3200,
            "category": "Plaza",
            "gps_latitude": 40.780215359205,
            "gps_longitude": -119.198303317885
        },
        "location_string": "3:00 3200', Plaza",
        "images": [
            {
                "gallery_ref": 82779,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82779_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbRLEAY",
        "year": 2016,
        "name": "Equal and Opposite",
        "url": null,
        "contact_email": null,
        "hometown": "Los Angeles, CA",
        "description": "Equal and Opposite is a lit sculpture that invites participants to consider a concept of Newton's third law (equal and opposite) through the form of a mobius strip. Two sides of the strip (opposites) come together in one continuous \"line\", the mobius strip.",
        "artist": "Kerri Fernsworth",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "2:55 2040', Open Playa",
            "hour": 2,
            "minute": 55,
            "distance": 2040,
            "category": "Open Playa",
            "gps_latitude": 40.782633692531,
            "gps_longitude": -119.201052282744
        },
        "location_string": "2:55 2040', Open Playa",
        "images": [
            {
                "gallery_ref": 82859,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82859_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbWQEAY",
        "year": 2016,
        "name": "Observer at Point X",
        "url": "http://soniayuditskaya.tumblr.com/search/Observer+at+point+X",
        "contact_email": "hello@publicworksdepartment.co",
        "hometown": "New York, NY",
        "description": "Observer at Point X is a sacred space & exploration of renaissance era optics used for divnatory/astronomical, photographic, & scientific/alchemical purposes. Participants draw the scenes from the camera obscuras, contemplate with the magic mirror & play with optics in the workspace/observatory.",
        "artist": "Soviet Bloc",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://igg.me/at/observerAtPtX",
        "location": {
            "string": "1:00 1600', Open Playa",
            "hour": 1,
            "minute": 0,
            "distance": 1600,
            "category": "Open Playa",
            "gps_latitude": 40.7875413562,
            "gps_longitude": -119.200913724333
        },
        "location_string": "1:00 1600', Open Playa",
        "images": [
            {
                "gallery_ref": 82315,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82315_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbWeEAI",
        "year": 2016,
        "name": "Piazza di Ferro",
        "url": "http://www.ironmonkeyarts.org/piazza-di-ferro.html",
        "contact_email": "info@ironmonkeyarts.org",
        "hometown": "Seattle, WA",
        "description": "This year the Iron Monkeys will pay homage to our craft by building a functional, participatory blacksmith shop on playa. Encircling the shop will be a public gathering space, encouraging the community to observe, discuss, and contribute to what is happening in the shop.",
        "artist": "Iron Monkey Arts",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://www.indiegogo.com/projects/piazza-di-ferro-at-burning-man-2016#/",
        "location": {
            "string": "3:15 1500', Open Playa",
            "hour": 3,
            "minute": 15,
            "distance": 1500,
            "category": "Open Playa",
            "gps_latitude": 40.783146087407,
            "gps_longitude": -119.203190231194
        },
        "location_string": "3:15 1500', Open Playa",
        "images": [
            {
                "gallery_ref": 82913,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82913_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbWeEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbV7EAI",
        "year": 2016,
        "name": "HYBYCOZO - Heart of Gold",
        "url": "http://www.hybycozo.com",
        "contact_email": "hybycozo@gmail.com",
        "hometown": "San Francisco, CA",
        "description": "Sculpture 1- The Improbability Drive will consist of an all-pipe skeletal frame connecting into a mirrored hypercube shape made of mirror. The inside shape, a rhombic dodecahedron, has an optical illusion that looks like 3 different shapes in 3 different perspectives. The mirror shape on the inside will reflect the outside edges, creating a 4D dimensional hypercube effect. \r\nSculpture 2- The Heart of Gold - will consist of a skeletal frame of a rhombic triactohedron and from its top-most point will hang a super intricate laser cut HYBYCOZO sculpture that will cast shadows far into the playa. This outer skeletal shape is the most complex shape that DaVinci drew and will form a super fun dome-like jungle gym.\r\nSculpture 3- Hyperspace Bypass- A stacked set of 11 HYBYCOZO rhombic dodecahedrons shapes set on top of each other tessellating perfectly in 3D space. Its form is reminiscent of an iceberg or a 4D pyramid. In the day it will looking like a gleaming gold multifactored pyramid.",
        "artist": "HYBYCOZO",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "11:15 2700', Open Playa",
            "hour": 11,
            "minute": 15,
            "distance": 2700,
            "category": "Open Playa",
            "gps_latitude": 40.793235065188,
            "gps_longitude": -119.202779389446
        },
        "location_string": "11:15 2700', Open Playa",
        "images": [
            {
                "gallery_ref": 83302,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83302_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbV7EAI.mp3"
    },
    {
        "uid": "a2Id0000000cbWpEAI",
        "year": 2016,
        "name": "Chiminea Planetaria",
        "url": "http://www.arkanearts.com",
        "contact_email": "contact@arkanearts.com",
        "hometown": "Tucson, AZ",
        "description": "A cluster of fiery hearths to warm up your nights! \"Chiminea Planetaria\" is inspired by the solar system as it was known in the time of Leonardo da Vinci. The traditional alchemical signs, names and attributes of each planet are cut into large steel spheres, transforming them into functional burn barrels. Burners feed the fires with wood from the \"Sun\" at the center of the system. As more participants join in to feed the \"Planets\" the fires shall burn brighter! During daylight hours, the decorated spheres become strange black globes on the stark white playa, a sculptural solar system landmark.",
        "artist": "Spencer Edgerton and Arkane Arts",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "9:00 3200', Plaza",
            "hour": 9,
            "minute": 0,
            "distance": 3200,
            "category": "Plaza",
            "gps_latitude": 40.792584060713,
            "gps_longitude": -119.214698208878
        },
        "location_string": "9:00 3200', Plaza",
        "images": [
            {
                "gallery_ref": 82968,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82968_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbWpEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbVlEAI",
        "year": 2016,
        "name": "Grove",
        "url": "https://cambridge.nuvustudio.com/studios/grove#tab-proposal",
        "contact_email": "pulseandbloom@gmail.com",
        "hometown": "Boston, USA & Bangalore, India",
        "description": "Visualized as a grove of beautiful low hanging trees, Grove is an interactive art installation that uses breath sensors to create a meditative and immersive experience. A reflection on the interdependence of breath, Grove uses biofeedback sensors, connecting our inner workings with tangible art installations. \r\n\r\nGrove brings together artists from India with neurotechnologists and architects from America, making it a truly global collaboration. Grove is a meditation on the interdependence of breath. Every time we breathe in, we inhale the 'out breath' of a tree around us, placing ourselves in a constant state of union between the macro-forest outside, and the micro-forest of alveoli within our lungs. \r\n\r\nGrove uses technology related to the quantified self, to break down the idea of self entirely and to remind us that we are all interconnected, through breath, to every living creature on this planet; from the leaves on trees to the sand of the desert.",
        "artist": "Grove",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "3:15 1100', Open Playa",
            "hour": 3,
            "minute": 15,
            "distance": 1100,
            "category": "Open Playa",
            "gps_latitude": 40.784013806678,
            "gps_longitude": -119.204072804498
        },
        "location_string": "3:15 1100', Open Playa",
        "images": [
            {
                "gallery_ref": 82376,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82376_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbVlEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbYGEAY",
        "year": 2016,
        "name": "The Dusty Supper",
        "url": null,
        "contact_email": "joyce.jamiel@gmail.com",
        "hometown": "Orlando, FL",
        "description": "A Burner version of Leonardo Da Vinci's Last Supper, the Dusty Supper is not just for the Burnier-Than-Thou's, but for all apostle-tively amazing Burners to celebrate the simultaneous divinity, mortality, and variety of the human experience.",
        "artist": "Jamie, Lidia, and Bree",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "1:17 1999', Open Playa",
            "hour": 1,
            "minute": 17,
            "distance": 1999,
            "category": "Open Playa",
            "gps_latitude": 40.787029189266,
            "gps_longitude": -119.199318949273
        },
        "location_string": "1:17 1999', Open Playa",
        "images": [
            {
                "gallery_ref": 82914,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82914_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbYGEAY.mp3"
    },
    {
        "uid": "a2Id0000000cbXIEAY",
        "year": 2016,
        "name": "Fantasy Dimension",
        "url": "http://www.fantasydimension.com/",
        "contact_email": "designer@fantasydimension.com",
        "hometown": "Reno, NV",
        "description": "Fantasy Dimension is to be assembled by a team of international artists who are contributing their time and energy to the single largest art project in the history of Burning Man -- and the most transparently created. Fantasy Dimension will encompass the Temple and the Man Base, and be so large it will take two days (and nights) to burn. Seed money for this project is provided by a non-U.S. business professional who does not wish to be named.\r\nFantasy Dimension will encompass design elements of the pyramids of Giza, Angkor Wat, and the Taj Mahal. It  uses locally sourced materials, and artist labor will be pulled from the eight continents of the world and Greater Northern Nevada.",
        "artist": "Frieda Gludten",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:20 6000', Open Playa",
            "hour": 12,
            "minute": 20,
            "distance": 6000,
            "category": "Open Playa",
            "gps_latitude": 40.795845830858,
            "gps_longitude": -119.188746260366
        },
        "location_string": "12:20 6000', Open Playa",
        "images": [
            {
                "gallery_ref": 82934,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82934_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbXNEAY",
        "year": 2016,
        "name": "Reactor",
        "url": "http://www.ryanlongo.ca",
        "contact_email": "ryanlongo@gmail.com",
        "hometown": "Toronto O.N., Canada",
        "description": "Reactor displays the contrast between nature and the industrial world. A natural shape from an alien environment, this sculpture  symbolizes growth and life in a harsh uncharted world. Its twisting limbs and futuristic paint job fires up the viewers imagination to wonder what is possible with material and shape.",
        "artist": "Ryan Longo",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "2:55 1700', Open Playa",
            "hour": 2,
            "minute": 55,
            "distance": 1700,
            "category": "Open Playa",
            "gps_latitude": 40.783261428233,
            "gps_longitude": -119.201960192713
        },
        "location_string": "2:55 1700', Open Playa",
        "images": [
            {
                "gallery_ref": 82915,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82915_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbYpEAI",
        "year": 2016,
        "name": "Sharky-Go-Round/Ghost Shark",
        "url": null,
        "contact_email": "kirk@freedom-forge.com",
        "hometown": "Santa Cruz, CA and Aachen, Germany",
        "description": "Art is a not a mirror held up to reality, but a hammer with which to shape it.\r\nBerthold Brecht\r\n This concept drives my creative process.\r\nThe goal of this piece is to raise the awareness of the human population to the devastation being wrought by our species on the oceans, which give life to our planet. \r\nThe piece will rotate on a central bearing when it is actuated by human interaction. A gentle push will cause the rotation  to simulate the movement of a school of sharks, swimming lazily in a rising spiral current. My goal is to underline the contrast of the beauty of schooling sharks in their ocean community, and the wasteful horror of shark finning by the human community.\r\nFrom a distance, the low profile of the turntable will show the school, to draw the playa community closer until the view is of the small cloud of sharks from below. Here will be placed the Ghost Shark on its back, as if lying finned and dead on the bottom in stark contrast to the live animals swimming above.",
        "artist": "Kirk McNeill / Ocean Awareness Group / Santa Cruz Shark Shaggas",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": "https://www.indiegogo.com/projects/sharky-go-round-ghost-shark--4#/",
        "location": {
            "string": "3:08 1900', Open Playa",
            "hour": 3,
            "minute": 8,
            "distance": 1900,
            "category": "Open Playa",
            "gps_latitude": 40.782479829972,
            "gps_longitude": -119.201983188379
        },
        "location_string": "3:08 1900', Open Playa",
        "images": [
            {
                "gallery_ref": 82403,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82403_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbYpEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbWqEAI",
        "year": 2016,
        "name": "Ascension",
        "url": "http://www.jrich.io",
        "contact_email": "jeremyshrichardson@gmail.com",
        "hometown": "San Francisco, CA",
        "description": "Ascension is a reflection of one person's journey of self-discovery pertaining to love. For many, the concept of being \"in love\" is defined by default society. Romantic plots in pop culture so often have characters falling in love uncontrollably to finally find \"happiness\". Society teaches us that the responsibility of our happiness lies on the shoulders of others. We spend so much time looking for happiness - love - everywhere but the one place we'll find it: within ourselves.\r\nAscension conveys a new definition of love: when separate, whole individuals form a partnership that reinforces their individuality while creating a unit where the whole is greater than the sum of its parts. Each person is growing as a whole individual first and foremost. The partnership reinforces this while bringing them both to a higher level, together. Through this symbolism, Ascension creates a space that inspires people to reflect on self love, loving others, and love as it relates to their world at large.",
        "artist": "Jeremy Richardson",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "8:50 1400', Open Playa",
            "hour": 8,
            "minute": 50,
            "distance": 1400,
            "category": "Open Playa",
            "gps_latitude": 40.788858627213,
            "gps_longitude": -119.210384327366
        },
        "location_string": "8:50 1400', Open Playa",
        "images": [
            {
                "gallery_ref": 82973,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82973_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000clb0EAA",
        "year": 2016,
        "name": "Soup Flavored Blankets",
        "url": "http://www.facebook.com/soupflavoredblankets",
        "contact_email": "soupflavoredblankets@gmail.com",
        "hometown": "Los Angeles, CA",
        "description": "Soup Flavored Blankets (SFB) is a giant soup can and cracker box located in the deep playa. SFB is designed to warm the wandering cold souls of deep playa in the wee hours of night before the scare ball arises from the horizon. Come share a joke or a talent, write in our book, and receive some hot action from Soup Flavored Blankets!",
        "artist": "Austin Blank and the Soup Flavored Blankettes",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:05 6550', Open Playa",
            "hour": 12,
            "minute": 5,
            "distance": 6550,
            "category": "Open Playa",
            "gps_latitude": 40.798538768572,
            "gps_longitude": -119.189062092889
        },
        "location_string": "12:05 6550', Open Playa",
        "images": [
            {
                "gallery_ref": 82877,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82877_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000clbtEAA",
        "year": 2016,
        "name": "The Portal",
        "url": "https://www.flickr.com/photos/92288254@N04/",
        "contact_email": null,
        "hometown": "Tacoma, WA",
        "description": "Portal appears as a twelve foot ring growing from the Playa.  Its outer casement is translucent fiberglass treated to appear organic.  Inside are many lights running a continuous and varying animation.  Sensors detect when Participants pass through Portal and then create a light show response.  Maybe a Participant will pass into another dimension.",
        "artist": "LaBerge/Prismaticamp",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:45 2820', Open Playa",
            "hour": 12,
            "minute": 45,
            "distance": 2820,
            "category": "Open Playa",
            "gps_latitude": 40.789367307538,
            "gps_longitude": -119.197084998952
        },
        "location_string": "12:45 2820', Open Playa",
        "images": [
            {
                "gallery_ref": 82929,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82929_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000ckwiEAA",
        "year": 2016,
        "name": "Sonic Runway",
        "url": "http://www.sonicrunway.net/",
        "contact_email": "sonicrunway@gmail.com",
        "hometown": "Berkeley, CA",
        "description": "Imagine sound speeding across the desert as light.\r\nThe Sonic Runway is a 1000 ft corridor of lights that visualizes the speed of sound.  Participants, especially sound art cars, are encouraged to play music or make other sounds at one end.  This triggers colorful patterns of light that ripple down the corridor.  Participants at the far end of the runway will see the sound coming at them before they hear it.  No matter where you stand, the lights and the sound will be in sync.\r\nThe first Sonic Runway was installed at Burning Man as part of Sol System in '03/'04.  16 years later, the new Runway takes the same basic concept but with an all new design, greater interactivity, and more intricate visualizations.",
        "artist": "Rob Jensen / Sonic Runway Team",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.indiegogo.com/projects/sonic-runway-burning-man-2016/x/7136542#/",
        "location": {
            "string": "11:30 4400', Open Playa",
            "hour": 11,
            "minute": 30,
            "distance": 4400,
            "category": "Open Playa",
            "gps_latitude": 40.79684400376,
            "gps_longitude": -119.198567805429
        },
        "location_string": "11:30 4400', Open Playa",
        "images": [
            {
                "gallery_ref": 83476,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83476_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000ckHiEAI",
        "year": 2016,
        "name": "Stands of Chime",
        "url": "http://",
        "contact_email": null,
        "hometown": "Pomona, CA",
        "description": "Stands of Chime has the look of a pagoda. As you approach it you see a simple four sided hut constructed of steel. It stands 9' at the peak of its roof and is about 12' wide. What you notice first is that the walls are made of large suspended steel chimes. They are 12\" in diameter and up to 4' long.  With a simple breeze, the pagoda comes to life as an enormous wind chime . As you enter into this amazing pagoda of tones you can take a seat in the epicenter of sound. There is a canopy to shade you from the sun.",
        "artist": "Mike Miller",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "6:45 2300', Open Playa",
            "hour": 6,
            "minute": 45,
            "distance": 2300,
            "category": "Open Playa",
            "gps_latitude": 40.783979289042,
            "gps_longitude": -119.214178278566
        },
        "location_string": "6:45 2300', Open Playa",
        "images": [
            {
                "gallery_ref": 82890,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82890_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000ckANEAY",
        "year": 2016,
        "name": "Identity Awareness Union",
        "url": "http://",
        "contact_email": "shane_pitzer@hotmail.com",
        "hometown": "Sammamish, WA",
        "description": "A 13' tall steel question mark  at a 10 degree slant and  is held up by a 7' human form. A female form  embraces the human form.  The idea is to evoke the question of how relationships and others affect our identity. I would like to expand on the lighting from last year and use kinetics to be more interactive with people.",
        "artist": "Shane M. Pitzer",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "8:00 2250', Open Playa",
            "hour": 8,
            "minute": 0,
            "distance": 2250,
            "category": "Open Playa",
            "gps_latitude": 40.787983491562,
            "gps_longitude": -119.21436334827
        },
        "location_string": "8:00 2250', Open Playa",
        "images": [
            {
                "gallery_ref": 82940,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82940_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbZOEAY",
        "year": 2016,
        "name": "The Light is Inside You",
        "url": null,
        "contact_email": "yelena@cozo.co",
        "hometown": "San Francisco, CA",
        "description": "Our deepest fear is not that we are inadequate.  Our deepest fear is that we are powerful beyond measure.  It is our light, not our darkness that most frightens us.  We ask ourselves, Who am I to be brilliant, gorgeous, talented, fabulous?  Actually, who are you not to be?  You are a child of God.  Your playing small does not serve the world...  It is not just in some of us; it is in everyone.  And as we let our own light shine, we unconsciously give other people permission to do the same.  As we are liberated from our own fear, our presence automatically liberates others.  ~Marianne Williamson",
        "artist": "Yelena Filipchuk",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "11:15 2500', Open Playa",
            "hour": 11,
            "minute": 15,
            "distance": 2500,
            "category": "Open Playa",
            "gps_latitude": 40.792728768162,
            "gps_longitude": -119.203055016497
        },
        "location_string": "11:15 2500', Open Playa",
        "images": [
            {
                "gallery_ref": 82884,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82884_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000csmxEAA",
        "year": 2016,
        "name": "Flight 513",
        "url": "http://",
        "contact_email": "jxejxe@hotmail.com",
        "hometown": "Stow, MA",
        "description": "Flight 513 consists of nine interconnected wooden posts. Six posts are arranged into a rectangle and are wrapped in black curtains to represent the fusilage of the plane. Gaps in the curtains allow visitors to enter. Four posts hold up the ends of two aluminum poles and translucent plastic sheets representing the wings. Ropes connect the fusilage to the post that represents the tail.",
        "artist": "Joseph Berman",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "11:30 2060', Open Playa",
            "hour": 11,
            "minute": 30,
            "distance": 2060,
            "category": "Open Playa",
            "gps_latitude": 40.791289760289,
            "gps_longitude": -119.202786601383
        },
        "location_string": "11:30 2060', Open Playa",
        "images": [
            {
                "gallery_ref": 83002,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83002_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000clfHEAQ",
        "year": 2016,
        "name": "Clock Brothers",
        "url": "http://",
        "contact_email": "steven.j.doughty@gmail.com",
        "hometown": "Mendocino, CA",
        "description": "The Clock - \r\nA large face stares at you and asks \"How did it get so late so soon.?\"",
        "artist": "Steven Doughty and Dax Herrera",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "8:10 1050', Open Playa",
            "hour": 8,
            "minute": 10,
            "distance": 1050,
            "category": "Open Playa",
            "gps_latitude": 40.787378368389,
            "gps_longitude": -119.210070487642
        },
        "location_string": "8:10 1050', Open Playa",
        "images": [
            {
                "gallery_ref": 82261,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82261_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cwxEEAQ",
        "year": 2016,
        "name": "Bells of Vitruviano",
        "url": null,
        "contact_email": null,
        "hometown": "Berkeley, CA",
        "description": "In keeping with the 2016 Burning Man theme, DaVinci's Workshop, we have designed a set of four bells and ringing mechanisms after a design of Leonardo daVinci. These will be placed in four campaniles around the Man Pavilion to call Burners on the hour to come and rotate the Man, who is modeled after the Vitruvian Man drawing of daVinci.",
        "artist": "Roger Carr",
        "category": null,
        "program": "Pavilion",
        "donation_link": null,
        "location": {
            "string": "4:30 175', Man Pavilion",
            "hour": 4,
            "minute": 30,
            "distance": 175,
            "category": "Man Pavilion",
            "gps_latitude": 40.785920839399,
            "gps_longitude": -119.206498858727
        },
        "location_string": "4:30 175', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82862,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82862_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000culDEAQ",
        "year": 2016,
        "name": "Web of Dreams",
        "url": "https://www.facebook.com/groups/Suspensionofdisbelief/",
        "contact_email": "webofdreams@hotmail.com",
        "hometown": "Seattle, WA",
        "description": "Have you ever wondered what it would be like to climb your Grandmother's doilies? Or to hang in a spider's web? Well, our intrepid Hookers have made that dream come true! Web of Dreams is 120,000 feet of rope, hand crocheted with love and snark, into a climbable playground for all activity levels. This is our biggest set-up yet, come climb with us!",
        "artist": "Kendra Randolph",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "7:20 1850', Open Playa",
            "hour": 7,
            "minute": 20,
            "distance": 1850,
            "category": "Open Playa",
            "gps_latitude": 40.78594922836,
            "gps_longitude": -119.213163547971
        },
        "location_string": "7:20 1850', Open Playa",
        "images": [
            {
                "gallery_ref": 83003,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83003_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cwlKEAQ",
        "year": 2016,
        "name": "Fireball Shooting Gallery",
        "url": "http://",
        "contact_email": null,
        "hometown": "Menlo Park, CA",
        "description": "The Fireball Shooting Gallery has the look and feel of an old-school carnival shooting booth, but with the \"firepower\" and noise that Burners desire. Participants approach the booth and stand behind one of four mounted cannons where they personally load, charge and fire the cannon at a variety of moving and stationary targets. Each person can shoot up to three tennis balls if the line is long, or more if there isn't a wait.",
        "artist": "Al Stahler",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.indiegogo.com/projects/fireball-shooting-gallery-burning-man-2016--3#/",
        "location": {
            "string": "10:48 1800', Open Playa",
            "hour": 10,
            "minute": 48,
            "distance": 1800,
            "category": "Open Playa",
            "gps_latitude": 40.791269216944,
            "gps_longitude": -119.205493243408
        },
        "location_string": "10:48 1800', Open Playa",
        "images": [
            {
                "gallery_ref": 83343,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83343_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cllUEAQ",
        "year": 2016,
        "name": "Electric Lazy Lounge",
        "url": "https://www.facebook.com/Electric-Lazy-Lounge-244842872224072/",
        "contact_email": "mightymike032@hotmail.com",
        "hometown": "Roy, UT",
        "description": "The subjective nature of the human experience is determined by our perception of sensation. The Electric Lazy Lounge creates a subjective and immersive experience through the manipulation of participants' sensation. Light, sound, vibration, scent, and even taste are stimulated and synchronized to create a state of hyper-stimulation. Thereby, altering participants' perception, allowing them to dissociate from their sense of self, and become open to an alternate realm of human experience—LazyLand. No one can effectively describe what LazyLand is like. It must be experienced to be appreciated.\r\nFrom a distance the ELL will appear as a large canopy bed. The back lit colors under the white fabric canopy will shift and dance to music playing for waiting participants. As interested participants get closer they will realize that there is mystery hidden inside this colorful dancing bed. An operator will lead participants to the true magic inside.",
        "artist": "MightyMike the Fluffer King",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "Mobile",
            "hour": null,
            "minute": null,
            "distance": null,
            "category": "Mobile",
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": "Mobile",
        "images": [
            {
                "gallery_ref": 82909,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82909_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbX9EAI",
        "year": 2016,
        "name": "Electric Renaissance (A Tribute to Cadillac Ranch)",
        "url": "http://electric-renaissance.org/",
        "contact_email": "info@electric-renaissance.org",
        "hometown": "Santa Cruz, CA and Aachen, Germany",
        "description": "An homage to Cadillac Ranch.  In 1974 the artists collaborative Ant Farm buried ten Cadillacs in the Texas prairie, leaving only the tail fins visible.  Cadillac Ranch has come to symbolize the demise of the dinosaurs that brought the American automobile industry to the brink of extinction.  The emergence of the nose-section of a zero-emissions vehicle turns the image of Cadillac Ranch on its head.  It suggests that, after a transformational journey through the bowels of earth, the automobile is being reborn as an environmentally-friendly descendant of gas-guzzling ancestors. \r\nhttps://www.instagram.com/electricrenaissance/",
        "artist": "Heliotropics",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://www.indiegogo.com/projects/electric-renaissance-burning-man-2016--2/x/14308970#/",
        "location": {
            "string": "2:18 2100', Open Playa",
            "hour": 2,
            "minute": 18,
            "distance": 2100,
            "category": "Open Playa",
            "gps_latitude": 40.784070558814,
            "gps_longitude": -119.199557053145
        },
        "location_string": "2:18 2100', Open Playa",
        "images": [
            {
                "gallery_ref": 82921,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82921_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbX9EAI.mp3"
    },
    {
        "uid": "a2Id0000000cxDEEAY",
        "year": 2016,
        "name": "El Diabla",
        "url": "http://",
        "contact_email": "fireconclave@burningman.org",
        "hometown": "Reno, NV",
        "description": "On the firest Monday of the event, Crimson Rose extracts a flame from the sun to light a fire in El Diabla, a special cauldron located between Center Camp and Esplanade.  For the flame to continue burning it must be stoked, disturbed and kept alive throughout the entire week.  On Saturday evening, fire is transferred from El Diabla to the Luminferrous and processed to the Great Circle and shared with the Fire Conclave before the Man is released in pyrotechnic delight.",
        "artist": "Fire Conclave",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "6:00 2600', Open Playa",
            "hour": 6,
            "minute": 0,
            "distance": 2600,
            "category": "Open Playa",
            "gps_latitude": 40.781356868701,
            "gps_longitude": -119.213135940832
        },
        "location_string": "6:00 2600', Open Playa",
        "images": [
            {
                "gallery_ref": 82916,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82916_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d1kVEAQ",
        "year": 2016,
        "name": "Guardino Leone",
        "url": null,
        "contact_email": null,
        "hometown": "Petaluma, CA",
        "description": "Lions are representative of protection and therefore our Guardiano Leone is the guardian of the Man.",
        "artist": "Kevin Clark",
        "category": null,
        "program": "Pavilion",
        "donation_link": null,
        "location": {
            "string": "7:30 75', Man Pavilion",
            "hour": 7,
            "minute": 30,
            "distance": 75,
            "category": "Man Pavilion",
            "gps_latitude": 40.786399629345,
            "gps_longitude": -119.206771220374
        },
        "location_string": "7:30 75', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82952,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82952_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cwxdEAA",
        "year": 2016,
        "name": "Hubris",
        "url": null,
        "contact_email": "hubris@attoparsec.com",
        "hometown": "Seattle, WA",
        "description": "Hubris is a kinetic sculpture representing Icarus, re­imagined as the historical figure of Otto Lilienthal. He was an aeronautical pioneer, inventing some of the first real gliders and convincing many for the first time that heavier­-than­-air flight was possible. The data he collected was a direct inspiration to the Wright Brothers. He was eventually killed in one of his experiments.\r\nOn the sides of the plinth is a series of bas relief scenes depicting other figures from modern science and technology as seen through the lens of classical mythology.",
        "artist": "Matthew 'Fish' Dockrey",
        "category": null,
        "program": "Pavilion",
        "donation_link": null,
        "location": {
            "string": "1:30 75', Man Pavilion",
            "hour": 1,
            "minute": 30,
            "distance": 75,
            "category": "Man Pavilion",
            "gps_latitude": 40.78640037002,
            "gps_longitude": -119.206228779623
        },
        "location_string": "1:30 75', Man Pavilion",
        "images": [
            {
                "gallery_ref": 83005,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83005_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000czcYEAQ",
        "year": 2016,
        "name": "The Before... Project",
        "url": "http://",
        "contact_email": null,
        "hometown": "Seattle, WA",
        "description": "The Before... Project inspires Participants to think through what they want to do in life and share these aspirations in a public space. It is comprised of inspirational signs surrounding a cylindrical temple space with glowing white curved fabric exterior walls. A short hallway opens into a round, welcoming, comfortable, carpeted, lit space with beautiful wooden walls, topped with the text \"Before I die, I want to ______\". The walls are covered with writings from Participants finishing that sentence – \"… make up with my parents\", \"… travel to Africa\", \"… help pass an Equal Rights amendment.\" People wander through, being inspired by the thoughts of others, and writing their own thought on the walls. In the center of the room is a table to provide a place to sit and talk and plan.\r\nInspired by the work of Candy Chang, with permission.",
        "artist": "Eric Schurman",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "9:45 1000', Open Playa",
            "hour": 9,
            "minute": 45,
            "distance": 1000,
            "category": "Open Playa",
            "gps_latitude": 40.788927740158,
            "gps_longitude": -119.207889965342
        },
        "location_string": "9:45 1000', Open Playa",
        "images": [
            {
                "gallery_ref": 82880,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82880_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cwxTEAQ",
        "year": 2016,
        "name": "Improba Putti",
        "url": null,
        "contact_email": null,
        "hometown": "San Diego, CA",
        "description": "Improba Putti  is in the style of an Italian Renaissance sculpture with modern elements. She and they will have a look of Patinated Bronze and Copper. It has mythological beings inter-reacting in a playful (or not so playful) way, depicting an innocence during the Renaissance period.\r\nImproba Putti is a female Centaur being pulled by Winged Putti. The bas-reliefs encircling the plinth will be of underground scenes depicting caves, roots, stalactites, as well as a salamander, crayfish, bats and an armadillo.",
        "artist": "Vulfie Munson",
        "category": null,
        "program": "Pavilion",
        "donation_link": null,
        "location": {
            "string": "4:30 75', Man Pavilion",
            "hour": 4,
            "minute": 30,
            "distance": 75,
            "category": "Man Pavilion",
            "gps_latitude": 40.786194645457,
            "gps_longitude": -119.206499510881
        },
        "location_string": "4:30 75', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82948,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82948_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cxHrEAI",
        "year": 2016,
        "name": "Determinazione",
        "url": null,
        "contact_email": null,
        "hometown": "San Rafael, CA",
        "description": "Determinazione is a larger than life depiction of the DPW spirit.  A twelve foot tall woman, dressed in protective, desert attire, pounding a fence stake into the Playa.  She is braced against the wind and dust.\r\nA Coyote gleefully encourages her to persevere against the elements.\r\nShe stands atop a 7' high base, adorned with four bas reliefs, depicting scenes of the Building and Restoration of Black Rock City.",
        "artist": "Steven Lee Burright",
        "category": null,
        "program": "Pavilion",
        "donation_link": null,
        "location": {
            "string": "10:30 75', Man Pavilion",
            "hour": 10,
            "minute": 30,
            "distance": 75,
            "category": "Man Pavilion",
            "gps_latitude": 40.786605354543,
            "gps_longitude": -119.206500489122
        },
        "location_string": "10:30 75', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82964,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82964_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000czb1EAA",
        "year": 2016,
        "name": "Sideways room",
        "url": "http://",
        "contact_email": "qualitywoodandtile@gmail.com",
        "hometown": "Phoenix, AZ",
        "description": "Sideways Room is a cube from the outside with a sideways doorway as the entrance. Inside, the room is designed to give the Participant a feeling of being in a sideways room. The project is meant for the deep playa where the seat facing the sky doubles as a stargazing lounge.",
        "artist": "Camp Savvy",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "11:40 2980', Open Playa",
            "hour": 11,
            "minute": 40,
            "distance": 2980,
            "category": "Open Playa",
            "gps_latitude": 40.793092081949,
            "gps_longitude": -119.200334157874
        },
        "location_string": "11:40 2980', Open Playa",
        "images": [
            {
                "gallery_ref": 82987,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82987_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kYEAQ",
        "year": 2016,
        "name": "Becoming the Master/Mistress of Stones: The Arts of Buon Fresco Revealed",
        "url": null,
        "contact_email": "ritualsart@aol.com",
        "hometown": "Oceanside, CA",
        "description": "Student Artists will learn the various actual old time techniques over several days to create a fresco (block) from scratch to take home. As part of our commitment to up-cycle we will utilize and recycle actual (old foam insulation) building materials. Participants will learn to recreate various historical stone mixtures that compromise the the surfaces of the block, complete with plastering, cartooning, and finally the stages of painting the actual fresco with pigments. This artifact creation will be followed by (and applied) techniques to 'age' their artwork with the patina and craquelure of passing time. The result? A beautiful, yet portable and tangible, aged piece of buon fresco that becomes their momento of inspired learning at Burning Man. ;)",
        "artist": "Gigi Clark & Rituals Art Collective, Three Faced (Stone) Wench Workshop/Guild",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "9:45 140', Man Pavilion",
            "hour": 9,
            "minute": 45,
            "distance": 140,
            "category": "Man Pavilion",
            "gps_latitude": 40.786753884626,
            "gps_longitude": -119.206694588778
        },
        "location_string": "9:45 140', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82907,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82907_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cyEzEAI",
        "year": 2016,
        "name": "A RAT's Nest",
        "url": "http://",
        "contact_email": "tattooedaliens@gmail.com",
        "hometown": "Truckee, CA",
        "description": "You see a mischief of rats in a nest. You assume that they are rats because they look like big ugly mice with beady eyes and long hairless tails. But what if they really aren't rats at all? What if they are actually aliens disguised to look like rats?",
        "artist": "Kathy D'Onofrio",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:00 8000', Open Playa",
            "hour": 12,
            "minute": 0,
            "distance": 8000,
            "category": "Open Playa",
            "gps_latitude": 40.80191494189,
            "gps_longitude": -119.186075397655
        },
        "location_string": "12:00 8000', Open Playa",
        "images": [
            {
                "gallery_ref": 83300,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83300_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2k7EAA",
        "year": 2016,
        "name": "Polimerica sulla Playa",
        "url": "http://",
        "contact_email": "baroness.shirley@gmail.com",
        "hometown": "New York, NY",
        "description": "Sit and create polymer clay pieces! Teachers will show Burners the techniques they need to create their own unique artwork. We expect, and encourage, Burners to interact with their fellow Burners: share techniques or how they've built their project and engage with each other as each person creates something they love.",
        "artist": "Horny Camp",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "11:15 130', Man Pavilion",
            "hour": 11,
            "minute": 15,
            "distance": 130,
            "category": "Man Pavilion",
            "gps_latitude": 40.786729098469,
            "gps_longitude": -119.206320877043
        },
        "location_string": "11:15 130', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82338,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82338_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kfEAA",
        "year": 2016,
        "name": "Rocky Mountain High Flyers Guild",
        "url": "https://artworkbyedvandyne.wordpress.com",
        "contact_email": "ed123455@gmail.com",
        "hometown": "Loveland, CO",
        "description": "We will be making and flying a full scale model of Leonardo da Vinci's flying machine that he designed oh so many years ago.  Leonardo da Vinci designed his wings after dissecting bird wings in order to figure out how they flew.  The Rocky Mountain High Flyers Guild will be making a giant kite with a 30 feet of wing span that will follow da Vinci's drawings as closely as possible.  It will be made of wood and rope, with the wings covered in unbleached cotton.  We will also have parts for over 100 kites with a 5 foot wing span that will be a replica of the big kite for the citizens to make and fly and take home with them.",
        "artist": "Ed VanDyne and the Rocky Mountain High Flyers Guild based in the Loveland CreatorSpace",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "1:15 160', Man Pavilion",
            "hour": 1,
            "minute": 15,
            "distance": 160,
            "category": "Man Pavilion",
            "gps_latitude": 40.786457964055,
            "gps_longitude": -119.205926482264
        },
        "location_string": "1:15 160', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82868,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82868_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kaEAA",
        "year": 2016,
        "name": "The Black Rock Notary",
        "url": "http://",
        "contact_email": "philnyetheplayaguy@gmail.com",
        "hometown": "Saugerties, NY",
        "description": "We are a Notary Guild and an interactive installation. Participants will be invited to caste customized documents with help from our artists, facilitators, and mediators that will then be notarized and \"sealed\". This interactive process will utilize aspects of ritual, ceremony and iconography. Some documents may require participants to create tokens, amulets or henna tattoos with materials we provide. These tangible \"takeaways\" will stand as official records for agreements made at our notary. Notable services such as Pair Bonding and Water Sharing Bonding may involve ceremony invoked through ritual in our inner shrine. Our Guild is composed of skilled and experienced Artists, Healers, Dancers, Singers, and Carpenters who will apply these talents to the many aspects of this project. Custom Notary and Ritual work for more unique social situations/needs will also be a focus. These services can be applied to the individual, pairs and larger groups.",
        "artist": "Philip DePoala, The Notarius Notary Guild",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "4:15 160', Man Pavilion",
            "hour": 4,
            "minute": 15,
            "distance": 160,
            "category": "Man Pavilion",
            "gps_latitude": 40.785965761323,
            "gps_longitude": -119.206423443063
        },
        "location_string": "4:15 160', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82933,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82933_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2k8EAA",
        "year": 2016,
        "name": "Chasing the Pounder \"Repoussé Cafe\"",
        "url": "http://",
        "contact_email": "benardtmanning@gmail.com",
        "hometown": "Alta, UT",
        "description": "Visit the Repoussé Café and Chase a Pounder!\r\nThe Repoussé Café is here for your pounding needs...   \r\nNeed a hammer? Done. \r\nNeed a punch?  Done. \r\nNeed a chisel? Done. \r\nCome over and chase some metal with a blunt object of striking force.   Experience the thrill of making metal cringe with each blow from your mighty fist of fiery, furry, fuzzy, funny elbow. Watch as large boring pieces of metal become pounded into all shapes and sizes.",
        "artist": "Jim Williams & His Fine Collection of Pounders",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "5:15 140', Man Pavilion",
            "hour": 5,
            "minute": 15,
            "distance": 140,
            "category": "Man Pavilion",
            "gps_latitude": 40.786045585954,
            "gps_longitude": -119.206692899661
        },
        "location_string": "5:15 140', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82115,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82115_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2k9EAA",
        "year": 2016,
        "name": "Grand Elaborated Rule Masters And No-holds-barrers (G.E.R.M.A.N.)",
        "url": "http://www.germanguild2016.de",
        "contact_email": "guildmaster@germanguild2016.de",
        "hometown": "Germany",
        "description": "Medieval Germany is known for the stories collected by Brothers Grimm, the Hanse trading company, people obeying to the rules of their kings, and\r\nGutenbergs art of printing. All of these attributes are reflected in the G.E.R.M.A.N. guild workshop. This workshop is about rule making and printing. Following a playful structure, a personal rules of life and/or behavior is told and traded for a new rule, which is chosen or created by chance. To make this new rule a temporary or permanent part of the participants life, he or she can print this rule on pieces of old German files, badges, wristbands or even body parts.",
        "artist": "German Burners with Berlin Burner e.V.",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "7:00 150', Man Pavilion",
            "hour": 7,
            "minute": 0,
            "distance": 150,
            "category": "Man Pavilion",
            "gps_latitude": 40.786292984045,
            "gps_longitude": -119.207023703499
        },
        "location_string": "7:00 150', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82951,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82951_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000czbGEAQ",
        "year": 2016,
        "name": "Flux",
        "url": "http://",
        "contact_email": "samuelandthehawk@yahoo.com",
        "hometown": "Los Angeles, CA",
        "description": "Flux are a series of magnetic ferrofluid sculptures that exemplify the wonderful symmetry and connected nature of our universe. These unique kinetic sculptures respond dynamically to the electromagnetic frequencies of the human bodies in the area. Participants can come to Flux to meditate, sing, and dance, all the while observing how their movements and actions effect the local electromagnetic frequencies!",
        "artist": "Samuel Steinman",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:00 4950', Open Playa",
            "hour": 12,
            "minute": 0,
            "distance": 4950,
            "category": "Open Playa",
            "gps_latitude": 40.79600029508,
            "gps_longitude": -119.193863403277
        },
        "location_string": "12:00 4950', Open Playa",
        "images": [
            {
                "gallery_ref": 82971,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82971_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kKEAQ",
        "year": 2016,
        "name": "Guild of Mile Higher Knowledge",
        "url": "http://",
        "contact_email": "coburners@gmail.com",
        "hometown": "Denver, CO",
        "description": "The Guild of Mile Higher Knowledge is an on-playa twist on a Maker Space.  The space is broken up into 3 areas. In the front you have a present day work area where modern workshops will be taught, like LED helicopters, making a solar stove, Tesla cell phone chargers, etc. If you want to tap into ancient technology, you can pass through the time portal into a workshop from the Renaissance era. The time portal will have an interactive clue aspect that you have to figure out in order to get the past to open up to you.\r\nThe front of the booth is heavy canvas walls painted to look like an ancient building with LED lit columns standing in front. The side project, the Da Vinci Code Capade, will involve picking up a cypher card in front of the booth and figuring out clues to take you around the playa. This will allow many of the Colorado theme camps to host our adventurers along the way. People can bring their completed card back at any time during the burn week.",
        "artist": "Colorado Burners",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "1:07 150', Man Pavilion",
            "hour": 1,
            "minute": 7,
            "distance": 150,
            "category": "Man Pavilion",
            "gps_latitude": 40.78648260681,
            "gps_longitude": -119.205968643277
        },
        "location_string": "1:07 150', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82878,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82878_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kSEAQ",
        "year": 2016,
        "name": "Commedia dell'Arte Morality Puppet Play",
        "url": "http://",
        "contact_email": null,
        "hometown": "Orange County, CA",
        "description": "Commedia dell'Arte Puppet Morality Play: A renaissance-era puppet show, complete with ornate stage decor, lighting, and puppet characters with changeable costumes. Story lines will be provided for volunteer puppeteers, and improvisation is highly encouraged! The Orange County team will be staging their own shows throughout each day as well. \r\nSome of the morality plays are based on the Ten Principles, and some infused with comedy. During the day, the shows are very kid-friendly, whereas at night they're a bit more adult.",
        "artist": "The Orange County Burners",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "10:00 150', Man Pavilion",
            "hour": 10,
            "minute": 0,
            "distance": 150,
            "category": "Man Pavilion",
            "gps_latitude": 40.786796522727,
            "gps_longitude": -119.206641339749
        },
        "location_string": "10:00 150', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82865,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82865_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kQEAQ",
        "year": 2016,
        "name": "Koulu School",
        "url": "http://www.kouluonfire.com",
        "contact_email": null,
        "hometown": "Finland",
        "description": "Everyone has something to teach. Koulu is a school of amateur teachers and gurus at heart. It is a learning space for hundreds of lessons to help people discover their inner teacher.\r\nThe real art of this approach is the curriculum and how it is presented: it is totally governed by the participants and created organically and collaboratively as it develops. The lessons are presented in an elaborate \"tree of knowledge\", that by the end of the day will have hundreds of lessons, on topics and in fields we can only imagine.  The Finnish Burners have a wealth of positive experiences and perspectives from the previously organized \"Koulu\" workshops held around the world.  The results are always mind blowing. Versatile and diverse is our method or magic is in the discovery of what people might be able to teach one another within a 15 minute interactive session / lesson among friends or strangers.",
        "artist": "Finnish Burners",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "8:30 130', Man Pavilion",
            "hour": 8,
            "minute": 30,
            "distance": 130,
            "category": "Man Pavilion",
            "gps_latitude": 40.786577417303,
            "gps_longitude": -119.206907556801
        },
        "location_string": "8:30 130', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82899,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82899_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kTEAQ",
        "year": 2016,
        "name": "Mad Sorcerer's Workshop",
        "url": "http://burningman.nyc",
        "contact_email": null,
        "hometown": "New York, NY",
        "description": "The Mad Sorcerer's Workshop has the very important job of creating new baby worlds.  It floats in space, seeding star systems with new planets, full of strange and wonderful creatures.  Is that an octopus in the ocean?  A banana tree on an island?  Are those birds or airplanes in the air?  All that can be known, is that they are all made of Play-Doh by the Workshop's visitors, one creature at a time.",
        "artist": "Blue Mars for the New York Regional",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "4:00 150', Man Pavilion",
            "hour": 4,
            "minute": 0,
            "distance": 150,
            "category": "Man Pavilion",
            "gps_latitude": 40.786003477101,
            "gps_longitude": -119.206358661938
        },
        "location_string": "4:00 150', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82966,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82966_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kIEAQ",
        "year": 2016,
        "name": "Arte Della Luce",
        "url": "http://www.makerlabs.com",
        "contact_email": "hello@makerlabs.com",
        "hometown": "Vancouver, Canada",
        "description": "Behold the giant Etch-A-Sketch of light! Artists and makers can use the mechanical gears and pulleys to create large drawings via solar pyrography. Travelling through our time portal, visitors can also observe and operate other digital fabrication tools from the future like laser cutters and CNC routers!",
        "artist": "MakerLabs",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "8:07 150', Man Pavilion",
            "hour": 8,
            "minute": 7,
            "distance": 150,
            "category": "Man Pavilion",
            "gps_latitude": 40.786529616362,
            "gps_longitude": -119.2070147208
        },
        "location_string": "8:07 150', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82999,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82999_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kMEAQ",
        "year": 2016,
        "name": "The Renaissance of Musical Instruments",
        "url": "http://www.degantiszmogus.lt",
        "contact_email": "ieva@meskenai.lt",
        "hometown": "Lithuania",
        "description": "The Renaissance of Musical Instruments project is about re-creating and reinventing various musical instruments, as well as, creating new ones in the process. The project aims to explore the renaissance theme through the modern topics of nowadays - recycling, individual creativity and modern tools.",
        "artist": "Duonelaičio dirbtuvės",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "2:15 140', Man Pavilion",
            "hour": 2,
            "minute": 15,
            "distance": 140,
            "category": "Man Pavilion",
            "gps_latitude": 40.786253944271,
            "gps_longitude": -119.206031911717
        },
        "location_string": "2:15 140', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82883,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82883_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2k6EAA",
        "year": 2016,
        "name": "YO! Union Guild BRC Local 420",
        "url": "https://www.facebook.com/groups/570008286483029/",
        "contact_email": "yo.union.guild@gmail.com",
        "hometown": "Philadelphia, PA",
        "description": "Yo! Union Guild BRC Local 420 is your local volunteer workers Union chapter here to represent YOU!  Yo! Union Guild celebrates Radical Self-Expression by offering an open communication channel for the volunteer workforce of Black Rock City.  \r\nBy day, Yo! Union Guild is a playful educational space focused on volunteer worker rights.  Interactive posters list changes the volunteer workforce of Black Rock City request to see enacted in the future.  There's a playful mix of honest real messages, sarcasm and rumors.  The Rumor Mill, a DaVinci inspired kinetic sculpture, cranks out rumors for participants to take with them and spread through our great city.  Yo! Union Guild hosts a daily Union Break for 20 minutes at 4:20.\r\nBy night, Union Headquarters is overrun by the Philly Mafia converting the space into an underground casino. You'll find bookies taking bets on Thunderdome fights as well as participatory gaming of Poker, BlackJack, Craps and Roulette just remember, the House always wins!",
        "artist": "Philly Burners",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "10:15 160', Man Pavilion",
            "hour": 10,
            "minute": 15,
            "distance": 160,
            "category": "Man Pavilion",
            "gps_latitude": 40.786834238626,
            "gps_longitude": -119.206576557938
        },
        "location_string": "10:15 160', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82867,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82867_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kXEAQ",
        "year": 2016,
        "name": "D'Oro de Sacramenti Regionale (Gold of Sacramento Region)",
        "url": "https://www.facebook.com/DOro-de-Sacramenti-Regionale-532736910235999",
        "contact_email": "sacbmproject@gmail.com",
        "hometown": "Sacramento, CA",
        "description": "Upon entering the busy, rustic, guild space of D'Oro di Sacramenti common folk, tradesmen, merchants and nobles will walk though a logge facade. They will be greeted by our Guild Members and invited to craft custom weapons of Dragonswood and Valyrian wood. \r\nOur Guild Tradesmen will instruct on skills and the precision of accuracy in the field of weaponry. Using the hand catapult and other weapons forged by our smiths.\r\nAll will be invited to enter into our Weapons Practice Gallery. Each visitor will select a projectile that either they have crafted in our Guild workshop or one made by previous visitors. The projectiles will be made from deconstructed, then reconstructed Stuffed Animals. Participants will be seated at one of our Practice Weapons, such as a giant slingshot.\r\nSkills of persuasion and accuracy will be needed to hit the targets on our gallery wall. Some of the targets will illuminate with LED lights if hit, earning the participant a treasured object from the House Sacramenti - \r\nThe Golden Dragonbear.",
        "artist": "Sacramento Region",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "4:45 160', Man Pavilion",
            "hour": 4,
            "minute": 45,
            "distance": 160,
            "category": "Man Pavilion",
            "gps_latitude": 40.785965555079,
            "gps_longitude": -119.20657448789
        },
        "location_string": "4:45 160', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82900,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82900_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d4mEEAQ",
        "year": 2016,
        "name": "JacketZ",
        "url": "https://vimeo.com/151220349",
        "contact_email": "phenceart@yahoo.com",
        "hometown": "El Porto, Manhattan Beach, CA",
        "description": "JACKETZ !  Project #7 out on the deep playa fence.  This year you will ride along the fence and find very strange and funny old album covers mounted  above each green stake that Just George and his fabulous crew put up every year.  These album jackets will be bizarre and certainly invite you over to check each pair out and discover the theme for each one. They will spin in the wind and a few wind chimes will beckon you to have a laugh and discover something new. PhenceArt from BlinkingMan  Camp always believes that discovery is a great way to find the hidden gems the playa provides. Deep Playa - it's not just for your grandparents any more......Dragnet",
        "artist": "Dragnet - Denny Smith - LA",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:00 8150', Open Playa",
            "hour": 12,
            "minute": 0,
            "distance": 8150,
            "category": "Open Playa",
            "gps_latitude": 40.802205812649,
            "gps_longitude": -119.185692345177
        },
        "location_string": "12:00 8150', Open Playa",
        "images": [
            {
                "gallery_ref": 83357,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83357_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d75mEAA",
        "year": 2016,
        "name": "Renoardo's Artisan Menagerie",
        "url": "http://",
        "contact_email": "info@renocore.org",
        "hometown": "Reno, NV",
        "description": "We are a group of artisans who travel incognito while instructing others in the fine art of making masks, anatomy illustration, & other indulgences. We have our own metal stamp label that we use to \"mark\" our handiwork. Our masks are the finest in the region & our artists have the flare of Leonardo.\r\nArt classes daily.\r\nIn the spirit of Carnivale, our menagerie started creating masks & providing instruction on how to create them. As our group increased, so did our artisan base to include painters & sketch artists. We plan to have classes in making & decorating masks along with art classes in anatomy & anything inspiring to those attending.We will have live models to help with inspiration.We will have a plexiglas panel for instruction and colouring.",
        "artist": "Reno Core Project",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "1:45 160', Man Pavilion",
            "hour": 1,
            "minute": 45,
            "distance": 160,
            "category": "Man Pavilion",
            "gps_latitude": 40.786343599694,
            "gps_longitude": -119.205926210855
        },
        "location_string": "1:45 160', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82903,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82903_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kUEAQ",
        "year": 2016,
        "name": "Vapor Cannon Guild",
        "url": "http://",
        "contact_email": null,
        "hometown": "Birmingham, AL",
        "description": "The Vapor Cannon Guild combines Leonardo's visions of war machines and with the Burner Principle: Participation! Black Rock City Participants will use vapor cannons to blast targets located within the guild space. The guild will offer three ground target areas as well as aerial targets to test the skill of the participants. In the evening the Vapor Cannon Guild will morph into another world with cryptic symbols. By the way, vapor cannons run on air so there is an endless supply of ammo!",
        "artist": "Alabama Burners",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "2:00 150', Man Pavilion",
            "hour": 2,
            "minute": 0,
            "distance": 150,
            "category": "Man Pavilion",
            "gps_latitude": 40.786294414918,
            "gps_longitude": -119.205975790116
        },
        "location_string": "2:00 150', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82925,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82925_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dDS7EAM",
        "year": 2016,
        "name": "Inside the Mind of DaVinci",
        "url": "https://www.facebook.com/InsideTheMindOfDaVinci/",
        "contact_email": "sledgenv@gmail.com",
        "hometown": "Reno, NV",
        "description": "A larger than life sculpted head is partly submerged in the earth from our Renaissance past. In a dust storm you stumble upon it and are awed by its presence as the sands blow off of it. Walking around the large sculpture you can enter: Inside The Mind of DaVinci.\r\nThe back of the head is cut out into two archways allowing entrance into the hollowed out interior of the piece. The interior has etched into the surface, Leonardo's sketches and writings. Geometric shapes that illuminate colors of blue, red and yellow create a unique and pleasant atmosphere with beautiful colored shadows cast by the sun inside the head.\r\nThe inside of the head is a resting area where there are cement balls to sit on that can be pushed and rolled leaving written words in the sand. It is a community spot for gathering and sharing artistic and inventive ideas. The piece consists of concrete, bronze, recycled glass and metal.",
        "artist": "Phoenix Rising and Wrecking House",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "5:55 1300', Open Playa",
            "hour": 5,
            "minute": 55,
            "distance": 1300,
            "category": "Open Playa",
            "gps_latitude": 40.783771296882,
            "gps_longitude": -119.209669676879
        },
        "location_string": "5:55 1300', Open Playa",
        "images": [
            {
                "gallery_ref": 82974,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82974_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dDOjEAM",
        "year": 2016,
        "name": "Miles",
        "url": "http://",
        "contact_email": null,
        "hometown": "Santa Cruz, CA",
        "description": "The Black Rock Desert's pervasive wind blows past an Art Deco styled \"totalizing anemometer\" which measures the number of miles of wind that blows past during the week. Will the total reach 1,000 miles before the Man burns?",
        "artist": "Kerry Veenstra",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "2:30 2050', Open Playa",
            "hour": 2,
            "minute": 30,
            "distance": 2050,
            "category": "Open Playa",
            "gps_latitude": 40.783602076041,
            "gps_longitude": -119.20007343068
        },
        "location_string": "2:30 2050', Open Playa",
        "images": [
            {
                "gallery_ref": 82996,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82996_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dEQPEA2",
        "year": 2016,
        "name": "Signs of Our Time",
        "url": "http://justinkerson.com",
        "contact_email": "justin@tottglobal.com",
        "hometown": "San Francisco, CA",
        "description": "This \"ready made\" mixed media art comes from the brilliant and diabolical mind of the nefarious Justin Kerson. The installation provokes awe of Justin's conceptual madness, leaving one with the simple and profound desire to seek truth and impact the world for the greater good in any and every capacity available. \r\nThis installation looks like a common, everyday road sign- but with an image reformatted from the expectation of the banal daily grind. The signs are inconspicuous to the undiscerning eye, but rich in symbolism and context of the issues that face civilization today. This subtle, yet thought-provoking installation invites social commentary on the unfortunate truths hiding just below the surface of society's awareness. \r\nWhat is this sign pointing to? What does it convey?",
        "artist": "Justin Kerson",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:45 2300', Open Playa",
            "hour": 1,
            "minute": 45,
            "distance": 2300,
            "category": "Open Playa",
            "gps_latitude": 40.785588972394,
            "gps_longitude": -119.198251874749
        },
        "location_string": "1:45 2300', Open Playa",
        "images": [
            {
                "gallery_ref": 83383,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83383_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dDJWEA2",
        "year": 2016,
        "name": "Humanarium",
        "url": "http://",
        "contact_email": "humanarium.art.project@gmail.com",
        "hometown": "Los Angeles, CA",
        "description": "The Humanarium is a human sized aquarium/terrarium, minus the water. The name accurately represents the contents of this space comprised of humans and human made items. Even though this space represents an aquarium by night and terrarium by day, the project has been created by humans and is a container for humans to interact together in a defined space. Your creativity, full self expression, and play, will emerge from this new perspective within the structure and the space surrounding the structure. The scale of a familiar object or space is pushed in a way that allows humans to experience the world in a new way.\r\nAquariums are comprised of aquatic items: sea animals, water, sea plants, sea monkeys. The terrarium has earth elements. The association of the name of the space to the elements made sense to use this in the Humanarium. Looking at what we create in the world, how are we impacting the world in new ways?",
        "artist": "Mark Thielen",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:55 2050', Open Playa",
            "hour": 1,
            "minute": 55,
            "distance": 2050,
            "category": "Open Playa",
            "gps_latitude": 40.785194775561,
            "gps_longitude": -119.199259606985
        },
        "location_string": "1:55 2050', Open Playa",
        "images": [
            {
                "gallery_ref": 82990,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82990_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dC0LEAU",
        "year": 2016,
        "name": "Flaming SeeSaw",
        "url": "http://",
        "contact_email": null,
        "hometown": "Washington, DC",
        "description": "The flaming see-saw is a 21 foot long golden see-saw. It is waiting for those riders who are brave enough to sit under its halos of fire. As riders rise up and down, big bursts of flame are shot out from over their heads. It is both intimidating and exhilarating. Fear is natural, but once overcome leads way to excitement and joy.",
        "artist": "Danny Ricciotti (Mutually Assured Destruction)",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "3:30 800', Open Playa",
            "hour": 3,
            "minute": 30,
            "distance": 800,
            "category": "Open Playa",
            "gps_latitude": 40.784504982035,
            "gps_longitude": -119.205049014433
        },
        "location_string": "3:30 800', Open Playa",
        "images": [
            {
                "gallery_ref": 82889,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82889_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d8DYEAY",
        "year": 2016,
        "name": "Playa Forever",
        "url": "http://www.monsoonpuppets.com/playaforever",
        "contact_email": "bill@nfo.edu",
        "hometown": "Silver City, NM",
        "description": "Playa Forever is a celebration of DaVinci's art and engineering.  The concept of perpetual motion is an intriguing one.  Participants will encounter it and observe the function of the levers and arms.\r\nThe slowly spinning wheel will generate a 'clacking' sound, as the levers and balls rotate.",
        "artist": "Bill Neely",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "5:59 1800', Open Playa",
            "hour": 5,
            "minute": 59,
            "distance": 1800,
            "category": "Open Playa",
            "gps_latitude": 40.782878419451,
            "gps_longitude": -119.211053806722
        },
        "location_string": "5:59 1800', Open Playa",
        "images": [
            {
                "gallery_ref": 83000,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83000_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dKC9EAM",
        "year": 2016,
        "name": "Fire In Balance - In The Round",
        "url": "http://www.poetickinetics.com/fire-in-balance/",
        "contact_email": "info@poetickinetics.com",
        "hometown": "Los Angeles, CA",
        "description": "Like moths to the flame, FIRE IN BALANCE – IN THE ROUND will draw you ever closer to its molten and mesmerizing blaze. Built to foster discussion, the ever-changing patterns will sustain and propel your dialogue in ways you never knew possible. Come cozy up in this inviting space, it will leave your heart warm long after you've left.",
        "artist": "Patrick Shearn of Poetic Kinetics",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.indiegogo.com/projects/fire-in-balance-in-the-round-burning-man-art-2016#/",
        "location": {
            "string": "1:00 3100', Open Playa",
            "hour": 1,
            "minute": 0,
            "distance": 3100,
            "category": "Open Playa",
            "gps_latitude": 40.788611132969,
            "gps_longitude": -119.195676416515
        },
        "location_string": "1:00 3100', Open Playa",
        "images": [
            {
                "gallery_ref": 82898,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82898_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dIUWEA2",
        "year": 2016,
        "name": "Mind Loop",
        "url": "https://www.facebook.com/bmjapanregional/",
        "contact_email": "japan@burningman.org",
        "hometown": "Japan",
        "description": "\"Mind Loop\" provides a test field to explore your sense of time and space. Blinking lights or anything that reflects light, even your body, will generate rainbow reflections in patterns. Create temporary sketches for new inventions right out of your mind! At this moment, everyone  becomes their own Da Vinci.",
        "artist": "Dream Machine Guild from Japan",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "6:45 140', Man Pavilion",
            "hour": 6,
            "minute": 45,
            "distance": 140,
            "category": "Man Pavilion",
            "gps_latitude": 40.786252666923,
            "gps_longitude": -119.206967389477
        },
        "location_string": "6:45 140', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82932,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82932_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dHaBEAU",
        "year": 2016,
        "name": "Iceberg",
        "url": "http://",
        "contact_email": "rock-e-boy@comcast.net",
        "hometown": "Sonoma, CA",
        "description": "An iceberg on the playa in the heat of a late August afternoon?  How cool is that?  See with your own eyes the sun and wind twirl around this kinetic sculpture every moment of the day and night.  Never the same twice.",
        "artist": "Rock Weir",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "8:10 1850', Open Playa",
            "hour": 8,
            "minute": 10,
            "distance": 1850,
            "category": "Open Playa",
            "gps_latitude": 40.788123718056,
            "gps_longitude": -119.212790929791
        },
        "location_string": "8:10 1850', Open Playa",
        "images": [
            {
                "gallery_ref": 82924,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82924_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dKfrEAE",
        "year": 2016,
        "name": "Playa Beach Ball",
        "url": "https://www.facebook.com/PlayaBeachBall",
        "contact_email": "nevadamuse@gmail.com",
        "hometown": "Carson City, Nevada",
        "description": "The Playa Beach Ball is bigger than you are. Decorated by Burners for Burners. Decorated with hands, bottoms, boobs and others, there are paintings of flowers, the Man, rainbows and fun designs and signatures. \r\nThe Playa Beach Ball is filled with actual beach balls. It is enclosed in a dome that can be stepped inside to play with the ball. The dome helps keep the ball from flying to the trash fence and allows it to be seen at night.",
        "artist": "NV Muse",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "9:05 1620', Open Playa",
            "hour": 9,
            "minute": 5,
            "distance": 1620,
            "category": "Open Playa",
            "gps_latitude": 40.789664838087,
            "gps_longitude": -119.210465835032
        },
        "location_string": "9:05 1620', Open Playa",
        "images": [
            {
                "gallery_ref": 82950,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82950_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dHJ0EAM",
        "year": 2016,
        "name": "Scopri da Vinci",
        "url": "http://",
        "contact_email": null,
        "hometown": "Chicago, IL & Denver, CO",
        "description": "This is an opportunity to discover the genius of da Vinci through interaction with several of his machines reconstructed and brought to life. Discover Da Vinci's genius and insight as these simple machines reveal their influence on modern day life!",
        "artist": "Matt Boggs & Mark Rodgers",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "3:45 140', Man Pavilion",
            "hour": 3,
            "minute": 45,
            "distance": 140,
            "category": "Man Pavilion",
            "gps_latitude": 40.786046115047,
            "gps_longitude": -119.206305413296
        },
        "location_string": "3:45 140', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82166,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82166_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dLLDEA2",
        "year": 2016,
        "name": "Project Aeon",
        "url": "http://",
        "contact_email": null,
        "hometown": "Reno, NV",
        "description": "Project Aeon explores the concept of vector equilibrium (VE) as expressed in all that we perceive as matter, our physical reality. This visual representation of the VE form, a 50' tall spherical \"Torus\" alludes to the bodies of energy that compose all of our Universe, reflecting the electromagnetic flow of energy structuring these bodies; from the Universe itself to stars, planets, atoms and subatomic systems, even our own human bodies. Sacred geometry unveiled in the systems of this form infinitely replicates itself throughout the structure. Light is the focus of interactive sculptures within the structure.",
        "artist": "Lewis Zaumeyer & Jub Jub World Projects",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.indiegogo.com/projects/project-aeon-at-burning-man-2016#/",
        "location": {
            "string": "6:56 1980', Open Playa",
            "hour": 6,
            "minute": 56,
            "distance": 1980,
            "category": "Open Playa",
            "gps_latitude": 40.7848053959,
            "gps_longitude": -119.21334341079
        },
        "location_string": "6:56 1980', Open Playa",
        "images": [
            {
                "gallery_ref": 82923,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82923_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dKTUEA2",
        "year": 2016,
        "name": "Cross-World",
        "url": "http://",
        "contact_email": "crossworldpuzzle@gmail.com",
        "hometown": "Moscow, Russia",
        "description": "Crossword is an intellectual game with great possibilities for the development of creative abilities, memory training.Today is a very large number of people crossword puzzles when they go to work, when all waiting in the clinic, many seniors are addicted to crossword puzzles and unraveling.\r\nWe want to build a giant crossword allowing everybody to use their erudition or to know something new during while guessing the right answers. And there's more -  not only one flatness can be used - you can write on two or three sides of the square. Or the citizens of Black Rock can just climb on it and spent some time on the top of the crossword blocks.",
        "artist": "Cross-World Team",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "10:33 2170', Open Playa",
            "hour": 10,
            "minute": 33,
            "distance": 2170,
            "category": "Open Playa",
            "gps_latitude": 40.792339835746,
            "gps_longitude": -119.206308711315
        },
        "location_string": "10:33 2170', Open Playa",
        "images": [
            {
                "gallery_ref": 82935,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82935_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dMQLEA2",
        "year": 2016,
        "name": "The Bear",
        "url": "http://",
        "contact_email": "mtscheu@sbcglobal.net",
        "hometown": "Sacramento, CA",
        "description": "Dwell in the possibility of discovering your self.",
        "artist": "Michael Tscheu",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:32 2600', Open Playa",
            "hour": 12,
            "minute": 32,
            "distance": 2600,
            "category": "Open Playa",
            "gps_latitude": 40.789862276455,
            "gps_longitude": -119.198284349758
        },
        "location_string": "12:32 2600', Open Playa",
        "images": [
            {
                "gallery_ref": 82420,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82420_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dNNxEAM",
        "year": 2016,
        "name": "BORING Sign",
        "url": "https://www.facebook.com/campboring",
        "contact_email": null,
        "hometown": "Mill Valley, CA",
        "description": "Inspired by vintage Las Vegas casino signs and a healthy sense of irony, the BORING sign is a 18-foot tall, 20-foot long reminder to never take one's self – or one's life work – too seriously. The sign itself is made out of reclaimed sheet metal and discarded letters from dismantled corporate signs, hand painted, lit by 300 ten-watt incandescent bulbs and securely attached to a welded base with wheels (and sometimes, pedal-power) so the piece is fully mobile across the playa. You can usually find the BORING sign accompanying burns, alongside popular art projects, and framing the silhouette of the Man at sunset. With four 500-watt speakers and a playlist of danceables from the 60s, 70s and 80s, the mobile, rolling sign often attracts an entourage of sunset or late night boogie revelers.",
        "artist": "Camp BORING",
        "category": "Mobile",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "Mobile",
            "hour": null,
            "minute": null,
            "distance": null,
            "category": "Mobile",
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": "Mobile",
        "images": [
            {
                "gallery_ref": 82910,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82910_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dMO0EAM",
        "year": 2016,
        "name": "Parasolvent",
        "url": "http://facebook.com/derbykinetic",
        "contact_email": "dan@benedictaugust.com",
        "hometown": "Anaheim, CA",
        "description": "\"Parasolvent\" is an interactive kinetic sculpture.  A 23 foot tall rotating ring of parasols that open as they ascend and close as they fall.  \r\nParasols are  protective devices created to shield us from the elements.  Here they represent the emotionally protective devices we believe are protecting us, but are in fact hindering our progression.  This is a meditative piece about letting them go.  The parasols exit a human figure, blossom (open) as they rise, and decay (close) as they fall.  Parasolvent was inspired by the artist's first Burning Man in 2013 and chosen as an Honorarium piece for 2014.",
        "artist": "Dan Benedict",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "6:45 1400', Open Playa",
            "hour": 6,
            "minute": 45,
            "distance": 1400,
            "category": "Open Playa",
            "gps_latitude": 40.784926584374,
            "gps_longitude": -119.211173801441
        },
        "location_string": "6:45 1400', Open Playa",
        "images": [
            {
                "gallery_ref": 82906,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82906_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dQJfEAM",
        "year": 2016,
        "name": "The Chapel of Dancing Shadows",
        "url": "http://www.chapelofdancingshadows.com",
        "contact_email": "info.mkreyn@gmail.com",
        "hometown": "New York City, NY",
        "description": "The Chapel of Dancing Shadows is a space of refuge, contemplation, meditation and wonder. Its artworks represent an invented creation myth for an imagined civilization. The 8-ft wall drawings are the first 7 images of a developing 150-image set that will ultimately comprise Maria Kreyn's developing book of drawings. The chapel is a semitransparent, luminous art gallery, yet also a shelter from the elements. A visual and auditory feast, its intricately cut wooden ceiling is covered with wind chimes and drawings. The chapel houses a set of encrypted scrolls in an invented language and a globe showing the imagined civilization's astrological map.",
        "artist": "Maria Kreyn",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "7:32 1300', Open Playa",
            "hour": 7,
            "minute": 32,
            "distance": 1300,
            "category": "Open Playa",
            "gps_latitude": 40.786455607891,
            "gps_longitude": -119.211200589062
        },
        "location_string": "7:32 1300', Open Playa",
        "images": [
            {
                "gallery_ref": 82912,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82912_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dOEiEAM",
        "year": 2016,
        "name": "DISC-GO-SPHERE",
        "url": null,
        "contact_email": "matthew@commonkinetics.com",
        "hometown": "New York, NY",
        "description": "The DISC-GO-SPHERE, by artist/engineer Matthew Davis, is an interactive kinetic sculpture that gives participants the experience of being inside a 3 dimensional moving version of Da Vinci's \"Vitruvian Man\" sketch. It consists of a series of six pairs of concentric rings ranging in diameter from 8ft to 12ft that fold into a flat vertical disc. By operating the pedals, the rings begin to spin in multiple directions forming a complex spherical shape. Each person's actions will alter their own experience and that of the other participants.",
        "artist": "Matthew Davis",
        "category": null,
        "program": "Pavilion",
        "donation_link": null,
        "location": {
            "string": "12:00 75', Man Pavilion",
            "hour": 12,
            "minute": 0,
            "distance": 75,
            "category": "Man Pavilion",
            "gps_latitude": 40.7865454693,
            "gps_longitude": -119.206308563675
        },
        "location_string": "12:00 75', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82954,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82954_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dN6lEAE",
        "year": 2016,
        "name": "Electric Dandelions",
        "url": "http://liquidpxl.com/portfolio/electric-dandelions/",
        "contact_email": "design@liquidpxl.com",
        "hometown": "Los Angeles, CA",
        "description": "Electric Dandelions are three 25-27ft tall light posts made to look like dandelions during the day and fireworks at night. There are 4,500 LEDs between the three Dandelions all controlled by an iPad. Participants will be able to control the project through a touch screen controller. The control station will be set 50ft away from the dandelions so that the controller can observe the changes. They will be able to control hue, saturation and speed and the project will also be sound sensitive to music and voice. Participants  can sit or lay on at the base of the dandelions on platforms, simply so that they can enjoy the show above them.",
        "artist": "Liquid PXL",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "6:45 2300', Open Playa",
            "hour": 6,
            "minute": 45,
            "distance": 2300,
            "category": "Open Playa",
            "gps_latitude": 40.783979289042,
            "gps_longitude": -119.214178278566
        },
        "location_string": "6:45 2300', Open Playa",
        "images": [
            {
                "gallery_ref": 82870,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82870_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dRDBEA2",
        "year": 2016,
        "name": "Cheese Maze",
        "url": "http://",
        "contact_email": null,
        "hometown": "London, United Kingdom",
        "description": "The Cheese Maze 2016.\r\nFollowing on from our wooden maze in 2012, we bring you an even bigger and harder maze. \r\nThe walls are made of string so you can completely see through the maze.",
        "artist": "Cheese",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:36 3760', Open Playa",
            "hour": 1,
            "minute": 36,
            "distance": 3760,
            "category": "Open Playa",
            "gps_latitude": 40.78587894056,
            "gps_longitude": -119.192920276142
        },
        "location_string": "1:36 3760', Open Playa",
        "images": [
            {
                "gallery_ref": 82965,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82965_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dUyjEAE",
        "year": 2016,
        "name": "Be Da Vinci's Banker!",
        "url": "http://",
        "contact_email": null,
        "hometown": "Zurich, Switzerland",
        "description": "You're welcome to this selfie-friendly frame provided to take pictures of yourself or somebody else as an ancient-style banker in different poses. Chose the one fitting best to your self  - or the opposite!",
        "artist": "Kahuna",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "11:10 1200', Open Playa",
            "hour": 11,
            "minute": 10,
            "distance": 1200,
            "category": "Open Playa",
            "gps_latitude": 40.789489539575,
            "gps_longitude": -119.205023079952
        },
        "location_string": "11:10 1200', Open Playa",
        "images": [
            {
                "gallery_ref": 82905,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82905_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000wluDEAQ",
        "year": 2016,
        "name": "Shamanic Portal",
        "url": "http://",
        "contact_email": "tom_woodall@msn.com",
        "hometown": "Kennewick, WA",
        "description": "Enter the circle and let yourself go... the Shamanic Portal will take you to uncharted territory. Depending on your personal power and experience, be prepared to journey to the myriad levels of no-ordinary reality. Strategically placed on one of the playa's most powerful, naturally occurring vortexes, the portal will gather and gain power the more it is used.\r\nDance, sing, drum, chant, meditate, breathe, spin, hoop, use body postures and any other techniques that will focus your consciousness and take you away.  Participants are encouraged to open the portal either individually or in groups.\r\nDon't believe?  Give it a try and then decide.\r\nAmbient trance-inducing sounds are available to support your experience.\r\nDisclaimer: this is an art installation. Use at your own risk. Participation in this installation is the sole responsibility of the participant. The artist is in no way responsible for whatever happens during your experience. Individual experiences may vary.",
        "artist": "Rock",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:25 4650', Open Playa",
            "hour": 12,
            "minute": 25,
            "distance": 4650,
            "category": "Open Playa",
            "gps_latitude": 40.793259387556,
            "gps_longitude": -119.192332643858
        },
        "location_string": "12:25 4650', Open Playa",
        "images": [
            {
                "gallery_ref": 82958,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82958_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dUQWEA2",
        "year": 2016,
        "name": "Anisoptera",
        "url": "http://",
        "contact_email": "quinn@artechreno.org",
        "hometown": "Reno, NV",
        "description": "This sculpture is called Anisoptera and consists of two very large, colorful dragonflies.  They are sculpted out of metal and glass.",
        "artist": "Ryan Adams",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "6:20 2050', Open Playa",
            "hour": 6,
            "minute": 20,
            "distance": 2050,
            "category": "Open Playa",
            "gps_latitude": 40.783172050916,
            "gps_longitude": -119.212564703389
        },
        "location_string": "6:20 2050', Open Playa",
        "images": [
            {
                "gallery_ref": 82938,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82938_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dTbzEAE",
        "year": 2016,
        "name": "Lumenoctis",
        "url": "http://katalinpazmandi.com",
        "contact_email": "fufaeg@gmail.com",
        "hometown": "Rosendale, NY",
        "description": "Lumenoctis is a portal to other dimensions or a gate to other worlds where you can experience day at night and night at day to make them all connected and one, to blend dualism and see both overlapping each other at the same time. The installation creates the feeling of oneness with the universe, oneness with the earth and with everyone all around you. This is how we learn compassion and love.\r\nIt is interactive as a meditation or hang out place, people can also stand in the middle of the portal where the symbol of infinity knot exists and experience sunlight, starlights, reflected lights or fluorescent lights, depending on the time of the day. You can also just hang out between the wings of the space, watching the flickering lights, as it creates a magical environment either at day or night.\r\nThe size of the installation will be about 28' in diameter and 12' tall. It forms a hexagonal shape with dark fabric dividing each sections. \r\nDuring Burning Man I am planning to create a quiet ceremony each day.",
        "artist": "Healers / Katalin Pazmandi & Brian Gardner",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.indiegogo.com/projects/lumenoctis-installation-for-burning-man-2016#/",
        "location": {
            "string": "1:25 2100', Open Playa",
            "hour": 1,
            "minute": 25,
            "distance": 2100,
            "category": "Open Playa",
            "gps_latitude": 40.786660919479,
            "gps_longitude": -119.198913625032
        },
        "location_string": "1:25 2100', Open Playa",
        "images": [
            {
                "gallery_ref": 82881,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82881_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dRDaEAM",
        "year": 2016,
        "name": "Axis Mundi",
        "url": "http://",
        "contact_email": "kathy@karyk.com",
        "hometown": "Santa Clara, CA",
        "description": "A huge geodesic dome with large streaming panels of fabric attached as its crown, sheltering a sacred circle of life-sized handmade goddesses, is Axis Mundi. Inside, five glass women stand holding space in a healing circle of the feminine.  Come enter this transformational arena - a circle of glass!  Hand-cast thick blocks of glass, sculpted with reliefs of the female form and arms outstretched in compassion,  welcome Participants. The circle they surround seems closed, yet calls you to duck under to enter. Overhead are spirit-charged oil paintings of soul stirring imagery, continuing the healing work of this place.  Bells blow on the wind overhead.  The space is alive, pulsing. At times it will be a quiet healing meditative space and other times there will be drumming, rattling, journeying, ritual, or even ecstatic dance for those who dare join in, or just watch and be changed.  Find your center, your Axis Mundi.",
        "artist": "Jason Hickey & Kat Caric",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:20 1550', Open Playa",
            "hour": 1,
            "minute": 20,
            "distance": 1550,
            "category": "Open Playa",
            "gps_latitude": 40.786777378425,
            "gps_longitude": -119.200916957756
        },
        "location_string": "1:20 1550', Open Playa",
        "images": [
            {
                "gallery_ref": 82997,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82997_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DbxwEAC",
        "year": 2016,
        "name": "Essencia La Playa",
        "url": "http://",
        "contact_email": "crowc47@gmail.com",
        "hometown": "Portland, OR",
        "description": "Essencia la Playa - the energy of the event morphed into the shape of a human heart. It is a welded piece of steel made from Harley fenders and perforated sheet of metal\r\nIt's meaning is to describe how space is shaped by energy. How energy is influenced by desire. How desire is the flame created within the heart.\r\n\r\nSpace energy and desire is defined by this piece. It's intent is to spark the fire, to ignite the possibility of culture. And once in place, it is the artist's intent to have it symbolizes a beacon for our ability to create and manifest this dream.",
        "artist": "CrowArt",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "7:00 1500', Open Playa",
            "hour": 7,
            "minute": 0,
            "distance": 1500,
            "category": "Open Playa",
            "gps_latitude": 40.785329733912,
            "gps_longitude": -119.211736959029
        },
        "location_string": "7:00 1500', Open Playa",
        "images": [
            {
                "gallery_ref": 83342,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83342_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DYP7EAO",
        "year": 2016,
        "name": "Arborealis Forest",
        "url": "http://www.arborealisforest.com/",
        "contact_email": "noamtur@gmail.com",
        "hometown": "Oakland, CA",
        "description": "Come together to create new shared experiences enhancing those bonds through music, visuals and shared activity. \r\nArborealis an interactive environmental multi-sensory art installation that incorporates many different elements together to create a life changing experience for its visitors.\r\nVisitors entering Arborealis affect the sounds and visuals the installation produces, creating a space that is ever changing and alive.",
        "artist": "Yes we would, Noam Turgeman",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.indiegogo.com/projects/arborealis-forest#/",
        "location": {
            "string": "6:45 2300', Open Playa",
            "hour": 6,
            "minute": 45,
            "distance": 2300,
            "category": "Open Playa",
            "gps_latitude": 40.783979289042,
            "gps_longitude": -119.214178278566
        },
        "location_string": "6:45 2300', Open Playa",
        "images": [
            {
                "gallery_ref": 82998,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82998_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DjKBEA0",
        "year": 2016,
        "name": "Without Geometry there is no Point 2.0",
        "url": "http://",
        "contact_email": "jimstamp93505@gmail.com",
        "hometown": "California City, CA",
        "description": "WITHOUT GEOMETRY THERE IS NO POINT 2.0 2016 Rev.\r\nWooden geometic constructions rough, natural, odd angular towers, stars, snowflakes & trees. Shadows play thru lit from interior at night.  Daytime shadows are a photographers playground!",
        "artist": "Just Jim",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "9:10 2200', Open Playa",
            "hour": 9,
            "minute": 10,
            "distance": 2200,
            "category": "Open Playa",
            "gps_latitude": 40.791007351266,
            "gps_longitude": -119.211625234611
        },
        "location_string": "9:10 2200', Open Playa",
        "images": [
            {
                "gallery_ref": 83407,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83407_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DjUkEAK",
        "year": 2016,
        "name": "The Pillars of Principles",
        "url": "https://www.dropbox.com/s/eqhj01hanvqvew2/Pillars%20of%20Principles.mp4?dl=0",
        "contact_email": "peter@theegg.ca",
        "hometown": "Vancouver B.C., Canada",
        "description": "The Pillars of Principles show each of the 10 principles of Burning Man on a 6 ft white pillar that automatically lights up at night. It's a fun and interactive way to learn about the guiding principles of Burning Man.",
        "artist": "Peter Blitz",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "8:50 1800', Open Playa",
            "hour": 8,
            "minute": 50,
            "distance": 1800,
            "category": "Open Playa",
            "gps_latitude": 40.789561068207,
            "gps_longitude": -119.211494188015
        },
        "location_string": "8:50 1800', Open Playa",
        "images": [
            {
                "gallery_ref": 83397,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83397_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DYUvEAO",
        "year": 2016,
        "name": "The Family Jewels",
        "url": "https://www.facebook.com/FamilyJewelsProject/",
        "contact_email": null,
        "hometown": "West Oakland, CA",
        "description": "The Family Jewels are glowing, UV-lit interactive sculptures inspired by 70's style string art – these faceted, radiant gems made of miles of bright strands of colored, dancing light will shine as beacons. In 2016, Participants can climb in, spin, explore and enjoy the enhanced and updated Jewels.",
        "artist": "Todd Cooper/The Family Jewels Collective",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "7:46 1960', Open Playa",
            "hour": 7,
            "minute": 46,
            "distance": 1960,
            "category": "Open Playa",
            "gps_latitude": 40.787137089464,
            "gps_longitude": -119.21352077048
        },
        "location_string": "7:46 1960', Open Playa",
        "images": [
            {
                "gallery_ref": 82873,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82873_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DbE1EAK",
        "year": 2016,
        "name": "bOOth",
        "url": "http://",
        "contact_email": null,
        "hometown": "Salt Lake City, UT",
        "description": "bOOth is a whimsical gateway from here to there, or maybe from there to here?",
        "artist": "Bogart McAvoy",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:50 2650', Open Playa",
            "hour": 12,
            "minute": 50,
            "distance": 2650,
            "category": "Open Playa",
            "gps_latitude": 40.78889359701,
            "gps_longitude": -119.197500385862
        },
        "location_string": "12:50 2650', Open Playa",
        "images": [
            {
                "gallery_ref": 83323,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83323_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DbFJEA0",
        "year": 2016,
        "name": "Pinhole Project",
        "url": "http://pinholeproject.org/about",
        "contact_email": "info@burningman.org",
        "hometown": "San Francisco, CA",
        "description": "The Pinhole Project exposes 30 x 40 inch sheets of light sensitive gelatin silver paper. We work with 12 pinhole cameras, created out of 50-gallon cardboard barrels. This size is uniquely suited for capturing the incredible scale and immense diversity of art and culture at Black Rock City. \r\n\r\nUnder the red safelights of the darkroom, photosensitive paper is inserted into the camera body. Exposures range from 40 to 300 seconds, where concentrated beams of sunlight are funnelled through the pinhole and into the camera, creating a negative image of the recorded subject.\r\n\r\nWe maintain a desert darkroom in a shipping container, where we gather to processes, develop and fix about one hundred photographs each Burning Man. \r\n\r\nWe transport our cameras and crew throughout the city in our trusty BAT.  (Big Ass Truck)  The BAT provides safe and secure transportation of 12 cameras complete with crew and support material.",
        "artist": "Pinhole Project",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "Mobile",
            "hour": null,
            "minute": null,
            "distance": null,
            "category": "Mobile",
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": "Mobile",
        "images": [
            {
                "gallery_ref": 83375,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83375_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DbE6EAK",
        "year": 2016,
        "name": "Cosmic Diamond",
        "url": "http://",
        "contact_email": "brett@llama.li",
        "hometown": "San Francisco, CA",
        "description": "The Cosmic Diamond is a night-time beacon that invites aimless playa wanderers to the deepest depths of deep playa.  A diamond is suspended at the top of the structure and illuminated with several thousand LED lights that create patterns ranging from soothing to nauseating.  The height, size and brightness of the illuminated diamond makes it seems closer than it actually is, creating a fun optical illusion.  Upon arrival, participants can climb into the partially enclosed base of the structure and control the diamond's LED patterns using a series of joysticks in each corner of the pentagonal base.",
        "artist": "Brett McIntosh",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "11:45 5800', Open Playa",
            "hour": 11,
            "minute": 45,
            "distance": 5800,
            "category": "Open Playa",
            "gps_latitude": 40.799015781148,
            "gps_longitude": -119.193759197332
        },
        "location_string": "11:45 5800', Open Playa",
        "images": [
            {
                "gallery_ref": 83333,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83333_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DdGEEA0",
        "year": 2016,
        "name": "Leonardo's Air Service",
        "url": "http://",
        "contact_email": "tangenjeff@gmail.com",
        "hometown": "Port Townsend, WA",
        "description": "Leonardo's Air Service is a replica of Da Vinci's helicopter design.  It will evoke a sense of wonder with its large canvas sail and colorful design. Residents of Black Rock City will be able to enjoy the shade it provides and get to see the city spin around them.",
        "artist": "Disciples of the Dust",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "6:00 700', Open Playa",
            "hour": 6,
            "minute": 0,
            "distance": 700,
            "category": "Open Playa",
            "gps_latitude": 40.785042271276,
            "gps_longitude": -119.208286698594
        },
        "location_string": "6:00 700', Open Playa",
        "images": [
            {
                "gallery_ref": 83362,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83362_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DcgTEAS",
        "year": 2016,
        "name": "Dick Garden Strikes Back",
        "url": "https://www.facebook.com/Dick-Garden-Strikes-Back-1649026915361126/",
        "contact_email": "dickgarden@pocketpony.org",
        "hometown": "Renton, WA",
        "description": "Dick Garden Strikes Back is a triumphant return of the dildo field that got so much attention last year.  It will feature about 200 dildos, planted and growing for the pleasure of all.  The day's harvest will be available at the nearby Farmers Market.",
        "artist": "Art by 3rd",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "10:30 3500', Open Playa",
            "hour": 10,
            "minute": 30,
            "distance": 3500,
            "category": "Open Playa",
            "gps_latitude": 40.795983212014,
            "gps_longitude": -119.206522828924
        },
        "location_string": "10:30 3500', Open Playa",
        "images": [
            {
                "gallery_ref": 83339,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83339_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DctIEAS",
        "year": 2016,
        "name": "IF...",
        "url": "http://",
        "contact_email": "garythisthingimade@gmail.com",
        "hometown": "Ben Lomond, CA",
        "description": "IF... not just what IF, or would of, or could of, or should have,  It's about the idea that once you have thought of something or the idea has been born you shouldn't ignore it . You can't ignore  it . You don't have to do anything about the IF but maybe you should think about the IF some more. WE would like to read about some of the IFs that you have experienced so feel free to write all over it IF you want to",
        "artist": "Gary Esser",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:00 3000', Open Playa",
            "hour": 12,
            "minute": 0,
            "distance": 3000,
            "category": "Open Playa",
            "gps_latitude": 40.792218525216,
            "gps_longitude": -119.198841892756
        },
        "location_string": "12:00 3000', Open Playa",
        "images": [
            {
                "gallery_ref": 83351,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83351_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DhXEEA0",
        "year": 2016,
        "name": "Wish Upon A StarWay",
        "url": "http://www.ddavies.me/starway/",
        "contact_email": "dd@ddavies.me",
        "hometown": "London, United Kingdom",
        "description": "Standing over 15 feet tall, StarWay is a star thrown to earth with two of its points sticking into the earth. It is a star made of over two hundred individually lit stars that twinkle internally, yet glow under a bank of UV light in blue, yellow and green. StarWay twinkles happily in the dark and yet it will twinkle more brightly if you make a wish on it. In order to make a wish on it you need to be in possession of a 'wishing star' that you place on the 'wishing console'. StarWay shows that the more we wish the brighter the world will be.",
        "artist": "Deborah Davies (Dd)",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "8:40 1900', Open Playa",
            "hour": 8,
            "minute": 40,
            "distance": 1900,
            "category": "Open Playa",
            "gps_latitude": 40.789376103075,
            "gps_longitude": -119.212135684813
        },
        "location_string": "8:40 1900', Open Playa",
        "images": [
            {
                "gallery_ref": 83406,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83406_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Did0EAC",
        "year": 2016,
        "name": "Black Rock Observatory",
        "url": "http://www.blackrockobservatory.com/",
        "contact_email": "blackrockobservatory2016@gmail.com",
        "hometown": "Los Angeles, CA",
        "description": "Heading off into deep playa, participants will approach two strange but familiar forms. Maybe a day dream or echo from last year's burn? Drawn to it, the observer will discover structures with astronomical inspirations. Two domes will beckon like a couple of plywood planets. Upon closer exploration, one dome is a gallery abuzz with science and experimentation. In the other, discover a telescope 8 feet tall where Burners can view planets, distant nebula and galaxies.  Outside the domes is the Open Air Planetarium, where eyeballs will fondle naked eye planets, while hands fondle a 4.5 billion year old meteorite. \r\n\r\nA tourist office for the rest of the universe, the secrets of the universe are revealed by powerful mirrors, optics, experiments, art, performances and interactive exhibits.\r\n\r\nThe sphere is the universe's answer to the form problem. Orbs above; orbs below. Echoes of the outer planets, the domes lie in a remote space requiring skills, effort and patience to reach.",
        "artist": "Major Tom Varden and the Desert Wizards of Mars",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:00 5000', Open Playa",
            "hour": 12,
            "minute": 0,
            "distance": 5000,
            "category": "Open Playa",
            "gps_latitude": 40.796097260725,
            "gps_longitude": -119.193735742243
        },
        "location_string": "12:00 5000', Open Playa",
        "images": [
            {
                "gallery_ref": 83320,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83320_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DkKbEAK",
        "year": 2016,
        "name": "Claude the Dragon",
        "url": "https://www.facebook.com/arealfirebreathingdragon?fref=ts",
        "contact_email": "dragonmasterbrc@gmail.com",
        "hometown": "Gridley, CA",
        "description": "Claude the Fire Breathing Dragon is a masterpiece of recycled parts, found art and unique metal and wood features that make it the most unique and interesting dragon on the planet. Claude has animatronics in the head with a movable jaw and fire breathing wonder. Since it took the artist over 30 years to perpetually create what is the current day masterful sculpture - it has evolved slowly, somewhat randomly but to an amazing degree of genius.Viewers often spend hours just looking at all the small to large parts that make up the total sculpture. For instance - recycled shovel heads make up the breast plate for the belly of the dragon! Come out and see for yourself. And often times Gabe the artist or his beautiful daughter will be there to share stories on how and why it came to be!",
        "artist": "Dragon Master",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "7:05 2300', Open Playa",
            "hour": 7,
            "minute": 5,
            "distance": 2300,
            "category": "Open Playa",
            "gps_latitude": 40.785025590833,
            "gps_longitude": -119.214616854157
        },
        "location_string": "7:05 2300', Open Playa",
        "images": [
            {
                "gallery_ref": 83328,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83328_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dmy4EAC",
        "year": 2016,
        "name": "Project Flashlight",
        "url": "http://",
        "contact_email": "pfbeams@gmail.com",
        "hometown": "San Francisco, CA",
        "description": "Project flashlight is the joy of light at grand scale.\r\n\r\nPure, incredibly bright white beams like fingers of god in the dust, contrasts with the night sky, scale across the open playa, interplay of beams, light in motion.\r\n\r\nMilitary and NASA billion-candlepower searchlights, reanimated for art! Interactively controlled by smartphones, tablets and light-saber toys.",
        "artist": "Neal Strickberger",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "2:00 1500', Open Playa",
            "hour": 2,
            "minute": 0,
            "distance": 1500,
            "category": "Open Playa",
            "gps_latitude": 40.785344042435,
            "gps_longitude": -119.201257976174
        },
        "location_string": "2:00 1500', Open Playa",
        "images": [
            {
                "gallery_ref": 83379,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83379_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dn4qEAC",
        "year": 2016,
        "name": "Magic Dance Mirror",
        "url": "https://vimeo.com/155638552",
        "contact_email": null,
        "hometown": "Topanga, CA",
        "description": "The Magic Dance Mirror creates a graphically stylized mirror image of those using it with dynamic animated visuals based on a users movement, audio, and social interactions. The visual experience rewards movement, dance, and dancing together with elaborate real-time animations. The range of possible visuals created by the user is as endless as your possible movements.",
        "artist": "Kyle Ruddick",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:45 3350', Open Playa",
            "hour": 1,
            "minute": 45,
            "distance": 3350,
            "category": "Open Playa",
            "gps_latitude": 40.785218525415,
            "gps_longitude": -119.194486493257
        },
        "location_string": "1:45 3350', Open Playa",
        "images": [
            {
                "gallery_ref": 83368,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83368_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DoC2EAK",
        "year": 2016,
        "name": "The ATM: Automatic Taco Machine",
        "url": "http://",
        "contact_email": null,
        "hometown": "San Francisco, CA",
        "description": "The ATM (Automatic Taco Machine) is your source for on-playa tacos!",
        "artist": "john keddie",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "6:40 1750', Open Playa",
            "hour": 6,
            "minute": 40,
            "distance": 1750,
            "category": "Open Playa",
            "gps_latitude": 40.784367006455,
            "gps_longitude": -119.212230547867
        },
        "location_string": "6:40 1750', Open Playa",
        "images": [
            {
                "gallery_ref": 83393,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83393_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DoEIEA0",
        "year": 2016,
        "name": "Writer's Block",
        "url": "http://",
        "contact_email": "cmdeperro@gmail.com",
        "hometown": "Arcata, CA",
        "description": "This year I was very inspired by the theme. Leonardo da Vinci wrote backwards with his non-dominate hand in most  of his personal journals.  It is unclear as to the exact reason for this behavior, however, it is speculated that he did it to unleash his writer's block and tap into undiscovered portions of his brain. Leo speculated that using his non dominated hand and writing backwards would unleash new creative portions of his brain and therefore push creativity to the ultimate boundaries of the brain. I would like to create a block or canvas for the artist of Black Rock City to exercise and flex this backwards and non dominate creative muscle. The project is  a block like structure with a negative space block (see pictures). Paint pens hang from the ceiling for participants to write on the wooden, primed and painted structure with their non-dominate hand, backwards. From the doorway will hang a sign with a riddle alluding to the directions. The structure will burn.",
        "artist": "Chessalynn Marie",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:15 4400', Open Playa",
            "hour": 1,
            "minute": 15,
            "distance": 4400,
            "category": "Open Playa",
            "gps_latitude": 40.787992976858,
            "gps_longitude": -119.190727897605
        },
        "location_string": "1:15 4400', Open Playa",
        "images": [
            {
                "gallery_ref": 83408,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83408_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DoBxEAK",
        "year": 2016,
        "name": "Global Rolling",
        "url": "http://",
        "contact_email": "kkinosian@gmail.com",
        "hometown": "Mountain View, CA",
        "description": "\"Global Rolling \" (GR) is a wooden globe eight feet in diameter, whose intent is to be a visceral reminder of the world we live in for those who travel to Black Rock City.   \r\n\r\nGlobal Rolling is intended to be rolled around the playa by people power.   It is large enough and slotted so that it will not simply be blown by the wind, but moveable by two or three people working in tandem.   The intent is also allow the globe to freely move around the city.  \r\n\r\nOn Friday evening, a simple burning will occur - no pyrotechnics or affects - just an open flame burn of the World on the open playa.",
        "artist": "Global Rolling Team",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "4:30 4400', Plaza",
            "hour": 4,
            "minute": 30,
            "distance": 4400,
            "category": "Plaza",
            "gps_latitude": 40.774352533462,
            "gps_longitude": -119.206471310128
        },
        "location_string": "4:30 4400', Plaza",
        "images": [
            {
                "gallery_ref": 83346,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83346_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Do6qEAC",
        "year": 2016,
        "name": "BarterDog",
        "url": "http://",
        "contact_email": null,
        "hometown": "Mammoth Lakes, CA",
        "description": "Your exploring the open Playa finding Amazing works of Art and Sculpture, your nostrils catch a whiff of the comforting aroma… Sizzling Hot Dogs. Is your mind playing tricks on you? You keep following your senses and suddenly it appears! A Shaded Bicycle powered Cart with a small BBQ full of Sizzling Hot Dogs, a group of Burners is around it enjoying the works of art they have created out of the Bun & Wiener canvas, piled with sauerkraut onions mustard ketchup relish, how could this be? Some burners search for years and never encounter Hot Dog bliss, believing it only to be a myth. Others fulfill their hot dog destiny Burn after Burn. If your lucky and the Playa Sprits are generous, you Too will become part of this legendary Hot Dog fantasy. BarterDog has been traveling the open Playa since 2002, randomly gifting Playa Dogs to the citizens of BRC. The hard part is finding BarterDog, the Cart never returns to the same spot out on the open Playa \"Enjoy the Journey\"",
        "artist": "BarterDog",
        "category": "Mobile",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "Mobile",
            "hour": null,
            "minute": null,
            "distance": null,
            "category": "Mobile",
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": "Mobile",
        "images": [
            {
                "gallery_ref": 83315,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83315_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DnykEAC",
        "year": 2016,
        "name": "Honey Bear",
        "url": "http://",
        "contact_email": "fnnch@fnnch.com",
        "hometown": "San Francisco, CA",
        "description": "The honey bear is a universal symbol of happiness.",
        "artist": "fnnch",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "6:45 2300', Open Playa",
            "hour": 6,
            "minute": 45,
            "distance": 2300,
            "category": "Open Playa",
            "gps_latitude": 40.783979289042,
            "gps_longitude": -119.214178278566
        },
        "location_string": "6:45 2300', Open Playa",
        "images": [
            {
                "gallery_ref": 83350,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83350_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Do70EAC",
        "year": 2016,
        "name": "Illumicone",
        "url": "http://www.illumicone.com",
        "contact_email": "illumicone@groups.facebook.com",
        "hometown": "Boise, ID",
        "description": "Illumicone is light art driven by participation and interaction. A softly glowing presence draws participants inside, where they encounter strange mechanical widgets. As they play with the widgets, patterns of light appear on the cone, surrounding the participants with a dazzling color spectacle of their own creation and rewarding their curiosity.\r\n\r\nIllumicone is 19 feet tall at its center and 38 feet across at its base.  Cables descending from the top of the cone carry 3600 individually controlled LEDs. Inside the cone are interactive widgets constructed mostly out of repurposed objects. Manipulating the widgets causes patterns of light to appear and move across the LEDs. Spinning wooden wheels causes stripes to move around the cone and collide to create seemingly random combinations of color. Other widgets create sparkles, stain the cone with blotches that expand and disappear, or twist and turn the whole display.",
        "artist": "Ross Butler and Coneheads Local 208",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:20 5900', Open Playa",
            "hour": 1,
            "minute": 20,
            "distance": 5900,
            "category": "Open Playa",
            "gps_latitude": 40.787835035456,
            "gps_longitude": -119.18524808118
        },
        "location_string": "1:20 5900', Open Playa",
        "images": [
            {
                "gallery_ref": 83353,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83353_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DoKpEAK",
        "year": 2016,
        "name": "Black Rock Blind Tiger",
        "url": "https://www.blackrockblindtiger.com",
        "contact_email": "tiffaney@blackrockblindtiger.com",
        "hometown": "Austin, TX",
        "description": "The Black Rock Blind Tiger is a rustic, vintage speakeasy deep within the playa, containing many oddities, gadgets, and alluring objects. Participate, explore & immerse yourself to experience the magic of the Black Rock Blind Tiger. On the outside of this mysterious structure, there are gears at work—rumbling away, while producing delicate gifts. Enjoy the view from the widow's walk, crowned with a charming cupola. Invent your own experience by touching, exploring & playing with all of the intriguing objects. Try gazing into the windows to see the playa past. Explore each of the objects, as some will help keep you warm on those magical, chilly playa nights. Figure out the clues to determine the password which will allow you inside, but keep in mind—all the clues of yesterday will rapidly change to keep the Blind Tiger and its mysteries concealed. Once you've unlocked the pathway to the inside, enjoy the swanky speakeasy, dance to jazz, and receive your own personalized prescription.",
        "artist": "Tiffaney Benson & The Blind Tiger Team",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.indiegogo.com/projects/black-rock-blind-tiger#/",
        "location": {
            "string": "11:37 6800', Open Playa",
            "hour": 11,
            "minute": 37,
            "distance": 6800,
            "category": "Open Playa",
            "gps_latitude": 40.801943704788,
            "gps_longitude": -119.192961323299
        },
        "location_string": "11:37 6800', Open Playa",
        "images": [
            {
                "gallery_ref": 83319,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83319_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DoENEA0",
        "year": 2016,
        "name": "Dark Horse",
        "url": "http://",
        "contact_email": null,
        "hometown": "Oakland, CA",
        "description": "Dark Horse represents Unicorn enlightenment.  About 85% of horses are actually Unicorns, humans just can't see their horns.  This is because Unicorns are vibrating on a higher frequency than humans and the horns are actually beams of light shooting from their third eye.  The light is special and magical and our eyes can't perceive it.  This sculpture aims to change this.  Humans will finally be able to perceive Unicorn horns.",
        "artist": "Liah Hansen",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "6:45 2300', Open Playa",
            "hour": 6,
            "minute": 45,
            "distance": 2300,
            "category": "Open Playa",
            "gps_latitude": 40.783979289042,
            "gps_longitude": -119.214178278566
        },
        "location_string": "6:45 2300', Open Playa",
        "images": [
            {
                "gallery_ref": 83337,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83337_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DkQ4EAK",
        "year": 2016,
        "name": "Berimbau",
        "url": "http://www.brazilianburners.com",
        "contact_email": "brazilianburners@gmail.com",
        "hometown": "Brazil",
        "description": "Berimbau is an extension of an existing art installation, Projeto Mangueira and an adaptation into reflecting more of the Brazilian culture and relating it to the Burning Man theme 2016 - Da Vinci. \r\nBerimbau is a music box that works by spinning. Once it spins, it plays capoeira music by a Brazilian instrument, purest in Brazil's culture; Berimbau -  a single-string percussion instrument, a musical bow, from Brazil. People can walk through the spinning cylinder look at the Brazilian instrument ( there will be 8 of them ) and listen to capoeira music. Capoeira is a system of physical discipline and movement originated among Brazilian slaves, treated as a martial art and dance form.",
        "artist": "Brazilian Burners",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "5:30 1800', Open Playa",
            "hour": 5,
            "minute": 30,
            "distance": 1800,
            "category": "Open Playa",
            "gps_latitude": 40.782127296487,
            "gps_longitude": -119.209744269595
        },
        "location_string": "5:30 1800', Open Playa",
        "images": [
            {
                "gallery_ref": 83316,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83316_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DpCwEAK",
        "year": 2016,
        "name": "Black Rock City (Steal Your) Thunder Co.",
        "url": "http://",
        "contact_email": null,
        "hometown": "New York, NY",
        "description": "Black Rock City (Steal Your) Thunder Co.\r\n\r\nA container full of thunder from the BRC (Steal Your) Thunder Co. is placed deep in the deep playa, designed to add another unpredictable element to a list of weather phenomena that Black Rock City is so famous for. Citizens of Black Rock City may milk its spring-like titty to produce better, louder thunder to use as a soundtrack to whatever's going on around the container.",
        "artist": "Yasha Spektor",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "11:19 6260'",
            "hour": 11,
            "minute": 19,
            "distance": 6260,
            "category": null,
            "gps_latitude": 40.802009413062,
            "gps_longitude": -119.197147182972
        },
        "location_string": "11:19 6260'",
        "images": [
            {
                "gallery_ref": 83321,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83321_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DpBeEAK",
        "year": 2016,
        "name": "Corral of Possibilities",
        "url": "http://",
        "contact_email": "azfairyduster@msn.com",
        "hometown": "Tucson, AZ",
        "description": "Skeleton dogs flying? I thought only pigs did!!",
        "artist": "Candi Carrell",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "6:45 2300', Open Playa",
            "hour": 6,
            "minute": 45,
            "distance": 2300,
            "category": "Open Playa",
            "gps_latitude": 40.783979289042,
            "gps_longitude": -119.214178278566
        },
        "location_string": "6:45 2300', Open Playa",
        "images": [
            {
                "gallery_ref": 83332,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83332_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DpBjEAK",
        "year": 2016,
        "name": "3 Point 2D in 3D",
        "url": "http://",
        "contact_email": "jacbowers@gmail.com",
        "hometown": "Venice, CA",
        "description": "This piece addresses perspective and how that altered reality and art in the Renaissance. The work is a 2 dimensional 3 point perspective drawing of a box that is rendered in 3 dimensions. The box is built with dimensions of the golden section in that it is 3x5x8 and the final piece will be approximately 20 feet in height.\r\n\r\nThe image shows a scale model of the sculpture that will have a 3' x 5' x 8' base. This will have an exterior surface that will allow for graffiti to be placed by viewers. An invitation to comment on the elements of the piece will be displayed on the side of the art work.",
        "artist": "Jack Bowers",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "2:36 1570', Open Playa",
            "hour": 2,
            "minute": 36,
            "distance": 1570,
            "category": "Open Playa",
            "gps_latitude": 40.784065133796,
            "gps_longitude": -119.201732999913
        },
        "location_string": "2:36 1570', Open Playa",
        "images": [
            {
                "gallery_ref": 83312,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83312_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DpBtEAK",
        "year": 2016,
        "name": "Progress",
        "url": "http://",
        "contact_email": null,
        "hometown": "Oakland, CA",
        "description": "Progress represents the questioning of technological advancement in today's post Moore's Law world. The focal point of progress will be a spinning bicycle (the entire bicycle, not just the wheels), held up by a geodesic dome, and powered by two residental sized solar panels. Extra power from the panels will go to USB and 120V plugs for people to plug their varyous technological advances into.\r\nProgress will engage its viewers by creating a space for meditation on the the \"point\" of continuous technological advancement through an utterly useless spinning bicycle. Through this self-reflective process, we hope that people will realize that they don't need to plug in their iphones, and will leave our pointless project in search of internal contentment.",
        "artist": "Borange",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:24 3970', Open Playa",
            "hour": 1,
            "minute": 24,
            "distance": 3970,
            "category": "Open Playa",
            "gps_latitude": 40.78698758642,
            "gps_longitude": -119.192164304809
        },
        "location_string": "1:24 3970', Open Playa",
        "images": [
            {
                "gallery_ref": 83378,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83378_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DpB9EAK",
        "year": 2016,
        "name": "Nicolas Cage in a Cage",
        "url": "http://nicolascageinacage.com",
        "contact_email": "hello@hungrycastle.com",
        "hometown": "Barcelona, Spain",
        "description": "Giant inflatable sculpture of Nicolas Cage in a Cage, this is public interactive art inspired by the Hollywood actor. People of all ages can interact in the bouncy cage, be active and explore their feelings towards Nicolas.",
        "artist": "Hungry Castle",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "8:25 2380', Open Playa",
            "hour": 8,
            "minute": 25,
            "distance": 2380,
            "category": "Open Playa",
            "gps_latitude": 40.789398347461,
            "gps_longitude": -119.214141771742
        },
        "location_string": "8:25 2380', Open Playa",
        "images": [
            {
                "gallery_ref": 83370,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83370_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Doy5EAC",
        "year": 2016,
        "name": "The G String",
        "url": "https://www.facebook.com/theelectricslinky/videos/1089769454422074/",
        "contact_email": null,
        "hometown": "Boise, ID",
        "description": "Illuminated interwoven evolving centripetal sine wave forms dancing in the night.",
        "artist": "Randumb",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "10:30 1200', Open Playa",
            "hour": 10,
            "minute": 30,
            "distance": 1200,
            "category": "Open Playa",
            "gps_latitude": 40.789685672691,
            "gps_longitude": -119.206507826317
        },
        "location_string": "10:30 1200', Open Playa",
        "images": [
            {
                "gallery_ref": 83396,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83396_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dp6xEAC",
        "year": 2016,
        "name": "#Monkey Luck",
        "url": "http://",
        "contact_email": "lazooka@hotmail.com",
        "hometown": "Reno, NV",
        "description": "#Monkey Luck is a sculpture of  the fire monkey seated on his firey  throne. According to Chinese astrology, the  fire monkey (the symbol of luck and audacity) only appears every 60 years. Celebrating 2016 year of the fire monkey. Made by a fire monkey as a gift of luck to all the playateers.",
        "artist": "L.A. Sugai aka gallactic butterfly",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "7:08 1465', Open Playa",
            "hour": 7,
            "minute": 8,
            "distance": 1465,
            "category": "Open Playa",
            "gps_latitude": 40.785627398077,
            "gps_longitude": -119.211698618293
        },
        "location_string": "7:08 1465', Open Playa",
        "images": [
            {
                "gallery_ref": 83311,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83311_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dp8ZEAS",
        "year": 2016,
        "name": "Soul of Man",
        "url": "http://",
        "contact_email": null,
        "hometown": "Fernley, NV",
        "description": "The installation  is a miniature structure of the man where from the outside you can see the Man through the smaller man. From the inside you can view the Man.\r\nMeaning the light stands illuminate the structure or the sole of the art piece and for within each of us a light burns, we in turn are the lights that in circle the Man for without one there is no other.",
        "artist": "Sole of Man              Artist Kioty",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:41 2630', Open Playa",
            "hour": 1,
            "minute": 41,
            "distance": 2630,
            "category": "Open Playa",
            "gps_latitude": 40.785722344974,
            "gps_longitude": -119.197031443993
        },
        "location_string": "1:41 2630', Open Playa",
        "images": [
            {
                "gallery_ref": 83387,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83387_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dp9IEAS",
        "year": 2016,
        "name": "Spacecats",
        "url": "http://",
        "contact_email": null,
        "hometown": "Chicago, IL",
        "description": "Cats and dogs are known to be one of humanity's best companions. For animal guardians, pets play an important role in their lives. Studies have shown owning a pet helps anxiety, depression, stress, lowers blood pressure, and regulates heart rate. As is true with any relationship, some human-pet relationships are likely to be more rewarding than others. Some people are more attached to their pets than others and those feelings could influence the impact of the pet on the person's health and life.\r\n\r\nThe rocketship will have engraved writing dedicating this project to all those who has lost a pet and all the cats who have decided to leave us reminding them they are always with us. \r\n\r\nMy hope is that when people discover this installation out in deep playa, they will be touched with this install reminding them of their lost loved ones and providing humor to all the cat lovers.",
        "artist": "Ayda Keshtkar",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.indiegogo.com/projects/art-installation-for-burning-man-spacecats/x/7414087#/",
        "location": {
            "string": "11:52 7700', Open Playa",
            "hour": 11,
            "minute": 52,
            "distance": 7700,
            "category": "Open Playa",
            "gps_latitude": 40.802335101507,
            "gps_longitude": -119.188265367625
        },
        "location_string": "11:52 7700', Open Playa",
        "images": [
            {
                "gallery_ref": 83388,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83388_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dq3pEAC",
        "year": 2016,
        "name": "Sunrise",
        "url": "http://",
        "contact_email": "iampaulanthony@gmail.com",
        "hometown": "Portland, OR",
        "description": "Play this instrument with your bike.  Find a friend, ride through Sunrise to experience a musical treat that celebrates the beauty we create when we work together.",
        "artist": "Disco Paul & the Corny Camp Collective",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:00 5700', Open Playa",
            "hour": 1,
            "minute": 0,
            "distance": 5700,
            "category": "Open Playa",
            "gps_latitude": 40.790464851758,
            "gps_longitude": -119.186598016607
        },
        "location_string": "1:00 5700', Open Playa",
        "images": [
            {
                "gallery_ref": 83391,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83391_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dq57EAC",
        "year": 2016,
        "name": "Lodo my Lodo",
        "url": "http://",
        "contact_email": "lodo@lord-family.net",
        "hometown": "Oakland, CA",
        "description": "As the Traveler crosses the bleak and glaring desert, she are drawn towards what appears to be date palms by a shimmering pool. Can it be real? Or are the shimmering lights just a Mirage?\r\n \r\nIt soon becomes clear – they have discovered the LoDo. The pool is actually an interactive, life-size, multiplayer game board. Stepping on a square after dark, LoDo comes to life, drawing players to co-operate in games like life-size Pong and Breakout.\r\n \r\nThe assembly consists of 35 pressure sensitive squares illuminated by thousands of LED lights. Players moving over the board trigger reactions in the microprocessor controlled game and sound effects.\r\n\r\nYou are the paddle, your movement over the squares controls the LED field.\r\n  \r\nBy day, the platform is a place to rest, meditate or get married.",
        "artist": "Chris DAndrea and James Lord",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "2:18 950', Open Playa",
            "hour": 2,
            "minute": 18,
            "distance": 950,
            "category": "Open Playa",
            "gps_latitude": 40.785346256721,
            "gps_longitude": -119.20335908276
        },
        "location_string": "2:18 950', Open Playa",
        "images": [
            {
                "gallery_ref": 83365,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83365_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dq5WEAS",
        "year": 2016,
        "name": "StairRamp to Heaven",
        "url": "http://",
        "contact_email": "lysajoy@gmail.com",
        "hometown": "Livermore, CA",
        "description": "This ramp is for the mobility challenged citizens to have access to art cars. It has a steel frame and is covered in wood painted with DaVinci-inspired depictions of mobility challenged dreams, goals, and accomplishments.",
        "artist": "Lysa/Dazzle!",
        "category": "Mobile",
        "program": "Self-Funded",
        "donation_link": "https://www.indiegogo.com/projects/stair-ramp-to-heaven#/",
        "location": {
            "string": "Mobile",
            "hour": null,
            "minute": null,
            "distance": null,
            "category": "Mobile",
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": "Mobile",
        "images": [
            {
                "gallery_ref": 83390,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83390_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dq9sEAC",
        "year": 2016,
        "name": "Elephant Expressions",
        "url": "http://bmelephantproject.com/",
        "contact_email": "info@bmelephantproject.com",
        "hometown": "New York, NY",
        "description": "A large high density foam Elephant painted with white stucco. It will be roughly 10-12 feet tall, depending on the base. It will be lit up from the base by LED lights. \r\nIt will then we decorated by artist on the playa (before the burn starts)  This will be a larger version of the Elephants that we will be letting burners decorate in the gild pavilion under the man.",
        "artist": "Scott London",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "10:15 2000', Open Playa",
            "hour": 10,
            "minute": 15,
            "distance": 2000,
            "category": "Open Playa",
            "gps_latitude": 40.791827979189,
            "gps_longitude": -119.207457046199
        },
        "location_string": "10:15 2000', Open Playa",
        "images": [
            {
                "gallery_ref": 83341,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83341_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DqCXEA0",
        "year": 2016,
        "name": "Let Them Have Light",
        "url": "http://",
        "contact_email": "us@connectionsociety.org",
        "hometown": "Oakland, CA",
        "description": "In the distance the burner sees a form she is familiar with: a gumball machine. But unlike those delight-dispensing fixtures of her past, this one glows with LED lights. Upon closer approach she reads a sign on top - \"Get Lit\", it commands.\r\n\r\nRather than take your money, this machine has a different purpose - to give the much needed resource of light to illumination-starved burners, AKA \"darkwads\". For the meager price of a kind thought, the machine dispenses a personal illumination device in an iconic plastic egg. A tombstone receptacle sits on the side to collect the empty eggs. \r\n\r\nThis piece is an oasis of light in the darkness. From it, individuals carry sparks of light out to the rest of the playa. Metaphorically this depicts the ongoing evolution of human society through individual acts of kindness. Be the light you wish to see in the world, and help others shine too!",
        "artist": "Artopia",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.indiegogo.com/projects/let-them-have-light#/",
        "location": {
            "string": "4:29 2300', Open Playa",
            "hour": 4,
            "minute": 29,
            "distance": 2300,
            "category": "Open Playa",
            "gps_latitude": 40.78010279954,
            "gps_longitude": -119.206412426873
        },
        "location_string": "4:29 2300', Open Playa",
        "images": [
            {
                "gallery_ref": 83364,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83364_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DqLjEAK",
        "year": 2016,
        "name": "The What If? Diner",
        "url": "http://",
        "contact_email": null,
        "hometown": "New York, NY",
        "description": "Ignite your child-like wonderment at the \"What If? Diner.\" The diner will include a towering 8ft tall Jukebox that will light up and invite you to come closer, dangle your feet at our oversized booth, enjoy some treats, and dance. Let your imagination run free, and don't forget to write in our massive \"What If...\" guest book.",
        "artist": "The Whynauts",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:15 4270', Open Playa",
            "hour": 12,
            "minute": 15,
            "distance": 4270,
            "category": "Open Playa",
            "gps_latitude": 40.793533427046,
            "gps_longitude": -119.194265088264
        },
        "location_string": "12:15 4270', Open Playa",
        "images": [
            {
                "gallery_ref": 83412,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83412_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DrLLEA0",
        "year": 2016,
        "name": "chaotick",
        "url": "http://",
        "contact_email": "ember@burningman.org",
        "hometown": "Palo Alto, CA",
        "description": "Inspired by a nineteenth-century German novelty clock, this reliably erratic flaming tetherball swoops and spirals through the Black Rock night: tick ... tick ... keeping exact playa time, more or less.",
        "artist": "Ember aka Larry Breed",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "8:17 750', Open Playa",
            "hour": 8,
            "minute": 17,
            "distance": 750,
            "category": "Open Playa",
            "gps_latitude": 40.787215426365,
            "gps_longitude": -119.208989234703
        },
        "location_string": "8:17 750', Open Playa",
        "images": [
            {
                "gallery_ref": 83326,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83326_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DsjmEAC",
        "year": 2016,
        "name": "BRC Wheels On Meals",
        "url": "http://brcwheelsonmeals.com/",
        "contact_email": "brcwheelsonmeals@gmail.com",
        "hometown": "Livermore, CA",
        "description": "BRC Wheels on Meals is hot meals delivered to your art installation during build week.  We offer 28 varieties including vegetarian, soothing pudding cups and a spork, that you get to keep.  Look for our bright yellow and black banners.  You and your crew will be able to take a break, clean up with our baby wipes, have a meal, and sit in our shaded eating zone. We'll even give you a back rub! We take the garbage when we're done and you can get back to work refreshed and energized. BRC Wheels on Meals. Food coming at you at 5 MPH.",
        "artist": "Dazzle!",
        "category": "Mobile",
        "program": "Self-Funded",
        "donation_link": "https://www.indiegogo.com/projects/brc-wheels-on-meals-2016-extra-days-and-options#/",
        "location": {
            "string": "Mobile",
            "hour": null,
            "minute": null,
            "distance": null,
            "category": "Mobile",
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": "Mobile",
        "images": [
            {
                "gallery_ref": 83324,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83324_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DuPWEA0",
        "year": 2016,
        "name": "JACK",
        "url": "http://www.chromaform.org",
        "contact_email": "martdtaylor1@gmail.com",
        "hometown": "Oakland California",
        "description": "The JACK is a very large inflatable chrome jack. It measures 18' long and 15' across. It contains an airtight bladder filled with helium allowing it to levitate.\r\n\r\nDespite being larger than a small truck, the JACK can be picked up with a single hand, tossed, kicked, or catapulted. It can be balanced atop other structures with improbable whimsy.\r\n\r\nThe Chromaform Collective creates objects of joy and wonder that inspire thought and understanding. By recreating this toy for adults, they hope to encourage adults to rediscover curiosity and play.",
        "artist": "Martin Taylor and Colin Bowring",
        "category": "Mobile",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null,
        "images": [
            {
                "gallery_ref": 83355,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83355_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001E4cLEAS",
        "year": 2016,
        "name": "THE SHOALS GUITAR",
        "url": "http://",
        "contact_email": "josh@partyprosusa.com",
        "hometown": "Florence, Alabama",
        "description": "THE SHOALS GUITAR\r\nIn 2005, I attended a particular art festival held in Black Rock City, Nevada. It was then and there that I had my first unforgettable experience with big art. I got completely enthralled and inspired by the wonderland of elaborate and intricate projects. Year after year, after returning home to Alabama from this Burning Man. I would feel so inspired but unable to take the next step in becoming part of it by creating art of my own. \r\n\r\nThis project is much bigger than just an oversized guitar; this is the beginning of an ongoing effort to generate creativity in my hometown and all over the South. I want to show people that creative thinking and actually creating is easier than one may expect, and eventually get into a position to help them reach their goals; just as you are here to help me with mine. I want to inspire others not only to think creatively, but to get out and do something about it. Help me show others that THEY CAN!",
        "artist": "Josh Johnston",
        "category": null,
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null,
        "images": [
            {
                "gallery_ref": 83411,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83411_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dq5qEAC",
        "year": 2016,
        "name": "Dinner for 12",
        "url": "http://",
        "contact_email": null,
        "hometown": "Portland, OR & San Jose, CA",
        "description": "What might the Last Supper look like if you were to be invited in our industrialized world? The exterior shares statements of thanksgiving to ponder how they may relate to our lives and the lives of those around us.  Greetings and Peace to all.",
        "artist": "Maquette Gann, Art Virgins XPO",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "5:08 990', Open Playa",
            "hour": 5,
            "minute": 8,
            "distance": 990,
            "category": "Open Playa",
            "gps_latitude": 40.783835404407,
            "gps_longitude": -119.207659420052
        },
        "location_string": "5:08 990', Open Playa",
        "images": [
            {
                "gallery_ref": 83340,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83340_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dq5vEAC",
        "year": 2016,
        "name": "swing theory",
        "url": "http://",
        "contact_email": null,
        "hometown": "Portland, OR",
        "description": "A swing set for people to play on.",
        "artist": "Alistair Mackay",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "5:26 1575', Open Playa",
            "hour": 5,
            "minute": 26,
            "distance": 1575,
            "category": "Open Playa",
            "gps_latitude": 40.782588654935,
            "gps_longitude": -119.209164713168
        },
        "location_string": "5:26 1575', Open Playa",
        "images": [
            {
                "gallery_ref": 83392,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83392_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001E66oEAC",
        "year": 2016,
        "name": "Kevin loves you and says hi!",
        "url": "http://",
        "contact_email": null,
        "hometown": "Durham, NC",
        "description": "\"Ken Deemer (who has a dog named Joey and a son named Kevin), Kevin loves you and says hi!\"\r\n\r\nLast year on Burn night we received this note (from a stranger) to pass along (to a stranger) but were unable to identify a Ken Deemer who looked like his dog would be named Joey on that particular evening. This ~6 ft wind sock, made of rip-stop nylon, will be hand-dyed and painted with this message, and mounted securely on a pole on the open playa. With a little playa magic, maybe Ken will see it. If not, we will have tried our best to deliver the words of love entrusted to us.\r\n\r\nThis project interacts directly with one particular Burner, Ken Deemer. However, we hope that many people will consider the Ken Deemers in their own lives when they view this piece.",
        "artist": "Just Some Guys at Bonertown",
        "category": null,
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null,
        "images": [
            {
                "gallery_ref": 83358,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83358_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DpQMEA0",
        "year": 2016,
        "name": "Slap Shack",
        "url": "http://",
        "contact_email": null,
        "hometown": "Detroit, MI",
        "description": "The Slap Shack is an open deli where visitors are invited to give and receive consensual slaps.  You are invited to choose from the menu of styles and intensities, or invent your own.  Come to the a Slap Shack, put on an apron, talk to your patrons, and serve them their slaps!",
        "artist": "BUNGA",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "7:45 900', Open Playa",
            "hour": 7,
            "minute": 45,
            "distance": 900,
            "category": "Open Playa",
            "gps_latitude": 40.786717198762,
            "gps_longitude": -119.2097275821
        },
        "location_string": "7:45 900', Open Playa",
        "images": [
            {
                "gallery_ref": 83385,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83385_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001E5KjEAK",
        "year": 2016,
        "name": "Love Beets Art Support",
        "url": "http://www.lovebeets.org",
        "contact_email": "nakedjen@gmail.com",
        "hometown": "Salt Lake City, UT",
        "description": "The LoveBeets are a worldwide group of self proclaimed Fluffers whose greatest pleasure is to spread love & to really help others wherever they happen to go. We are a very special mobile fluffing group that arrives fresh and ready to relieve workers in various camps & art installations all over the playa by providing their builders with delicious food, water, caffeine, electrolytes, massages, sunblock, building assistance, unloading assistance, hugs, smiles, shade & any other relief we can to lighten everyone's loads and lift everyone's spirits while our love literally BEETS across the playa.\r\n\r\nIf you need our services, contact Nakedjen@gmail.com to pre-register your Art Installation or Camp for fluffing or find us on playa by looking for THE GOLDEN BEET lighted sculpture and the BEET Dome.",
        "artist": "The Love Beets",
        "category": "Mobile",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "Mobile",
            "hour": null,
            "minute": null,
            "distance": null,
            "category": "Mobile",
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": "Mobile",
        "images": [
            {
                "gallery_ref": 83366,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83366_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001E7CSEA0",
        "year": 2016,
        "name": "Scent Wall",
        "url": "http://salvagione.com/works/vessels/",
        "contact_email": null,
        "hometown": "Sausalito, CA",
        "description": "The Scent Wall consists of handmade vessels containing scents made by the artist. The vessels are carefully engineered glass decanters and with a simple touch they emit the requisite measure of scent. The decanters are modest sculptures, their glass essentially transparent. The scents are in liquid form inside the vessels. They are as clear as the glass, and thus bring into question the concept, the purpose, of hue; released as vapor, they all are almost invisible. And finally, aligned in a particular sequence, the decanters tell the story that the smell artist desires to tell.",
        "artist": "Paolo Salvagione",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "6:25 2500', ARTery",
            "hour": 6,
            "minute": 25,
            "distance": 2500,
            "category": "ARTery",
            "gps_latitude": 40.782711441149,
            "gps_longitude": -119.214115648361
        },
        "location_string": "6:25 2500', ARTery"
    },
    {
        "uid": "a2Id0000001E84PEAS",
        "year": 2016,
        "name": "Naked Poetry",
        "url": "http://",
        "contact_email": "amir.yaari@gmail.com",
        "hometown": "Tel-Aviv, AL",
        "description": "Naked poetry is a booth where a poet sits and writes poetry using a typewriter. The installation allows visiting burners to sit down and relax as the poet turns what he sees into poetry. Visitors are than gifted with a poem that was written about them, their friend or an entirely random thing. \r\n\r\nNakedness optional",
        "artist": "Amir Yaari",
        "category": null,
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null
    },
    {
        "uid": "a2Id0000001gxkyEAA",
        "year": 2016,
        "name": "Nymph",
        "url": "http://",
        "contact_email": "randy@plantnyc.net",
        "hometown": "Joshua Tree",
        "description": "\"NYMPH,\" a large welded aluminum and blown glass large flower, 6 x 6 x 5 feet, 300lbs.  Illuminated by LEDs in a computer controlled sequence to attract human pollinators.",
        "artist": "Randy Polumbo",
        "category": null,
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null
    },
    {
        "uid": "a2Id0000001gyxAEAQ",
        "year": 2016,
        "name": "Confessions of the Soul",
        "url": "http://www.aniitrump.com",
        "contact_email": "westburnerbrc@gmail.com",
        "hometown": "Olympia, Wa",
        "description": "What is it people say when they \"Pray to God\"? What are the true confessions of soul that we hide from each other and wear in our hearts?\r\n\r\nIn the \"Confessions of the Soul\" installation, we seek to give participants a chance to explore the deepest confessions of a soul anonymously. \r\n\r\nIn this way we both hope to allow others a secret glimpse into the truest nature of humanity through its most sacred (and profaned) form: vocal utterance. \r\n\r\nWe also hope to give people a chance to not only \"Talk to God\" but be heard by All of His Ears.",
        "artist": "WsetBurner Baptist church",
        "category": null,
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null
    },
    {
        "uid": "a2Id0000001h14EEAQ",
        "year": 2016,
        "name": "Fireflower",
        "url": "http://",
        "contact_email": "hazelmosaic@gmail.com",
        "hometown": "Reno, Nevada",
        "description": "The sculpture FIRE FLOWER consists of a sinuous 12 ft high central stem constructed of rebar wrapped in a complex pattern of overlapping metal segments that gradually taper towards the top. At the pinnacle of this arching stem a large, 5ft diameter glass and steel flower looks down upon the playa, it's flame-colored glass petals radiating from a central boss of brightly lit LED lights. The petals themselves will also be inset with LED lights and programmed with a mind-blowing light show. At intervals along the stem there are steel-wrapped glass leaves in shades of yellow, green and blue.",
        "artist": "Peter Hazel",
        "category": null,
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null
    },
    {
        "uid": "a2Id0000001h15WEAQ",
        "year": 2016,
        "name": "Tulip",
        "url": "http://",
        "contact_email": "hazelmosaic@gmail.com",
        "hometown": "Reno",
        "description": "This is a simple visual piece of an orange Yellow-Eye Rockfish. It shows the beauty to be found in a creature commonly seen as \"ugly.\"  It's smooth, tiled sides are inviting to the touch.",
        "artist": "Peter Hazel",
        "category": null,
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null
    },
    {
        "uid": "a2Id0000001h1fYEAQ",
        "year": 2016,
        "name": "The Secret Library",
        "url": "http://",
        "contact_email": "kai@kaidalgleish.io",
        "hometown": "Oakland, CA",
        "description": "What secrets do you keep bottled inside? What lurks in the hearts of others? A visit to the Secret Library can ease your burden. The Secret Library not only provides a quiet place to weather the storm of blinking lights and and pounding sounds, it also invites visitors to browse the secrets of those around them, and leave their own hidden thoughts and hopes for others.",
        "artist": "Kai",
        "category": null,
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null
    },
    {
        "uid": "a2Id0000001DwRuEAK",
        "year": 2016,
        "name": "You Are Home",
        "url": "http://",
        "contact_email": "brcmiles@yahoo.com",
        "hometown": "Campbell, CA",
        "description": "14-foot high wood GPS locator pin with painted flames on top.\r\nMade of 2x8 wood \"stem\" that is anchored two-feet in ground.  Stem supports 2 four feet diameter plywood sides that attached to stem. \r\n\r\nSatire on cell phone two-dimensional GPS locator \"You Are Here\" pins. Reinforces viewer that they have finally \"arrived\" home and are in the rightful place that they have been seeking.",
        "artist": "Bruce Miles",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "8:20 1750', Open Playa",
            "hour": 8,
            "minute": 20,
            "distance": 1750,
            "category": "Open Playa",
            "gps_latitude": 40.788417046369,
            "gps_longitude": -119.21224054418
        },
        "location_string": "8:20 1750', Open Playa",
        "images": [
            {
                "gallery_ref": 83409,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83409_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DpB4EAK",
        "year": 2016,
        "name": "La Musa de Davinci (The Muses of Davinci)",
        "url": "http://www.musadavinci.tumblr.com",
        "contact_email": "www.castawaycastings@gmail.com",
        "hometown": "Oakland, CA",
        "description": "Da Vinci was a genius  who epitomized the Renaissance humanist ideal. His view of the world was logical rather than mysterious.THE MUSES OF DA VINCI are the muses that inspired the genius of Leonardo. It's a visual opera that explores the ideals of the Renaissance and the divas who influenced Leonardo.The dreams of such creative individuals who see beyond the material world, and can conjure up a new reality, shape our culture and shape our idea of life. Such dreams  inspire millions of people.\r\n\r\nThese visions first begin with the The Muse. The seven muses are:THE NUN who symbolizes The Virgin Mary from the Catholic Faith. LAKSHIMI-who represents The Indigenous Ancient Pagan Religions. LUCREZIA BORGA-embodies the power of Renaissance ruling elite. INANNA-The Influence of Middle Eastern Religions from the opened trade routes. MARS-God of War, from the Roman Era. OKAM-a monk. CATERIANA-who symbolizes Divinci's 3 mothers: Caterina-birth mother, Albiera-2nd mother, Lanfredini-3rd mother.",
        "artist": "elizabeth mallory and mikell haynes",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "4:42 2250', Open Playa",
            "hour": 4,
            "minute": 42,
            "distance": 2250,
            "category": "Open Playa",
            "gps_latitude": 40.780271947973,
            "gps_longitude": -119.207335837111
        },
        "location_string": "4:42 2250', Open Playa",
        "images": [
            {
                "gallery_ref": 83361,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83361_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DpC3EAK",
        "year": 2016,
        "name": "Kimonoasis",
        "url": "http://",
        "contact_email": "smoothripple@hotmail.com",
        "hometown": "San Francisco, CA",
        "description": "Kimonoasis\r\n\r\nThree wooden 'shade trees' & supporting structures form a constellation on the Deep Playa galaxy's outer edge.  Fabric canopies adorn each tree offering a sheltered daytime embrace & an irresistible beacon to Deep Playa Moth Peoples by night. Along the central axis, aligned with Wednesday morning's rising sun, The Haiku Booth marks the eastern counter point.  The shade trees are gathered to evoke casual interaction between visitors, while the Haiku Booth & integral mailbox is set apart to instill a creative breadth in which to write haiku on postcards.  Serving perhaps as a memento of one's adventures or a gift to a loved one, the postcards are themselves a component of a greater 'mailed art' installation now in its 4th year, associated with Kamp Kimono.  The post cards are read aloud at camp (see event board) and later mailed to their designated recipients mid year.  The best of which are bound into books for Kamp Kimono visitors to enjoy throughout the week.",
        "artist": "Mike & Dominika Herrin, Kamp Kimono",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:10 6600', Open Playa",
            "hour": 1,
            "minute": 10,
            "distance": 6600,
            "category": "Open Playa",
            "gps_latitude": 40.789567742276,
            "gps_longitude": -119.183001559408
        },
        "location_string": "1:10 6600', Open Playa",
        "images": [
            {
                "gallery_ref": 83359,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83359_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbQlEAI",
        "year": 2016,
        "name": "The Ascension Pendulum",
        "url": null,
        "contact_email": "taylor.taylor.taylor.tc@gmail.com",
        "hometown": "Austin, TX",
        "description": "The Ascension Pendulum is a blend of architecture and technology that serves to identify the unique touch human interaction represents while illustrating the beauty of the participant's experience. The 34' tall tetrahedron will support a large pendulum capable of drawing intricate patterns into the playa. By capturing the movement of the pendulum, three projectors draw an identical image in light on every side of the structure. This project's goal is not only to put the participant on display, but to involve them in creating a continually changing art piece. The amazing thing about the human element is that it is inherently random and by harnessing this, our project ensures that the same pattern can never be created twice unless by a robot in controlled circumstances. What this means is that each participant will be involved in not only creation, but synthesis, creating something completely new that cannot be replicated which represents each persons individuality in a aesthetically pleasing way.",
        "artist": "Taylor Christensen - Lotus Ranch - Camp Shakin Bacon",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "2:50 1200', Open Playa",
            "hour": 2,
            "minute": 50,
            "distance": 1200,
            "category": "Open Playa",
            "gps_latitude": 40.784292501588,
            "gps_longitude": -119.203170805458
        },
        "location_string": "2:50 1200', Open Playa",
        "images": [
            {
                "gallery_ref": 83009,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83009_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbWKEAY",
        "year": 2016,
        "name": "The Musical Periscope",
        "url": "http://www.themusicalperiscope.com",
        "contact_email": "yulilevtov@gmail.com",
        "hometown": "London",
        "description": "The Musical Periscope is a 30'-wide hexagonal pyramid that transforms the Playa as you know it. Inside the pyramid hangs a periscope that you can pan, zoom, and tilt around your physical surroundings. Whatever the periscope is looking is then turned into unique visuals inside the space. Point the periscope at a starry night sky, the entire pyramid will start to look like the sky, whereas if you point it at the neon horizon, the visuals will become more kaleidoscopic.\r\n\r\nThe Musical Periscope will even be an interactive backdrop for performers such as fire conclaves and poi spinners.\r\n\r\nThe art provides an abstract lens through which people can appreciate the Playa, and creates a feedback loop which not only shapes, but also interprets each participant's adventure through Burning Man. Burners interact with Periscope, and Periscope interacts with the Playa.",
        "artist": "Frogma Art Collective",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "2:20 1500', Open Playa",
            "hour": 2,
            "minute": 20,
            "distance": 1500,
            "category": "Open Playa",
            "gps_latitude": 40.784670876708,
            "gps_longitude": -119.201579811118
        },
        "location_string": "2:20 1500', Open Playa",
        "images": [
            {
                "gallery_ref": 82256,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82256_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2m5EAA",
        "year": 2016,
        "name": "Got Framed",
        "url": "https://www.instagram.com/got_framed",
        "contact_email": "gotframed2015@gmail.com",
        "hometown": "Puerto Rico",
        "description": "Got Framed is a fun & interactive art piece for the making of memories. From afar, it's a life-sized, fabulous frame that captures a notable image in the distance. Up close, it's the ultimate stage to strike a pose on! With ladders on either side & monkey bars across the top, you can let your imagination go wild. Inspired by the artist's Abuela, Rosamelia, in Puerto Rico who turned 91 last year, the design is a Baroque style, gold, beveled frame with 91 roses for Rosamelia, identical on either side. The solid structure and ladders inspire awesome participation, encouraging passersby to BE THE ART. Step up, climb on, take a photograph...'monkey around', change the image, and invite others to join in. Have fun interacting with a large scale art piece and make a memory to take with you.",
        "artist": "NiNO",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:18 1720', Open Playa",
            "hour": 12,
            "minute": 18,
            "distance": 1720,
            "category": "Open Playa",
            "gps_latitude": 40.789174915628,
            "gps_longitude": -119.201474307875
        },
        "location_string": "12:18 1720', Open Playa",
        "images": [
            {
                "gallery_ref": 82286,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82286_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DbEpEAK",
        "year": 2016,
        "name": "The Starfield",
        "url": "https://www.facebook.com/thestarfield/",
        "contact_email": "lhaury@gmail.com",
        "hometown": "Seattle, WA",
        "description": "The Starfield is a 3 dimensional field of light. From afar, viewers see waves and patterns of light move through the space. Inside, viewers experience the waves of light wash over them and see the patterns move and shift all around them. At times, the Starfield beckons participants to play, responding to their location and movement. All the while, it plays relaxing, ambient music, creating a whimsical, calming oasis of light and sound.",
        "artist": "Lane Haury, Lumineer Labs",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:45 1000', Open Playa",
            "hour": 12,
            "minute": 45,
            "distance": 1000,
            "category": "Open Playa",
            "gps_latitude": 40.787452324278,
            "gps_longitude": -119.203161443429
        },
        "location_string": "12:45 1000', Open Playa",
        "images": [
            {
                "gallery_ref": 83399,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83399_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dnz9EAC",
        "year": 2016,
        "name": "Cyclops the Wonder Pony (old school animation)",
        "url": "http://",
        "contact_email": "mcjuice27@yahoo.com",
        "hometown": "Reno, NV",
        "description": "The outer housing is cylindrical, with a wooden top, decorated with horseshoes. On the side of the cylinder is Cyclop's eye, where the citizen will peer thru to witness the horses in motion inside.  Below the eye is Cyclop's mouth, where the citizen will use the teeth to propel the wheel, putting the animation into motion.",
        "artist": "Mike \"Bacon\" Gray, Union Phi",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "6:25 2500', ARTery",
            "hour": 6,
            "minute": 25,
            "distance": 2500,
            "category": "ARTery",
            "gps_latitude": 40.782711441149,
            "gps_longitude": -119.214115648361
        },
        "location_string": "6:25 2500', ARTery",
        "images": [
            {
                "gallery_ref": 83335,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83335_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DijNEAS",
        "year": 2016,
        "name": "Avaricia (Greed)",
        "url": "http://",
        "contact_email": "tofst2ctch@aol.com",
        "hometown": "Capistrano Beach, CA",
        "description": "Throughout history the ruling classes have attracted and utilized the creative genius of the brightest minds to build and preserve wealth and power. In reciprocation the inspired have sought out the wealth and resources of the rich and powerful to realize their dreams. Resulting in some of the most inspirational and destructive forces that the has seen from the time of the Renaissance to present day.",
        "artist": "Marco Minaya, Visiones del Sueño",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "5:20 2200', Open Playa",
            "hour": 5,
            "minute": 20,
            "distance": 2200,
            "category": "Open Playa",
            "gps_latitude": 40.780936004217,
            "gps_longitude": -119.209848986563
        },
        "location_string": "5:20 2200', Open Playa",
        "images": [
            {
                "gallery_ref": 83314,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83314_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DkPLEA0",
        "year": 2016,
        "name": "Concentric Smile",
        "url": "http://",
        "contact_email": "chad.rice.art@gmail.com",
        "hometown": "Fernley, NV",
        "description": "Concentric Smile explores the idea that a slight shift in perspective can greatly alter a person's ability to perceive ideas, beauty, and emotion. This wide range of human perceptions is responsible for much of the disagreement, inequality, and division in our world. Regardless of our individual perspectives, allowing ourselves to stand in a new position can be very eye-opening. Once we understand the viewpoint of others, the answers to our questions become so much clearer.",
        "artist": "Chad Rice",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "4:55 1850', Open Playa",
            "hour": 4,
            "minute": 55,
            "distance": 1850,
            "category": "Open Playa",
            "gps_latitude": 40.781452672348,
            "gps_longitude": -119.207936117251
        },
        "location_string": "4:55 1850', Open Playa",
        "images": [
            {
                "gallery_ref": 83330,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83330_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DkWMEA0",
        "year": 2016,
        "name": "Flow and Wonder",
        "url": "http://www.flowandwonder.com/",
        "contact_email": "gregory.schlomoff@gmail.com",
        "hometown": "San Francisco, CA",
        "description": "Come play with Flow And Wonder! A giant mushroom covered in a thousand color LEDs that you can control with your hands. Watch the beautiful colors glow and flow on the surface of the mushroom as you move your hands.",
        "artist": "Gregory Schlomoff",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "8:40 2300', Open Playa",
            "hour": 8,
            "minute": 40,
            "distance": 2300,
            "category": "Open Playa",
            "gps_latitude": 40.790002616153,
            "gps_longitude": -119.213322209143
        },
        "location_string": "8:40 2300', Open Playa",
        "images": [
            {
                "gallery_ref": 83344,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83344_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dn47EAC",
        "year": 2016,
        "name": "Chicken",
        "url": "http://",
        "contact_email": "budowski@gmail.com",
        "hometown": "Hertzelia, Israel",
        "description": "Step out of reality.\r\nHow far can you go?\r\nRemember the safe word.",
        "artist": "Yaron Budowski",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:13 7250', Open Playa",
            "hour": 12,
            "minute": 13,
            "distance": 7250,
            "category": "Open Playa",
            "gps_latitude": 40.7987837046,
            "gps_longitude": -119.186007214777
        },
        "location_string": "12:13 7250', Open Playa",
        "images": [
            {
                "gallery_ref": 83327,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83327_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DnzJEAS",
        "year": 2016,
        "name": "The Pork Chop Nebula 2.0",
        "url": "http://",
        "contact_email": "porkchopnebula@gmail.com",
        "hometown": "Cordova, AK",
        "description": "So the Art project \"Pork Chop Nebula\" is a concept born from the desire of its creators to build a representation of an Inter-Dimensional Transport Device.  Having the ability transport its passengers to a parallel  universe where unlike our own certain laws that govern our world are turned upside down. A place where silliness trumps sensibility, absurdity overpowers rationality and evolution favors the foolish.",
        "artist": "Proffesor Ballbungie",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "11:52 3850', Open Playa",
            "hour": 11,
            "minute": 52,
            "distance": 3850,
            "category": "Open Playa",
            "gps_latitude": 40.794367909555,
            "gps_longitude": -119.197383777977
        },
        "location_string": "11:52 3850', Open Playa",
        "images": [
            {
                "gallery_ref": 83410,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83410_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DnzsEAC",
        "year": 2016,
        "name": "Flying Kinetic Sculpture",
        "url": "http://",
        "contact_email": "jeff.gollober@gmail.com",
        "hometown": "Woodland, CA",
        "description": "Crafted by aerospace engineer, Jeff Gollober, whose lifelong fascination with the sky and the mechanisms imaginations can place there, compelled him to explore the imaginary line between art and engineering. His belief that \"engineering is the artful application of an exacting science,\" is what this piece is all about. This is art of a new kind, flying illuminated kinetic sculptures!",
        "artist": "Jeff Gollober",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "Mobile",
            "hour": null,
            "minute": null,
            "distance": null,
            "category": "Mobile",
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": "Mobile",
        "images": [
            {
                "gallery_ref": 83345,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83345_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DoGsEAK",
        "year": 2016,
        "name": "Connection Station",
        "url": "http://",
        "contact_email": "aboehnlein@yahoo.com",
        "hometown": "Ann Arbor, MI",
        "description": "The connection station is a place to rest, swing, share, connect, and make new friends, especially if you are feeling  \"lonely in the crowd\".  It is a modified porch swing with colorful graphics encouraging passersby to have a seat and make a new friend.  It is hoped that it will encourage participants at BRC to make new friends and connections.",
        "artist": "Al Boehnlein from Syncytium",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:40 5650', Open Playa",
            "hour": 1,
            "minute": 40,
            "distance": 5650,
            "category": "Open Playa",
            "gps_latitude": 40.785077700902,
            "gps_longitude": -119.186143008465
        },
        "location_string": "1:40 5650', Open Playa",
        "images": [
            {
                "gallery_ref": 83331,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83331_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DoJ3EAK",
        "year": 2016,
        "name": "Pit Stop",
        "url": "http://",
        "contact_email": "deborahcolotti@gmail.com",
        "hometown": "Sebastopol, CA",
        "description": "Hands and arms waving in the air!\r\nWhat do you see? Underarm hair! \r\nA rare and special treat indeed!\r\nProclaiming and celebrating our animal splendor!",
        "artist": "Deborah Colotti",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "3:55 1220', Open Playa",
            "hour": 3,
            "minute": 55,
            "distance": 1220,
            "category": "Open Playa",
            "gps_latitude": 40.783215975381,
            "gps_longitude": -119.205165806536
        },
        "location_string": "3:55 1220', Open Playa",
        "images": [
            {
                "gallery_ref": 83376,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83376_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DoJIEA0",
        "year": 2016,
        "name": "Biggest Little Horseshoe On The Playa",
        "url": "http://",
        "contact_email": "mcjuice27@yahoo.com",
        "hometown": "Reno, NV",
        "description": "Biggest Little Horseshoe on the Playa is an 8 foot tall steel horseshoe with the words \"Good Luck\" proudly stated overhead.  It beckons the passerby to walk thru and receive the good luck wishes of the spirit horse... or possibly a wise crack from the jackass!",
        "artist": "Mike \"Bacon\" Gray, Union Phi",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "6:45 2300', Open Playa",
            "hour": 6,
            "minute": 45,
            "distance": 2300,
            "category": "Open Playa",
            "gps_latitude": 40.783979289042,
            "gps_longitude": -119.214178278566
        },
        "location_string": "6:45 2300', Open Playa",
        "images": [
            {
                "gallery_ref": 83317,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83317_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DpCcEAK",
        "year": 2016,
        "name": "Space Dog",
        "url": "http://www.mtnforge.com",
        "contact_email": "info@mtnforge.com",
        "hometown": "Truckee, CA",
        "description": "Space Dog is 14' tall by 16' long by 5' wide.  It's a collaborative effort between a working blacksmith shop and a mosaic tile artist group.  The steel framework is fabricated using mild steel and hot rivets with a hot dipped galvanizing finish.  The interior has a mosaic tile finish.  The top orbiting three circle antenna is fabricated using 316L stainless steel.  The center connection uses a sealed ball bearing system  to allow the three ovals to spin independently.",
        "artist": "Mountain Forge & Arteclettica",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "4:20 1100', Open Playa",
            "hour": 4,
            "minute": 20,
            "distance": 1100,
            "category": "Open Playa",
            "gps_latitude": 40.783400067285,
            "gps_longitude": -119.206146172785
        },
        "location_string": "4:20 1100', Open Playa",
        "images": [
            {
                "gallery_ref": 83389,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83389_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DpKWEA0",
        "year": 2016,
        "name": "Il Vecchio Stivale",
        "url": "http://",
        "contact_email": "ilvecchiostivale@gmail.com",
        "hometown": "Leucadia, CA",
        "description": "\"Being willing is not enough; we must do.\" And this piece encourages just that. \r\n\r\nDust and more dust. Follows us around all week.\r\n\r\nUntil now. For a fleeting moment you can shine.\r\n\r\nHere, just for you dear dusty burners, Il Vecchio Stivale, a wonder, a miracle, a vision to behold. 2 shaded seats, foot rests and a big box of shoe polish. The rest is up to you: you can get down and polish, talk, improvise, take a nap, gift a shoeshine or ten, watch the sun rise or go down from up on high atop this colorful shoeshine stand made for two.",
        "artist": "Jane",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "11:50 7200', Open Playa",
            "hour": 11,
            "minute": 50,
            "distance": 7200,
            "category": "Open Playa",
            "gps_latitude": 40.801523476298,
            "gps_longitude": -119.189795804248
        },
        "location_string": "11:50 7200', Open Playa",
        "images": [
            {
                "gallery_ref": 83352,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83352_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DpWPEA0",
        "year": 2016,
        "name": "Art Car Bus Stops",
        "url": "http://artcarbusstop.com",
        "contact_email": "wait@artcarbustop.com",
        "hometown": "Los Angeles, CA & Colorado",
        "description": "Two bus stops will be made from two different cities, LA and Denver. The LA bus stop will look like a real LA city bus stop, complete with the ability to tag and also a burner themed commercial poster. The Denver Bus stop will be expertly crafted out of wood and have a winter theme. Our farthest bus stop is a sign post, next to the trash fence, with signs pointing to all the art and landmarks for the lost burner. We have two other bus stops that will be nicely placed for people to rest and engage in a cultural discussion, whereever they get placed.",
        "artist": "Art Car Bus Stop (Ace,Thunk,Dave)",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "11:55 7900', Open Playa",
            "hour": 11,
            "minute": 55,
            "distance": 7900,
            "category": "Open Playa",
            "gps_latitude": 40.802372561027,
            "gps_longitude": -119.187232720267
        },
        "location_string": "11:55 7900', Open Playa",
        "images": [
            {
                "gallery_ref": 83336,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83336_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dq3QEAS",
        "year": 2016,
        "name": "ADT-Art Discovery Tours",
        "url": "http://",
        "contact_email": "lysajoy@gmail.com",
        "hometown": "Livermore, CA",
        "description": "These are public notice signs that establish a starting point for bike tours given by the ARTery team members.  This large pink and black sign will inform participants of the availability, timing and physical direction of bike tours along with additional information on playa-art.  These signs will (hopefully) be co-located with the Art Car Bus Stops which will provide some seating while people wait. Citizens on foot may get lucky if a passing by art car stops and is willing to pick them up.",
        "artist": "Lysa/Dazzle!",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "3:05 2400', Open Playa",
            "hour": 3,
            "minute": 5,
            "distance": 2400,
            "category": "Open Playa",
            "gps_latitude": 40.781562953305,
            "gps_longitude": -119.200625405559
        },
        "location_string": "3:05 2400', Open Playa",
        "images": [
            {
                "gallery_ref": 83313,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83313_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dq3zEAC",
        "year": 2016,
        "name": "Celestial Gears",
        "url": "http://",
        "contact_email": null,
        "hometown": "Vancouver, BC, Canada",
        "description": "The Celestial Gears themselves are a set of 32 interconnected painted wooden gears in the symmetry of a dodecahedron, held in place by a dodecahedral cage. Rotating any one of the 32 gears causes all the rest to rotate. The environment of the Celestial Gears will invite participants into a space to touch and turn the Celestial Gears. Mounted at the center of an icosahedral dome tent, the gears motion will cast moving shadows on the tent walls. By rotating the Celestial Gears in the tent, light and shadow emanating from the center of the Celestial Gear will dance across the translucent walls of the space. Participants will be amazed at the simultaneous motion of all 32 gears, as well as the motion of the shadows on the tent walls.",
        "artist": "Adam Barlev, Symmetry Group Collective",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:55 2950', Open Playa",
            "hour": 12,
            "minute": 55,
            "distance": 2950,
            "category": "Open Playa",
            "gps_latitude": 40.788842330669,
            "gps_longitude": -119.196331157409
        },
        "location_string": "12:55 2950', Open Playa",
        "images": [
            {
                "gallery_ref": 83325,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83325_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dq4YEAS",
        "year": 2016,
        "name": "Da Vinci's Labyrinth",
        "url": "http://",
        "contact_email": null,
        "hometown": "Chadds Ford , PA",
        "description": "Leonardo DaVinci was invited by the king of France to come to his court and create a labyrinth. The project is a participatory rendition of this labyrinth.",
        "artist": "Vickie Manning and Vicki Vinton",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:57 1850', Open Playa",
            "hour": 1,
            "minute": 57,
            "distance": 1850,
            "category": "Open Playa",
            "gps_latitude": 40.785226202826,
            "gps_longitude": -119.19999204399
        },
        "location_string": "1:57 1850', Open Playa",
        "images": [
            {
                "gallery_ref": 83338,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83338_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dr72EAC",
        "year": 2016,
        "name": "Shoot the Moon",
        "url": "http://",
        "contact_email": null,
        "hometown": "Fallon, NV",
        "description": "This is a memorial for Canis lupus.  He has been a burner from the earlier days, he passed away in March 2016.  We want to honor him.  The piece \"Shoot the Moon\" has three meanings, one Canis lupus and his family were avid archers.  Secondly, Canis lupus, his family and friends would play Pinochle together, \"shooting the moon\" as it applies to pinochle is a play that can win the whole game in one hand.  Thirdly, Canis lupus means wolf - the wolf at the bottom of the bow, will be howling at the moon.  \r\n\r\nThe piece is a 10' x 6' x 4'.  The bow is on a rotating base with a wolf howling at the moon under the bow.  The piece is made from scrap metal from various family ranches.  The tip of the arrow, the feathers, and the wolf's eye are made of copper by a fellow burner.",
        "artist": "Nevada Springers",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "5:00 2300', Open Playa",
            "hour": 5,
            "minute": 0,
            "distance": 2300,
            "category": "Open Playa",
            "gps_latitude": 40.780314084979,
            "gps_longitude": -119.208638023433
        },
        "location_string": "5:00 2300', Open Playa",
        "images": [
            {
                "gallery_ref": 83382,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83382_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DtMlEAK",
        "year": 2016,
        "name": "Creative Cauldron",
        "url": "https://docs.google.com/document/d/1MLpaJaU9jnhNhSX-5bOefAs7-rCK0lrjg1smODjt-lQ/edit?usp=sharing",
        "contact_email": "fireinsideart@gmail.com",
        "hometown": "Carson City, Nevada",
        "description": "A solid wooden sculpture stands 10 feet tall x 8 foot thick, carved to a luster from a massive tree stump. It’s a carved depiction of The Man's head lit up in carved flames -- and the Firemeister will light a real fire, boring down into those chiseled flames to complete the sculpture, It's a Fire Inside performance designed to survive the playa! Participants ascend a wobbly orchard ladder to tend the wooden cauldron of fire crackling deep into the carving. From the rim they will drive or suppress the flames with water and Burner breath, both through copper tubes as Firemeister Timeless barks! The fire will be visible across the playa so watch for it mid to late week, right up close to the temple on 12:00 ... as the driving winds permit...",
        "artist": "Timeless and the Guardians of Liberty",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:42 1985', Open Playa",
            "hour": 12,
            "minute": 42,
            "distance": 1985,
            "category": "Open Playa",
            "gps_latitude": 40.78861940298,
            "gps_longitude": -119.199947343683
        },
        "location_string": "12:42 1985', Open Playa",
        "images": [
            {
                "gallery_ref": 83334,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83334_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbUKEAY",
        "year": 2016,
        "name": "Seeing humanity for what it really is",
        "url": null,
        "contact_email": null,
        "hometown": "Montréal, Québec, Canada",
        "description": "This artwork consists of two massive gorillas in different lifelike poses wearing wings inspired by Leonardo da Vinci's sketches of flying machines.  \r\nThe pieces have a wooden armature. The wings will be in wood. The details of the work are made out of cardboard that the artist wraps and glues around the armature to give it it's realistic look. The cardboard is recuperated from stores and recycling bins. The animals will be disposed in a way that people can walk between them.",
        "artist": "Laurence Vallières",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "5:55 1500', Open Playa",
            "hour": 5,
            "minute": 55,
            "distance": 1500,
            "category": "Open Playa",
            "gps_latitude": 40.78336687332,
            "gps_longitude": -119.210157297205
        },
        "location_string": "5:55 1500', Open Playa",
        "images": [
            {
                "gallery_ref": 82911,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82911_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbUKEAY.mp3"
    },
    {
        "uid": "a2Id0000000cbZiEAI",
        "year": 2016,
        "name": "Celestial Mechanica",
        "url": "http://www.celestial-mechanica.org",
        "contact_email": null,
        "hometown": "San Francisco, CA",
        "description": "Celestial Mechanica is a glimpse of our solar system that is only allowed by means of an artistic lens that we are providing for you. Because of the massive scale of our solar system it is very difficult to imagine what all of it looks like working together as one. Celestial Mechanica will allow us this privilege. From a distance it may not be clear what we are looking at but as we approach it becomes instantly clear what this is. First we step into a loosely fenced area that is for pedestrians only where all of the Gas Giants are whirling above us. As we get closer to the Sun we can see the Rocky Planets at eye level spinning around their orbits around the Sun. It is now time to step up onto the catwalk via 4 staircases that lead up to an elevated walking area where we can really view the complex mechanics, feel the heat from the Sun's fire effect and see the orbiting Rocky Planets, now slightly below us and separated by a handrail so that we do not disturb their delicate orbits.",
        "artist": "Jessika Welz",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "11:45 830', Open Playa",
            "hour": 11,
            "minute": 45,
            "distance": 830,
            "category": "Open Playa",
            "gps_latitude": 40.788205447696,
            "gps_longitude": -119.204677044041
        },
        "location_string": "11:45 830', Open Playa",
        "images": [
            {
                "gallery_ref": 82972,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82972_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbZiEAI.mp3"
    },
    {
        "uid": "a2Id0000000d2k5EAA",
        "year": 2016,
        "name": "Dragon Smelter Coin Press",
        "url": "http://www.macreativedesign.com/public/bm.html",
        "contact_email": "danny1mac@sbcglobal.net",
        "hometown": "San Francisco, CA",
        "description": "The alchemists are in action, turning waste and scrap into gold! The Dragon Smelter Coin Crew is back, and will be smelting and helping participants create their own coin from 100% recycled material. This on playa workshop features all the tools, materials and guidance you need to recycle scrap aluminum into a coin, featuring yearly unique sculpted imagery. Proper training for all participants of any age included. Sick of coinage, currency and commodification? Necklace making materials also provided.",
        "artist": "Daniel Macchiarini and The Dragon Smelter Crew",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "6:30 130', Man Pavilion",
            "hour": 6,
            "minute": 30,
            "distance": 130,
            "category": "Man Pavilion",
            "gps_latitude": 40.786221469431,
            "gps_longitude": -119.206906706809
        },
        "location_string": "6:30 130', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82936,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82936_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbOBEAY",
        "year": 2016,
        "name": "Fractal Rock",
        "url": null,
        "contact_email": null,
        "hometown": "Fremont, CA",
        "description": "For centuries, people have claimed that math is the language of the universe. It has been used to describe phenomena both comprehensible and absolutely unfathomable. Math can also be descriptive of patterns that people find mesmerizing and beautiful.\r\nFractal Rock is a sculpture built using fractal math. The artist team of Pooja Shah and Stijn van der Linden created the shape using custom software and equations, methods seemingly so rigid, to create its fluid, organic shape. It appears as a twisting ebony helix that looks like it has risen from the earth.\r\nThe team is passionate about math, mathy art, and using technology to build complex shapes, among other things.",
        "artist": "Pooja Shah and Stijn van der Linden",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": "https://www.indiegogo.com/projects/fractal-rock-math-sculpture-for-burning-man-2016#/",
        "location": {
            "string": "9:07 1900', Open Playa",
            "hour": 9,
            "minute": 7,
            "distance": 1900,
            "category": "Open Playa",
            "gps_latitude": 40.790289997184,
            "gps_longitude": -119.211062354409
        },
        "location_string": "9:07 1900', Open Playa",
        "images": [
            {
                "gallery_ref": 82827,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82827_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbOBEAY.mp3"
    },
    {
        "uid": "a2Id0000000dAICEA2",
        "year": 2016,
        "name": "The Orca Project",
        "url": "https://www.facebook.com/orcaproject/",
        "contact_email": "erikmre76@gmail.com",
        "hometown": "Vancouver B.C., Canada",
        "description": "The Orca project is a large-scale sculptural installation of a pod of orcas travelling through the ocean. Constructed out of wood, the pod of orcas invites participants to walk amongst them, to climb on them and to listen to their sounds.  The intent is for participants to ponder our own relationship to family, community, animals and the natural world while raising awareness about the declining population of orcas in the Pacific North West.",
        "artist": "Erik More",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "11:00 1400', Open Playa",
            "hour": 11,
            "minute": 0,
            "distance": 1400,
            "category": "Open Playa",
            "gps_latitude": 40.790104450691,
            "gps_longitude": -119.205198402567
        },
        "location_string": "11:00 1400', Open Playa",
        "images": [
            {
                "gallery_ref": 82962,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82962_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DpudEAC",
        "year": 2016,
        "name": "The Stoop",
        "url": "http://",
        "contact_email": "kaitlin.hellier@gmail.com",
        "hometown": "Santa Cruz, CA",
        "description": "The Stoop is a community gathering place where you can meet new people, remember those no longer with us, or reflect on experiences from Black Rock City and beyond. With stairs facing the city and sunset, it is the perfect place to watch the world go by. The bar below serves sporadically, bringing groups together and refreshing those wandering the playa.",
        "artist": "HellKat",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "11:40 3590', Open Playa",
            "hour": 11,
            "minute": 40,
            "distance": 3590,
            "category": "Open Playa",
            "gps_latitude": 40.794461897181,
            "gps_longitude": -119.199071869154
        },
        "location_string": "11:40 3590', Open Playa",
        "images": [
            {
                "gallery_ref": 83400,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83400_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbQHEAY",
        "year": 2016,
        "name": "Dreams of Flight",
        "url": null,
        "contact_email": "michael.c.gard@gmail.com",
        "hometown": "San Francisco, CA",
        "description": "Two near-human scaled wire figures. Constructed of handwoven aluminum wire. Each with 120 high intensity LED lights illuminating every inch of wire.\r\nFloating above the playa, suspended below large helium balloons, which often disappear against the night sky.\r\nWhatever meaning the viewer brings will have to suffice. Typical comments involve beauty, wonder and uniqueness.",
        "artist": "Michael Gard",
        "category": "Mobile",
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "Mobile",
            "hour": null,
            "minute": null,
            "distance": null,
            "category": "Mobile",
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": "Mobile",
        "images": [
            {
                "gallery_ref": 83008,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83008_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbZxEAI",
        "year": 2016,
        "name": "Automata Equis",
        "url": null,
        "contact_email": null,
        "hometown": "Oakland, CA",
        "description": "From the back of a horse one becomes a spectator  of their surroundings. Their placement is frequented by many but distant enough they emerge unexpectedly from a sudden whiteout. They are along the way to a desired destination but only increase anticipation as their constant trudging leads nowhere.",
        "artist": "Equis Collective",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://connect.clickandpledge.com/Organization/burningmanproject/campaign/automataequis",
        "location": {
            "string": "2:30 1800', Open Playa",
            "hour": 2,
            "minute": 30,
            "distance": 1800,
            "category": "Open Playa",
            "gps_latitude": 40.783943305367,
            "gps_longitude": -119.200857129655
        },
        "location_string": "2:30 1800', Open Playa",
        "images": [
            {
                "gallery_ref": 82856,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82856_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbZxEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbTLEAY",
        "year": 2016,
        "name": "The MechaGator",
        "url": "http://www.swamprocket.com",
        "contact_email": "owligatorman@gmail.com",
        "hometown": "New Orleans, LA",
        "description": "The MechaGator is New Orleans' own big beautiful flaming hot Kaiju creature. She is a fully interactive puppet made of steel and upcycled junk and is the protector of the swamp.",
        "artist": "Ryan S. Ballard",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "8:55 2050', Open Playa",
            "hour": 8,
            "minute": 55,
            "distance": 2050,
            "category": "Open Playa",
            "gps_latitude": 40.790184511655,
            "gps_longitude": -119.211975044233
        },
        "location_string": "8:55 2050', Open Playa",
        "images": [
            {
                "gallery_ref": 82352,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82352_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbTLEAY.mp3"
    },
    {
        "uid": "a2Id0000001DoRHEA0",
        "year": 2016,
        "name": "blue lotus",
        "url": "http://",
        "contact_email": "brad.bao@gmail.com",
        "hometown": "San Jose, CA",
        "description": "The 2016 Man will see a beautiful \"Blue Lotus,\" designed and built by Blue Lotus Camp, blossoming on playa with its unique oriental charm together with modern minimalistic taste. Standing 12 feet tall in the sandstorm is a structure, 50 feet in diameter, made of freshly cut green bamboo,wood, and fabric. Its bamboo pistils with long flags on top will wave to the Man in the distance, its 12 PVC framed and fabric covered petals will undulate with roaring wind by its side, its far visible LED-lit figure will warm home-goers' hearts at night. Representing the harmony of heaven and human, \"Blue Lotus\" will integrate the Burning Man spirit seamlessly with the Black Rock Desert environment and provide eye candy to our fellow brothers and sisters, and at the same time, bring tranquility and peace to this land that we love.",
        "artist": "Brad Bao, Tao Xie, Ou Lin",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:08 1300', Open Playa",
            "hour": 12,
            "minute": 8,
            "distance": 1300,
            "category": "Open Playa",
            "gps_latitude": 40.788740018628,
            "gps_longitude": -119.202957431964
        },
        "location_string": "12:08 1300', Open Playa",
        "images": [
            {
                "gallery_ref": 83322,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83322_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbOmEAI",
        "year": 2016,
        "name": "Ursa Major",
        "url": "https://www.facebook.com/Mr-and-Mrs-Ferguson-Art-434710516694820/",
        "contact_email": "lisa@lisa-and-camera.com",
        "hometown": "Alameda, California",
        "description": "Reaching to grab what is within her grasp is Ursa Major, a 14 foot tall, grizzly bear sow. She may simply be reaching for berries but perceivably she is reaching higher: to the northern sky and the constellation that is her name, Ursa Major. In navigation, the constellation is useful in pointing the way to the North Star. \r\nUrsa Major's pose is inspiring, she brings the gaze and hopes of the participant skyward. She also demonstrates respect for the bears and nature, her pose is not like a taxidermy bear. She is in her natural state and unthreatening. \r\nWith a durable, unique material that was used on their previous Burning Man project (Penny the Goose), Ursa Major's fur will be made of US and Canadian pennies. The pattern and feel will be like fur.",
        "artist": "Mr and Mrs Ferguson",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "6:15 1250', Open Playa",
            "hour": 6,
            "minute": 15,
            "distance": 1250,
            "category": "Open Playa",
            "gps_latitude": 40.784311515747,
            "gps_longitude": -119.210081151261
        },
        "location_string": "6:15 1250', Open Playa",
        "images": [
            {
                "gallery_ref": 82917,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82917_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbOmEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbYVEAY",
        "year": 2016,
        "name": "Peace Pavillion",
        "url": null,
        "contact_email": "majangles@gmail.com",
        "hometown": "Seattle, WA",
        "description": "The Peace Pavilion is an octagonal wood shade structure conceived by Orca Moon a 12 year old artist and built by Disciples of the Dust.  There are 8 pillars and a prayer wheel on each post.  The prayer wheels have inspiring words of peace, love, kindness and blessings written in different languages.  \r\nPowerful artwork by Orca Moon is painted on the structure.  The mandalas and designs are of the colors  red, orange and gold.  Burners can interact by spinning the wheels as they walk around the structure, releasing powerful energy waves of kindness and compassion.  Lit inside and on the posts, lights shine up from each pillar at night symbolizing the feelings of good will and love being released to the Universe. Participants can gather under the shade.  \r\nIn the center of the pavilion is a Buddha created in both the feminine, masculine, animal and insect representing the God in all of us.  It is made of wood, metal and has mirrors around its body.",
        "artist": "Orca Moon & Disciples of the Dust",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "4:30 1400', Open Playa",
            "hour": 4,
            "minute": 30,
            "distance": 1400,
            "category": "Open Playa",
            "gps_latitude": 40.782566715193,
            "gps_longitude": -119.206490870275
        },
        "location_string": "4:30 1400', Open Playa",
        "images": [
            {
                "gallery_ref": 82180,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82180_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbNuEAI",
        "year": 2016,
        "name": "Horizon Lines",
        "url": null,
        "contact_email": "tylerbuckheim@gmail.com",
        "hometown": "Key West, FL",
        "description": "At first look Horizon Lines appears to be a cluster or 'forest' of twenty five wooden posts rising out of the Playa. The top portion of the posts are painted black, with a golden line between the black and raw wood sections and the sides of each post painted to a different level. When Participants come to the properly marked location looking directly North, South, East or West at the sculpture, the painted portions visually align with the horizon or mountain range behind it. The golden stripe  creates a gilded horizon line. The moment the paint on each post and the natural backdrop line up, you will see the optical illusion of the merging of the foreground and background to make one whole image.",
        "artist": "Tyler Buckheim",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "12:30 4000', Open Playa",
            "hour": 12,
            "minute": 30,
            "distance": 4000,
            "category": "Open Playa",
            "gps_latitude": 40.79189255031,
            "gps_longitude": -119.193984875518
        },
        "location_string": "12:30 4000', Open Playa",
        "images": [
            {
                "gallery_ref": 82831,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82831_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbNuEAI.mp3"
    },
    {
        "uid": "a2Id0000001hBSEEA2",
        "year": 2016,
        "name": "Reverse Image Paintings",
        "url": "https://artrevolution.com/wizardsky",
        "contact_email": "rikwiz@gmail.com",
        "hometown": "Forestville CA.",
        "description": "The painting is called the naked lady fairy as she is sitting on a pile of 'naked lady flowers. \nSince these pieces are on upcycled window frames it my desire to help people understand that beauty can be made from so many discarded items and that objects have a life of their own. The interaction is above all the messages of utility and utilization realization but each of the three have hinges so that people can turn the paintings over and see the back side of the painting to see how the process works...please be gentle. as there is potentially 70 thousand people that want to open these doorways. I say door ways as I see using windows as a way for others to see into the reality that I am creating out of my imagination.",
        "artist": "Richard Wizardsky",
        "category": null,
        "program": null,
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null
    },
    {
        "uid": "a2Id0000001hCGtEAM",
        "year": 2016,
        "name": "Souconna s garden",
        "url": "http://",
        "contact_email": "artesus@gmail.com",
        "hometown": "Miami",
        "description": "Is a six piece illustrated story  inspaired by love and the journey to have the joy of love .the name of the piece is Souconnas garden .wich tells the story of Souconna the river goddess from France and her journey to find her own  divinity refelected on  the sweet and hard moments of her journey thru live and death.\n\nis to be hang at the center camp art gallery, each piece is 12inches by 12 inches square pieces.the Wall space require for it will be 6 feet long by 3 feet wide.",
        "artist": "Angelov Franco",
        "category": null,
        "program": null,
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null
    },
    {
        "uid": "a2Id0000000cbQbEAI",
        "year": 2016,
        "name": "DaVinci Virus",
        "url": "https://www.behance.net/gallery/31467045/Davinci-Virus-BRC-Honoraria-2016-LOI",
        "contact_email": "steelebrennan0@gmail.com",
        "hometown": "New Orleans, LA",
        "description": "Visually the installation represents a giant diabolical clockwork bacteriophage infecting the playa or planet. Symbolically the installation represents the connection between people, technology, and the environment.",
        "artist": "Brennan Steele",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "8:45 2100', Open Playa",
            "hour": 8,
            "minute": 45,
            "distance": 2100,
            "category": "Open Playa",
            "gps_latitude": 40.789891950142,
            "gps_longitude": -119.21253351502
        },
        "location_string": "8:45 2100', Open Playa",
        "images": [
            {
                "gallery_ref": 82392,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82392_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbQbEAI.mp3"
    },
    {
        "uid": "a2Id0000000wlyZEAQ",
        "year": 2016,
        "name": "NEON ANGEL WINGS",
        "url": "http://",
        "contact_email": null,
        "hometown": null,
        "description": "As the night begins, a truly majestic pair of multi-colourful Neon Angel Wings appear to hover way in the distance. Summoning you to come closer and closer; Burners will have a heavenly opportunity for a moment in time to ‘wear’ the magnificent Wings.   \r\nFor some it will be a spiritual experience as the Neon Angel Wings bring enlightenment, love, a sense of flight, purity of spirit and freedom.  \r\n\r\nThe Neon Angel Wings will have flown over from Australia and are made from LED Neon Flex; a revolutionary replacement for glass neon and have a wing span of 4 meters(13 feet).",
        "artist": null,
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "9:30 2200', Open Playa",
            "hour": 9,
            "minute": 30,
            "distance": 2200,
            "category": "Open Playa",
            "gps_latitude": 40.791611205681,
            "gps_longitude": -119.210490637328
        },
        "location_string": "9:30 2200', Open Playa"
    },
    {
        "uid": "a2Id0000001DjwUEAS",
        "year": 2016,
        "name": "Tomb of the Unknown Unfinished Playa Art Project (aka TUUPAP)",
        "url": "http://tuupap.org",
        "contact_email": "billgilman@yahoo.com",
        "hometown": "Long Beach, CA",
        "description": "Honoring past projects that have (or almost, or never) graced the playa... we are providing a space for you to bring your albatross project, concept drawings or half-finished never-to-be partial executions of art designed to live on playa.  This includes past art that has previously lived on playa, we subscribe to the idea that \"nothing is finished, nothing is perfect, everything is temporary.\"  \r\n\r\nOn Sunday morning of Temple burn day, we will burn the things that are able to be burned in a ceremony designed for a group catharsis and cleanse.  All are welcome.  No plastic, predominantly metal or electrical elements will be burned, although those are welcome to join the exhibition.\r\n\r\nCome shed that thing you sunk so much love, treasure, and psychic energy into, but know you've grown beyond.  Check out tuupap.org for more information or call Massive at 323-428-0913.  Questions encouraged!",
        "artist": "Massive",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.kickstarter.com/projects/billgilman/the-tomb-of-the-unknown-unfinished-playa-art-proje",
        "location": {
            "string": "12:01 5200', Open Playa",
            "hour": 12,
            "minute": 1,
            "distance": 5200,
            "category": "Open Playa",
            "gps_latitude": 40.796397026606,
            "gps_longitude": -119.193109355094
        },
        "location_string": "12:01 5200', Open Playa",
        "images": [
            {
                "gallery_ref": 83401,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83401_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001h164EAA",
        "year": 2016,
        "name": "red",
        "url": "http://",
        "contact_email": "mtaluc@yahoo.com",
        "hometown": "portland",
        "description": "Red is a testament to the power of the wind out here.  With over 150 yards of fabric, one can feel, hear, and see its presence through this tower.",
        "artist": "michael taluc",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "9:50 1910', Open Playa",
            "hour": 9,
            "minute": 50,
            "distance": 1910,
            "category": "Open Playa",
            "gps_latitude": 40.791311056445,
            "gps_longitude": -119.208874240761
        },
        "location_string": "9:50 1910', Open Playa"
    },
    {
        "uid": "a2Id0000001E3KcEAK",
        "year": 2016,
        "name": "Oriflamme",
        "url": "http://",
        "contact_email": "brysonwallen56@hotmail.com",
        "hometown": "San Diego",
        "description": "The Da Vinci inspired piece, \"Oriflamme\", invites onlookers to enjoy the mesmerizing flame effects while soaking up some warmth before venturing further into the playa.",
        "artist": "Bryson Allen",
        "category": null,
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null,
        "images": [
            {
                "gallery_ref": 83372,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83372_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001hBOlEAM",
        "year": 2016,
        "name": "Rinascita - Renaissance - ReBirth",
        "url": "http://",
        "contact_email": "pinisiluk@gmail.com",
        "hometown": "Tel Aviv + Jerusalem",
        "description": "The Piece will shape as a circle inside a square build out of red wood.\n\nthe interior will look like the red room from the Uffizi Gallery in Florence and it will contain framed portraits of the heroes of the renaissance.\nThe works will be printed on canvas streched on ply wood and framed with golden moldings.\nthe circle diameter will be  24 feet.\n\nIt will be light up by Solar spot lights so you can see the show day and night \nI will put a circle table in the center of it and on it will be a huge diary book with pencils so the people of the playa could write what ever they want  for these heroes:\n\nDante, Giotto, Brunelleschi, Ghiberti, Botticelli with Venus,\nMichelangelo, Leonardo de Vinci, Titian, Giorgio Vasari, Albrecht\nDurer, Jan van Eyck, Lorenzo De Medici & Savonarola.",
        "artist": "Moses Pini Siluk",
        "category": null,
        "program": null,
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null
    },
    {
        "uid": "a2Id0000001gtfrEAA",
        "year": 2016,
        "name": "The Lost Tea Party",
        "url": "http://www.facebook.com/LostTeaParty/",
        "contact_email": null,
        "hometown": "Petaluma, CA",
        "description": "The Lost Tea Party is a large scale caravan of tea pots that from a distance look to be a caravan of camels, like a mirage appearing in the desert.  Participants are welcomed into a cozy atmosphere where people can come together from different cultures in a space that is unique for meeting new friends, having conversations, and sipping tea in a one-of-a-kind setting.",
        "artist": "Wreckage International",
        "category": null,
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null,
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000001gtfrEAA.mp3"
    },
    {
        "uid": "a2Id0000001Dp6EEAS",
        "year": 2016,
        "name": "Reflection Tree",
        "url": "http://",
        "contact_email": null,
        "hometown": "Somerville, MA",
        "description": "Reflection Tree condenses the most colorful movements on the horizon and condenses them onto the trunk with the past representations reaching toward the sky.",
        "artist": "David Fisher",
        "category": "Art in Camp",
        "program": null,
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null,
        "images": [
            {
                "gallery_ref": 83381,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83381_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001hDLeEAM",
        "year": 2016,
        "name": "This too shall pass",
        "url": "http://lekhawashington.com/art/this-too-shall-pass/",
        "contact_email": "lekhawashington@gmail.com",
        "hometown": "Mumbai, Maharashtra, India",
        "description": "This Too Shall Pass\n\n Created by Lekha Washington, four gigantic moon like forms float high into the atmosphere implying the possibilities of living in other worlds. Speaking of the various phases we go through, and how things can sometimes be other that what we imagine them to, this piece is playful with it's continuous movement with the elements as well as an unmissable anchor point- unless, ofcourse, it moves, making everything a little more surreal.",
        "artist": "Lekha Washington",
        "category": null,
        "program": null,
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null
    },
    {
        "uid": "a2Id0000000cbQqEAI",
        "year": 2016,
        "name": "Chronosydra",
        "url": "https://www.facebook.com/chronosydra/",
        "contact_email": null,
        "hometown": "San Francisco, CA",
        "description": "Chronosydra is a reverse hourglass that runs for the week of Burning Man 2016. An abstract timepiece for Black Rock City, it sits deep in the playa awaiting your discovery. The hourglass is filling upwards with small particulates that float unhurriedly from bottom to top chamber; its translucent pellets catch the sunlight during the day and swirl like fireflies when LED lit at night. Like a meter that measures the growing creativity and energy around it, this hourglass fills steadily over the length of the event and stands full at exodus; full like an hourglass that has just been turned over, full like time itself has been turned back. Chronosydra is an art piece that mirrors the week-long transformation of Black Rock City, and playfully reflects on the way in which our time at Burning Man may reset, revivify, and refill us if we let it.",
        "artist": "Kate Greenberg and Dust Crusaders",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://www.indiegogo.com/projects/chronosydra-burning-man-2016--3/x/7136542#/",
        "location": {
            "string": "12:05 1800', Open Playa",
            "hour": 12,
            "minute": 5,
            "distance": 1800,
            "category": "Open Playa",
            "gps_latitude": 40.789736106353,
            "gps_longitude": -119.201708538714
        },
        "location_string": "12:05 1800', Open Playa",
        "images": [
            {
                "gallery_ref": 82844,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82844_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbQqEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbUxEAI",
        "year": 2016,
        "name": "Imago",
        "url": "http://www.kirstenberg.com",
        "contact_email": "kberginfo@gmail.com",
        "hometown": "Berkeley, CA and SE Asia",
        "description": "Blue mirror-steel butterflies hover 17 ft over the desert, wings lifted as if just alighted, yet ready for takeoff. Stepping beneath the delicately-perforated, arching wingspan, vivid blue light scatters, encircling us in a vaulted, luminous space of geometric patterns/reflections. \"Imago\" holds a space, in structure and feeling, that is light and uplifting, like an intimate temple or futuristic shrine.\r\nThe elevated butterflies are easily-resonant metaphors for the transformative experiences that compel so many migrations to Burning Man: immersion into a place of imagination, to be renewed, transformed. \r\nButterfly metamorphosis mirrors our Playa experiences: intense preparations, followed by the suspension of mundane life, to immerse into a dreamlike space that is safe-yet-undefined, full of potential. When the time of cocooning is over, we emerge, high on imagination. Just as the mature butterfly, known as an imago, returns to the wider world, ripe for creation and pollination.",
        "artist": "Kirsten Berg",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://www.kickstarter.com/projects/cofone/imago",
        "location": {
            "string": "6:05 800', Open Playa",
            "hour": 6,
            "minute": 5,
            "distance": 800,
            "category": "Open Playa",
            "gps_latitude": 40.784917222454,
            "gps_longitude": -119.208629383825
        },
        "location_string": "6:05 800', Open Playa",
        "images": [
            {
                "gallery_ref": 82864,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82864_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbUxEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbTWEAY",
        "year": 2016,
        "name": "The Giant Weta",
        "url": "http://www.gaintweta.nz",
        "contact_email": "hippie.tim@burningman.org",
        "hometown": "Auckland, New Zealand",
        "description": "Giant weta are endemic insects native to and only found in New Zealand. Their genus name, Deinacrida, is Greek for \"fierce grasshopper.\" Larger weta can be up to 10 cm (4\") long not inclusive of legs and antennae and it is one of the heaviest documented insects in the world. Due to introduced mammals the weta is now an endangered species.\r\nWe are making a 50:1 scale model of real life giant weta and making it shoot flames.\r\nIt is being built in Auckland, New Zealand, taken to Black Rock City, returning to New Zealand for Kiwiburn and then finally being installed somewhere in New Zealand as a permanent installation.",
        "artist": "Andrew Benson, Hippathy Valentine and Auckland Burners",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://www.indiegogo.com/projects/the-giant-weta-at-burning-man-2016-kiwiburn-2017#/gallery",
        "location": {
            "string": "6:05 1820', Open Playa",
            "hour": 6,
            "minute": 5,
            "distance": 1820,
            "category": "Open Playa",
            "gps_latitude": 40.783026624319,
            "gps_longitude": -119.211344210302
        },
        "location_string": "6:05 1820', Open Playa",
        "images": [
            {
                "gallery_ref": 82894,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82894_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbTWEAY.mp3"
    },
    {
        "uid": "a2Id0000000cbWjEAI",
        "year": 2016,
        "name": "The Traveling Sound Museum",
        "url": "http://www.thetravelingsoundmuseum.com/",
        "contact_email": null,
        "hometown": "Brooklyn, NY",
        "description": "The Traveling Sound Museum is a collection of ancient sounds stored in jars for centuries and mounted on a timeless cart, wheeled from continent to continent. The collection has passed through the centuries, taking different forms in different eras, and contains sounds previously thought lost to history.\r\nWhat did it sound like when the Mongols swept down from the steppe to invade Europe? Or the wildlife of the Galapagos Islands a hundred years before Darwin? An early morning walk through a fish market on the outskirts of Constantinople a thousand years before it became Istanbul? \r\n \r\nFortunately the Traveling Sound Museum will be making a stop in Black Rock City this year, as part of its never-ending journey through time. So burners who discover it on the playa will have an opportunity to find out.",
        "artist": "Mike Rosenthal and Chris Cerrito",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "1:05 2250', Open Playa",
            "hour": 1,
            "minute": 5,
            "distance": 2250,
            "category": "Open Playa",
            "gps_latitude": 40.787743980363,
            "gps_longitude": -119.198559274159
        },
        "location_string": "1:05 2250', Open Playa",
        "images": [
            {
                "gallery_ref": 82855,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82855_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbWjEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbRoEAI",
        "year": 2016,
        "name": "Flocons",
        "url": "http://www.dustyvisions.org/current-projects/flocon/",
        "contact_email": "flocons@dustyvisions.org",
        "hometown": "Portland, OR",
        "description": "Flocons is a dynamic and evolving series of large-scale ornament-like sculptures, imagined and built by a collective of artists, to be displayed in a garden-like manner. Flocons is a shared creative experience in participatory art that displays the beauty of human collaboration and communal effort. As participants approach the series, they will find a collection of large free-floating sculptures, each as unique as the artists who created them.\r\n\r\nAeolianFyre by Joshua Rooker & Chloe Veneneux\r\nAlpha, Beta & Wings by Anna-Gaelle Lucy Marshall\r\nDreaming of Trees by Francis Kanach\r\nMomotombo by Rachel Babenar\r\nFly Fast by Casey Bage\r\nPlanet Janet by Elizabeth & Mel Adams\r\nSmoke Cloud by Kevan Christiaens\r\nSnow Crystal by Sara Sebby\r\nFabrication by Seth Byrnes\r\n\r\nEach Flocon is a window into the artist’s creativity, but each sculpture is only a small part of the whole. Not only will each piece be a reflection of an artist, the collaboration of artists in creating a larger work makes the whole larger than its parts.",
        "artist": "Anna-Gaelle Lucy Marshall, Dusty Visions",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://www.indiegogo.com/projects/flocons-burning-man-2016#/",
        "location": {
            "string": "7:55 1340', Open Playa",
            "hour": 7,
            "minute": 55,
            "distance": 1340,
            "category": "Open Playa",
            "gps_latitude": 40.787187560655,
            "gps_longitude": -119.211232886718
        },
        "location_string": "7:55 1340', Open Playa",
        "images": [
            {
                "gallery_ref": 83477,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83477_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbRoEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbQKEAY",
        "year": 2016,
        "name": "Intention",
        "url": "http://buchananwp.com/Intention",
        "contact_email": null,
        "hometown": "Oakland, CA",
        "description": "Intention is an immersive and interactive tensegrity structure that treads the intersections of art, engineering, and science. The sculpture disrupts the horizon as a form of jumbled symmetry, six struts held together purely in tension and compression, seemingly weaving through thin air.\r\n \r\nFrom the human body down through the cellular level, we are tensegrities ourselves. The form of the  structure is inspired by Donald Ingber's research on eukaryotic cell construction and biomechanics. A complex network of tensioned filaments connect the struts, with a nucleus suspended inside that is the mathematical DNA of the tensegrity. At night it comes alive as a structural data visualization and beacon.\r\nIntention explores the fundamental building blocks of our bodies by allowing the participant to immerse themselves within the responsive architecture of a nucleated tensegrity structure.",
        "artist": "Will Buchanan",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://www.indiegogo.com/projects/intention-burning-man-2016#/",
        "location": {
            "string": "12:05 950', Open Playa",
            "hour": 12,
            "minute": 5,
            "distance": 950,
            "category": "Open Playa",
            "gps_latitude": 40.788160747494,
            "gps_longitude": -119.203971233203
        },
        "location_string": "12:05 950', Open Playa",
        "images": [
            {
                "gallery_ref": 82963,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82963_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbQKEAY.mp3"
    },
    {
        "uid": "a2Id0000000cbS8EAI",
        "year": 2016,
        "name": "Mechanica Musica",
        "url": "http://douglasruuska.com/human-music-wheel/",
        "contact_email": "ruuskado@yahoo.com",
        "hometown": "Boston, MA",
        "description": "The participant sees an 8-foot wheel with someone walking inside of it, creating beautiful music.\r\nThe art responds to user's desires by means of an input musical seed, but only if they are willing to generate the motive force making it play. Thus it becomes a more powerful & versatile object. The old & the new meld together: mechanical linkages & controls work in concert with computationally intense algorithms creating a delightful musical instrument for everyone.\r\nThis goes beyond the limitations of expectation for the original; music boxes usually play one short tune.  Here is shown that things do not always behave according to one's expectations. \r\nThe viewer is the catalyst necessary to fulfill its potential, becoming an integral component of the creative process. They become the artist, only one that is making a unique, ephemeral creation, the music, by means of their input & operation, all played out on the canvas of our device for the delight & appreciation of  all around them.",
        "artist": "Douglas Ruuska",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "7:38 1650', Open Playa",
            "hour": 7,
            "minute": 38,
            "distance": 1650,
            "category": "Open Playa",
            "gps_latitude": 40.7867069,
            "gps_longitude": -119.2124531
        },
        "location_string": "7:38 1650', Open Playa",
        "images": [
            {
                "gallery_ref": 83724,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82848_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbS8EAI.mp3"
    },
    {
        "uid": "a2Id0000001DpGFEA0",
        "year": 2016,
        "name": "Vibraj",
        "url": "http://vibraj.com",
        "contact_email": "dania@daniamorris.com",
        "hometown": "Los Angeles, CA",
        "description": "Vibraj (Haitian for vibratory) is a climbable wind harp and percussive instrument, designed to give the wind a voice. Vibration as the main expression attempts to point at the interconnected nature of the universe. Sunrise, Sunset, and colored light animate painted climbable surfaces. The top half of an S curve is produced by combining 28 wooden boxes acting as resonating chambers for the harp portion into a curved climbable staircase. The bottom part of the S curve is steel pipe bent into multiple curves and welded together producing a flute like instrument for the wind, and a percussive instrument for human interaction. LED spot lights with slowly phasing color create animated night views with the painted portions of the instrument. Citizens interact with Vibraj by climbing on, viewing changing color patterns, plucking, strumming, singing with, and pounding out rhythms. Designed to give the wind a voice Vibraj expresses via the elements.",
        "artist": "Dania Morris",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.gofundme.com/vibraj2016",
        "location": {
            "string": "1:30 3080'",
            "hour": 1,
            "minute": 30,
            "distance": 3080,
            "category": null,
            "gps_latitude": 40.786414673078,
            "gps_longitude": -119.19536188077
        },
        "location_string": "1:30 3080'",
        "images": [
            {
                "gallery_ref": 83404,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83404_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbNoEAI",
        "year": 2016,
        "name": "The 10 Benches of Sitting Man",
        "url": null,
        "contact_email": null,
        "hometown": "Santa Cruz, CA",
        "description": "Each of The 10 Benches of Sitting Man represents one of the 10 Principles of Burning Man. \r\n1. Radical Inclusion: A bench that expands beyond initial perception\r\n2. Gifting: Lavishly painted, padded, and decorated, this bench conceals gifts to curious sitters\r\n3. Decommodification: This bench is created entirely out of reclaimed and re-branded materials\r\n4. Radical Self Reliance: Trash fence. Lincoln log style DIY bench\r\n5. Radical Self Expression: Two benches facing each other with rotating speaking/listening horns mounted on sticks in between them\r\n6. Communal Effort: An ornate and regal carrying litter provides an elegant sitting space\r\n7. Civic Responsibility: A small shelter holds a safe space for the weary traveler with 3 low benches and a table\r\n8. Leave No Trace: A clear plexiglass bench sits in the center of a light up zen garden\r\n9. Participation: What is a Teeter-Totter if not a huge communal bench?\r\n10. Immediacy: This bench is mobile. It seeks weary wanderers....",
        "artist": "Art to be Continued...",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "7:20 2100', Open Playa",
            "hour": 7,
            "minute": 20,
            "distance": 2100,
            "category": "Open Playa",
            "gps_latitude": 40.785888283875,
            "gps_longitude": -119.214064020487
        },
        "location_string": "7:20 2100', Open Playa",
        "images": [
            {
                "gallery_ref": 82826,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82826_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbTuEAI",
        "year": 2016,
        "name": "Wittgenstein, Da Vinci, Rachmaninoff: A Recursive Wooden Design",
        "url": null,
        "contact_email": null,
        "hometown": "Eugene, OR",
        "description": "Wittgenstein, Da Vinci, Rachmaninoff is a hexagonal pavilion whose bamboo faces are carved with intricate knot designs by Leonardo da Vinci. Para-cord woven into one of the knot patterns will span over the hexagonal void. A pedestal holds spools of para-cord underneath. Laser-etched patterns on the pedestal provide a template for the six knots as a guide to anyone who wishes to create them with the para-cord. The panels will have laser etched quotes from Wittgenstein's philosophical writings, and the podium will have a sound system playing Rachmaninoff piano compositions. The title – Wittgenstein, Da Vinci, Rachmaninoff: A Recursive Wooden Design – is meant to evoke Gödel, Escher, Bach: an Eternal Golden Braid,  a book by Douglas Hofstadter that explores deep questions of consciousness, and particularly the intertwining layers of thought that occur when we compartmentalize our minds into nested layers of recursion.",
        "artist": "Landon Committed, The Institute for Joyful Nihilism",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "2:55 740', Open Playa",
            "hour": 2,
            "minute": 55,
            "distance": 740,
            "category": "Open Playa",
            "gps_latitude": 40.785033820038,
            "gps_longitude": -119.204523795855
        },
        "location_string": "2:55 740', Open Playa",
        "images": [
            {
                "gallery_ref": 82961,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82961_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbVREAY",
        "year": 2016,
        "name": "Pulse Portal",
        "url": "www.PulsePortal.us",
        "contact_email": "davismccarty@gmail.com",
        "hometown": "Chicago, IL",
        "description": "A portal acts as a gateway to a distant and magical world. Pulse Portal is a freestanding laser cut parabolic archway made from steel and tessellated dichroic acrylic pyramids. Juxtaposing futuristic materials that reflect the viewer and the rugged landscape will provide a sense of awe and inspiration as they step onto the playa. The combination of these materials and geometric design will create an effect that simultaneously feels space age and classic effectively placing the viewer in a time portal.",
        "artist": "Davis McCarty",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://www.kickstarter.com/projects/933382321/pulse-portal-center-camp-archway-burning-man-2016?ref=project_tweet",
        "location": {
            "string": "6:00 2700', Cafe Portal",
            "hour": 6,
            "minute": 0,
            "distance": 2700,
            "category": "Cafe Portal",
            "gps_latitude": 40.781162894521,
            "gps_longitude": -119.2133911492
        },
        "location_string": "6:00 2700', Cafe Portal",
        "images": [
            {
                "gallery_ref": 82882,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82882_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001E56pEAC",
        "year": 2016,
        "name": "La Bottega",
        "url": "http://",
        "contact_email": "labottega@burningman.org",
        "hometown": "Black Rock City, NV",
        "description": "La Bottega is a hub which will serve as a welcome and information center for the Guilds located at the base of the Man, in the Piazza. La Bottega will also support the Guilds by being the logistics center for all the Guild regional groups and artists, Man Watch, and Rangers assigned to the Man Pavilion.\r\nFor three magical years, The Man Pavilion has been a focal point of promotion of our worldwide community. From the Souk, to the Midway, and now the Workshop Guilds, The Man himself is much more than a destination throughout the week, it is now also the center for participants to reach out and learn about our communities growing in every corner of the world.",
        "artist": "La Bottega Team",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "8:15 140', Man Pavilion",
            "hour": 8,
            "minute": 15,
            "distance": 140,
            "category": "Man Pavilion",
            "gps_latitude": 40.7865461,
            "gps_longitude": -119.2069681
        },
        "location_string": "8:15 140', Man Pavilion",
        "images": [
            {
                "gallery_ref": 83726,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83726_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001gtfDEAQ",
        "year": 2016,
        "name": "The Magic Garden at the ARTery",
        "url": "http://www.sustainablemagic.org/magic-garden.html",
        "contact_email": "info@sustainablemagic.org",
        "hometown": "San Francisco, CA",
        "description": "The Magic Garden awaits and rewards those who come close and explore its flowers. A colorful fusion of the organic and electronic, the Magic Garden will brighten your day--but especially your night--and leave you with a smile and the joy of knowing magic still exists in the world today. Relax in the Magic Garden at the ARTery, and immerse yourself in both past and present Burning Man art to the backdrop of chill music.",
        "artist": "Sustainable Magic",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "6:25 2500', ARTery",
            "hour": 6,
            "minute": 25,
            "distance": 2500,
            "category": "ARTery",
            "gps_latitude": 40.782711441149,
            "gps_longitude": -119.214115648361
        },
        "location_string": "6:25 2500', ARTery"
    },
    {
        "uid": "a2Id0000001hDsTEAU",
        "year": 2016,
        "name": "Gifting Tree",
        "url": "http://www.facebook.com/RootistLounge",
        "contact_email": "mikepierce@texaslive.us",
        "hometown": "Las Vegas",
        "description": "The Gifting tree is a representation of the the collected tribes. Outlined in LED's with it's Heart Pulsing for all to see. Love it is the way! Gifting is our exchange. Give, receive and connect.",
        "artist": "Rootist Lounge Gifting Tree",
        "category": null,
        "program": null,
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null
    },
    {
        "uid": "a2Id0000000cbOIEAY",
        "year": 2016,
        "name": "Carousel Candeo",
        "url": "http://www.deniznicoleart.squarespace.com/carouselcandeo",
        "contact_email": null,
        "hometown": "Ventura, CA",
        "description": "Carousel Candeo - a psychedelic manifesto, a glittering kaleidoscopic merry go round that in motion fuses the artist, installation & community.",
        "artist": "Deniz Nicole Art",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:45 2900', Open Playa",
            "hour": 1,
            "minute": 45,
            "distance": 2900,
            "category": "Open Playa",
            "gps_latitude": 40.785377303392,
            "gps_longitude": -119.196100223038
        },
        "location_string": "1:45 2900', Open Playa",
        "images": [
            {
                "gallery_ref": 82171,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82171_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbPTEAY",
        "year": 2016,
        "name": "Jedi Dog Temple",
        "url": null,
        "contact_email": "ladymerv@gmail.com",
        "hometown": "Las Vegas, NV",
        "description": "An art project for children designed by a child.  Sagan Bocskor (4.5 years old) designed the structure using the tools he has - his building blocks. \"Jedi Dog Temple, But Everyone Is Welcome\" was selected and submitted to Burning Man by him and his parents. Sagan has been creating and his parents have been photographing his progress since he could stack blocks... about 2.5 years ago. We have scaled up his toy/block design to make it a child's play space, perfect for a few 5 year olds.\r\nSagan asked for other kids to decorate the inside, so the kids & community of Las Vegas got together to create the art for the little space for little people.",
        "artist": "Sagan Bocskor & Team",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "5:22 1300', Open Playa",
            "hour": 5,
            "minute": 22,
            "distance": 1300,
            "category": "Open Playa",
            "gps_latitude": 40.783197929511,
            "gps_longitude": -119.208553130855
        },
        "location_string": "5:22 1300', Open Playa",
        "images": [
            {
                "gallery_ref": 83007,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83007_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbPTEAY.mp3"
    },
    {
        "uid": "a2Id0000000cbRKEAY",
        "year": 2016,
        "name": "MirrorrorriM",
        "url": "http://flockarts.com",
        "contact_email": "mcaloon.andrew@gmail.com",
        "hometown": "Whistler B.C., Canada",
        "description": "MirrorrorriM is a kaleidoscope the size of a school bus that requires many people working together to make it spin. Participants can choose to be part of the team spinning the kaleidoscope or can get into the \"human roll chamber\" by slipping their feet into bindings and going for a spin! Or they can control the lights that light the kaliedoscopic tube. MirrorrorriM is a full body experience whether you're spinning or being spun, but even just enjoying the effects of the kaleidoscope has been elevated: instead of simply putting your eye up to the kaleidoscope, our project allows you to immerse yourself fully in the Observation Room. This room is walled completely by mirrors, creating an infinity effect. The Observation Room is the best place to view the ever changing images that the other participants create with their bodies. MirrorrorriM is more than a hands-on experience—it's a Bodies-On-Art experience. The team behind it believe that everyone can make and be a part of art.",
        "artist": "Flock Arts",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.indiegogo.com/projects/mirrorrorrim-the-alchemy-of-play#/",
        "location": {
            "string": "10:52 775', Open Playa",
            "hour": 10,
            "minute": 52,
            "distance": 775,
            "category": "Open Playa",
            "gps_latitude": 40.788483738867,
            "gps_longitude": -119.205970181459
        },
        "location_string": "10:52 775', Open Playa",
        "images": [
            {
                "gallery_ref": 83010,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83010_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kBEAQ",
        "year": 2016,
        "name": "M3 - Minnesota Makers & Masterpieces",
        "url": "https://www.facebook.com/groups/734540250015287/?fref=nf",
        "contact_email": "mnburningarts@gmail.com",
        "hometown": "Minneapolis, MN",
        "description": "Apprentices will enter the M3 Guild space and be treated to a variety of interactive, educational experiences... and a few bits of just plain fun.  The novices can learn to strike coins, become DaVinci coders, control lights and sound with logical programming, learn and practice drawing.  Applying science and physics they can heat their own tater tot with the sun.\r\nThere will be an oversize component Moog synthesizer that can be reconfigured and reprogrammed.\r\nFor fun, apprentices will be encouraged to join the low-brow instrument band, and participate in a parade through the Man Pavilion.\r\nAs a commemorative, \"graduates\" will be lined up as participants in a 2.5 dimensional version of DaVinci's Last Supper with costumes and have their photo taken.",
        "artist": "MN Regional Burning Arts Cooperative",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "12:30 130', Man Pavilion",
            "hour": 12,
            "minute": 30,
            "distance": 130,
            "category": "Man Pavilion",
            "gps_latitude": 40.786578529141,
            "gps_longitude": -119.206093291004
        },
        "location_string": "12:30 130', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82918,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82918_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kCEAQ",
        "year": 2016,
        "name": "Hot Glass Arts Guild",
        "url": "http://",
        "contact_email": "sschumacher89@gmail.com",
        "hometown": "Berkeley, CA",
        "description": "This will be an interactive glassblowing studio giving live demonstrations, and offering opportunities to learn the craft of glassblowing.",
        "artist": "Berkeley Bohemian Glassblowing Cooperative",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "11:30 130', Man Pavilion",
            "hour": 11,
            "minute": 30,
            "distance": 130,
            "category": "Man Pavilion",
            "gps_latitude": 40.786708580624,
            "gps_longitude": -119.206265675477
        },
        "location_string": "11:30 130', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82377,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82377_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kPEAQ",
        "year": 2016,
        "name": "Scultura di Colletivo",
        "url": "https://www.facebook.com/Sculturadicolletivo/",
        "contact_email": "sculturadicolletivo@gmail.com",
        "hometown": "Truckee, CA",
        "description": "Our intent is to bring and operate a full working traditional blacksmith shop in the Man pavilion. The workshop space will have the look, feel and smell of a traditional blacksmith shop. It will be completely outfitted with coal forges, anvils, vices, hammers and tongs. A group of participants will be able to heat and mold steel like clay under the guidance of our international team of smiths. Blacksmiths from Austria, England, Canada, Columbia, Tasmania, Wisconsin, Illinois, Oregon, Colorado, Nevada and also Lake Tahoe California will be on site guiding and instructing participants to spread the knowledge and traditions of the blacksmithing craft. At the front of the space will be the start of what will be become a life size Da Vinci inspired steel wing. Participants will be able to forge steel feathers that will be added to the sculpture as the week progresses. This will result in a truly city wide built sculpture as people of all ages and backgrounds use their collective creativity to produce a metal work of art.",
        "artist": "Kyle Larrain & an International Crew of Smiths",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "5:30 130', Man Pavilion",
            "hour": 5,
            "minute": 30,
            "distance": 130,
            "category": "Man Pavilion",
            "gps_latitude": 40.7860914,
            "gps_longitude": -119.2067343
        },
        "location_string": "5:30 130', Man Pavilion",
        "images": [
            {
                "gallery_ref": 83725,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83725_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2keEAA",
        "year": 2016,
        "name": "Amalgamated Debris Assemblage",
        "url": "http://",
        "contact_email": "jimmydescant@gmail.com",
        "hometown": "Salida, CO",
        "description": "Involving the public in the 'Amalgamated Debris Assemblage' Guild's art, not only in vision but in tactile experience, is irresistible and anticipated! The 'artist participants' of the public are welcome to the ADA booth to create their own vision in assemblage of 'found objects'' - pieces/parts from the Golden Age of American manufacturing, and the castoff debris of society! Portraits, beauty, free speech, etc. coupled with guidance in assembling into vision when needed by the Guild artists! It's okay to handle, tool, and work and arrange… and see, and do! PLACEMENT in the moment, because YOU say so, and the magnetism used by the assemblage artist, interacts with the whole of this epicenter of Guild creativity. Art created can be taken, given away, picked up later, or labeled 'free' for anyone to take. Transposed and balanced with the public build, \"The Creative Cavern\" is a solo art experience booth where the artists can create in private - the artwork within will be unveiled at the end of the week!",
        "artist": "Jimmy Descant and the \"Amalgamated Debris Assemblage\" Guild",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "7:15 160', Man Pavilion",
            "hour": 7,
            "minute": 15,
            "distance": 160,
            "category": "Man Pavilion",
            "gps_latitude": 40.786342033106,
            "gps_longitude": -119.207073516735
        },
        "location_string": "7:15 160', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82943,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82943_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d9NhEAI",
        "year": 2016,
        "name": "Tower of Ascension",
        "url": "http://swigmiller.wix.com/toa16",
        "contact_email": "swigmiller@gmail.com",
        "hometown": "Santa Monica, CA",
        "description": "The Tower of Ascension (TOA) is a 40' steel tower that looks like something out of ancient Babylon. It has a strong symbolic presence that will be a beacon of light on the Playa. The tower itself is comprised of a three-legged base, on which rests an observation platform at 25'. Above this is a floating metal sphere with two dragons climbing up it. The dragons have their necks intertwined at the top and will spit fire at night. \r\nA 12' wooden tower will rest about 80' from the TOA. This tower will serve as a platform for Andrea Brook's Sonic Butterfly, a newer version of the Earth Harp. \r\nA ring of 23' smaller towers surrounds the TOA, forming a perimeter and defining a space around the Tower.",
        "artist": "Swig Miller and Friends",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.kickstarter.com/projects/1320638597/the-tower-of-ascension",
        "location": {
            "string": "10:50 3000', Open Playa",
            "hour": 10,
            "minute": 50,
            "distance": 3000,
            "category": "Open Playa",
            "gps_latitude": 40.794491947181,
            "gps_longitude": -119.204635163395
        },
        "location_string": "10:50 3000', Open Playa",
        "images": [
            {
                "gallery_ref": 83001,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83001_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dPLOEA2",
        "year": 2016,
        "name": "Ziggy Sawdust & the Chainsaws from Mars",
        "url": "http://",
        "contact_email": "glenn20008@yahoo.com",
        "hometown": "Woodstock, VA",
        "description": "Ziggy Sawdust and the Chainsaws from Mars is essentially portrait sketch artists with chainsaws. \r\nWe carve a sitters likeness and profile into a pine plank in about 15 minutes  (or less depending on how many warts they need removed) This is performed in a moop proof enclosure in front of any passing burner. Two carvers are on duty from about 1 pm till just after sunset. One cleans up after the portrait they just carved while the other carves and/or engages the audience. \r\n   ALL portraits are held till after sunset. At that point each image is brought forth and subjected to the kiss of the charring roof torch. This turns each portrait into an image of glowing embers reminding everyone of our brief spark. \r\n   They are hung inside the moop containment cage and are wire brushed in the morning, ready to be collected by the Burner who was brave enough to sit for us. They can further be adorned at other guilds, taken home as is or contributed to other burns.",
        "artist": "Glenn Richardson",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "5:00 150', Man Pavilion",
            "hour": 5,
            "minute": 0,
            "distance": 150,
            "category": "Man Pavilion",
            "gps_latitude": 40.786003093702,
            "gps_longitude": -119.206639448255
        },
        "location_string": "5:00 150', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82887,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82887_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DmLCEA0",
        "year": 2016,
        "name": "The Śiṣya",
        "url": "http://",
        "contact_email": "ks@kristasanders.com",
        "hometown": "San Francisco, CA",
        "description": "To lose a great friendship is to alter your life forever. But if we can remain open to the lessons offered by these losses, a deeper Self can be revealed.\r\n\r\nŚiṣya (pronounced shi-shya) refers to the relationship between a Guru (teacher) and a śiṣya (disciple). In sanskrit, Gu means darkness and ru means the one who dispels them. Therefore, a guru is one who dispels the darkness.\r\n\r\nThe Śiṣya, a walk-through experience, prompts participants to recognize the opportunities created by the loss of a close relationship. Participants are encouraged to write on the walls near the prompts to share their stories with others. At the end of the week, The Śiṣya along with all of the memories left behind will be burned.",
        "artist": "Collaboration between Rob Bell and Krista Sanders (sponsored by Friendlandia)",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.indiegogo.com/projects/the-si-ya-burning-man-2016-art-experience#/",
        "location": {
            "string": "8:45 1100', Open Playa",
            "hour": 8,
            "minute": 45,
            "distance": 1100,
            "category": "Open Playa",
            "gps_latitude": 40.788229155933,
            "gps_longitude": -119.209660333491
        },
        "location_string": "8:45 1100', Open Playa",
        "images": [
            {
                "gallery_ref": 83398,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83398_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000001DmLCEA0.mp3"
    },
    {
        "uid": "a2Id0000001DoESEA0",
        "year": 2016,
        "name": "Paul's Chair",
        "url": "http://",
        "contact_email": "star.snowmaddness.quinn@gmail.com",
        "hometown": "The west & the east, Canada",
        "description": "Paul's Chair is an oversized Muskoka (Adirondack) chair in honour of a great Black Rock City citizen passed named Paul Morrison.  Please come enjoy some vodka & oranges, take in a sunset or a sunrise, and meet some more great Black Rock City citizens.",
        "artist": "Paul's friends",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:00 5900', Open Playa",
            "hour": 12,
            "minute": 0,
            "distance": 5900,
            "category": "Open Playa",
            "gps_latitude": 40.797842618265,
            "gps_longitude": -119.191437779851
        },
        "location_string": "12:00 5900', Open Playa",
        "images": [
            {
                "gallery_ref": 83373,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83373_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DoLiEAK",
        "year": 2016,
        "name": "Great Big Zapper",
        "url": "https://www.greatbigzapper.com",
        "contact_email": null,
        "hometown": "Reno, NV",
        "description": "In our daily lives, we've become desensitized to the curiosity and serenity that is all around us. Technology and social media have taken the place of conversation and natural interaction. The Great Big Zapper will be a visual representation of how we trap ourselves amid the wonder of life. You can sit back and watch the experience unfold, and participate by interacting with bright, buzzing distractions inside the GBZ. The Great Big Zapper is my way of letting the world see the fray of our daily lives and the inherent joy of escaping it.- Also it's a hippy trap ;)",
        "artist": "Fire and Dust Crew",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "11:45 7400', Open Playa",
            "hour": 11,
            "minute": 45,
            "distance": 7400,
            "category": "Open Playa",
            "gps_latitude": 40.802495749978,
            "gps_longitude": -119.190243640926
        },
        "location_string": "11:45 7400', Open Playa",
        "images": [
            {
                "gallery_ref": 83348,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83348_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DoM2EAK",
        "year": 2016,
        "name": "Petunia",
        "url": "http://",
        "contact_email": "twinkiipdx@gmail.com",
        "hometown": "Portland, OR",
        "description": "The Petunia is a small meditative space, meant for one or two people.\r\nIt is created almost entirely out of newspapers, which have been spun into yarn and knitted into lace. The first row of knitting is supported by a cube-shaped metal frame (4x4x4 ft). Consequent rows are knitted outwards from the frame, leaving the space inside hollow.\r\nThe outermost row will be knitted out solid wire. When we burn the Petunia, the main rows, made of paper, will burn away, and the outer row will collapse, taking on a new shape around the frame, and giving us a new sculpture.\r\n\r\nIn the information age we live in, surrounded by data, big and small, there is certain poetry to using newspaper as building material for a cocoon-like structure. He who sits inside the Petunia will be completely enveloped in data, which has been printed to paper and then encrypted beyond recognition by the yarn-making process and the knitting.\r\nCopies of all newspaper issues used, will be available on site for the curious reader.",
        "artist": "Nadinski",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "10:13 5300', Open Playa",
            "hour": 10,
            "minute": 13,
            "distance": 5300,
            "category": "Open Playa",
            "gps_latitude": 40.800748418583,
            "gps_longitude": -119.209367755153
        },
        "location_string": "10:13 5300', Open Playa",
        "images": [
            {
                "gallery_ref": 83374,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83374_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DpD1EAK",
        "year": 2016,
        "name": "We Traffic In Dreams",
        "url": "http://www.wetrafficindreams.com",
        "contact_email": "toby@pelicancamp.com",
        "hometown": "Austin, TX",
        "description": "We Traffic In Dreams is a mobile medicine show theater troupe that will perform daily in open playa. A small troupe of performers will bring a human-powered wagon that doubles as a stage into the area between Esplanade and the Man each evening for a multi-act show featuring circus and performance arts. The troupe will also ply their wares, namely patent medicines that will be offered to audience members for the low, low price of one dream each!\r\n\r\nAudiences will be treated to a fully immersive, interactive medicine show experience. The troupe will present the entire performance as if they are from an alternate reality 1902, with vintage costumes, a fantastical backstory to explain their arrival in the present day, and a variety of engaging acts and skills on display.",
        "artist": "Pelican Camp Arts Collective",
        "category": "Mobile",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "Mobile",
            "hour": null,
            "minute": null,
            "distance": null,
            "category": "Mobile",
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": "Mobile",
        "images": [
            {
                "gallery_ref": 83405,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83405_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dq28EAC",
        "year": 2016,
        "name": "Smoke and Mirrors",
        "url": "http://",
        "contact_email": "awallacegoesawol@gmail.com",
        "hometown": "Bend, OR",
        "description": "Smoke and Mirrors is a wooden vision crystal rising from a seemingly chaotic environment. It is a a simple, 12 sided crystalline structure with a somewhat plain exterior. Through intricately shaped windows, forms or people can be seen. Upon further inspection, a doorway can be found in one of the 12 sides. Once inside, guests to its interior will be treated to fire, infinite reflection, and an intimate space to share with others.",
        "artist": "Abney Wallace",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:20 3300', Open Playa",
            "hour": 1,
            "minute": 20,
            "distance": 3300,
            "category": "Open Playa",
            "gps_latitude": 40.78720312744,
            "gps_longitude": -119.19461344673
        },
        "location_string": "1:20 3300', Open Playa",
        "images": [
            {
                "gallery_ref": 83386,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83386_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dq5REAS",
        "year": 2016,
        "name": "The Crack Of Dawn",
        "url": "https://riotnrrd.com/tcod",
        "contact_email": "tcod@riotnrrd.com",
        "hometown": "San Francisco, CA",
        "description": "Dawn is a magical time at Burning Man, and the first appearance of the sun over the hills surrounding the Black Rock Desert is met daily with cheers across the playa. The Crack Of Dawn aims to recognize, honor and augment that special moment, by adding an audible decoration to that first sliver of light - off in the distance, as the dawn sun breaches the horizon... what was that BOOM? Why, it was the Crack of Dawn, of course!\r\n\r\nWhether you're still out celebrating or winding down in your tent, The Crack Of Dawn will let you know that a new day has officially begun.",
        "artist": "Drew Smith",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:25 7390', Open Playa",
            "hour": 12,
            "minute": 25,
            "distance": 7390,
            "category": "Open Playa",
            "gps_latitude": 40.797300451809,
            "gps_longitude": -119.183983196721
        },
        "location_string": "12:25 7390', Open Playa",
        "images": [
            {
                "gallery_ref": 83394,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83394_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001E5N4EAK",
        "year": 2016,
        "name": "The Fireside Circles",
        "url": "http://",
        "contact_email": null,
        "hometown": "Black Rock City, NV",
        "description": "For those of you who miss a nice and simple fire to congregate around, The Fireside Circles are concrete burn platforms and benches and a cord of firewood for you, the community, to sit and get warm while watching the world go round and telling stories. You, the community are the fire tender. Please keep it clean and beautiful. Leave No Trace.",
        "artist": "DA of Black Rock and the Department of Public Works",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "3:07 2200', Open Playa",
            "hour": 3,
            "minute": 7,
            "distance": 2200,
            "category": "Open Playa",
            "gps_latitude": 40.781895568282,
            "gps_longitude": -119.20121794155
        },
        "location_string": "3:07 2200', Open Playa",
        "images": [
            {
                "gallery_ref": 83395,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83395_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbPYEAY",
        "year": 2016,
        "name": "The Black Rock Lighthouse Service",
        "url": "http://brlighthouse.org/",
        "contact_email": null,
        "hometown": "Oakland, CA",
        "description": "A crystal like cluster of Lighthouses ranging from 6 to 60 foot tall and some leaning as much as 20 degrees. Inspired by the juxtaposition of creating a destination of fun and shelter by something that is meant to warn you of danger. This adult jungle gym aims to become a destination where participants come to seek shelter, play, meetup with friends and navigate the inland sea that is the Playa. At night the Lighthouses will truly come alive with fire, light, and a few other surprises.",
        "artist": "Jonny and Max Poynton",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": "https://www.indiegogo.com/projects/the-black-rock-lighthouse-service#/",
        "location": {
            "string": "11:00 3900', Open Playa",
            "hour": 11,
            "minute": 0,
            "distance": 3900,
            "category": "Open Playa",
            "gps_latitude": 40.7967195,
            "gps_longitude": -119.2028738
        },
        "location_string": "11:00 3900', Open Playa",
        "images": [
            {
                "gallery_ref": 82838,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82838_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbPYEAY.mp3"
    },
    {
        "uid": "a2Id0000000dEUCEA2",
        "year": 2016,
        "name": "Catacomb of Veils",
        "url": "https://www.facebook.com/CatacombofVeils",
        "contact_email": null,
        "hometown": "San Francisco, CA",
        "description": "Catacomb rises like a rocky outcropping off the desert floor, evoking Black Rock Point itself. It is a ruin of a previous society-- a remnant of our collective search for moments of quiet, introspection and reflection. It is a journey of discovery and a descent into a subterranean world.\r\n\r\nA path winds up to the Narthex at the eastern Pyramid and from this vantage point, the inward descent begins. Ancient relics of a collective history grace the walls as shafts of light illuminate effigies and offerings. These are moments in our primeval memory, inviting us further downward and inward into ourselves. The journey culminates in an inner sanctum-- a sanctuary of veils-- a confluence of concealment, revelation and sublime beauty.",
        "artist": "Dan Sullivan and the Catacomb Crew",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": "https://www.indiegogo.com/projects/catacomb-of-veils-burning-man-2016-architecture#/",
        "location": {
            "string": "1:00 3900', Open Playa",
            "hour": 1,
            "minute": 0,
            "distance": 3900,
            "category": "Open Playa",
            "gps_latitude": 40.7891816,
            "gps_longitude": -119.1928831
        },
        "location_string": "1:00 3900', Open Playa",
        "images": [
            {
                "gallery_ref": 82930,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82930_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000dEUCEA2.mp3"
    },
    {
        "uid": "a2Id0000001DpABEA0",
        "year": 2016,
        "name": "Heyoka",
        "url": "http://",
        "contact_email": "lazooka@hotmail.com",
        "hometown": "Reno, NV",
        "description": "Heyoka  is a sixty foot across circle with a ten foot  center   Four part colored circle representing the four elements . \r\n Four katchinas stand at the perimeter cardinal points. There is a tall feather flag in the center representing the 5th element \" spirit\". \r\nAccording to Native American lore , Heyoka is the pesky pot stirrer who will rattle  your cage of denial.",
        "artist": "L.A.Sugai aka gallactic butterfly",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "4:42 1760', Open Playa",
            "hour": 4,
            "minute": 42,
            "distance": 1760,
            "category": "Open Playa",
            "gps_latitude": 40.781606502039,
            "gps_longitude": -119.207153823499
        },
        "location_string": "4:42 1760', Open Playa",
        "images": [
            {
                "gallery_ref": 83349,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83349_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kVEAQ",
        "year": 2016,
        "name": "I Tamburisti di FIREnze (The Drummers of Florence)",
        "url": "http://www.itdfguild.com",
        "contact_email": "itdf2016@gmail.com",
        "hometown": "New Orleans, LA",
        "description": "Our project will recreate a 16th century drum-crafter's workshop while exploring a strange and ancient fiction fabricated by our team. The space itself is split into two major parts: the workshop and the play space. First you'll take a tour of our workshop which is embellished with drapery and a parody of Leonardo-inspired paintings (including a 20-foot mural of The Last Supper as if they were all building drums). As RECRUITS, you'll learn our history and bring an offering to our founder. As an APPRENTICE, you'll discover your Rhythmic Identity Code and we'll send you on a Rhythm Quest! Once a JOURNEYMAN, we'll teach you a few of our drum-building secrets while you help us assemble drums to gift off-playa. If you make it that far, you'll complete your apprenticeship by building a drum of your OWN to prove yourself worthy of the title \"MASTER\" within our ranks! Throughout the week, you'll find facilitated drum circles & various workshops in our play space, and there will be plenty of time for all burners to explore their own sense of play!     CALLOUT We're looking for volunteers to help facilitate drumming in our play space. We have a volunteer form on our website.  Our project is huge and ever-evolving, and and we can always use more bodies :)",
        "artist": "The Camp ThumpThump Drum Collective",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "2:30 130', Man Pavilion",
            "hour": 2,
            "minute": 30,
            "distance": 130,
            "category": "Man Pavilion",
            "gps_latitude": 40.7862226,
            "gps_longitude": -119.2060924
        },
        "location_string": "2:30 130', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82942,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82942_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kFEAQ",
        "year": 2016,
        "name": "Geometrical Constructions",
        "url": "http://",
        "contact_email": "studio@greggfleishman.com",
        "hometown": "Los Angeles, CA",
        "description": "The Rhombohedron Society is about exploring the world of cubic symmetry. The lesson being taught by the Society is about the unifying properties of the rhombic dodecahedrton. This includes finding and learning about the how the lost triangle of Pythagoras defines the slopes of the faces of cubic polyhedra.\r\n\r\nWithin the space are four areas. The primary workshop/classroom includes seating and work tables where visitors will learn about the Lost Triangle and make a Lost Triangle template to take with them. Visitors also will have the opportunity to learn more about geometry by assembling models.\r\n\r\nThere will be a cube based dome with built in seats and a transparent skin being used for on demand and 24/7 multi-media presentations, and the Gypsy Wagon and Car \"Rose\" made of plywood with integral slotted and notched connections, whimsical creations as if from the mind of Leonardo.",
        "artist": "Gregg Fleishman",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "9:30 130', Man Pavilion",
            "hour": 9,
            "minute": 30,
            "distance": 130,
            "category": "Man Pavilion",
            "gps_latitude": 40.786707938703,
            "gps_longitude": -119.206735792976
        },
        "location_string": "9:30 130', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82970,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82970_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2kOEAQ",
        "year": 2016,
        "name": "Elephant Expressions/Radical Self-Expression, The Ten Principles of Burning Man",
        "url": "http://bmelephantproject.com/",
        "contact_email": "mail@bmelephantproject.com",
        "hometown": "New York, NY",
        "description": "A ten part, ten year art project based on the Ten Principles of Burning Man.  This year, in name of \"Radical Self Expression\" we sent out five hundred vinyl toy elephants to kids all over the world and asked them to express themselves by decorating them.  We are then taking those elephants and displaying them at Burning Man under The Man as part of the Guild Workshops piazza.\r\nOur aim is to bring awareness of the importance of creativity in a child's life. Lack of funding has stopped art programs in many public schools across the country. We are figuratively and literally putting the crayon back in the child's hand. We are also bringing 10,000 elephants to the playa this year and letting burners express themselves by decorating the elephants, and gifting them to fellow burners. \r\nWe chose to create a vinyl elephant for the kids to decorate because of the elephant's outstanding memory. We are building positive experiences in children that we want them to remember for a lifetime. \r\nWe also sculpted the elephant into the shape of the Vitruvian Man, as a wink to this year's Burning Man theme.",
        "artist": "Scott London",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "3:30 130', Man Pavilion",
            "hour": 3,
            "minute": 30,
            "distance": 130,
            "category": "Man Pavilion",
            "gps_latitude": 40.7860921,
            "gps_longitude": -119.2062642
        },
        "location_string": "3:30 130', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82866,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82866_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000d2k3EAA",
        "year": 2016,
        "name": "The Mask Factory",
        "url": "http://",
        "contact_email": null,
        "hometown": "Houston, TX & Portland, OR",
        "description": "The Mask Factory II welcomes you to our Guild Workshop under The Man.  Shade, Interesting People, and Unique Hand-made Masks are all waiting for your Creative Spirit.  Open from 11:00 to 5:00: seating is limited.  Start the day by working with your hands and meeting amazing strangers!",
        "artist": "The Mask Factory Guild",
        "category": null,
        "program": "ManPavGrant",
        "donation_link": null,
        "location": {
            "string": "11:07 150', Man Pavilion",
            "hour": 11,
            "minute": 7,
            "distance": 150,
            "category": "Man Pavilion",
            "gps_latitude": 40.7867897,
            "gps_longitude": -119.2063288
        },
        "location_string": "11:07 150', Man Pavilion",
        "images": [
            {
                "gallery_ref": 82370,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82370_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbOzEAI",
        "year": 2016,
        "name": "The Space Whale",
        "url": "http://www.thespacewhale.com",
        "contact_email": "mrschultz@gmail.com",
        "hometown": "Reno, NV",
        "description": "The Space Whale is a 50 foot tall full-scale crystalline humpback whale mother and calf diving through the sky built from steel and stained glass. A monumental testament to family, our relationships with nature, time and space and our responsibility to preserve our environment. First appearing at Burning Man and then traveling to 6 countries around the world. The Space Whale is a monument meant to inspire people to create the change needed to herald in a future of environmental balance and space travel.",
        "artist": "The Pier Group with Matthew Schultz, Android Jones and Andy Tibbetts",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "6:00 2500', Keyhole",
            "hour": 6,
            "minute": 0,
            "distance": 2500,
            "category": "Keyhole",
            "gps_latitude": 40.7815508,
            "gps_longitude": -119.2128807
        },
        "location_string": "6:00 2500', Keyhole",
        "images": [
            {
                "gallery_ref": 82834,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82834_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbOzEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbT6EAI",
        "year": 2016,
        "name": "The Last Apothecary",
        "url": "http://lastapothecary.com",
        "contact_email": null,
        "hometown": "Los Angeles, CA",
        "description": "The Last Apothecary is an immersive, narrative haunted house. It is a narrative about an outer colony space apothecary obsessed with Old-Earth, and also about the persistence of ritual, the space immigrant diaspora, and the obsessive nature of archiving and collecting.\r\nThe Last Apothecary is meant to be stumbled upon in deep playa, a strange and imposing structure that evokes nervous curiosity. The interior is built to someone's idea of an Old Earth apothecary, clutter and warm wood reminiscent of 14th century pharmacies and Chinese medicine shops. There is no masking the anachronism, though – there are infomercials for anti-gravity yoga, and promised cures for all sorts of space ailments. The room is filled with odd and wonderful artifacts, an amulet to heal small wounds, vials of a green powder from Europa for nausea. The counter too, is strewn with artifacts that weave between truth and hoax, asking the participant to stay a while, explore, and maybe share a remedy or two...",
        "artist": "Shing Yin Khor and the Black Rock Civilian Defense Corps",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://www.kickstarter.com/projects/1454865760/the-last-apothecary",
        "location": {
            "string": "12:15 6800', Open Playa",
            "hour": 12,
            "minute": 15,
            "distance": 6800,
            "category": "Open Playa",
            "gps_latitude": 40.7977594,
            "gps_longitude": -119.1870146
        },
        "location_string": "12:15 6800', Open Playa",
        "images": [
            {
                "gallery_ref": 82853,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82853_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbT6EAI.mp3"
    },
    {
        "uid": "a2Id0000000cbTMEAY",
        "year": 2016,
        "name": "Le Attrata",
        "url": "http://therm.cc/le-attrata/",
        "contact_email": "info@therm-fire.com",
        "hometown": "Oakland, CA",
        "description": "After the Events of 2175, the perfect storm of industrial pollution, population explosion and the destruction of biodiversity raged. It was only a renewal of the vows between science and nature that saved us. The amount of horrendous  wastes we had piled up over a millenia- much of it toxic and flammable- was daunting.  The Fuocco Falene are a crux of biomech, artistry and divine intervention. Fire moths- drawn to the most noxious of wastes, able to consume the wastes and leave a benign byproduct. Their consumption of fuels is spectacular, so much so that Falena became sought after for their beauty. It has become fashionable to convert outdated civic fixtures, like fountains, to be attractions to the Fuocco Falena. Le Attrata is a prime example of such an installation, its jagged spires providing perches for the Falena, the curved benches housing seating for people, and the Falena chrysalises lighting the way throughout the night.",
        "artist": "Therm",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "5:15 2000', Open Playa",
            "hour": 5,
            "minute": 15,
            "distance": 2000,
            "category": "Open Playa",
            "gps_latitude": 40.7813369,
            "gps_longitude": -119.2092555
        },
        "location_string": "5:15 2000', Open Playa",
        "images": [
            {
                "gallery_ref": 82904,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82904_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbTMEAY.mp3"
    },
    {
        "uid": "a2Id0000000cbXrEAI",
        "year": 2016,
        "name": "Renaiximent - (Renaissance)",
        "url": "http://www.pinkintruder.com/?p=476",
        "contact_email": "info@pinkintruder.com",
        "hometown": "Valencia, Spain",
        "description": "A combination of geometry and sculpture with techniques used in the Fallas festival from Valencia, Spain.\r\nA reinterpretation of grotesque decorations from Valencia Silk Market, UNESCO Heritage building from XV century.\r\nGrotesque decorations at this building were used by civic society to laugh at and face against established power and rules.\r\nMolds and pieces hang in the inside of the installation and create a space for participants to interact.\r\nA golden cube in the desert to attract people inside, where they become part of an art installation that mixes the contemporary language of the latticed architecture of the pavilion with the cardboard pieces and molds of a traditional Fallas guild. \r\nThe cube lays over a wooden mosaic of thousands of pieces assembled by social collectives. The debate between traditional and contemporary is held over the floor that has been built by the collective. Neither the tradition nor the experimentation have a future without communal effort.",
        "artist": "pink intruder (miguel arraiz + david moreno)",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://www.kickstarter.com/projects/406131569/renaixement-fallas-project-for-burning-man-2016",
        "location": {
            "string": "4:45 1700', Open Playa",
            "hour": 4,
            "minute": 45,
            "distance": 1700,
            "category": "Open Playa",
            "gps_latitude": 40.781784,
            "gps_longitude": -119.2072914
        },
        "location_string": "4:45 1700', Open Playa",
        "images": [
            {
                "gallery_ref": 82908,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82908_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbXrEAI.mp3"
    },
    {
        "uid": "a2Id0000000cbUaEAI",
        "year": 2016,
        "name": "روشن کردن - Roshanai (Illuminate)",
        "url": "http://www.charlesgadeken.com/roshanai",
        "contact_email": null,
        "hometown": "San Francisco, CA",
        "description": "ROSHANAI is a path of enlightenment, shifting colors in static form. Along this corridor, perspective changes and opposites unite. Islamic mathematical art is married to the great Western landscape, serenaded with the voice of your heart and the whisper of the Playa.\r\nROSHANAI comprises two double-walled panels that create a 108-ft long tunnel of light and sound with a 3-ft corridor. The sides of the hallway rise from 8-ft tall at the ends to 12-ft tall at the apex in the middle. Simultaneously, the panels sink into the ground to form a shallow valley. Fractal arrangements of Islamic geometric patterns are cut into the outside panels, lit from within to illuminate the patterns and cast fantastic night shadows. The entrances will be 16-ft tall gates inspired by the Great Mosque of Isfahan in Iran, pointed arches filled with sacred geometry. The inside walls are smooth and lit in solid colors by daylight-visible LED spotlights embedded in the edges of the floor.",
        "artist": "Charles Gadeken and everyone who works to make it happen",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": "https://www.kickstarter.com/projects/aurora/roshanai-illuminate-for-burning-man-2016",
        "location": {
            "string": "2:12 1100', Open Playa",
            "hour": 2,
            "minute": 12,
            "distance": 1100,
            "category": "Open Playa",
            "gps_latitude": 40.785325654777,
            "gps_longitude": -119.202783800777
        },
        "location_string": "2:12 1100', Open Playa",
        "images": [
            {
                "gallery_ref": 82995,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82995_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DycPEAS",
        "year": 2016,
        "name": "jack champions murder",
        "url": "http://",
        "contact_email": "jackchampionart@gmail.com",
        "hometown": "Oakland, CA",
        "description": "Five large fiberglass crows, 12ft long and 5/12 to 7/12 ft tall, 3 variations. Crows play with altered perspective as you come to them.  From a distance they appear much larger than life.",
        "artist": "jack champions murder",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:05 6700', Open Playa",
            "hour": 1,
            "minute": 5,
            "distance": 6700,
            "category": "Open Playa",
            "gps_latitude": 40.7904005,
            "gps_longitude": -119.1828533
        },
        "location_string": "1:05 6700', Open Playa",
        "images": [
            {
                "gallery_ref": 83356,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83356_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001Dp9NEAS",
        "year": 2016,
        "name": "MAGIC",
        "url": "http://",
        "contact_email": "isaihahmartin@mac.com",
        "hometown": "Fairfax, CA and Miami, FL",
        "description": "MAGIC is an original sculpture created by Laura Kimpton and Jeff Schomberg. Crafted in aluminum, MAGIC is a monumental sculpture set to shine in the desert sun. Commissioned by Dragonfly Den, MAGIC will have its inaugural showing in Black Rock City, and will ultimately be installed in Miami as part of art garden designed to feature Burning Man artists.",
        "artist": "Laura Kimpton",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "1:45 4400', Open Playa",
            "hour": 1,
            "minute": 45,
            "distance": 4400,
            "category": "Open Playa",
            "gps_latitude": 40.784848,
            "gps_longitude": -119.1907212
        },
        "location_string": "1:45 4400', Open Playa",
        "images": [
            {
                "gallery_ref": 83367,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83367_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbWyEAI",
        "year": 2016,
        "name": "@EARTH #HOME",
        "url": null,
        "contact_email": null,
        "hometown": "Fairfax, CA",
        "description": "@Earth#Home is Laura and Jeff's eighth installation slated for Black Rock City. Built of steel and lit with LEDs and fire, @Earth#Home is a love letter (no pun intended) to Burning Man participants, reminding them that to come to Black Rock City is in essence to come home. It's a touch stone for the belief that it's the art that makes the event come alive, that inspires us all to embrace and promote Burning Man's ethos and principles every day of the year, across the globe.",
        "artist": "Laura Kimpton and Jeff Schomberg",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "12:30 1500', Open Playa",
            "hour": 12,
            "minute": 30,
            "distance": 1500,
            "category": "Open Playa",
            "gps_latitude": 40.7884599,
            "gps_longitude": -119.2018071
        },
        "location_string": "12:30 1500', Open Playa",
        "images": [
            {
                "gallery_ref": 82325,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82325_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dUQvEAM",
        "year": 2016,
        "name": "Temple Project",
        "url": "http://www.thetemplecrew.org",
        "contact_email": null,
        "hometown": "Petaluma, CA",
        "description": "The temple this year will be built in the tradition of David Best temples, but with a significant departure from his usual style - this temple will be hand-built without CNC cut materials. It will be extremely ornate, with a large interior altar and a large chandelier. This temple will take on an ancient air, patina'ed with organic water-based stains, and look as if it were built hundreds of years in the past.\r\nThere will be 8 altars placed around the courtyard, which is walled off to create a protected, quiet, respectful space. The interactivity will be the usual function of the Burning Man temple: it will be a place for the community to come and express their emotions, reflect on the losses of friends and family members, and celebrate the lives of people around them. The temple will be built with the consideration of the community, with adequate space to accommodate the needs of people in the temple and the surrounding courtyard for reflection, safety and privacy.",
        "artist": "David Best and The Temple Crew",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "12:00 2500', Open Playa",
            "hour": 12,
            "minute": 0,
            "distance": 2500,
            "category": "Open Playa",
            "gps_latitude": 40.791248806173,
            "gps_longitude": -119.200118337166
        },
        "location_string": "12:00 2500', Open Playa",
        "images": [
            {
                "gallery_ref": 82876,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82876_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000dUQvEAM.mp3"
    },
    {
        "uid": "a2Id0000001hGGjEAM",
        "year": 2016,
        "name": "Broken Man",
        "url": "http://",
        "contact_email": "ravingmedusa@ix.netcom.com",
        "hometown": "Duvall, Washington",
        "description": "Broken Man is the \"Man\" crucified on a burnt cross wondering \"Why have you forsaken Me?\" Anyone encountering Broken Man will have to contemplate the future of Burning Man as it has become \"mainstream\" and a \"Must Be There\" event. Broken Man displays a cascading rainbow of colors reflecting the emotions of losing an icon. And, of course, the plaque at the top of the cross, \"Corruptus Pecunia\".",
        "artist": "Patrick Plummer",
        "category": null,
        "program": null,
        "donation_link": null,
        "location": {
            "string": null,
            "hour": null,
            "minute": null,
            "distance": null,
            "category": null,
            "gps_latitude": null,
            "gps_longitude": null
        },
        "location_string": null
    },
    {
        "uid": "a2Id0000000cbTQEAY",
        "year": 2016,
        "name": "Cascadia Serapeum",
        "url": "http://www.cascadiaserapeum.com",
        "contact_email": "info@cascadiaserapeum.com",
        "hometown": "Vancouver, BC, Canada; Seattle, WA; and Portland, OR",
        "description": "Cascadia Serapeum is a large scale Art Experience built across Vancouver (BC), Seattle and Portland for Burning Man 2016. Inspired by the Library of Alexandria, the structure is classically Ancient Greek in style; however, a closer look reveals things are not what they seem. Inside are walls of books, sculptures, a secret room, and more, all centered around a flaming chandelier. Once inside the secret room, one will encounter a podium atop which sits a giant glowing community book for all to inscribe. Preconceptions will be challenged through play and exploration.\r\nJust like the Library of Alexandria, part way through the week, the Serapeum will burn to the ground, leaving ruins behind. The structure will now take on a second life, as people are able to experience the romance and magic of the folly. In the center of these ruins, the podium and Community Book will sit, appearing unscathed by the fire. Beauty and community will continue on, altered but unmoving.",
        "artist": "Cascadia Collective",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.indiegogo.com/projects/cascadia-serapeum-a-project-for-burning-man-2016/x/7136542#/",
        "location": {
            "string": "1:15 2600', Open Playa",
            "hour": 1,
            "minute": 15,
            "distance": 2600,
            "category": "Open Playa",
            "gps_latitude": 40.7873416,
            "gps_longitude": -119.1971802
        },
        "location_string": "1:15 2600', Open Playa",
        "images": [
            {
                "gallery_ref": 83011,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83011_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000dHfDEAU",
        "year": 2016,
        "name": "1:44 Alcyone Portal",
        "url": "http://transportals.org",
        "contact_email": "harlanemil@gmail.com",
        "hometown": "Taos, NM",
        "description": "The 1:44 Alcyone Portal, located at 1:44 and near the trash fence, is a continuation of the previous two years of Portals at Burning Man and the thirteenth year that Portals have been coming to Burning Man (see TransPortals.org). It is a 50 foot diameter Playa colored wall with Playa colored carpet to provide shelter and a container for the interaction of participants. It has the Vortrex wind and solar power unit in the center surrounded by an icosidodecahedron geometric stainless steel mirror structure that is the shape the Earth's grid is evolving to. It also has hidden in the wall the low frequency feedback device the Quasar Wave Transducer that vibrates the entire space with cat purring like tones as well as a high fidelity sound system to reproduce Tibetan bowls, tuning forks, vocals and other sound healing recordings. A number of other artists will be collaborating synergetically to share their talents and creativity to activate the space with installations, art, sound healing journeys, tea service, ceremonies and other consciousness evolving activities. See last years 11:55 Reformation Portal video to get an idea: https://www.youtube.com/watch?v=sp-6zOlw1-c",
        "artist": "Harlan Emil Gruber - TransPortals",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.generosity.com/community-fundraising/1-44-alcyone-portal-at-burning-man-2016--2",
        "location": {
            "string": "1:44 6900', Open Playa",
            "hour": 1,
            "minute": 44,
            "distance": 6900,
            "category": "Open Playa",
            "gps_latitude": 40.784128737693,
            "gps_longitude": -119.18172907879
        },
        "location_string": "1:44 6900', Open Playa",
        "images": [
            {
                "gallery_ref": 82902,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82902_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DbuTEAS",
        "year": 2016,
        "name": "Goddesscraft Temple",
        "url": "http://",
        "contact_email": "steveneye@gmail.com",
        "hometown": "Tucson, AZ",
        "description": "Ascension is a 30ft tall three sided pyramidal structure that looks like an ancient relic recreated from some collaborative cellular memory. With three 20ft long dragons angling up its sides to a central wind powered spinning spire, this stationary temple will appear to be alive or in motion. The temples' three walls are sculpted with art Nouveau curves, psychedelic patterns and archetypal symbols that act as a type of optical illusion making those experiencing it question everything.",
        "artist": "Ascension Temple by Goddesscraft",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "11:57 1180', Open Playa",
            "hour": 11,
            "minute": 57,
            "distance": 1180,
            "category": "Open Playa",
            "gps_latitude": 40.788747594081,
            "gps_longitude": -119.203568131436
        },
        "location_string": "11:57 1180', Open Playa",
        "images": [
            {
                "gallery_ref": 83347,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83347_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbNeEAI",
        "year": 2016,
        "name": "Spire of Fire",
        "url": "http://www.spireoffire.com/",
        "contact_email": null,
        "hometown": "Reno, NV",
        "description": "The Spire of Fire is a work of fire art that stands grand and high on the expanse of the open landscape much like a skyscraper in a metropolis. The tower's height, geometry, metal textures are designed to reflect the evolution of modern metropolitan architecture. Its sheer size and presence will draw your attention from afar. At night the piece will come alive with brightly colored lights and bursts of rhythmic flame.",
        "artist": "Steve Atkins and Eric Smith",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "7:00 1000', Open Playa",
            "hour": 7,
            "minute": 0,
            "distance": 1000,
            "category": "Open Playa",
            "gps_latitude": 40.7856865,
            "gps_longitude": -119.2099913
        },
        "location_string": "7:00 1000', Open Playa",
        "images": [
            {
                "gallery_ref": 82830,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82830_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbNsEAI",
        "year": 2016,
        "name": "Plug 'N Play",
        "url": null,
        "contact_email": "play@plug4.com",
        "hometown": "SF/LA in CA; NY, NY",
        "description": "A confluence of elements in African-American, Caribbean, & Latino culture in New York in the ‘80s gave rise to one of the most formidable music genres of the century: Hip-hop. Plug ’n Play pays tribute to the essential power of hip-hop & its foundational elements: Emceeing (oral), Deejaying (aural), Breaking (physical), Graffiti (visual), & Knowledge (spiritual).\r\n\r\nPlug ‘n Play is a large orange wooden electrical plug protruding upwards. Surrounding the Plug are five Quad Boxes with interior exhibits; each visually represents one of the five elements of hip-hop.\r\n\r\nWe plug in; we explore & examine the almighty vinyl record, the mic, & the crowd. In our DJ Dojo, feel with your hands what it’s like to drop the needle on the record & physically engage with actual vinyl. Passersby can tune in on turntablism demonstrations, scratching lessons, & roundtable sessions on the Elements. We’ll also have lectures, films, sonic history trips, & other interactive moments. “If music be the food of love, play on. Give me excess of it.”",
        "artist": "Plug 4 Play Collect (PB&J)",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "3:45 1700', Open Playa",
            "hour": 3,
            "minute": 45,
            "distance": 1700,
            "category": "Open Playa",
            "gps_latitude": 40.7821028,
            "gps_longitude": -119.2041373
        },
        "location_string": "3:45 1700', Open Playa",
        "images": [
            {
                "gallery_ref": 83377,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83377_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbNsEAI.mp3"
    },
    {
        "uid": "a2Id0000001DnyLEAS",
        "year": 2016,
        "name": "La Victrola",
        "url": "http://www.lavictrola2016.com/",
        "contact_email": "volunteer@lavictrola2016.com",
        "hometown": "Oakland, CA",
        "description": "La Victrola is a 35 ft tall Art Nouveau gramophone. Around its base is a fully immersive turn-of-the-century cabaret featuring the live music and performances from another era. During daytime hours, La Victrola will play the old time music of crackly old 78s to all who cross its path. Each evening, the cafe tables and lounges will be filled by the audience and performers will grace its stage. On a playa dominated by digital technology and music, La Victrola offers a counterpoint of jazz, blues, bluegrass, classical, and vaudeville that formed the foundations of what we hear today.",
        "artist": "La Victrola Society",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": "https://www.kickstarter.com/projects/lavictrola/la-victrola-music-art-and-cabaret",
        "location": {
            "string": "12:45 5000', Open Playa",
            "hour": 12,
            "minute": 45,
            "distance": 5000,
            "category": "Open Playa",
            "gps_latitude": 40.7916607,
            "gps_longitude": -119.1898062
        },
        "location_string": "12:45 5000', Open Playa",
        "images": [
            {
                "gallery_ref": 83279,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83279_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbTREAY",
        "year": 2016,
        "name": "Tangential Dreams",
        "url": "http://mamou-mani.com/tangentialdreams/",
        "contact_email": "arthur@mamou-mani.com",
        "hometown": "London, United Kingdom",
        "description": "Tangential Dreams is a climbable sinuous tower made from off-the-shelf timber and digitally designed via algorithmic rules. One thousand \"tangent\" thin wooden pieces are held in position via horizontal pieces rotating along a central axis, gently moving in the wind like leaves of a giant tree. The pieces are stencilled with inspiring sentences, and dynamically lit by LED strips during the night time. In line with this year's theme, the piece is reminiscent of Leonardo's Vitruvian Man's movement and helicoid inventions as well as his deep, systematic, understanding of the rules behind form to create art. From a wooden flame all the way to a giant desert cactus, the complex simplicity of the art piece will trigger many interpretations, many dreams. The audience will read and discuss the poetry written on each tangent coming from the Burners' community itself via our crowd funding campaign like a collage of sentences creating a serendipitous \"cadavre exquis\" of thoughts.",
        "artist": "Arthur Mamou-Mani",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": "https://www.kickstarter.com/projects/257047360/making-architecture-tangential-dreams-for-burning",
        "location": {
            "string": "6:11 1600', Open Playa",
            "hour": 6,
            "minute": 11,
            "distance": 1600,
            "category": "Open Playa",
            "gps_latitude": 40.7836072,
            "gps_longitude": -119.2109578
        },
        "location_string": "6:11 1600', Open Playa",
        "images": [
            {
                "gallery_ref": 82858,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82858_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbTREAY.mp3"
    },
    {
        "uid": "a2Id0000000cbY1EAI",
        "year": 2016,
        "name": "Burntanical Garden",
        "url": "https://www.facebook.com/Burntanicalgarden/",
        "contact_email": "burntanicalgarden@thinkcreategrow.com",
        "hometown": "Reno, NV",
        "description": "When we're sitting by a fireside, all of our senses become absorbed in the experience. The calming focus of attention relaxes and calms us. The Burntanical Garden provides the multi-sensory stimulation of fire through a collection of one-of-a-kind art pieces. It is a respite from the chaos and sensory overload of the Playa.\r\nFire Art Pieces – Each art piece is a unique creation from a different artist. The fire-art pieces utilize standing flame to create a calm, sociable atmosphere; a place to keep warm, and to make friends. Individual art pieces are arranged within the garden, with seating, to create a space to appreciate each piece. Pyrocents ensure participant safety and answer questions about each art piece.\r\nFence – The 20'x30' garden is bordered by a steel panel fence. Fence panels are constructed of rectangular welded square steel tube frames. Individual artists will 'fill-in' the blank canvas with cut sheet steel designs, which are welded in place.",
        "artist": "Artists of the Burntanical Garden",
        "category": null,
        "program": "Honorarium",
        "donation_link": null,
        "location": {
            "string": "6:13 2050', Open Playa",
            "hour": 6,
            "minute": 13,
            "distance": 2050,
            "category": "Open Playa",
            "gps_latitude": 40.7828977,
            "gps_longitude": -119.2122931
        },
        "location_string": "6:13 2050', Open Playa",
        "images": [
            {
                "gallery_ref": 82860,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82860_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000000cbQJEAY",
        "year": 2016,
        "name": "Helios",
        "url": null,
        "contact_email": null,
        "hometown": "New York, NY",
        "description": "In resonance with the Leonardo’s Renaissance - the era of rebirth - Helios calls upon every citizen of the playa to activate their inner fire that is essential to illuminate our present era of  darkness. Inside an interactive chamber of six Vitruvian activation platforms, participants offer a private statement of their highest selves to a central mirrored witness, and then ritualistically and physically project light beams to illuminate others and collectively light up the night sky. Helios is burned in ritual celebration of the light we collectively must shine to illuminate the darkness.",
        "artist": "Kate Raudenbush",
        "category": null,
        "program": "Honorarium",
        "donation_link": "https://www.generosity.com/community-fundraising/helios-a-burning-man-sculpture-by-kate-raudenbush--2",
        "location": {
            "string": "9:30 1600', Open Playa",
            "hour": 9,
            "minute": 30,
            "distance": 1600,
            "category": "Open Playa",
            "gps_latitude": 40.79019,
            "gps_longitude": -119.2094022
        },
        "location_string": "9:30 1600', Open Playa",
        "images": [
            {
                "gallery_ref": 82944,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82944_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbQJEAY.mp3"
    },
    {
        "uid": "a2Id0000000cbNwEAI",
        "year": 2016,
        "name": "Jar of Sand",
        "url": "https://www.facebook.com/jarofsandart/",
        "contact_email": null,
        "hometown": "Vancouver, BC, Canada",
        "description": "Jar of Sand is a large-scale (8' tall x 4' diameter) canning-style \"glass\" jar filled with plastic collected from beaches of the Pacific Northwest. By engaging people to clean up our oceans, Jar of Sand intends to create awareness and encourage action. Domestic garbage and pieces of garbage from the Pacific Trash Vortex—the massive island of floating trash—are carried across oceans and wind up on our shores, telling a story of resource extraction, production, and consumption. In this time of climate change and excessive use of fossil fuels, this art installation is a reflection and commentary on our plastic consumption and ultimately unsustainable waste. Participants are welcome to bring plastic that they have collected from the ocean and beaches to the playa and put them in the Jar. The collected plastic will be creatively layered in an over-height custom fabricated jar that will be displayed at Burning Man .",
        "artist": "Trish Dolman and friends",
        "category": "Open Playa",
        "program": "Honorarium",
        "donation_link": "https://fundrazr.com/jarofsand",
        "location": {
            "string": "11:28 1305', Open Playa",
            "hour": 11,
            "minute": 28,
            "distance": 1305,
            "category": "Open Playa",
            "gps_latitude": 40.789528265675,
            "gps_longitude": -119.204219405895
        },
        "location_string": "11:28 1305', Open Playa",
        "images": [
            {
                "gallery_ref": 82832,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/82832_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ],
        "audio_tour_url": "https://iburn-data.iburnapp.com/2016/audio_tour/a2Id0000000cbNwEAI.mp3"
    },
    {
        "uid": "a2Id0000001Dq3LEAS",
        "year": 2016,
        "name": "Sinners Stage",
        "url": "http://",
        "contact_email": "mawalkerart@gmail.com",
        "hometown": "Ukiah, CA",
        "description": "The Sinner Stage is a heathen theater setting with three large steel and rebar sculptures on it. The Devil's Throne stands powerfully in the center cushioned with sensual red velvet, and on one side is The Satan Andrew's Cross, both standing over 8' tall with 4' ceramic horns looming overhead. On the other side is The Dark Star, with the appearance of a sand worm crossed with a flower it is poised, blossoming, and ready to strike. It is made with 560' of 1/2 inch rebar twisted and woven together forming the base/stem, 33 ceramic thorns, and 5 large ceramic petals/horns at the top reaching 12' tall.",
        "artist": "Matt Walker",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "4:07 1465', Open Playa",
            "hour": 4,
            "minute": 7,
            "distance": 1465,
            "category": "Open Playa",
            "gps_latitude": 40.782470705773,
            "gps_longitude": -119.205434481671
        },
        "location_string": "4:07 1465', Open Playa",
        "images": [
            {
                "gallery_ref": 83384,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83384_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DpG5EAK",
        "year": 2016,
        "name": "Biodiversity Sphere \"Endless Prospect of Life\"",
        "url": "https://www.flickr.com/photos/shanecubed/albums/72157665310978476",
        "contact_email": "shanecubed@comcast.net",
        "hometown": "Albuquerque, NM",
        "description": "The Sphere depicts the importance of biodiversity. Originally a 500 gallon propane tank, we carved 45 endangered creatures and flora from around the planet. Participants may enjoy playing the sphere using attached mallets. The sphere is pretty during the day and mesmerizing at night, especially when lit inside by fire, providing some heat for a chilly night, or by LED lights. It's a great gathering spot, complete with a table to hold your drinks!",
        "artist": "Shane Shane Shane",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "7:30 4400', Plaza",
            "hour": 7,
            "minute": 30,
            "distance": 4400,
            "category": "Plaza",
            "gps_latitude": 40.786377180746,
            "gps_longitude": -119.222411589962
        },
        "location_string": "7:30 4400', Plaza",
        "images": [
            {
                "gallery_ref": 83318,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83318_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DoN0EAK",
        "year": 2016,
        "name": "Cleu of Life",
        "url": "http://www.cleu.org",
        "contact_email": "querys@cleu.org",
        "hometown": "Lakeview, OR",
        "description": "The Cleu of Life seeks to provide a moment to fully experience what it means to be a conscious being on planet Earth. Da Vinci would appreciate the Fibonacci sequence expressed by the Cleu with circles in the ratios of 1, 2, 3, 5. The labyrinth provides a contemplative experience on the playa, a special place where participants can take as long as they like to walk individually or with others on the intertwining circular paths representing the miraculous synchronicities of Consciousness, Life, Earth, Universe. Just beyond the colorful pinwheels and flags of the labyrinth, the artist/scientist/mystic in you can view the fascinating panoply of creativity on the playa. Within the labyrinth, participants find a calm center, a space for musing and meditation, or a peaceful moment of At-Onement. In a magical box at the base of a large Cleu, participants may find a clue to their own lives or even be led to CleuCamp where they can get a polyphonic Cleu brainwashing & copper Cleu pendant.",
        "artist": "Gian Anello/Jean LeCleu",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "3:37 2150', Open Playa",
            "hour": 3,
            "minute": 37,
            "distance": 2150,
            "category": "Open Playa",
            "gps_latitude": 40.781136358013,
            "gps_longitude": -119.203018546749
        },
        "location_string": "3:37 2150', Open Playa",
        "images": [
            {
                "gallery_ref": 83329,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83329_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    },
    {
        "uid": "a2Id0000001DpwPEAS",
        "year": 2016,
        "name": "Let Go",
        "url": "http://",
        "contact_email": "darrellansted@gmail.com",
        "hometown": "Boulder, CO",
        "description": "Let......Go - The Dance of Life is a 15' tall steel form made of wire mesh that invites reflection of baggage we carry that is no longer needed.",
        "artist": "Darrell E. Ansted",
        "category": "Open Playa",
        "program": "Self-Funded",
        "donation_link": null,
        "location": {
            "string": "10:00 1800', Open Playa",
            "hour": 10,
            "minute": 0,
            "distance": 1800,
            "category": "Open Playa",
            "gps_latitude": 40.7911583,
            "gps_longitude": -119.2081962
        },
        "location_string": "10:00 1800', Open Playa",
        "images": [
            {
                "gallery_ref": 83363,
                "thumbnail_url": "http://galleries.burningman.org/include/../filestore/tmp/api_resource_cache/83363_bbe3408f7c71e6bcc6dc11bb9c5e3695.jpg"
            }
        ]
    }
]
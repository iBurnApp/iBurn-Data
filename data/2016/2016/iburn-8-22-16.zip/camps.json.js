[
    {
        "uid": "a1Xd0000001IAslEAG",
        "year": 2016,
        "name": "Motor Guild Entresol",
        "contact_email": "mark.mcgothigan@gmail.com",
        "hometown": "Oakland",
        "description": "Get your motor running at the Motor Guild camporee."
    },
    {
        "uid": "a1Xd0000001IBAgEAO",
        "year": 2016,
        "name": "Euro-Orphans",
        "url": "https://www.facebook.com/groups/1640811576171828/",
        "hometown": "Barcelona Spain",
        "description": "Euro Orphans Chillout \r\nSpend some time getting to know your European burners while relaxing to some wonderful European delights."
    },
    {
        "uid": "a1Xd0000001IBSuEAO",
        "year": 2016,
        "name": "Ponycorn Island",
        "hometown": "Berkeley",
        "description": "On Ponycorn Island you can be the magical creature you were meant to be."
    },
    {
        "uid": "a1Xd0000001IBK2EAO",
        "year": 2016,
        "name": "Golden Phoenix",
        "url": "http://jozphoto.com/goldenphoenix",
        "contact_email": "jozphoto@gmail.com",
        "hometown": "Chengd",
        "description": "Golden Phoenix"
    },
    {
        "uid": "a1Xd0000001IBzPEAW",
        "year": 2016,
        "name": "Kinksters",
        "hometown": "Orange County, CA",
        "description": "Kinkiness is any unconventional sexual practice, concept or fantasy.  The term comes from an idea of a \"bend/kink\" in a sexual behavior.  Our camp enthusiastically provides a non-judgmental entryway into the world of sensual kink."
    },
    {
        "uid": "a1Xd0000001IC4KEAW",
        "year": 2016,
        "name": "Camp Love Boat",
        "description": "Camp Love Boat"
    },
    {
        "uid": "a1Xd0000001ICnwEAG",
        "year": 2016,
        "name": "Camp Rugburn",
        "url": "https://www.tumblr.com/blog/giftecon",
        "hometown": "San Francisco"
    },
    {
        "uid": "a1Xd0000001IDchEAG",
        "year": 2016,
        "name": "Gauchos de Fuego",
        "url": "http://facebook.com/GauchosDelFuego",
        "contact_email": "mmarquez@gmail.com",
        "hometown": "Ciudad de Buenos Aires",
        "description": "Gauchos del Fuego brings Latin American culture to mix with other in the Dusty Desert.\r\n\r\nWe aim to know other burners and co-create together this space, sharing mate, asados and other typical things from our Country while learning songs to sing all together."
    },
    {
        "uid": "a1Xd0000001IDRVEA4",
        "year": 2016,
        "name": "Camp Sereni-Tea",
        "hometown": "San Diego",
        "description": "Camp Sereni-Tea: rejuvenate you mind and body with afternoon guided meditation and iced recovery tonics M, W, & F 2PM-5PM.  Warm up with us and some hot toddies by the fire T & TH 9PM-11PM."
    },
    {
        "uid": "a1Xd0000001IEPhEAO",
        "year": 2016,
        "name": "got sleep?",
        "url": "http://eyeree.me",
        "contact_email": "mike@eyeree.me",
        "hometown": "Seattle",
        "description": "Hammocks and deep shade: gifting naps to weary burners. Got sleep?"
    },
    {
        "uid": "a1Xd0000001IEQDEA4",
        "year": 2016,
        "name": "Mordecai's Playshop",
        "hometown": "Seattle",
        "description": "Come insult our dumb fucking bastard, Mordecai, have a drink in his 70s porno den lounge and play with Mordecai's creepy, rusty toys.\r\n\r\nMordecai is our camp mascot. He is our devil's advocate, our own mini cathartic effigy, insult receptacle, slut, instigator, and scapegoat, i.e. little fucking bastard."
    },
    {
        "uid": "a1Xd0000001IGSvEAO",
        "year": 2016,
        "name": "Affinity Camp",
        "url": "http://affinitytribe.org",
        "contact_email": "affinitygathering@gmail.com",
        "hometown": "Los Angeles",
        "description": "AFFINITY is a fantastic frolic of  authentic self expression through music, dance, workshops, performance, and community. We are sparkly inappropriate purveyors of the necessary unnecessary, divinely kneeling in deep reverence for life's brilliance AT the altar, IN the temple, WITH a rainbow afro. Join us in creative celebration of your sexy, dynamic being-ness!"
    },
    {
        "uid": "a1Xd0000001IIoQEAW",
        "year": 2016,
        "name": "Velvet Lamb",
        "contact_email": "brinemuth@yahoo.com",
        "hometown": "Los Angeles"
    },
    {
        "uid": "a1Xd0000001IJHgEAO",
        "year": 2016,
        "name": "Camp Struggle Bus",
        "hometown": "South Lake Tahoe",
        "description": "Come make your own personalized wooden alphabet necklace and relax in our light up jelly tentacle forest dome. If neither of these sound good maybe you can just enjoy a cup of lemonade and play some corn hole!"
    },
    {
        "uid": "a1Xd0000001IJhbEAG",
        "year": 2016,
        "name": "Recess",
        "contact_email": "jenn.brayden@gmail.com",
        "hometown": "Vancouver",
        "description": "noun  re·cess  \\ˈrē-ˌses, ri-ˈ\\ : a suspension of business or procedure often for rest or relaxation, such as a short period of time during the school day when children can play.  Let loose your inner child on our playground and take part in some self-directed art and play.  Who knows, you might learn something while you're at it."
    },
    {
        "uid": "a1Xd0000001IKZdEAO",
        "year": 2016,
        "name": "Pancake Playhouse",
        "hometown": "Sacramento",
        "description": "Pancake Playhouse: Serving fresh pancakes and playing soft rock Monday through Friday, nine-ish to noonish.",
        "location": {
            "string": "9:00 Plaza @ 3:15",
            "frontage": "9:00 Plaza",
            "intersection": "3:15",
            "intersection_type": "@",
            "gps_latitude": 40.792352979352394,
            "gps_longitude": -119.21499728426735
        },
        "location_string": "9:00 Plaza @ 3:15"
    },
    {
        "uid": "a1Xd0000001ILmMEAW",
        "year": 2016,
        "name": "PlayaPals Depot",
        "url": "http://www.playapals.com",
        "contact_email": "playapalsdepot@gmail.com",
        "hometown": "Sacramento",
        "description": "Delivering messages to people who didn't know they needed them since 2016."
    },
    {
        "uid": "a1Xd0000001IKlIEAW",
        "year": 2016,
        "name": "Sensual Pleasures (The Camp for)",
        "url": "http://campsensualpleasures.com/",
        "contact_email": "5d349e0a@opayq.com",
        "hometown": "LA & Orange County",
        "description": "The Camp for Sensual Pleasures is dedicated to providing pleasure for women in an environment that's sensual, safe, comfortable & private.  \r\n\r\nThe well-known Orgasamator Experience is back, enhanced to give women an even more intensely enjoyable experience, and the very popular Eros Tangeré, an Erotic Sensation Performance, is also returning.",
        "location": {
            "string": "Esplanade & 2:30",
            "frontage": "Esplanade",
            "intersection": "2:30",
            "intersection_type": "&",
            "gps_latitude": 40.78297439508715,
            "gps_longitude": -119.19866462296086
        },
        "location_string": "Esplanade & 2:30"
    },
    {
        "uid": "a1Xd0000001IKmLEAW",
        "year": 2016,
        "name": "Oasis 47",
        "url": "http://karenchristians.com/index.php/jewelry-of-burning-man/oasis-47",
        "contact_email": "cleverwerx@gmail.com",
        "hometown": "Boston",
        "description": "Since 2006, Oasis 47 continues its mission of engaging BRC Citizens in the art of jewelry embellishment. For 10 years, we have produced exquisite themed bronze pendants that are embellished and personalized with colorful resin inlay. For Da Vinci's Workshop, we are proud to present the historical 1627 Florin coin, from the Republic of Italy. Originally struck in gold, ours is gold colored in rich bronze. Hand carved in green wax by Sumner Silverman, one side displays the beautiful \"fleur-de-lis\" symbol. The reverse, is St. John the Baptist, outlined in negative space cells for the resin. BM 2016 is carved on the side of the coin. This project and the stories we learned about other jewelry for the last two years, was the inspiration for the book \"Jewelry of Burning Man\", published in 2015. We teach every day for 3 hours per day.",
        "location": {
            "string": "Esplanade & 8:30",
            "frontage": "Esplanade",
            "intersection": "8:30",
            "intersection_type": "&",
            "gps_latitude": 40.78982507488664,
            "gps_longitude": -119.21433618536174
        },
        "location_string": "Esplanade & 8:30"
    },
    {
        "uid": "a1Xd0000001IMTpEAO",
        "year": 2016,
        "name": "#Octothorpe",
        "url": "https://octothorpe.club",
        "contact_email": "hashtag@octothorpe.club",
        "hometown": "Seattle",
        "description": "Come # with us!!",
        "location": {
            "string": "I & 9:15",
            "frontage": "I",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.796965163936136,
            "gps_longitude": -119.21720937584996
        },
        "location_string": "I & 9:15"
    },
    {
        "uid": "a1Xd0000001IMz8EAG",
        "year": 2016,
        "name": "Space Baggers",
        "hometown": "Vancouver",
        "description": "Our big ass board games bring all the burners to the yard, and they're like, \"hey, this is pretty fun.\" Come for the games, stay to get schooled in DJing, juggling, and the fine art of hula hoop. Don't worry, we always make time for recess."
    },
    {
        "uid": "a1Xd0000001IN9pEAG",
        "year": 2016,
        "name": "Cheshire Camp",
        "url": "http://brc-fun.webs.com",
        "contact_email": "grady.bartley@gmail.com",
        "hometown": "Portland",
        "description": "Black Rock City's Bicycle Food/Gifting Cart Pod"
    },
    {
        "uid": "a1Xd0000001INrlEAG",
        "year": 2016,
        "name": "Hot Cheeks",
        "hometown": "California, Hawaii, Taiwan, New York",
        "description": "Hot Cheeks!  Best body painting on the playa! Get a portrait by world renowned Amedeus (His actual name not a misspelling), or stick your face in the cut-out and have a selfie as \"The Vetruvian Man\". Come in, relax, chill with a Blended Margarita, or warm up around our fire pit.   Full bar, non-techno music, conversation with our international members.  Learn the Chinese swear word of the day.  Watch for our Kava Ceremony and  wine tasting events!"
    },
    {
        "uid": "a1Xd0000001INyYEAW",
        "year": 2016,
        "name": "Scotch & Hop",
        "contact_email": "scotch--hop@googlegroups.com",
        "hometown": "New York, Reno, SF, LA, The Dakotas, Portland, Seattle, Somewhere in Wyoming, Philly, Boston, Toronto, London",
        "description": "Jump around and be silly playing Hop Scotch and drinking Scotch. All ages are welcome, but must be 21+ for the Scotch.",
        "location": {
            "string": "8:30 & C",
            "frontage": "8:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.791085369007384,
            "gps_longitude": -119.21722010505046
        },
        "location_string": "8:30 & C"
    },
    {
        "uid": "a1Xd0000001IOAGEA4",
        "year": 2016,
        "name": "Duane's Whirld",
        "hometown": "Burlington VT, Incline Village, NV, London, UK, Dubai UAE, Springfield, MA, NYC, South Lake Tahoe, CA Park City, UT",
        "description": "Duane's Whirld is a gathering of roughly 40 fun-loving, creative do-gooders from across the globe who love to make people feel welcome and warm. We thrive on cultivating connection and emotional  intimacy in a playful, joyful way. Please join us for a sunset sip or a cozy fireside chat.\r\n\r\neWay alsoAy oveLay igPay atinLay andAy eWay speciallyEay oveLay eakingSpay itaAy ithWay angerstStray osSay omeCay akeMay ewNay endsFray atAy uanesDay irldWhay. ayYay!"
    },
    {
        "uid": "a1Xd0000001IO4CEAW",
        "year": 2016,
        "name": "Camp of no Commitment",
        "hometown": "San Francisco",
        "description": "An art support camp, helping support the people who bring out the art you love."
    },
    {
        "uid": "a1Xd0000001IOCMEA4",
        "year": 2016,
        "name": "Playa Penthouse",
        "hometown": "Camarillo",
        "description": "Playa Penthouse. In Spanky's Village, come and enjoy the view from the top, over the entire Playa. Watch over your friends at the Wine Bar.",
        "location": {
            "string": "Esplanade & 2:30",
            "frontage": "Esplanade",
            "intersection": "2:30",
            "intersection_type": "&",
            "gps_latitude": 40.78297439508715,
            "gps_longitude": -119.19866462296086
        },
        "location_string": "Esplanade & 2:30"
    },
    {
        "uid": "a1Xd0000001IOVgEAO",
        "year": 2016,
        "name": "Dustrikt",
        "hometown": "Salt Lake City",
        "description": "Dustrikt"
    },
    {
        "uid": "a1Xd0000001IOOkEAO",
        "year": 2016,
        "name": "Cats!Cats!Cats!",
        "hometown": "San Francisco, Seattle, Vancouver, Los Angeles, Berlin",
        "description": "Cats!Cats!Cats! is part of the Planned Playahood village. We offer pregnancy testing, fornication counseling, bicycle repair, a playground and other \"second aid\" services to UN-FUCK YOUR BURN. Let's face it, sometimes your Burn gets fucked and we are here to un-fuck it for you.",
        "location": {
            "string": "7:00 & B",
            "frontage": "7:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.78414410068907,
            "gps_longitude": -119.21761649320165
        },
        "location_string": "7:00 & B"
    },
    {
        "uid": "a1Xd0000001IOvZEAW",
        "year": 2016,
        "name": "Prismaticamp",
        "url": "http://prismaticamp.org",
        "hometown": "Berkeley",
        "description": "A community of LED light artists. Join us each night at dusk for prismatic reception, interactive LED art projects and games, and our nightly community LED procession to the night Playa.  Also see the schedule for daytime interactive activities including LED fabrication/programming classes, Yoga classes, and Zen Bell ritual.",
        "location": {
            "string": "5:00 & B",
            "frontage": "5:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.77798282151022,
            "gps_longitude": -119.2094783790733
        },
        "location_string": "5:00 & B"
    },
    {
        "uid": "a1Xd0000001IOz2EAG",
        "year": 2016,
        "name": "Tazii",
        "contact_email": "jainesy@yahoo.com",
        "hometown": "San Francisco",
        "description": "Tazii will provide Moroccan chill space and top-shelf bar.  New this year will be live music, including our house David Bowie cover band!",
        "location": {
            "string": "3:30 & D",
            "frontage": "3:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.77771409960112,
            "gps_longitude": -119.19987774416956
        },
        "location_string": "3:30 & D"
    },
    {
        "uid": "a1Xd0000001IPLiEAO",
        "year": 2016,
        "name": "Primate Playground",
        "hometown": "Cupertino",
        "description": "Primate Playground will have events all week with, Home Brew, Flying Monkeys, Viking Ice Hugs, BubbleTron, Bacon and GrrrrAnimal Yoga is back! OR just come be a lazy monkey on our luscious astro-grass under the shade of the flying monkey hut.",
        "location": {
            "string": "7:00 & D",
            "frontage": "7:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.78380349492602,
            "gps_longitude": -119.21929438883451
        },
        "location_string": "7:00 & D"
    },
    {
        "uid": "a1Xd0000001IPN5EAO",
        "year": 2016,
        "name": "Sun Guardians",
        "url": "http://www.sunguardians.net",
        "contact_email": "info@sunguardians.net",
        "hometown": "San Francisco",
        "description": "A psuedo Hindu temple honoring Ganesh and Hanuman. Come get your spiritual groove on with Vinyasa, Hatha and amazing Rootist Temple style yoga sessions. Our meditation classes are centering and lifting unlike anything you experienced before. Come and enjoy the shade anytime. This is a Safe Place if you need to escape the sun, the crazy lights or just need a place to collect yourself.",
        "location": {
            "string": "F & 7:45",
            "frontage": "F",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.7878746073425,
            "gps_longitude": -119.22135635615312
        },
        "location_string": "F & 7:45"
    },
    {
        "uid": "a1Xd0000001IPNFEA4",
        "year": 2016,
        "name": "Hanuman's House of Tea and Ramen",
        "hometown": "San Francisco",
        "description": "We are serving Boba Milk Tea scheduled through the week and for those looking for a tummy warming last night nibble we will have hot ramen! Join us and see when we are serving in the What Where When or see the schedule posted on the front of the Tea House.",
        "location": {
            "string": "F & 7:45",
            "frontage": "F",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.7878746073425,
            "gps_longitude": -119.22135635615312
        },
        "location_string": "F & 7:45"
    },
    {
        "uid": "a1Xd0000001IPerEAG",
        "year": 2016,
        "name": "Lola",
        "hometown": "Las Vegas/Menlo Park/New York",
        "description": "At Camp LOLA our philosophy is spontaneity and serendipity. Bring us something from your heart - a poem, a dance, a song, etc. and express it on our \"soap box\" or draw a square for our Living with Heart tapestry. We offer healing touch instruction for couples, children's book story and cuddle time with optional vibrator, daily meditation and amateur yoga.",
        "location": {
            "string": "Esplanade & 2:30",
            "frontage": "Esplanade",
            "intersection": "2:30",
            "intersection_type": "&",
            "gps_latitude": 40.78297439508715,
            "gps_longitude": -119.19866462296086
        },
        "location_string": "Esplanade & 2:30"
    },
    {
        "uid": "a1Xd0000001IQ5TEAW",
        "year": 2016,
        "name": "Camp Asterix",
        "contact_email": "cr8tif@gmail.com",
        "hometown": "Coldwater",
        "description": "Camp Asterix with our new TURBO BAR dispensing Magiacal Illuminated Elixher that starts the night off with fun magical times."
    },
    {
        "uid": "a1Xd0000001IQHUEA4",
        "year": 2016,
        "name": "Dr. Carl's Dept of Recollection",
        "url": "http://www.drcarlscamp.com",
        "contact_email": "drcarl@drcarlscamp.com",
        "hometown": "Los Angeles",
        "description": "Dr Carl's Dept of Recollection will have you wracking your brain to solve a delightful puzzle of larger-than-life proportions. Achieve some level of success and you may find yourself with a semi-fabulous prize.",
        "location": {
            "string": "5:00 & B",
            "frontage": "5:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.77798282151022,
            "gps_longitude": -119.2094783790733
        },
        "location_string": "5:00 & B"
    },
    {
        "uid": "a1Xd0000001IQyhEAG",
        "year": 2016,
        "name": "Rootist Lounge",
        "url": "http://www.facebook.com/RootistLounge",
        "contact_email": "mikepierce@texaslive.us",
        "hometown": "Las Vegas",
        "description": "Rootist Lounge is a camp dedicated to sharing the joy of knowledge, of healing, of yoga, of oneness and so much more. We build a space that is interactive for different teachings that include various modalities of life. They include guided meditation, yoga, hug healing, sound therapy, color therapy, chakra charging and resonance sound resetting for a truer authentic self. Many teachers, many truths, one path.",
        "location": {
            "string": "F & 7:45",
            "frontage": "F",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.7878746073425,
            "gps_longitude": -119.22135635615312
        },
        "location_string": "F & 7:45"
    },
    {
        "uid": "a1Xd0000001IQsyEAG",
        "year": 2016,
        "name": "Anti M's Home for Wayward Art",
        "hometown": "Ogden",
        "description": "I went to an Art Festival, and brought home ART!  Come visit Anti M's Home for Wayward Art and adopt art into a forever home, or leave art to be adopted by others.",
        "location": {
            "string": "E & 5:15",
            "frontage": "E",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.776525043868155,
            "gps_longitude": -119.21189639030393
        },
        "location_string": "E & 5:15"
    },
    {
        "uid": "a1Xd0000001IR7tEAG",
        "year": 2016,
        "name": "Reincarnation Location",
        "contact_email": "burningman@funkweb.net",
        "hometown": "Los Angeles",
        "description": "Reincarnation Location\r\n\r\nParticipants are reborn into the world of the Playa!  \r\n\r\nFirst confess your sins, then spin the Wheeeeel of Penance.  Whatever it lands on, you'll have to do - but you do get to choose a G, R or NC-17 rated version.  Once your task is complete, you will be cleansed of all your sins and can be reborn!   You'll then rid yourself of all your worldly possessions (take your clothes off) and crawl out of our structure through a 6' vagina - where someone in hospital scrubs spanks you and gives you a rebirth certificate (with your thumb print and Playa name, then laminated)!"
    },
    {
        "uid": "a1Xd0000001IRCkEAO",
        "year": 2016,
        "name": "Awesome Town",
        "url": "http://www.yelp.com/biz/awesometown-black-rock-city",
        "hometown": "San Francisco",
        "description": "AwesomeTown, your favorite local municipality, is having a FUN-raising bake sale and KNEAD YOUR SUPPORT!  Actually, we're doing the kneading, and the baking, and we're serving up warm delicious cookies at our cookie cabana, \"Crumb In My Mouth\", every day from 4 - 6 pm.  Come by to get cookied!"
    },
    {
        "uid": "a1Xd0000001IRCuEAO",
        "year": 2016,
        "name": "Camp FerSherbert",
        "hometown": "Las Vegas",
        "description": "We will bring a superfluous amount of vegan treats to share with our burning man family.  Random acts of kindness and positive reinforcement will be a mainstay at our camp, Fer Sherbert!"
    },
    {
        "uid": "a1Xd0000001IRJxEAO",
        "year": 2016,
        "name": "Palinka Lounge",
        "hometown": "San Mateo/Budapest",
        "description": "Palinka is a Hungarian alcoholic delicacy, distilled from a variety of fruits like plum, apricot, apple, pear, grape or berries!\r\nWe'll be serving these with Rose Spritzers for everyones enjoyment while one can create their very own handmade crafts in our dome.\r\nCome join the Huns!"
    },
    {
        "uid": "a1Xd0000001IRJdEAO",
        "year": 2016,
        "name": "The Magic Theater",
        "hometown": "Ashland",
        "description": "THE MAGIC THEATER...Not for everyone...for madmen (and madwomen) only!"
    },
    {
        "uid": "a1Xd0000001IRh1EAG",
        "year": 2016,
        "name": "What Would Duct Tape Do??",
        "hometown": "New York City",
        "description": "What Would Duct Tape Do?? Helping our community members keep their cargo in good repair! We will instruct and assist people on useful playa fixes using duct tape in innovative and creative ways to repair, strengthen and create!"
    },
    {
        "uid": "a1Xd0000001IRrkEAG",
        "year": 2016,
        "name": "Sextant",
        "url": "http://sextantcamp.com/",
        "contact_email": "sextantcamp@gmail.com",
        "hometown": "Oakland",
        "description": "At Sextant, your life is in your hands: Giant Tesla Coils, Zip-Lines, a 75 foot Tower with a Crow's Nest, and Vünderbar (ze bar in ze sky!) 16 feet off the ground - we are committed to bringing the tallest, craziest, and most electrifying builds to the Playa.\r\n\r\nSextant is Hard Science, Hard Engineering and Hard Sexy.",
        "location": {
            "string": "Esplanade & 7:00",
            "frontage": "Esplanade",
            "intersection": "7:00",
            "intersection_type": "&",
            "gps_latitude": 40.78462658391771,
            "gps_longitude": -119.21523944492934
        },
        "location_string": "Esplanade & 7:00"
    },
    {
        "uid": "a1Xd0000001IRnxEAG",
        "year": 2016,
        "name": "Miso Horny",
        "url": "http://misohorny.us",
        "contact_email": "info@misohorny.us",
        "hometown": "Santa Cruz/Oakland",
        "description": "Miso Horny is all about refining ourselves and each other. We value humor, communication, playfulness, open mindedness, and creating strong meaningful bonds between one another. On the Playa we gift hot miso soup, sake, and herbal aphrodisiacs, as well as engaging conversations with our guests.\r\n\r\nThere are camps at Burning Man that offer public spaces for sexual play and exploration. While we fully support those groups, we choose to instead explore sex positivism by creating a safe event space for healthy dialogue of human sexuality. Our mission is to share ideas and philosophies that aid in the discovery of our sexual selves. We have created, and are always improving, a dedicated workshop and event space that is a platform for our lifelong journey of learning.",
        "location": {
            "string": "9:00 Portal & A",
            "frontage": "9:00 Portal",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.79209649034368,
            "gps_longitude": -119.21402456241272
        },
        "location_string": "9:00 Portal & A"
    },
    {
        "uid": "a1Xd0000001ISOgEAO",
        "year": 2016,
        "name": "Apocalypse Wow",
        "url": "http://www.apocalypsewow.camp",
        "contact_email": "winner.meredith@gmail.com",
        "hometown": "San Francisco",
        "description": "You gotta bone to pick, soldier? Trade your warm beers for cold ones at our Cold Beer Exchange Bar! Go MIA or commando in our Officers' lounge!"
    },
    {
        "uid": "a1Xd0000001ISdvEAG",
        "year": 2016,
        "name": "Trash Talk",
        "contact_email": "bymattgarcia@yahoo.com",
        "hometown": "St. Louis",
        "description": "Trash talk is a small but tenacious group of tinkerers and backyard inventors dedicated to bringing waste management services to the Burning Man community. Our Trash Trolley will roam BRC compacting trash and collecting burnables for our burn pit."
    },
    {
        "uid": "a1Xd0000001IUgBEAW",
        "year": 2016,
        "name": "Hyperbole",
        "contact_email": "hyperbolemusik@gmail.com",
        "hometown": "Oakland",
        "description": "Hyperbole is a camp for dreamers, artists, builders, makers, druids, reptaliens, time travelers, cynics and jokers..."
    },
    {
        "uid": "a1Xd0000001IV4aEAG",
        "year": 2016,
        "name": "Boots & Cats",
        "contact_email": "bmbootsandcats@gmail.com",
        "hometown": "San Francisco",
        "description": "According to urban dictionary, the phrase \"boots and cats\" is used to describe the baseline in beat boxing. We've adopted this phrase and chant it during good house songs, usually while at a show, and more predominantly after 2am."
    },
    {
        "uid": "a1Xd0000001IV6MEAW",
        "year": 2016,
        "name": "Normal People",
        "url": "http://www.normalpeople.life/",
        "contact_email": "normalpeople@hypesheet.com",
        "hometown": "San Francisco",
        "description": "Normal People Camp - Come enjoy movies, music, and hot beverages!"
    },
    {
        "uid": "a1Xd0000001IVCqEAO",
        "year": 2016,
        "name": "You Got This!",
        "hometown": "South Lake Tahoe",
        "description": "You Got This!\r\nFeeling overwhelmed by the Playa at the moment?  We got you.  Each of the stone cold weirdos in our eclectic crew brings a unique talent that just may help you get back on track."
    },
    {
        "uid": "a1Xd0000001IVFBEA4",
        "year": 2016,
        "name": "Morning Glory",
        "hometown": "Portland & Bend",
        "description": "Come for the hard candies and rosy cheeks, stay for the sass! Come get wild with some sassy, steel haired grannies ready to cause a ruckus, or maybe even a hubbub (but no fracases)."
    },
    {
        "uid": "a1Xd0000001IVI5EAO",
        "year": 2016,
        "name": "Bottoms Up!",
        "hometown": "San Francisco",
        "description": "Qweens, It's time to Lipstynk For Your Lives!\r\nBottoms Up! features Ass Lipstynk contests, Asshole decorating salon and the L'Ass supper group photo booth.\r\nGet that ass in the air and put some lashes on it for christ's sake."
    },
    {
        "uid": "a1Xd0000001IVPvEAO",
        "year": 2016,
        "name": "Temple Homage Camp",
        "hometown": "San Jose",
        "description": "A gathering place for like-minded people who love and honor the Temple. And providing support to those affected by their experiences at the Temple"
    },
    {
        "uid": "a1Xd0000001IVnnEAG",
        "year": 2016,
        "name": "Perky Parts",
        "url": "http://perkyparts.com/",
        "contact_email": "info@perkyparts.com",
        "hometown": "Newport Beach",
        "description": "Perky Parts - We Can't Pace Ourselves"
    },
    {
        "uid": "a1Xd0000001IVp5EAG",
        "year": 2016,
        "name": "Sacred Cow",
        "url": "https://www.facebook.com/groups/sacredcow/",
        "contact_email": "sacredcowkid@gmail.com",
        "hometown": "New York/ Seattle",
        "description": "Desert wanderer! Join the mystical culinary odyssey of the Sacred Cow as we romp through BRC on the Sacred Cow Hajj rooftop restaurant- lounge-mutant vehicle! Catch the Hajj spouting delectable smells down your neighborhood street, or toss fantastically fabricated food stuffs to the land locked participants below: such technological wonders of flavor they have never experienced. Sunset dinner cruise art tours. Late night playa picnics. Moonlit Temple Feasts. We always need kitchen help!"
    },
    {
        "uid": "a1Xd0000001IVqNEAW",
        "year": 2016,
        "name": "Sustainable Infrastructure Ideas",
        "url": "http://sustainabletransportationandcommunity.blogspot.com",
        "contact_email": "sustainabletransandcomm@gmail.com",
        "hometown": "Monroe Township",
        "description": "Brainstorming sessions on creating and implementing Sustainable Infrastructure: in a 30' PlayaDome covered with posters of ideas and innovations. 12 sessions: tentatively 11 am - 1 pm and 4-6 pm, Monday 8/29 - Saturday 9/3."
    },
    {
        "uid": "a1Xd0000001IVqmEAG",
        "year": 2016,
        "name": "Spaced Out",
        "contact_email": "iliana.hazzard@gmail.com",
        "hometown": "Oakland",
        "description": "Spaced Out is an astro-physics-themed camp celebrating the ever-expanding horizons of the universe.  Consisting of a planetarium and a human-sized galaxy wand, and home to our space jam dance party, Spaced Out provides a participatory experience for scientists to space cadets alike."
    },
    {
        "uid": "a1Xd0000001IVsxEAG",
        "year": 2016,
        "name": "BlackRockCity RetirementCommunity",
        "url": "https://brcrc.wordpress.com/",
        "hometown": "Seattle",
        "description": "Remember that time you visited your Gramma in the home? All those hard candies? Stories from how hard things were when she started was your age? Welcome to the Black Rock City Retirement Community.\r\n\r\nWe'll have custom-engineered, ergonomic and hemmorhoid-proof glider rocking chairs for old-timers to rest their aching bones. On-staff nurses will assess retirees for delirium and intervene appropriately. Feeling old?Feeling creaky and tired? Complain about your aches and pains and get some unsolicited and completely useless medical advice from Mags - her daughter's a doctor, after all. Hang out for Kanasta or large-print crosswords and talk about how it was better when you started Burning. Shake your fist or cane at the young kids and then head on back to the Nurse's Station for a soothing spongebath or libation, just to take that edge off.\r\n\r\nThe Retirement Community was designed with you, the aging Burner, in mind. Welcome Home."
    },
    {
        "uid": "a1Xd0000001IVvXEAW",
        "year": 2016,
        "name": "Twinkii",
        "contact_email": "twinkiipdx@gmail.com",
        "hometown": "Portland",
        "description": "Once upon a time, there was Twinkii, the magical twini-corn with two horns instead of one. Twinkii loved tasty sugar cubes, hot water foot soaks, pineapple tequila and granting wishes with his magical wish-hole. But because of his second horn, he was laughed at by other unicorns, his wish-hole largely overlooked by creatures seeking tru magic.\r\nFinally, on his 4th birthday he met the Horny Camp. Horny campers knew that two horns are better than one, and an unlimited number of horns is better than two. They loved Twinkii the twini-corn and both of his magical horns and his wish-hole. Together, Twinkii and his new friends, embarked on a great journey to enlighten the public on the subject of safe horn making, horn maintenance and... magic.",
        "location": {
            "string": "8:30 & C",
            "frontage": "8:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.791085369007384,
            "gps_longitude": -119.21722010505046
        },
        "location_string": "8:30 & C"
    },
    {
        "uid": "a1Xd0000001IW3DEAW",
        "year": 2016,
        "name": "Engineers Anonymous",
        "hometown": "Minneapolis/St Paul"
    },
    {
        "uid": "a1Xd0000001IVwpEAG",
        "year": 2016,
        "name": "Party Naked Tiki Bar",
        "url": "https://www.facebook.com/SinCityVillage/",
        "contact_email": "sincitybrc@gmail.com",
        "hometown": "Las Vegas",
        "description": "Cold alcohol Tiki Punch is served, for those age 21 and over (ID required), starting at 11:00am daily. Enjoy the sounds of classic rock in a cool and relaxing clothing optional environment. Stop in and have a seat where you are bound to meet someone new. You never have to get naked to enjoy but if you do, you may get \"leid\". Come party with us for our 8th year & please bring your own cup to be LNT friendly.",
        "location": {
            "string": "8:00 & C",
            "frontage": "8:00",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.78882496520954,
            "gps_longitude": -119.21845631653528
        },
        "location_string": "8:00 & C"
    },
    {
        "uid": "a1Xd0000001IWAEEA4",
        "year": 2016,
        "name": "Martini Camp",
        "contact_email": "aadams1997@yahoo.com",
        "hometown": "Reno",
        "description": "Come find Martini Camp located in Martini Village and join us for a Princess party, an evening of cocktails and sophistication as well as beer hot hour and a NV theme party!",
        "location": {
            "string": "E & 9:15",
            "frontage": "E",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79487521198001,
            "gps_longitude": -119.2150987488738
        },
        "location_string": "E & 9:15"
    },
    {
        "uid": "a1Xd0000001IW9VEAW",
        "year": 2016,
        "name": "Mist'R Cool Camp",
        "hometown": "Cupertino",
        "description": "Mist'R Cool Camp is about being cool. Cool as in cold and cool as in Fonze.  Our interactivity includes The Cool Mist Experience, an automated misting booth with pleasant surprises along with large wooden puzzles and other attractions.",
        "location": {
            "string": "7:30 & D",
            "frontage": "7:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.78639924266466,
            "gps_longitude": -119.21974624373193
        },
        "location_string": "7:30 & D"
    },
    {
        "uid": "a1Xd0000001IW4pEAG",
        "year": 2016,
        "name": "Barbie Death Camp",
        "url": "http://barbiedeathcamp.com",
        "hometown": "Placerville CA",
        "description": "Barbie Death Camp- the sickest Bastards on the Playa, still serving fine wine in cheap paper cups.",
        "location": {
            "string": "6:30 & E",
            "frontage": "6:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78105582486477,
            "gps_longitude": -119.21872283512668
        },
        "location_string": "6:30 & E"
    },
    {
        "uid": "a1Xd0000001IWDSEA4",
        "year": 2016,
        "name": "Shotski Wanderlust",
        "hometown": "Reno",
        "description": "Looking for skis, boards, a killer chair lift, shots & fun? Camp ShotSki Wanderlust is the place to come! We are an open and diverse group of people comprised of veterans and newbies who like to bring a bit of the Sierra fun to the Playa.",
        "location": {
            "string": "B & 4:15",
            "frontage": "B",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77776035808324,
            "gps_longitude": -119.20499938179593
        },
        "location_string": "B & 4:15"
    },
    {
        "uid": "a1Xd0000001IWFYEA4",
        "year": 2016,
        "name": "...and then there's only LOVE",
        "url": "http://www.andthentheresonlylove.com/",
        "contact_email": "andthentheresonly@yahoo.com",
        "hometown": "Sacramento",
        "description": "ATTOL is a place to love and be loved, and we work together to provide the residents of Black Rock City our world famous, air conditioned Orgy Dome - a safe, consensual, sex-positive, inclusionary and exploratory environment where adult couples and moresomes can play and love. We celebrate life and love in all forms where straight, gay, lesbian, bi, polyamorous and monogamous are enthusiastically welcomed.",
        "location": {
            "string": "4:30 & D",
            "frontage": "4:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.776370604715595,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & D"
    },
    {
        "uid": "a1Xd0000001IWG7EAO",
        "year": 2016,
        "name": "Boom Town",
        "contact_email": "ebozzy@gmail.com",
        "hometown": "Santa Cruz",
        "description": "Sweet awesome friendly wild whacky wonderful loving bunch of beautiful motherfuckers! Come get a drink and shake a leg :)"
    },
    {
        "uid": "a1Xd0000001IWHjEAO",
        "year": 2016,
        "name": "Murmuration",
        "contact_email": "campmurmuration@gmail.com",
        "hometown": "Brooklyn",
        "description": "Join us at Camp Murmuration for an interactive ritualized bird dance every night at sunset. Come fly with us!"
    },
    {
        "uid": "a1Xd0000001IWIXEA4",
        "year": 2016,
        "name": "Dusty Frogz",
        "url": "http://www.dustyfrogz.fr",
        "contact_email": "contact@dustyfrogz.fr",
        "hometown": "Montpellier",
        "description": "Come on little froggy, we are a french team with the fucking french touch. We 'll try to share our fucking culture to the burners and more \"si affinités\"."
    },
    {
        "uid": "a1Xd0000001IWJQEA4",
        "year": 2016,
        "name": "Electric Kool-Aid Vision Quest",
        "url": "http://fb.com/ekavq",
        "contact_email": "electric-koolaid@googlegroups.com",
        "hometown": "Boston",
        "description": "Electric Kool-Aid Vision Quest brings its special brand of free love to the playa for the first time in 2016 after three years as a theme camp at Firefly, New England's regional burn. Electric Kool-Aid provides a beautiful lounge space with a custom-built glow-in-the-dark purple heart bar serving what else but Electric Kool-Aid, and features the Reflection Tree, a two-meter tower of 2,160 LEDs with a sensor array that picks up and redisplays the most saturated color in every direction. The LEDs change over time as they flow up, allowing the viewer to \"go back in time\" by viewing the colors of previous playa passers-by. Theme nights at the Electric Kool-Aid Lounge will include Futuristic Space Femme-bot Alien Matriarchy, where residents of the planet Liminality including ladies dressed as high priestesses and men dressed as temple prostitutes usher you into a fantastic new world where everything is better and nothing sucks… unless you want it to.",
        "location": {
            "string": "Esplanade & 8:30",
            "frontage": "Esplanade",
            "intersection": "8:30",
            "intersection_type": "&",
            "gps_latitude": 40.78982507488664,
            "gps_longitude": -119.21433618536174
        },
        "location_string": "Esplanade & 8:30"
    },
    {
        "uid": "a1Xd0000001IWIrEAO",
        "year": 2016,
        "name": "Camp UNTITLED",
        "hometown": "New York",
        "description": "Camp UNTITLED: Where everyone is equal and everyone gets a lobster roll!"
    },
    {
        "uid": "a1Xd0000001IWMeEAO",
        "year": 2016,
        "name": "Black Rock City Airbrush",
        "url": "https://www.facebook.com/SinCityVillage/",
        "contact_email": "sincitybrc@gmail.com",
        "hometown": "Las Vegas",
        "description": "Black Rock City Airbrush with Jake-A-Saurus is here to provide your airbrushing needs!\r\n\r\nThis camp resides within the Sin City Village and offers the finest custom airbrushed body art made just for you! Bring in a clean, white, T-shirt if you want your art to last even after you leave home. \"You-say-it-we-spray-it\" at Black Rock City Airbrush.\r\n\r\nWe are creating MAXIMUM participation from gifted patrons!\r\n\r\nExpect to participate, and/or take a guerilla course in airbrushing! You may even find yourself running our booth while we sneak away.\r\n \r\nEnthusiasm, Curiosity, Compliments, Flirting, Patience, and Cold Beer go a long way at our camp!",
        "location": {
            "string": "8:00 & C",
            "frontage": "8:00",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.78882496520954,
            "gps_longitude": -119.21845631653528
        },
        "location_string": "8:00 & C"
    },
    {
        "uid": "a1Xd0000001IWL2EAO",
        "year": 2016,
        "name": "Althing",
        "description": "Althing, where there's a little of everything! Come and entertain your brain, jumpstart your heart, wet your whistle and leave with a smile...",
        "location": {
            "string": "E & 5:15",
            "frontage": "E",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.776525043868155,
            "gps_longitude": -119.21189639030393
        },
        "location_string": "E & 5:15"
    },
    {
        "uid": "a1Xd0000001IWN8EAO",
        "year": 2016,
        "name": "Coup de Foudre",
        "url": "http://coupdefoud.re",
        "contact_email": "meawoppl@gmail.com",
        "hometown": "San Francisco",
        "description": "We are a camp dedicated to creating otherworldly electrical experiences of all sorts.  We love large Tesla coils above all, but welcome all interest and skill levels of electro-enthusiasts to visit!",
        "location": {
            "string": "Esplanade & 5:00",
            "frontage": "Esplanade",
            "intersection": "5:00",
            "intersection_type": "&",
            "gps_latitude": 40.7797827277492,
            "gps_longitude": -119.2088415564309
        },
        "location_string": "Esplanade & 5:00"
    },
    {
        "uid": "a1Xd0000001IWNNEA4",
        "year": 2016,
        "name": "Pair-a-dice",
        "hometown": "Smartsville",
        "description": "Come hang out at The Bamboo Bar in Pairadice! Leave time to check out The Fish Tank!",
        "location": {
            "string": "9:00 & K",
            "frontage": "9:00",
            "intersection": "K",
            "intersection_type": "&",
            "gps_latitude": 40.79674632413234,
            "gps_longitude": -119.22016801956524
        },
        "location_string": "9:00 & K"
    },
    {
        "uid": "a1Xd0000001IWOpEAO",
        "year": 2016,
        "name": "The Firehouse",
        "url": "http://www.do-more-now.com/",
        "contact_email": "chad@do-more-now.com",
        "hometown": "Everett",
        "description": "Each year camp Do-More-Now brings to Burning Man the Firehouse, a five story building providing a relaxing hangout, one of the best views on the playa, a bar, and a space and materials for people to create awesome art. In addition we host bands, fire dancers and hold themed parties most evenings and morning mimosa bar.",
        "location": {
            "string": "7:30 & B",
            "frontage": "7:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.786399428284064,
            "gps_longitude": -119.21800903146068
        },
        "location_string": "7:30 & B"
    },
    {
        "uid": "a1Xd0000001IWOuEAO",
        "year": 2016,
        "name": "Trashistan",
        "hometown": "Clearlake",
        "description": "There will be heckling. And movies.",
        "location": {
            "string": "5:00 & B",
            "frontage": "5:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.77798282151022,
            "gps_longitude": -119.2094783790733
        },
        "location_string": "5:00 & B"
    },
    {
        "uid": "a1Xd0000001IWPYEA4",
        "year": 2016,
        "name": "DREAMSCAPE",
        "contact_email": "dreamscapeburns@gmail.com",
        "hometown": "Seattle",
        "description": "DREAMSCAPE invites you to explore our playa dreamland- complete with Dream Dome, Glow Jellies art installation, Shimmer Shimmy Hoop Building Workshop and Hooping Lessons, Prisma Dance Party, PlayaFried Laser Tag, Afterglow Shadow Wall, and popup Fantasy Table Top Gaming sessions offer throughout the week! Explore our ethereal realm where surreal soundscapes and rainbows of light elevate your conscious to fantastic new heights!",
        "location": {
            "string": "B & 8:15",
            "frontage": "B",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.78973011696535,
            "gps_longitude": -119.21713560963664
        },
        "location_string": "B & 8:15"
    },
    {
        "uid": "a1Xd0000001IWRZEA4",
        "year": 2016,
        "name": "Sin City Day Spa",
        "url": "https://www.facebook.com/SinCityVillage/",
        "contact_email": "sincitybrc@gmail.com",
        "hometown": "Las Vegas",
        "description": "Have a mini \"MIRACLE SHOWER\" and learn how you can \"shower\" on playa with two glasses of water and feel squeaky clean. All you need to do is bring your own towel. Other services include foot massage/moisturizing, sun screen or aloe vera application, manicures and more. Come by and check for hours of operation and full services list.",
        "location": {
            "string": "8:00 & C",
            "frontage": "8:00",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.78882496520954,
            "gps_longitude": -119.21845631653528
        },
        "location_string": "8:00 & C"
    },
    {
        "uid": "a1Xd0000001IWQqEAO",
        "year": 2016,
        "name": "Sin City Art Center",
        "url": "https://www.facebook.com/SinCityVillage/",
        "contact_email": "sincitybrc@gmail.com",
        "hometown": "Las Vegas",
        "description": "Come by any time to enjoy our collection of Burner Art created by camp members and local Burners. See what creative minds have made for you to enjoy. If you have art that you created and to have displayed you can bring it by to add to the collection. Please, be respectful of the artists that have contributed to create this display and do not vandalize or steal from the art center.  Thank you.",
        "location": {
            "string": "8:00 & C",
            "frontage": "8:00",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.78882496520954,
            "gps_longitude": -119.21845631653528
        },
        "location_string": "8:00 & C"
    },
    {
        "uid": "a1Xd0000001IWS3EAO",
        "year": 2016,
        "name": "Videogasm",
        "url": "http://www.videogasm.com",
        "contact_email": "videogasm@gmail.com",
        "hometown": "Detroit",
        "description": "Black Rock City's Playa Theater since 1998! Nightly video screenings on our two big screens. Body painting every afternoon in our shade structure. Come by and cool off in our mister! Play with our smoke ring cannons and over-sized games. Adult Hoppity Hop races every afternoon in our courtyard! Record a message in our Burning Man video comment booth then watch it later on our screens. Play Playa Jeopardy on Wednesday night. Live Rocky Horror Picture Show on Friday night! Home of The 48 Hour Film Project BRC. Contact us if you have an original video you'd like to show. Located in Snowflake Village.",
        "location": {
            "string": "Esplanade & 6:45",
            "frontage": "Esplanade",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78377478201974,
            "gps_longitude": -119.21485701075231
        },
        "location_string": "Esplanade & 6:45"
    },
    {
        "uid": "a1Xd0000001IWTuEAO",
        "year": 2016,
        "name": "VEGAN NIGHTMARE CAMP",
        "url": "https://www.facebook.com/VEGANNIGHTMARE/",
        "contact_email": "phil.godbout@gmail.com",
        "hometown": "Sacramento",
        "description": "Vegan Nightmare Camp is a celebration of homo sapiens asserting the rightful place on top of the food chain.  Serving up bacon and spam infused booze during daily bar hours Vegan Nightmare hosts a loving forum to discuss the ethical, sustainable, and delicious aspects of eating animals."
    },
    {
        "uid": "a1Xd0000001IWUJEA4",
        "year": 2016,
        "name": "CARAVAN OF LIGHT CAMP",
        "url": "https://www.facebook.com/events/1534568293514150/",
        "hometown": "Los Angeles",
        "description": "BM 2016: CARAVAN OF LIGHT CAMP * \r\n* WHERE'S THE FIRE' STAGE * FREEDOM TEMPLE\r\nCamp INTERACTIVITY will consist of many fun loving colorful profound Activities in our LEONARDO'S LOUNGE AREA and on our WHERE'S THE FIRE STAGE:\r\n- DAILY: By Caravan of Light \"JUJU JUICE BAR\" during the Daytime Hours (2pm-Sunset). Alongside our World Class (WTF?)STAGE bringing Live Music back to the Playa, Special Guest DJ's, Full NataRaj Dancing, Stage Performances, Live Body Painting... Environmentally Conscious Lectures, Workshops, Meditation, Morning Yoga... \r\n\r\nhttps://www.facebook.com/events/1534568293514150/"
    },
    {
        "uid": "a1Xd0000001IWUTEA4",
        "year": 2016,
        "name": "Cloud City",
        "url": "http://recreationallightandmagic.com/category/cloudcity",
        "contact_email": "shelly@totallylegitllc.com",
        "hometown": "Seattle",
        "description": "Find us at Cloud City, where we would love to give you a ride on our giant pinball machine, Attacks from Mars!"
    },
    {
        "uid": "a1Xd0000001IWUEEA4",
        "year": 2016,
        "name": "Debocceri",
        "url": "http://debocceri.com",
        "contact_email": "info@debocceri.com",
        "hometown": "San Francisco Bay Area, Los Angeles, Vancouver, British Columbia, New York",
        "description": "Debocceri is located inside \"Planned Playahood\" village. The Bocce courts are open 24/7 with lights for night-time play: come play with our balls! We host special events 3-5pm daily featuring open bar and ice cream. We offer bicycle repair, car-buffer massage, a chill dome, live bluegrass music, furkins and \"second aid\" services including playa-naming and open playa-marriage officiating.",
        "location": {
            "string": "7:00 & B",
            "frontage": "7:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.78414410068907,
            "gps_longitude": -119.21761649320165
        },
        "location_string": "7:00 & B"
    },
    {
        "uid": "a1Xd0000001IWXDEA4",
        "year": 2016,
        "name": "Burning Man Mafia",
        "url": "https://www.facebook.com/groups/BurningManMafia/",
        "contact_email": "burningmanmafia@groups.facebook.com",
        "hometown": "San Jose",
        "description": "Show off your visionary skills. Come over and play a psychologically thrilling game of Mafia in the setup inspired by Leonardo's Last Supper."
    },
    {
        "uid": "a1Xd0000001IWYQEA4",
        "year": 2016,
        "name": "IN YOUR EYES",
        "url": "https://www.facebook.com/groups/486403201565488/",
        "hometown": "Sebastopol, CA",
        "description": "Many of us come from cultures where physical touch and speaking openly is discouraged. Even in the swirling world of self-expression that is Burning Man, people can easily miss simple human contact. Our camp wants to see each individual spirit, to hear their stories and to offer moments of real connection. We plan to offer: \r\n●\t60 seconds or more of Intentional Gazing. \r\n●\tFive Minutes or more of Focused Listening. \r\n●\tGenerous Hugs - just as long as each visitor wants. \r\nOur camp members will offer these services Noon to 6 PM daily (or pretty much any time we're in our big round public living room). We want to empower and encourage our campers and visitors to continually offer these same three tokens of human contact. \r\nWe are an international group of campers. A few of our campers plan to get the \"self-Guided Art Tour\" document (in English) from The ARTery and use that document to lead Art tours in their native language. Meeting place and times to be determined."
    },
    {
        "uid": "a1Xd0000001IWXXEA4",
        "year": 2016,
        "name": "Pseudogram",
        "url": "http://www.pseudogram.com",
        "hometown": "San Jose",
        "description": "What's in the name? Come over and find out. Using our original and innovative method, we will create a playa name for you."
    },
    {
        "uid": "a1Xd0000001IWgMEAW",
        "year": 2016,
        "name": "SHLTRD",
        "contact_email": "campshltrd@gmail.com",
        "hometown": "Fort Lauderdale"
    },
    {
        "uid": "a1Xd0000001IWZJEA4",
        "year": 2016,
        "name": "The Phage",
        "url": "http://thephage.org/",
        "contact_email": "phage@alumni.stanford.edu",
        "hometown": "San Francisco, Los Angeles, Boston, NYC",
        "description": "The Phage is an homage to the vast dark ecology whose foment gave birth to Earth's living diversity. These ubiquitous viral life forms evolve faster than any other life on earth. In their furious co-optive radiations they have acted as the vital genetic pollinators that wove long-separated lines of cellular life into resplendent new threads -- the phage are the needles of life's tapestry. Beware if you encounter us: memetic biohazards lie ahead.",
        "location": {
            "string": "Esplanade & 5:00",
            "frontage": "Esplanade",
            "intersection": "5:00",
            "intersection_type": "&",
            "gps_latitude": 40.7797827277492,
            "gps_longitude": -119.2088415564309
        },
        "location_string": "Esplanade & 5:00"
    },
    {
        "uid": "a1Xd0000001IWlvEAG",
        "year": 2016,
        "name": "Syncytium",
        "url": "http://www.syncytium.org",
        "contact_email": "syncytiumcamp@gmail.com",
        "hometown": "Ann Arbor/Detroit",
        "description": "Syncytium: a single cell containing several nuclei, formed by fusion of cells or by division of nuclei. Syncytium consists of people who \"do\". Artists, Engineers, Scientists, Flow Artists, Seekers, Builders, Makers, Musicians and Circus performers. We come together with our varied talents to push our own limits. We are never exactly the same from year to year.",
        "location": {
            "string": "3:30 & B",
            "frontage": "3:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.778853255646204,
            "gps_longitude": -119.20074613806385
        },
        "location_string": "3:30 & B"
    },
    {
        "uid": "a1Xd0000001IX2hEAG",
        "year": 2016,
        "name": "Juicy Rootz",
        "hometown": "New York",
        "description": "Camp Juicy Rootz!\r\nSolid roots, family pride and growth.\r\nOur roots are strong, a camp mix of friends from both on and off  the playa. We are full positive juicy vibes and a family tree the continues to grow with wonderful people who enjoy life's journey."
    },
    {
        "uid": "a1Xd0000001IX6jEAG",
        "year": 2016,
        "name": "Garden of Geeky Delights",
        "hometown": "Lyon",
        "description": "Let out your geeky side in our garden. Chill with board games and e-shishas in our Tushisha and Hooha Lounge, and test your Playamobile tricycle racing skills on our 1:200 scale Formula One racing tracks - a different one each day!"
    },
    {
        "uid": "a1Xd0000001IX8aEAG",
        "year": 2016,
        "name": "The Tinkers",
        "contact_email": "mr.seamus.leonard@gmail.com",
        "hometown": "San Francisco/Vancouver/Boston/Sydney",
        "description": "The Tinkers are on the road to your village to repair pots pans & utensils.\r\nWe can fix your cup & fill it up, with water, wine, whiskey and love!"
    },
    {
        "uid": "a1Xd0000001IXB0EAO",
        "year": 2016,
        "name": "Sexy Tramps",
        "hometown": "New York city area including Brooklyn and nearby New Jersey",
        "description": "Full of joy from unabridled admiration from our Compliment Booth, you can lay your bindlestiff down and take a moment from your travels to share a story with your fellow adventurers at Sexy Tamps.  Refresh yourself with an ice-cold SnakeByte, bounce on our Sexy Trampoline, warm yourself by our fire, dance with abandon, and take in the abundant amusements and oddities presented for your enjoyment.  Most of all, Stay Sexy."
    },
    {
        "uid": "a1Xd0000001IXCIEA4",
        "year": 2016,
        "name": "Camp Manifestation",
        "url": "http://campmanifestation.com",
        "contact_email": "jed@campmanifestation.com",
        "hometown": "Oakland",
        "description": "At Camp Manifestation we encourage and explore the process of creation, acknowledging that power within each of us, in order to manifest whatever is in one's heart and to experience life as one desires. By discovering our innate ability, we put intention toward the coupling of the power of thought with the moving force of action. We then begin to ignite and catalyze these forces which allows us to create magical results in the world. Come explore with us!"
    },
    {
        "uid": "a1Xd0000001IXC3EAO",
        "year": 2016,
        "name": "Phar-Ho’s & Sphinxters",
        "hometown": "Reno"
    },
    {
        "uid": "a1Xd0000001IXCwEAO",
        "year": 2016,
        "name": "Babes in Toyland",
        "contact_email": "lamcdougall14@gmail.com",
        "hometown": "Los Angeles",
        "description": "Magical fantasy land filled with beautiful burners that want to serve you Thanksgiving dinner on Thursday at the burn and really have the urge to discuss your thoughts on Drew Barrymore, Laurel and Hardy, or the all punk girl band Babes in Toyland. Come eat some turkey and tell us what you're thankful for!"
    },
    {
        "uid": "a1Xd0000001IX6AEAW",
        "year": 2016,
        "name": "Firedrop",
        "contact_email": "churchillster42@gmail.com",
        "hometown": "Nevada City",
        "description": "Experience a nonstop celebration of life expressed through fire dancing, samba drums, and general revelry at Firedrop. Come see one of our fire shows,  or come take a ride on our Hypergalactic Space Yacht - the Sol Riser."
    },
    {
        "uid": "a1Xd0000001IXHcEAO",
        "year": 2016,
        "name": "Camp Yaaaaas!"
    },
    {
        "uid": "a1Xd0000001IXH8EAO",
        "year": 2016,
        "name": "Nice Nice",
        "url": "http://campnicenice.com/",
        "hometown": "Palo Alto / Napa",
        "description": "We are an international group of artists, musicians, yogis, dancers, scientists, and creators.\r\n\r\nWe invite you to enjoy daily musical jam sessions around specially crafted interactive 8 foot long chimes (tubular bells), the Playa xylophone, and two deep-pitched gongs. Wander through our Art Garden. Chill out under our shade or sit by our camp fire. And, of course, the flamingos are expected to return to the light pond."
    },
    {
        "uid": "a1Xd0000001IXMmEAO",
        "year": 2016,
        "name": "Got Time For That!?",
        "contact_email": "burning-man-2016----i----@googlegroups.com",
        "hometown": "Los Angeles",
        "description": "Simultaneously an exclamation and a question, Camp Got Time For That!? toys with the nebulous concept of time, cultivating a sensory exploration of Playa time. Stop and smell the time with us. Got Time For That!?"
    },
    {
        "uid": "a1Xd0000001IXNBEA4",
        "year": 2016,
        "name": "PlovKraft",
        "url": "https://sites.google.com/site/plovkraft",
        "contact_email": "burningplov@groups.facebook.com",
        "hometown": "Los Angeles",
        "description": "PlovKraft: bringing fine Uzbek pilaff to the Playa! 5:00 PM until supplies last."
    },
    {
        "uid": "a1Xd0000001IXOdEAO",
        "year": 2016,
        "name": "Captain Pump's Raiders",
        "url": "https://www.facebook.com/PumpsRaiders?fref=ts",
        "contact_email": "silathis@gmail.com",
        "hometown": "Boulder",
        "description": "Captain Pump's Raiders is Black Rock City's finest mercenary company. By which we mean we are a collection of geeks, gamers, musicians, artists and storytellers committed to adding to the fantastical nature of Burning Man through song, story, and roleplaying games."
    },
    {
        "uid": "a1Xd0000001IXOxEAO",
        "year": 2016,
        "name": "Crepe Day Camp",
        "hometown": "Santa Rosa",
        "description": "Crepe Day Camp - A group of pun loving crepe people. Serving fresh crepes 9am-12pm Thursday morning. Come bearing puns!"
    },
    {
        "uid": "a1Xd0000001IXOYEA4",
        "year": 2016,
        "name": "Disco Chateau",
        "url": "http://www.discochateau.org",
        "contact_email": "desiree@discochateau.com",
        "hometown": "San Francisco",
        "description": "Disco Chateau is a creative global community for artistic, loving & inspirational people who are committed to sharing their experience at Burning Man as one family. The focus being human connection. We are a community that thrives on human intimacy, mindfulness, creativity, love of music, dance, community, art, & relaxation. In order to foster our growing, global community at Burning Man, the majority of our activities are focused on interactivity."
    },
    {
        "uid": "a1Xd0000001IXPqEAO",
        "year": 2016,
        "name": "Art Car Bus Stop",
        "url": "http://www.artcarbusstop.com",
        "contact_email": "wait@artcarbusstop.com",
        "hometown": "Los Angeles",
        "description": "Hurry up and wait!  Art Car Bus Stop is your premier source for faux municipality.   Do you desperately crave the civil structure of a Metropolis?   Can your thirst for order and reason only be quenched by public service legislation?  Do you desire municipal services to help your lifestyle gain that extra degree of sophistication?  Us neither!  But we can pretend, right?\r\n\r\nWarning: Art Car Bus Stop was produced in a factory that processes peanuts.  The FDA has not evaluated the effects of art as part of a daily diet.  Use at your own risk."
    },
    {
        "uid": "a1Xd0000001IXQtEAO",
        "year": 2016,
        "name": "Moon Cheese",
        "url": "http://tastethemoon.com/",
        "hometown": "San Francisco Bay Area",
        "description": "Crossroads pumps out the best live music on the playa, verified by gods and science. Moon Cheese is the best grilled cheese camp on the playa according to YOUR MOUTH. Get down with our nightly live music shows featuring a 20+ piece band, dancers, performers, and people wearing nothing but aprons covered in grill marks. Get a grilled cheese sandwich, a drink at the bar, dance your dusty self to sheer exhaustion and then snag some downtime in our sparkly star chill dome before it all disappears.\r\nYou'll never know whether it was real or just a greasy, funktastic dream so intense it made Mona Lisa (the original sparkle pony) blush.",
        "location": {
            "string": "9:00 Plaza @ 10:30",
            "frontage": "9:00 Plaza",
            "intersection": "10:30",
            "intersection_type": "@",
            "gps_latitude": 40.79256133313418,
            "gps_longitude": -119.2141864372901
        },
        "location_string": "9:00 Plaza @ 10:30"
    },
    {
        "uid": "a1Xd0000001IXPREA4",
        "year": 2016,
        "name": "Mischevious Ambition",
        "hometown": "Chicago",
        "description": "Mischevious Ambition is a Chicago-based group of burners providing ultraviolet lighting to bring out the glow in you, as we offer lemonade and snow cones, and have a glowing race track, as well as blacklight group photography and blacklight face painting.",
        "location": {
            "string": "Esplanade & 2:30",
            "frontage": "Esplanade",
            "intersection": "2:30",
            "intersection_type": "&",
            "gps_latitude": 40.78297439508715,
            "gps_longitude": -119.19866462296086
        },
        "location_string": "Esplanade & 2:30"
    },
    {
        "uid": "a1Xd0000001IXQjEAO",
        "year": 2016,
        "name": "*cats",
        "hometown": "SF/NYC/LA",
        "description": "fearless felines, feeling frantic? feel free to fervently flutter up our fantastically fanciful yet firm fabrication (please climb on our dome!). comatose cats, come crawl climb or clamber into cool and comfortable cushioned cradles for a cathartic catnap (we have hammocks, sleep in them!).",
        "location": {
            "string": "Esplanade & 8:30",
            "frontage": "Esplanade",
            "intersection": "8:30",
            "intersection_type": "&",
            "gps_latitude": 40.78982507488664,
            "gps_longitude": -119.21433618536174
        },
        "location_string": "Esplanade & 8:30"
    },
    {
        "uid": "a1Xd0000001IXRcEAO",
        "year": 2016,
        "name": "Significant Encounter",
        "hometown": "Houston",
        "description": "A social game designed to promote closeness among strangers as well as to deepen the connection among friends and couples. This game is based on academic research in psychology and social sciences."
    },
    {
        "uid": "a1Xd0000001IXR8EAO",
        "year": 2016,
        "name": "Love Potion Camp",
        "url": "http://lovepotion.camp",
        "contact_email": "lovepotioncamp@googlegroups.com",
        "hometown": "Oakland",
        "description": "Celebrating art, creativity, whimsy, fun, family, positive vibes, and our famous Love Potion. To join us on-Playa, please visit http://lovepotion.camp\r\n\r\nOff-Playa, many of our crew spend time building Love Potion Collective, a nonprofit makerspace and creative meeting place. To learn more, visit http://www.lovepotioncollective.org",
        "location": {
            "string": "7:00 & D",
            "frontage": "7:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.78380349492602,
            "gps_longitude": -119.21929438883451
        },
        "location_string": "7:00 & D"
    },
    {
        "uid": "a1Xd0000001IXRhEAO",
        "year": 2016,
        "name": "Camp Hey Gurl, Hey!",
        "contact_email": "campheygurlhey@gmail.com",
        "hometown": "San Francisco",
        "description": "Camp Hey Gurl, Hey! is a very chill bunch of gay guys from San Francisco, Seattle, and Sydney, Australia. When you visit us we will treat you right."
    },
    {
        "uid": "a1Xd0000001IXSKEA4",
        "year": 2016,
        "name": "False Profit",
        "url": "http://false-profit.com/burningman",
        "hometown": "San Francisco",
        "description": "False Profit pays dividends to investors in the form of innovative cultural experiences and immersive community. Invest wisely, the life you enjoy may be your own.",
        "location": {
            "string": "Esplanade & 5:00",
            "frontage": "Esplanade",
            "intersection": "5:00",
            "intersection_type": "&",
            "gps_latitude": 40.7797827277492,
            "gps_longitude": -119.2088415564309
        },
        "location_string": "Esplanade & 5:00"
    },
    {
        "uid": "a1Xd0000001IXTwEAO",
        "year": 2016,
        "name": "Hapless Genies",
        "hometown": "San Francisco",
        "description": "We are the Hapless Genies -  a camp of welcoming and passionate guys and gals, always excited to have an amazing time to share with each other and with our fellow burners. For Hapless Genies, creating amazing experiences and lasting relationships have always been at our core of how we participate in and what we plan to bring as a camp to the Playa community."
    },
    {
        "uid": "a1Xd0000001IXTXEA4",
        "year": 2016,
        "name": "Just The Tip",
        "hometown": "Reno",
        "description": "Just The Tip, inside Martini Village, of course has dick jokes, double entendres and lots of inappropriate gesturing, along with amazing people.",
        "location": {
            "string": "E & 9:15",
            "frontage": "E",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79487521198001,
            "gps_longitude": -119.2150987488738
        },
        "location_string": "E & 9:15"
    },
    {
        "uid": "a1Xd0000001IXXZEA4",
        "year": 2016,
        "name": "16 Inches of Joy",
        "hometown": "New York, Copenhagen (Denmark), Washington D.C, Beijing",
        "description": "16 Inches of Joy serves steaming hot and delicious New York Pizza. Delivery available.",
        "location": {
            "string": "8:15 & K",
            "frontage": "8:15",
            "intersection": "K",
            "intersection_type": "&",
            "gps_latitude": 40.79199845038348,
            "gps_longitude": -119.22435685122926
        },
        "location_string": "8:15 & K"
    },
    {
        "uid": "a1Xd0000001IXZkEAO",
        "year": 2016,
        "name": "Pyrotex Fire Conclave Camp",
        "contact_email": "pyrotex.coordinator@gmail.com",
        "hometown": "Austin (primary), Houston (secondary), Dallas, other Texas locations.",
        "description": "Pyrotex is a group of Texas based fire artists offering classes in a variety of movement arts, as well as drumming, permaculture and other interests.",
        "location": {
            "string": "G & 6:15",
            "frontage": "G",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.21907490302245
        },
        "location_string": "G & 6:15"
    },
    {
        "uid": "a1Xd0000001IXZVEA4",
        "year": 2016,
        "name": "Web of Dreams and Tautology",
        "location": {
            "string": "B & 8:15",
            "frontage": "B",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.78973011696535,
            "gps_longitude": -119.21713560963664
        },
        "location_string": "B & 8:15"
    },
    {
        "uid": "a1Xd0000001IXbWEAW",
        "year": 2016,
        "name": "Camp Mind Eraser",
        "contact_email": "dimonds@campminderaser.com",
        "hometown": "facebook.com/campminderaser",
        "description": "Camp Mind Eraser wants You! Forget the your plans and go with the Flow!",
        "location": {
            "string": "10:00 & I",
            "frontage": "10:00",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.7992638417704,
            "gps_longitude": -119.21105332133216
        },
        "location_string": "10:00 & I"
    },
    {
        "uid": "a1Xd0000001IXasEAG",
        "year": 2016,
        "name": "Black Rock Kwoon and Dojo",
        "url": "https://www.facebook.com/blackrockkwoon",
        "hometown": "Sunnyvale",
        "description": "We are an on-playa temple dedicated to the teaching, learning, practicing and sharing of the martial arts, meditation and philosophy, hosting many open classes and sessions for all to come in and experience, learn, and discover the beauty of the martial and meditative arts.  We aim to be a locus for the martial and meditative arts on the playa, and our hall is available as a practice space for anyone who wishes to train in the spirit of growth.",
        "location": {
            "string": "Esplanade & 4:30 Portal",
            "frontage": "Esplanade",
            "intersection": "4:30 Portal",
            "intersection_type": "&",
            "gps_latitude": 40.77954932016092,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "Esplanade & 4:30 Portal"
    },
    {
        "uid": "a1Xd0000001IXdXEAW",
        "year": 2016,
        "name": "Clevian Circularity",
        "hometown": "Milwaukee",
        "description": "Home of the fabulous Clevian Speed Dating Game, every night at dusk!",
        "location": {
            "string": "Esplanade & 6:45",
            "frontage": "Esplanade",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78377478201974,
            "gps_longitude": -119.21485701075231
        },
        "location_string": "Esplanade & 6:45"
    },
    {
        "uid": "a1Xd0000001IXdSEAW",
        "year": 2016,
        "name": "Nomads of the East (N.O.T.E)",
        "contact_email": "nomadsatburningman@gmail.com",
        "hometown": "NJ"
    },
    {
        "uid": "a1Xd0000001IXcAEAW",
        "year": 2016,
        "name": "Steam Bath Project",
        "url": "https://www.facebook.com/SteamBathProject/timeline",
        "contact_email": "japyr2@gmail.com",
        "hometown": "Boston",
        "description": "Steam Bath Project offers a playa twist on the ritual cleansing tradition and embraces the possibility of transformation.",
        "location": {
            "string": "8:00 & E",
            "frontage": "8:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78916521244671,
            "gps_longitude": -119.22013446592231
        },
        "location_string": "8:00 & E"
    },
    {
        "uid": "a1Xd0000001IXceEAG",
        "year": 2016,
        "name": "Camp Contact",
        "url": "http://burningman.campcontact.org",
        "contact_email": "dance@campcontact.org",
        "hometown": "Earth",
        "description": "Transformational Interactions are what we're about at Camp Contact. Through Contact Improvisation Dance, Acro/Yoga, Authentic Relating, Tantra, Meditation, the Steam Bath and more, we gather to bring self-awareness, connection, and heart opening catharsis to the burns and festivals we attend.",
        "location": {
            "string": "7:00 & E",
            "frontage": "7:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78363318293099,
            "gps_longitude": -119.22013333019713
        },
        "location_string": "7:00 & E"
    },
    {
        "uid": "a1Xd0000001IXdcEAG",
        "year": 2016,
        "name": "Pongo Lounge",
        "url": "https://www.facebook.com/groups/288772264532755/",
        "contact_email": "keithcich@gmail.com",
        "hometown": "Berkeley",
        "description": "Pongo Lounge is a psychedelic chill space dedicated to interactive games, luscious libations, and soulful deep house.  We throw two evening parties (Tues/Thur) and are two daytime game days (Mon/Wed).",
        "location": {
            "string": "8:00 & E",
            "frontage": "8:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78916521244671,
            "gps_longitude": -119.22013446592231
        },
        "location_string": "8:00 & E"
    },
    {
        "uid": "a1Xd0000001IXd8EAG",
        "year": 2016,
        "name": "Space Jam",
        "url": "https://www.facebook.com/SpaceJamBC/?fref=ts",
        "contact_email": "bshott09@gmail.com",
        "hometown": "Vancouver",
        "description": "Come on and slam, welcome to the Jam! We're here to take you to another world.Check out our Zero G hammock dome or The Bar At The End of the Universe.",
        "location": {
            "string": "H & 9:15",
            "frontage": "H",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79644345068721,
            "gps_longitude": -119.21668043777967
        },
        "location_string": "H & 9:15"
    },
    {
        "uid": "a1Xd0000001IXezEAG",
        "year": 2016,
        "name": "Cirque du Cliché",
        "url": "http://jankytown.org",
        "contact_email": "info@jankytown.org",
        "hometown": "Reno, NV, Bay Area, CA, and LA",
        "description": "Cirque du Cliché, of the JaNyTown Village brings live music, circus arts, and musical improv comedy. Come jam, or dance, or clown with\r\nus. Cirque will be continuing the JanKyTown Orchestra - group flow music and performance art happening all week and featuring a wicked cast of musicians and performing artists (clowns, stilt-walkers, fire dancers).",
        "location": {
            "string": "D & 6:15",
            "frontage": "D",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.780290026048306,
            "gps_longitude": -119.21700375742115
        },
        "location_string": "D & 6:15"
    },
    {
        "uid": "a1Xd0000001IXdwEAG",
        "year": 2016,
        "name": "Planetarium Camp",
        "contact_email": "mikedeprez@aol.com",
        "hometown": "Redondo Beach",
        "description": "An  Open Sky Planetarium style art structure using the actual night sky as the screen.  Additionally, \"artificial\" constellations, zig zagging meteors, UFOs and other celestial events are superimposed over the actual night sky in real time.   Inspiring thoughts of Art, Philosophy and science that were at the forefront of the Italian Renaissance."
    },
    {
        "uid": "a1Xd0000001IXf4EAG",
        "year": 2016,
        "name": "BuzzInn & Spaghettigeddon",
        "url": "http://www.facebook.com/BuzzInnNews",
        "contact_email": "ramonamayhem@gmail.com",
        "hometown": "Cascadian Foothills, and Milano",
        "description": "Evviva!  Spaghettigeddon lands at Burning Man for the first time, bringing tons of pasta cooked directly from a handful of alien chefs from the PLANET AGLIO! Get ready for an apocalypse of Renaissance tastes impossible to define.  Warning!  Abuse of extra virgin olive oil, garlic, and onion will put you into orbit!\r\n\r\nPer la prima volta lo spaghettigeddon  atterra al burning  man! Tonnellate di pasta invaderanno il vostro pianeta, tenetevi pronti per l'apocalisse del gusto. ATTENZIONE! La zona verrà contaminata da olio extra vergine, aglio e peperoncino!\r\n\r\nThe BuzzInn is a hive of information related to all things bee--a whimsical platform to share our passion for the pollinator through raw honey tastings, a beekeeper's summit, and waggle dances\r\n\r\nIl BuzzInn è un alveare di informazioni relative all'apicoltura;  \r\nuna estrosa piattaforma per condividere la nostra passione \r\nattraverso degustazioni di miele grezzo, discussioni con gli apicoltori, e la famosa danza delle api.",
        "location": {
            "string": "7:30 & B",
            "frontage": "7:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.786399428284064,
            "gps_longitude": -119.21800903146068
        },
        "location_string": "7:30 & B"
    },
    {
        "uid": "a1Xd0000001IXhUEAW",
        "year": 2016,
        "name": "Rubber Armstrong",
        "hometown": "london",
        "description": "Pimp my pushie bike decoration service; providing unique individual designs to your naked bikes. Decoration workshop is housed inside our resident spaceman \"RubberArmstrong\" who crashlanded at BRC hundreds of years ago and has all but been consumed by the dust.",
        "location": {
            "string": "9:00 & J",
            "frontage": "9:00",
            "intersection": "J",
            "intersection_type": "&",
            "gps_latitude": 40.796281355415935,
            "gps_longitude": -119.21955363512441
        },
        "location_string": "9:00 & J"
    },
    {
        "uid": "a1Xd0000001IXglEAG",
        "year": 2016,
        "name": "Amori's Casino & Burlesque",
        "url": "http://www.pauleamori.com/amori-s-casino---burlesque.html",
        "hometown": "Los Angeles",
        "description": "Amori's Casino & Burlesque is an interactive stage experience featuring cabaret, burlesque, live music, magic and comedy acts, and casino themed games all set in a sexy and unique atmosphere that is equal parts Vegas casino, carnivale and speakeasy.\r\n\r\nHosted by the Mayor of Love himself, the Italian lothario - Paul E. Amori, a night at Amori's is a sexy, silly and raucous affair that has a proven track record of delighting everyone.",
        "location": {
            "string": "E & 9:45",
            "frontage": "E",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79627201074232,
            "gps_longitude": -119.21190658406445
        },
        "location_string": "E & 9:45"
    },
    {
        "uid": "a1Xd0000001IXj1EAG",
        "year": 2016,
        "name": "Camp Caftan",
        "hometown": "San Francisco",
        "description": "Camp Caftan is a vivid oasis of color, wonder, pampering and love!  Featuring a bedouin tent of richly ornate fabrics from around the globe, weary travelers may sip cool cucumber water, hot spiced tea and enjoy a belly dance or Caftan Creation lesson on designated days. \r\n\r\nCamp Caftan will culminate its splendor on Thursday evening with a kaleidoscope of world-class djs spinning snaky vibes and a massive Caftan give-away.  \r\n\r\nCamp Caftan - where everyone is enveloped in love, silk, color and comfort!"
    },
    {
        "uid": "a1Xd0000001IXhFEAW",
        "year": 2016,
        "name": "Made In The Shade",
        "contact_email": "hotheartedhealer@yahoo.com",
        "hometown": "Berkeley",
        "description": "Made In The Shade is a comfortable, shady atmosphere under which burners gather, share camaraderie, and take a break from the hot sun and intensity of the playa"
    },
    {
        "uid": "a1Xd0000001IXhPEAW",
        "year": 2016,
        "name": "Best Butt",
        "hometown": "Seattle",
        "description": "Best Butt is a camp dedicated to all the wonderful asses out there! Come take a photo with our butt cutouts, participate in the Best Butt competition, or down to a booty blast workout!",
        "location": {
            "string": "H & 9:15",
            "frontage": "H",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79644345068721,
            "gps_longitude": -119.21668043777967
        },
        "location_string": "H & 9:15"
    },
    {
        "uid": "a1Xd0000001IXhjEAG",
        "year": 2016,
        "name": "Anchor-What!?",
        "hometown": "San Francisco",
        "description": "Anchor-What!?"
    },
    {
        "uid": "a1Xd0000001IXmZEAW",
        "year": 2016,
        "name": "Tea Time!",
        "hometown": "San Francisco",
        "description": "Come by Tea Time to share a cup of Ice Cold Tea on these hot days! Grab a cup on the go, or stay a while and share your story with the community."
    },
    {
        "uid": "a1Xd0000001IXmeEAG",
        "year": 2016,
        "name": "Camp Disco Nap",
        "url": "http://pinterest.com/campdisconap/",
        "hometown": "NYC",
        "description": "Because the best type of nap is one with a party at the end!  Dedicated to the art of getting ready-- Camp Disco Nap is about bonding over creative frenzied makeovers, dancing in hot pants, and all things shiny and distracting."
    },
    {
        "uid": "a1Xd0000001IXknEAG",
        "year": 2016,
        "name": "Dream",
        "hometown": "San Francisco",
        "description": "We make your dreams come."
    },
    {
        "uid": "a1Xd0000001IXmyEAG",
        "year": 2016,
        "name": "Camp Anam Cara",
        "hometown": "Phoenix"
    },
    {
        "uid": "a1Xd0000001IXfYEAW",
        "year": 2016,
        "name": "Gr[a|e]y Matter",
        "url": "http://brchoa.com",
        "hometown": "Kamloops",
        "description": "Hey you, yeah you, you are awesome. Have a wonderful day.",
        "location": {
            "string": "5:00 & B",
            "frontage": "5:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.77798282151022,
            "gps_longitude": -119.2094783790733
        },
        "location_string": "5:00 & B"
    },
    {
        "uid": "a1Xd0000001IYHuEAO",
        "year": 2016,
        "name": "Borscht Central"
    },
    {
        "uid": "a1Xd0000001IXjpEAG",
        "year": 2016,
        "name": "Angels & Shamans & Shakti Temple",
        "url": "http://www.angelsandshamans.com",
        "contact_email": "soultouch@ymail.com",
        "hometown": "Boise",
        "description": "World Class Angelic Shamanic Tantric healing with the Shakti Shaman"
    },
    {
        "uid": "a1Xd0000001IHqXEAW",
        "year": 2016,
        "name": "Camp Koozy",
        "hometown": "St. Thomas"
    },
    {
        "uid": "a1Xd0000001IUyUEAW",
        "year": 2016,
        "name": "Sunnyvale Trailer Park"
    },
    {
        "uid": "a1Xd0000001IWKJEA4",
        "year": 2016,
        "name": "Playa Surfers",
        "contact_email": "playasurfers@gmai.com",
        "hometown": "Venice beach",
        "description": "Come surf the playa on real motorized surfboards!  No experience is necessary and we are easily found on the Esplanade by our full size replica lifeguard tower #33 . You can also stop by and get some cool shade in our giant sized shade structure or get a tan on our sun bathing beachfront."
    },
    {
        "uid": "a1Xd0000002ycyLEAQ",
        "year": 2016,
        "name": "Ascension",
        "url": "http://ascendtolove.com",
        "description": "Ascension is a 20' tall, 10,000 LED climbable sculpture that inspires people to reflect on self love, loving others, and love as it relates to their world at large. It can be found in inner playa."
    },
    {
        "uid": "a1Xd0000001IP7lEAG",
        "year": 2016,
        "name": "Camp Magic School Bus",
        "contact_email": "camp.magic.school.bus@gmail.com",
        "hometown": "Dublin",
        "description": "Camp Magic School Bus was created by a group of fun loving artists, musicians, wanderers, builders and festival designers. The camp is a fun loving community, we put emphasis on openness and inclusion. Our shaded communal space is protected from dust storms by our three school busses and provides a quiet space within the mayhem to sit down and really get to know your fellow burners. \r\nWe're an eclectic group of \"craic\" loving creatives who don't take ourselves too seriously. Our event space will host various gifting experiences throughout the day and will become a 90's hot spot to kick off your party. We plan to give back to our playa community by helping you get ready to take on the biggest and baddest playground in the world!\r\nThis week long experience is one hell of a journey, join us as we relish the whole experience and treasure those single moments!"
    },
    {
        "uid": "a1Xd0000001INiAEAW",
        "year": 2016,
        "name": "Valencia",
        "hometown": "Valencia",
        "description": "Camp of Fallas festival"
    },
    {
        "uid": "a1Xd0000001IWnNEAW",
        "year": 2016,
        "name": "Doom Kingdom",
        "hometown": "Brooklyn"
    },
    {
        "uid": "a1Xd0000001IXcoEAG",
        "year": 2016,
        "name": "Incandescence",
        "hometown": "Portland",
        "description": "Come find your flow and cultivate your fire magic at Incandescence! Fire circle & fire performances at night, circus arts workshops during the day and chill dome all the time!",
        "location": {
            "string": "G & 6:15",
            "frontage": "G",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.21907490302245
        },
        "location_string": "G & 6:15"
    },
    {
        "uid": "a1Xd0000001IQIDEA4",
        "year": 2016,
        "name": "Feed the Artists",
        "url": "http://www.feedtheartists.org",
        "contact_email": "info@feedtheartists.net",
        "hometown": "Atlanta, GA",
        "description": "Started in 2007 w/ Larry Harvey's blessing and support, FtA has fed tens of thousands of burners, and actively modeled the concept of creating community through the sharing of meals at BRC and far beyond.  You never know when we'll show up, but when we do, you'll be treated to some of the finest food ever gifted on the playa!"
    },
    {
        "uid": "a1Xd0000001IPNPEA4",
        "year": 2016,
        "name": "Unholy Cupcake Brigade",
        "contact_email": "killtrew@gmail.com",
        "hometown": "Vancouver",
        "description": "Come by for Tea and Cupcakes at sundown! Stay for Board and Card games and interesting conversations.",
        "location": {
            "string": "I & 9:15",
            "frontage": "I",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.796965163936136,
            "gps_longitude": -119.21720937584996
        },
        "location_string": "I & 9:15"
    },
    {
        "uid": "a1Xd0000001IWWKEA4",
        "year": 2016,
        "name": "Blackbird",
        "contact_email": "mbeerley1967@gmail.com",
        "hometown": "NYC/PHL/PDX",
        "description": "Blackbird Camp, A Mobile Art Based Camp which is the Home of the Blackbird Bus(PHL/LA), The Quetzal Bus (NYC), Thump The Intergalactic Gnarwhal Experiment(PDX) and much more",
        "location": {
            "string": "10:00 & I",
            "frontage": "10:00",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.7992638417704,
            "gps_longitude": -119.21105332133216
        },
        "location_string": "10:00 & I"
    },
    {
        "uid": "a1Xd0000001IILdEAO",
        "year": 2016,
        "name": "Front Porch Sitters",
        "contact_email": "frontporchsitters@att.net",
        "hometown": "Louisville",
        "description": "Front Porch Sitters is the teaching dance camp within Vaude Ville village.  Come find the performer you have been hiding inside.",
        "location": {
            "string": "I & 7:45",
            "frontage": "I",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78813699883062,
            "gps_longitude": -119.22393925217301
        },
        "location_string": "I & 7:45"
    },
    {
        "uid": "a1Xd0000001IWDhEAO",
        "year": 2016,
        "name": "Dreamers Playground",
        "hometown": "London",
        "description": "We are Dreamers. Open minds filled with imagination and restless energy. The Playground is a cushion of comfort and warmth clearing routes for kinder high frequency experiences."
    },
    {
        "uid": "a1Xd0000001IXjLEAW",
        "year": 2016,
        "name": "Beats Boutique",
        "contact_email": "epykentertainment@gmail.com",
        "hometown": "Las Vegas",
        "description": "Come where love is always in fashion, dancing is a way of life and every person you know is waiting. Grab some beautiful threads, have a drink and dance till there's holes in your shoes. This camp is devoted to turning your energy UP!! We will have Beats Droppin, Booze Flowin and a Boutique to enhance your style on the playa! Our positive and loving vybes will make your stay at our camp epic!",
        "location": {
            "string": "2:00 & B",
            "frontage": "2:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.78414410068907,
            "gps_longitude": -119.1953835067984
        },
        "location_string": "2:00 & B"
    },
    {
        "uid": "a1Xd0000001IBn1EAG",
        "year": 2016,
        "name": "Camp Reno Nation",
        "url": "https://www.facebook.com/renonation14/",
        "contact_email": "reno.nation.14@gmail.com",
        "hometown": "Reno",
        "description": "We are a young group of Reno locals, desert rats, beer enthusiasts, jaded burner vets, and over excited virgins alike.  We come from all corners of the wild west working to bring our favorite parts of The Biggest Little City to the Playa and help bring the burner spirit back to Reno.",
        "location": {
            "string": "2:00 & D",
            "frontage": "2:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.78380349492602,
            "gps_longitude": -119.19370561116553
        },
        "location_string": "2:00 & D"
    },
    {
        "uid": "a1Xd0000001IXi8EAG",
        "year": 2016,
        "name": "Dragonfly Den",
        "hometown": "LOS ANGELES",
        "description": "Dragonfly Den\r\nAn oasis of music and hydration.",
        "location": {
            "string": "2:00 & G",
            "frontage": "2:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.78329254071427,
            "gps_longitude": -119.19118879998587
        },
        "location_string": "2:00 & G"
    },
    {
        "uid": "a1Xd0000001IX73EAG",
        "year": 2016,
        "name": "Camp Mystic",
        "url": "http://www.campmystic.org",
        "contact_email": "registration@campmystic.org",
        "hometown": "Bay Area",
        "description": "Camp Mystic is an ongoing experiment in the power of love, artistic expression, contribution, collaboration, compassion and exploration into our conscious evolution and ultimately the evolution of our human civilization.\r\n\r\nWe host an Evolutionary Speaker Series and Visionary Art collection during the day and DJ Dance Parties and Performances at night.",
        "location": {
            "string": "2:00 & E",
            "frontage": "2:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78363318293099,
            "gps_longitude": -119.19286666980291
        },
        "location_string": "2:00 & E"
    },
    {
        "uid": "a1Xd0000001IX3uEAG",
        "year": 2016,
        "name": "Root Society",
        "hometown": "New England",
        "description": "ROOT SOCIETY - WE WANT THE WORLD TO DANCE WITH US!",
        "location": {
            "string": "2:00 & A",
            "frontage": "2:00",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.784314394456956,
            "gps_longitude": -119.19622246106843
        },
        "location_string": "2:00 & A"
    },
    {
        "uid": "a1Xd0000001IYHVEA4",
        "year": 2016,
        "name": "Disco Knights",
        "url": "http://www.discoknightscamp.com",
        "contact_email": "disco.knights.ug.sf@gmail.com",
        "hometown": "San Francisco",
        "description": "https://www.facebook.com/groups/135396679814248/",
        "location": {
            "string": "2:00 & I",
            "frontage": "2:00",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.78295187419581,
            "gps_longitude": -119.18951094738038
        },
        "location_string": "2:00 & I"
    },
    {
        "uid": "a1Xd0000001IFK9EAO",
        "year": 2016,
        "name": "Voted Best Camp",
        "contact_email": "votedbestcamp@gmail.com",
        "hometown": "Reno",
        "description": "Come on down to the wrong side of the tracks folks! We serve up Punk Rock debauchery in it's most distilled form. Aged to perfection and rammed down your throat by the bushel, this is bad art for bad people. Are you a piece of shit? Of course you are. Have a drink you piece of shit.",
        "location": {
            "string": "2:00 & L",
            "frontage": "2:00",
            "intersection": "L",
            "intersection_type": "&",
            "gps_latitude": 40.78244082885346,
            "gps_longitude": -119.18699420074579
        },
        "location_string": "2:00 & L"
    },
    {
        "uid": "a1Xd0000001ISMVEA4",
        "year": 2016,
        "name": "Time Colony",
        "url": "http://www.timecolony.org/",
        "contact_email": "info@timecolony.org",
        "hometown": "Seattle, Minneapolis, Los Angeles, Bay Area",
        "description": "A time travel agency and resource center for the temporally dislocated. Come enjoy games, drinks, and performances from the past, present and future!",
        "location": {
            "string": "B & 2:15",
            "frontage": "B",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78306073698514,
            "gps_longitude": -119.19586992770513
        },
        "location_string": "B & 2:15"
    },
    {
        "uid": "a1Xd0000001IX0gEAG",
        "year": 2016,
        "name": "Dusty Lady",
        "hometown": "San Francisco",
        "description": "Camp Dusty Lady: Come for the fire tornado, stay for the comfortable shade and ambient sounds. Mid-week party with DJ- stop by for details!",
        "location": {
            "string": "B & 2:15",
            "frontage": "B",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78306073698514,
            "gps_longitude": -119.19586992770513
        },
        "location_string": "B & 2:15"
    },
    {
        "uid": "a1Xd0000001IExAEAW",
        "year": 2016,
        "name": "Rancho Sparkle Pony Rodeo D'Vinci",
        "contact_email": "dreadlockcowboy@gmail.com",
        "hometown": "Black Rock, CT",
        "description": "The Spirit and Mission of the Wranglers at Rancho Sparkle Pony has been to redeem the vulnerable Sparkle Pony by celebrating her (or his) Beauty and Grace.  At the end of the day, there is a little sparkle pony in us all;  we encourage people to tap into that inner-beauty and discover how to make it shine on the outside.",
        "location": {
            "string": "2:30 & E",
            "frontage": "2:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78105582486477,
            "gps_longitude": -119.19427716487334
        },
        "location_string": "2:30 & E"
    },
    {
        "uid": "a1Xd0000001IXdmEAG",
        "year": 2016,
        "name": "NeverSleepAgain",
        "hometown": "Berlin, LA, SF",
        "description": "NeverSleepAgain",
        "location": {
            "string": "B & 2:15",
            "frontage": "B",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78306073698514,
            "gps_longitude": -119.19586992770513
        },
        "location_string": "B & 2:15"
    },
    {
        "uid": "a1Xd0000001IRXBEA4",
        "year": 2016,
        "name": "Electric Gypsy Coffee Oasis",
        "contact_email": "electricgypsycoffeeoasis@gmail.com",
        "hometown": "Umpqua",
        "description": "In the blink of an eye don't let it pass you by — after the sun rises, join us at the Electric Gypsy Coffee Oasis for a small but potent piece of your normal routine: a damn fine cup of coffee. Sing a song, recite a poem, tell a joke and receive a handmade Stroopwafel, a tasty Dutch syrup waffle.",
        "location": {
            "string": "B & 2:15",
            "frontage": "B",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78306073698514,
            "gps_longitude": -119.19586992770513
        },
        "location_string": "B & 2:15"
    },
    {
        "uid": "a1Xd0000001IWmUEAW",
        "year": 2016,
        "name": "Petting Zoo",
        "hometown": "San Jose",
        "description": "16th Edition of Petting Zoo. Best Bar on the Playa several years running.  We welcome newcomers and hope to share the experiences of the playa all while offering an array of creative cocktails, ice-cold draft beer, imbibing beverages, and our classic and exclusive 'pussy juice'. Daytime Bar Only. We open same time as Artica (coincidence, I think not, hint hint), Close at sunset.",
        "location": {
            "string": "2:30 & A",
            "frontage": "2:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.78237143378006,
            "gps_longitude": -119.19728568024945
        },
        "location_string": "2:30 & A"
    },
    {
        "uid": "a1Xd0000001IXRrEAO",
        "year": 2016,
        "name": "Hello, We Love you!",
        "url": "https://www.facebook.com/helloweloveyou",
        "contact_email": "thelostlighter@gmail.com",
        "hometown": "Los Angeles",
        "description": "At Camp HELLO, We Love you! We Want to create an experience that shows you that HELLOO>>..... WE LOVE YOU! Art, Light Painting, Sound baths, Healing, Gifts, food and Fun galore! We want to make you smile! because HELLO...We Love you!",
        "location": {
            "string": "2:30 & B",
            "frontage": "2:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.78204253887612,
            "gps_longitude": -119.19653354023222
        },
        "location_string": "2:30 & B"
    },
    {
        "uid": "a1Xd0000001IWPTEA4",
        "year": 2016,
        "name": "Disco Bomb",
        "url": "http://www.discobomb.org",
        "contact_email": "campdiscobomb@gmail.com",
        "hometown": "Worldwide",
        "description": "Silent Disco, Daily Workshops, Community Chill Space, and Center for Aural Pleasure. < 3",
        "location": {
            "string": "2:30 & G",
            "frontage": "2:30",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.780397991108615,
            "gps_longitude": -119.19277295187766
        },
        "location_string": "2:30 & G"
    },
    {
        "uid": "a1Xd0000001IBhDEAW",
        "year": 2016,
        "name": "TickleTrunkTastic",
        "contact_email": "jwilkinssd@gmail.com",
        "hometown": "Anchorage/Seattle/Vancouver",
        "description": "Our Mobile Quesadilla Stand Hits the Playa Once Again,\r\nTake a Dig Through Our Lovely Costumes in Our Tickle Truck - Trade, Eat, Talk, Smile. Don't Forget to Strike that Pose!",
        "location": {
            "string": "2:30 & B",
            "frontage": "2:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.78204253887612,
            "gps_longitude": -119.19653354023222
        },
        "location_string": "2:30 & B"
    },
    {
        "uid": "a1Xd0000001IWMoEAO",
        "year": 2016,
        "name": "ONE TRIBE",
        "contact_email": "www.likemindedpeople@hotmail.com",
        "hometown": "canada",
        "description": "ONE TRIBE \r\nInclusively sharing our gifts in full acceptance of ourselves & one another. foundation of love and acceptance. create a container/safe sacred space to freely experience, explore and express. Community & connection. WE HAVE TIPIS!",
        "location": {
            "string": "C & 2:15",
            "frontage": "C",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.782808722545894,
            "gps_longitude": -119.1950676753229
        },
        "location_string": "C & 2:15"
    },
    {
        "uid": "a1Xd0000001IIXUEA4",
        "year": 2016,
        "name": "camp crazyhorse.",
        "url": "https://www.facebook.com/pyramixcar/",
        "contact_email": "douglasbosworth@gmail.com",
        "hometown": "sonoma county",
        "description": "Camp Crazyhorse. featuring the hall of chiefs(an exhibit of letters written by native americans",
        "location": {
            "string": "L & 2:15",
            "frontage": "L",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78054699343649,
            "gps_longitude": -119.1878438109233
        },
        "location_string": "L & 2:15"
    },
    {
        "uid": "a1Xd0000001IGy2EAG",
        "year": 2016,
        "name": "Inspiration Oasis",
        "contact_email": "vision@morrisburnerhotel.com",
        "hometown": "Israel, Atlanta and Reno",
        "description": "An International Oasis will invite you to meet movers and shakers in our culture from all over the world.\r\nCome and get inspired from those that living burning man in their every day life.",
        "location": {
            "string": "D & 2:15",
            "frontage": "D",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78255670886589,
            "gps_longitude": -119.19426542535763
        },
        "location_string": "D & 2:15"
    },
    {
        "uid": "a1Xd0000001IWE1EAO",
        "year": 2016,
        "name": "Kindred Spirit",
        "url": "https://www.facebook.com/kindredspiritcar/",
        "contact_email": "kindredspiritcar@gmail.com",
        "hometown": "New York",
        "description": "Kindred Spirit is 30-feet of audio-visual stimulation designed to spark conversation about the American Bison's complicated past, present, and future.",
        "location": {
            "string": "L & 2:15",
            "frontage": "L",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78054699343649,
            "gps_longitude": -119.1878438109233
        },
        "location_string": "L & 2:15"
    },
    {
        "uid": "a1Xd0000001IX9JEAW",
        "year": 2016,
        "name": "Heart Tribe",
        "hometown": "Berkeley",
        "description": "Heart Tribe offers a chance to engage in platonic touch in our Healing Sanctuary and Movement Revolution Spaces. Come get a massage, reiki session, chiropractic adjustment or squish session in our Healing Sanctuary between the hours of 2-6pm Tuesday through Saturday. \r\nWe are excited to expand our public offering to include yoga, dance and other movement workshops in our Movement Revolution. \r\nCome play with us and connect to your true essence.",
        "location": {
            "string": "E & 2:15",
            "frontage": "E",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.7823046959451,
            "gps_longitude": -119.19346317780918
        },
        "location_string": "E & 2:15"
    },
    {
        "uid": "a1Xd0000001IFLvEAO",
        "year": 2016,
        "name": "Mycodelic Forest",
        "url": "http://www.burners.mycodelicforest.org",
        "contact_email": "mycodelicforest@gmail.com",
        "hometown": "Humboldt County, northern; Arcata, Bayside, Eureka",
        "description": "The mycodelic magic of the redwoods awaits you! We'll be dancing and giving away free hugs 24/7. If your timing is right, our Wizard has been perfecting his homebrew to quench your thirst! Maybe you'll stumble across an impromptu dance party, a read aloud at sunset or an expression of the arts! Our family is full of enchantment, each with our own talents to offer, bring your hOOp, your glow and fire toys, your cup, and that smile and we'd love to move with you!",
        "location": {
            "string": "C & 2:15",
            "frontage": "C",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.782808722545894,
            "gps_longitude": -119.1950676753229
        },
        "location_string": "C & 2:15"
    },
    {
        "uid": "a1Xd0000001IAyeEAG",
        "year": 2016,
        "name": "MIKI Beach Camp",
        "contact_email": "info@mikimau.com",
        "hometown": "MIAMI",
        "description": "MIKI BEACH CAMP is a unique twist from the traditional Burning Man theme camp. Inspired by the relaxing beach vibes, and cultivated with the electrifying energies of Miami and New York, MIKI BEACH will allow you to indulge and experience Burning Man in a unique way. Consider this camp \"The Remix”.",
        "location": {
            "string": "G & 2:15",
            "frontage": "G",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78180595810437,
            "gps_longitude": -119.19185561706045
        },
        "location_string": "G & 2:15"
    },
    {
        "uid": "a1Xd0000001IXgvEAG",
        "year": 2016,
        "name": "Kissing Dinos",
        "hometown": "San Francisco",
        "description": "Kissing Dinos\r\nCome visit Tea Wrex Corner.  Feelin' like a wreck?  Come have a roarin' good time with us!",
        "location": {
            "string": "C & 2:15",
            "frontage": "C",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.782808722545894,
            "gps_longitude": -119.1950676753229
        },
        "location_string": "C & 2:15"
    },
    {
        "uid": "a1Xd0000002yespEAA",
        "year": 2016,
        "name": "Lumenoctis",
        "url": "http://katalinpazmandi.com",
        "contact_email": "katalinpaz@gmail.com",
        "hometown": "Rosendale, NY, 12472",
        "description": "Lumenoctis is a portal to other dimensions or a place to meet your inner self. Enter this space at daytime when the sunbeams create miracle or visit at night when you can see its luminous nature.",
        "location": {
            "string": "D & 2:15",
            "frontage": "D",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78255670886589,
            "gps_longitude": -119.19426542535763
        },
        "location_string": "D & 2:15"
    },
    {
        "uid": "a1Xd0000001IBN1EAO",
        "year": 2016,
        "name": "DinerTown",
        "hometown": "Whistler, BC",
        "description": "Our Diner has terrible service, randomness on the menu,  and you will never get what you order.  We have a Canada party and a Mad Hatter tea party... who knows when.  It's always a confusing joy to visit DinerTown.",
        "location": {
            "string": "C & 2:15",
            "frontage": "C",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.782808722545894,
            "gps_longitude": -119.1950676753229
        },
        "location_string": "C & 2:15"
    },
    {
        "uid": "a1Xd0000001IXadEAG",
        "year": 2016,
        "name": "Psychonaut Cafe",
        "location": {
            "string": "E & 2:15",
            "frontage": "E",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.7823046959451,
            "gps_longitude": -119.19346317780918
        },
        "location_string": "E & 2:15"
    },
    {
        "uid": "a1Xd0000001IX5vEAG",
        "year": 2016,
        "name": "D.O.R.I.S.",
        "url": "https://www.facebook.com/doristhelovebug/",
        "contact_email": "nick.david@gmail.com",
        "hometown": "London",
        "description": "D.O.R.I.S brings you the Disco Operative Radical Inclusion Shuttle! Look out for our daily shuttle service from 4am and 8am between the 2 and 10 o'clock sides of the playa or come visit our camp and chill with us over a drink and some tunes.",
        "location": {
            "string": "I & 2:15",
            "frontage": "I",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78130238890905,
            "gps_longitude": -119.190250876356
        },
        "location_string": "I & 2:15"
    },
    {
        "uid": "a1Xd0000001IVvSEAW",
        "year": 2016,
        "name": "Black Hole Literary Society",
        "description": "Black Hole Literary Society provides an interactive black light art gallery and chill space in addition to a coloring tent and trampoline. Drop by for good vibes day and night.",
        "location": {
            "string": "2:30 & E",
            "frontage": "2:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78105582486477,
            "gps_longitude": -119.19427716487334
        },
        "location_string": "2:30 & E"
    },
    {
        "uid": "a1Xd0000001IRnsEAG",
        "year": 2016,
        "name": "Camp Delicioso & Creperie",
        "url": "http://campdelicioso.com",
        "hometown": "Long Beach",
        "description": "Serving delicious crepes WTF from 9ish - noonish!  Come on down for some tasty tunes and groovy crepes at Camp Delicioso.",
        "location": {
            "string": "D & 2:15",
            "frontage": "D",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78255670886589,
            "gps_longitude": -119.19426542535763
        },
        "location_string": "D & 2:15"
    },
    {
        "uid": "a1Xd0000001IXL0EAO",
        "year": 2016,
        "name": "EPIC",
        "url": "https://www.facebook.com/GiveEpicAChance",
        "contact_email": "shpagat69@hotmail.com",
        "hometown": "Los Angeles",
        "description": "Burgers every day 1-3 pm. Hookah lounge open 24/7 (even in rain), & Sparky goes out for a DJ spin every night with its 16,000 sound system.",
        "location": {
            "string": "D & 2:15",
            "frontage": "D",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78255670886589,
            "gps_longitude": -119.19426542535763
        },
        "location_string": "D & 2:15"
    },
    {
        "uid": "a1Xd0000001IMTVEA4",
        "year": 2016,
        "name": "Music Savages Camp",
        "url": "http://www.musicsavages.com",
        "contact_email": "javier@musicsavages.com",
        "hometown": "Los Angeles",
        "description": "Music Savages Camp is a lounge camp that is all about finding alternative ways to present its eclectic passion for music. We use comedy, colors, fabrics, technology, style, relaxation, architecture, games, gifts, and anonymity as tools to elevate our visitors' experiences from the standard \"DJ on a stage\" setup seen elsewhere. Our stage, is the SAVAGE ARENA - an environment that breathes with its performers and cradles its listeners. Find shelter from the wind, dust and sun inside its robust structure and flexible skin. Find an elevated perch to watch the sun rise and set through the horizon. Find a hammock to sleep or a daybed to rest. Find a bocce ball, give it a toss. Find a beer to shotgun, and some tits to motorboat. Find a jungle gym and climb. Find a wheel with questionable dares, and spin it. And while you're exploring, listen to our music, watch our lights, find your friends, and lose your minds -- together.",
        "location": {
            "string": "9:30 & G",
            "frontage": "9:30",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.796794104365375,
            "gps_longitude": -119.21442727198003
        },
        "location_string": "9:30 & G"
    },
    {
        "uid": "a1Xd0000001IXN6EAO",
        "year": 2016,
        "name": "NUTZ",
        "contact_email": "nutzcamp@gmail.com",
        "hometown": "Los Angeles, San Francisco, New York",
        "description": "Here comes the sun. Beautiful beats and positive vibrations overflow the Playa at Nutz Sunrise Parties. Come feel the NutzLove.",
        "location": {
            "string": "10:00 & J",
            "frontage": "10:00",
            "intersection": "J",
            "intersection_type": "&",
            "gps_latitude": 40.79989908857765,
            "gps_longitude": -119.21127822243027
        },
        "location_string": "10:00 & J"
    },
    {
        "uid": "a1Xd0000001IXaiEAG",
        "year": 2016,
        "name": "Playa Broadcasting Network",
        "contact_email": "jharkenrider@mac.com",
        "hometown": "los angeles",
        "description": "The Playa Broadcasting Network is the only mainstream (totally not mainstream) media conglomerate producing content at Burning Man. We're innovating entertainment media on the playa one fake program at a time.",
        "location": {
            "string": "9:30 & F",
            "frontage": "9:30",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.79622457844993,
            "gps_longitude": -119.21399283663455
        },
        "location_string": "9:30 & F"
    },
    {
        "uid": "a1Xd0000001IWS8EAO",
        "year": 2016,
        "name": "SHIFT",
        "url": "http://www.shift-bm.com",
        "contact_email": "contact@shift-bm.com",
        "hometown": "Napa",
        "description": "SHIFT - It happens",
        "location": {
            "string": "10:00 & C",
            "frontage": "10:00",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.79545235175782,
            "gps_longitude": -119.20970400513266
        },
        "location_string": "10:00 & C"
    },
    {
        "uid": "a1Xd0000001IX3LEAW",
        "year": 2016,
        "name": "Twisted Tentacles Village",
        "hometown": "Northern California, Nevada, and Beyond...",
        "description": "A village swimming in aquatic tomfoolery.",
        "location": {
            "string": "10:00 & E",
            "frontage": "10:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.79672285017505,
            "gps_longitude": -119.21015375998337
        },
        "location_string": "10:00 & E"
    },
    {
        "uid": "a1Xd0000001IVpyEAG",
        "year": 2016,
        "name": "Emergent Evolution",
        "contact_email": "projects.nowak@gmail.com",
        "hometown": "Corning",
        "description": "kARTopia The Human Race.\r\n\r\nA cerebral experience of how our minds create and process decisions in our lives. An experience of thoughts racing through the brain to create our own reality",
        "location": {
            "string": "10:00 & G",
            "frontage": "10:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.797993346845956,
            "gps_longitude": -119.2106035320494
        },
        "location_string": "10:00 & G"
    },
    {
        "uid": "a1Xd0000001IYHfEAO",
        "year": 2016,
        "name": "Hammered and Sickled",
        "location": {
            "string": "A & 9:45",
            "frontage": "A",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79384195510268,
            "gps_longitude": -119.21057572042989
        },
        "location_string": "A & 9:45"
    },
    {
        "uid": "a1Xd0000001IWjGEAW",
        "year": 2016,
        "name": "Funky Town",
        "url": "http://www.funkytownbrc.com",
        "hometown": "Bozeman",
        "description": "You can't spell \"funk\" without the first three letters, \"F, U, N\"!  Funky Town is about family, amazing music, delicious cocktails, art and most important - the funk!",
        "location": {
            "string": "10:00 & I",
            "frontage": "10:00",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.7992638417704,
            "gps_longitude": -119.21105332133216
        },
        "location_string": "10:00 & I"
    },
    {
        "uid": "a1Xd0000001IXR3EAO",
        "year": 2016,
        "name": "Kazbah",
        "url": "http://www.kazbah.org",
        "contact_email": "reach@kazbah.org",
        "hometown": "San Francisco and the surrounding Bay Area",
        "description": "The Kazbah is a vibe, that is physically manifested in a towering pyramid/obelisk-hybrid illuminated light sculpture which houses a DJ booth in the all-seeing eye of horus at it's base, and a laser shooting from its spire up toward Sirius, the brightest star in the sky.",
        "location": {
            "string": "10:00 & A",
            "frontage": "10:00",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.794181851594416,
            "gps_longitude": -119.20925426749584
        },
        "location_string": "10:00 & A"
    },
    {
        "uid": "a1Xd0000001IVuoEAG",
        "year": 2016,
        "name": "HUGGZILLA",
        "url": "http://www.huggzilla.com/",
        "contact_email": "info@huggzilla.com",
        "hometown": "San Francisco Bay Area",
        "description": "HUGGZILLA:  Unlocking human intimacy among people regardless of age, gender, or sexuality by using Hug therapy as a powerful way of healing, expression, and connection.",
        "location": {
            "string": "10:00 & H",
            "frontage": "10:00",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.7986285945265,
            "gps_longitude": -119.21082842453862
        },
        "location_string": "10:00 & H"
    },
    {
        "uid": "a1Xd0000001IAyyEAG",
        "year": 2016,
        "name": "Camp Scatter",
        "hometown": "Venice",
        "description": "Go ape shit at Camp Scatter!\r\n\r\nCAMP SCATTER pays tribute to the all but forgotten Prince of Mayhem, Elvis' chimpanzee, SCATTER PRESLEY, who once reigned over GRACELAND with a bottle of Bourbon and an unbridled libido. This pampered CHIMP was draped in the finest studded jumpsuits and was known to be the life of the party.",
        "location": {
            "string": "9:30 & D",
            "frontage": "9:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.7950855217312,
            "gps_longitude": -119.21312398830506
        },
        "location_string": "9:30 & D"
    },
    {
        "uid": "a1Xd0000001IWWtEAO",
        "year": 2016,
        "name": "Opulent Temple of Interactivity",
        "url": "http://www.opulenttemple.org/",
        "contact_email": "info@opulenttemple.org",
        "hometown": "San Francisco",
        "description": "Opulent Temple: Sacred dance to world class music and interactivity since 2003",
        "location": {
            "string": "10:00 & D",
            "frontage": "10:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.796087601184716,
            "gps_longitude": -119.2099288804062
        },
        "location_string": "10:00 & D"
    },
    {
        "uid": "a1Xd0000001IWKEEA4",
        "year": 2016,
        "name": "Goodbye Horses",
        "contact_email": "campgoodbyehorses@gmail.com",
        "hometown": "Brooklyn",
        "description": "Home of the Kernel's World-Famous Playa PopCart. Would you fuck us? We'd fuck us. Welcome to Goodbye Horses.",
        "location": {
            "string": "A & 9:45",
            "frontage": "A",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79384195510268,
            "gps_longitude": -119.21057572042989
        },
        "location_string": "A & 9:45"
    },
    {
        "uid": "a1Xd0000001IWW5EAO",
        "year": 2016,
        "name": "Pile Palace",
        "url": "https://www.facebook.com/pilepalace?ref=hl",
        "hometown": "San Diego",
        "description": "Here at the Pile Palace, we provide an unbelievably lavish, Moroccan-themed environment for Burners to pile hard. Whether you choose dancing your heart out to our amplified sound, lounging back in one of our pillow pits with a craft cocktail in hand, or taking a picture with friends upon our royal thrones, we want you and everything about you in a state of complete relaxation. Pile on.",
        "location": {
            "string": "B & 9:45",
            "frontage": "B",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79444946765153,
            "gps_longitude": -119.21090843559313
        },
        "location_string": "B & 9:45"
    },
    {
        "uid": "a1Xd0000001IUYMEA4",
        "year": 2016,
        "name": "HYBYCOZO",
        "url": "http://www.hybycozo.com",
        "contact_email": "hybycozo@gmail.com",
        "hometown": "Oakland",
        "description": "Your local intergalactic construction zone neighborhood association invites you to stop by for a 4th dimensional geometry lesson.",
        "location": {
            "string": "C & 9:45",
            "frontage": "C",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79505698110772,
            "gps_longitude": -119.21124115125328
        },
        "location_string": "C & 9:45"
    },
    {
        "uid": "a1Xd0000001IXkiEAG",
        "year": 2016,
        "name": "Nom De Plume",
        "hometown": "Magicalville",
        "description": "Come by to drink yerba mate, burn palo santo, lounge, dance, relax and lurk to the sounds of dub music in our tea lounge. Come experience a mellow morning of thrivelry with us.",
        "location": {
            "string": "D & 9:45",
            "frontage": "D",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79566449547131,
            "gps_longitude": -119.21157386741038
        },
        "location_string": "D & 9:45"
    },
    {
        "uid": "a1Xd0000001IVs9EAG",
        "year": 2016,
        "name": "Enchante",
        "contact_email": "enchantyay@gmail.com",
        "hometown": "San Luis Obispo, San Francisco",
        "description": "From the bosom of the Pacific Northwest, an astounding force of righteous revelry, dashing decency, gorgeous gallantry and impeccable taste erupts to dazzle all dreamers and depreciate the depraved. Dance while you lounge, whistle while you work and discover the differences that distinguish the Non from the Enchante. We double dog dare ya.",
        "location": {
            "string": "D & 9:45",
            "frontage": "D",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79566449547131,
            "gps_longitude": -119.21157386741038
        },
        "location_string": "D & 9:45"
    },
    {
        "uid": "a1Xd0000001IXNVEA4",
        "year": 2016,
        "name": "inDUSTry",
        "hometown": "Healdsburg",
        "description": "A camp full of food, music, art and amazing people! Come enjoy the beautiful shade structures, Yoga Geo-Dome and great vibes!",
        "location": {
            "string": "E & 9:45",
            "frontage": "E",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79627201074232,
            "gps_longitude": -119.21190658406445
        },
        "location_string": "E & 9:45"
    },
    {
        "uid": "a1Xd0000001IOYpEAO",
        "year": 2016,
        "name": "ZOO CAMP",
        "contact_email": "blackrockcityzoo@gmail.com",
        "hometown": "FRANCE",
        "description": "Zoo Camp - animal chilled zone - happy music and bar - sunset everyday.",
        "location": {
            "string": "L & 9:45",
            "frontage": "L",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.800526522970046,
            "gps_longitude": -119.21422997199771
        },
        "location_string": "L & 9:45"
    },
    {
        "uid": "a1Xd0000001IKJeEAO",
        "year": 2016,
        "name": "Humano",
        "url": "http://www.humanothetribe.com/",
        "contact_email": "members@humanothetribe.com",
        "hometown": "New York City, NY",
        "description": "Humano is an ideology, a place where you can free your mind,  your soul can dance and your heart can flourish.\r\n\r\nHumano is a place to connect with yourself and likeminded individuals, which use tools such as arts, culture and music to spark human progression",
        "location": {
            "string": "L & 9:45",
            "frontage": "L",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.800526522970046,
            "gps_longitude": -119.21422997199771
        },
        "location_string": "L & 9:45"
    },
    {
        "uid": "a1Xd0000001IOHAEA4",
        "year": 2016,
        "name": "Ibiza Camp",
        "contact_email": "mariana@liomalca.com",
        "hometown": "Ibiza. This is were the founding members of the camp met, most people are from different countries but Ibiza is the root",
        "description": "Ibiza Camp - Replica of a Moroccan oasis",
        "location": {
            "string": "L & 9:45",
            "frontage": "L",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.800526522970046,
            "gps_longitude": -119.21422997199771
        },
        "location_string": "L & 9:45"
    },
    {
        "uid": "a1Xd0000001IWnhEAG",
        "year": 2016,
        "name": "Bad Ass Mammals",
        "hometown": "Santa Cruz",
        "description": "BAD ASS\r\nˈbadˌas\r\nadjective\r\nadjective: badass; adjective: bad-ass\r\n1. formidable; excellent.\r\n\"this was one badass mammal!\"\r\n\r\nMAMMAL\r\nˈmaməl/Submit\r\nnoun\r\nplural noun: mammals\r\n1. a warm-blooded vertebrate animal of a class that is distinguished by the possession of hair or fur, the secretion of milk by females for the nourishment of the young, and (typically) the birth of live young.\r\n\r\nIf you fit this description then you are one of us :)",
        "location": {
            "string": "H & 9:45",
            "frontage": "H",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79809619016884,
            "gps_longitude": -119.21289985003958
        },
        "location_string": "H & 9:45"
    },
    {
        "uid": "a1Xd0000001IV5iEAG",
        "year": 2016,
        "name": "Moonwalk Mission",
        "url": "http://moonwalkmission.com/",
        "contact_email": "souto_patricia@yahoo.com",
        "hometown": "Oakland",
        "description": "Moonwalk Mission is a station for Playa explorers, space cadets and anyone set for out-of-this-world experiences.",
        "location": {
            "string": "L & 9:45",
            "frontage": "L",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.800526522970046,
            "gps_longitude": -119.21422997199771
        },
        "location_string": "L & 9:45"
    },
    {
        "uid": "a1Xd0000001IXicEAG",
        "year": 2016,
        "name": "The Dusty Rhino Camp",
        "url": "http://www.dustyrhino.com/",
        "contact_email": "dustyrhinollc@gmail.com",
        "hometown": "San Francisco",
        "description": "The Dusty Rhino Camp aspires to bring people together through art, fire and electronic music, and to be the best Black Rock public transportation possible. While people take an Art Safari they listen to great DJs and enjoy a 29' Rhino that shoots fire from its horn."
    },
    {
        "uid": "a1Xd0000002yoUSEAY",
        "year": 2016,
        "name": "Big Puffy Yellow",
        "url": "https://www.facebook.com/Big-Puffy-Yellow-558193654250611/home",
        "hometown": "Charlotte, Dallas, San Francisco, NYC and more",
        "description": "What began as a Burning Man Theme Camp in 1999 has grown into a collective of Burner's, Artist's, DJ's, Performers and general Badasses who love all things Big, Puffy and Yellow!",
        "location": {
            "string": "2:30 & G",
            "frontage": "2:30",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.780397991108615,
            "gps_longitude": -119.19277295187766
        },
        "location_string": "2:30 & G"
    },
    {
        "uid": "a1Xd0000001IXGZEA4",
        "year": 2016,
        "name": "DeMentha",
        "url": "http://www.dementha.com",
        "contact_email": "mintygoodness@dementha.com",
        "hometown": "San Francisco",
        "description": "Come join in the minty fun at DeMentha. You'll find music from out DJ line-up, enthusiastically prepared fresh mojitos, aromatherapy, ample shade and plenty of cooling mist. Combined with a hearty welcome you've got the perfect recipe for a awesome time. 1-6pm daily.",
        "location": {
            "string": "3:00 & E",
            "frontage": "3:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77884267712845,
            "gps_longitude": -119.19652042944098
        },
        "location_string": "3:00 & E"
    },
    {
        "uid": "a1Xd0000001IWo1EAG",
        "year": 2016,
        "name": "Iron Rose",
        "hometown": "Northern California",
        "description": "When you're tired of the techno, find us.",
        "location": {
            "string": "3:00 & A",
            "frontage": "3:00",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.78070302098065,
            "gps_longitude": -119.19897672841634
        },
        "location_string": "3:00 & A"
    },
    {
        "uid": "a1Xd0000001INsPEAW",
        "year": 2016,
        "name": "Galactic Labyrinth",
        "url": "https://www.facebook.com/groups/GalacticLabyrinth2016/",
        "hometown": "Los Angeles",
        "description": "A sacred space where one can journey to the center of their deepest self and back out on to the playa with a deeper understanding of who they are. The labyrinth is a model and reminder that we are all on a path and exactly where we need to be.",
        "location": {
            "string": "2:30 & C",
            "frontage": "2:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.781713639088856,
            "gps_longitude": -119.1957814076638
        },
        "location_string": "2:30 & C"
    },
    {
        "uid": "a1Xd0000001IXDVEA4",
        "year": 2016,
        "name": "Midnight Ridazz Camp",
        "hometown": "Los Angeles and Oakland",
        "description": "Bike repair, bar and megaphones.",
        "location": {
            "string": "2:30 & A",
            "frontage": "2:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.78237143378006,
            "gps_longitude": -119.19728568024945
        },
        "location_string": "2:30 & A"
    },
    {
        "uid": "a1Xd0000001IWP4EAO",
        "year": 2016,
        "name": "Houphoria",
        "url": "http://houstonburners.com/",
        "contact_email": "houston@burningman.com",
        "hometown": "Houston",
        "description": "Makers & artists from Houston CORE bring you: Houphoria's Illuminated Interactive Playground. Hydrate at Water Bar, relax and play and SEE in our interactive projection mapping lounge, and find your stimuli in one of the interactive pieces in our vision of comfort, wonder, connection, and escape.",
        "location": {
            "string": "2:30 & F",
            "frontage": "2:30",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.78072691042815,
            "gps_longitude": -119.19352505465118
        },
        "location_string": "2:30 & F"
    },
    {
        "uid": "a1Xd0000001IM75EAG",
        "year": 2016,
        "name": "Ranger Outpost Berlin",
        "location": {
            "string": "3:00 & C",
            "frontage": "3:00",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.77977285556469,
            "gps_longitude": -119.19774856173052
        },
        "location_string": "3:00 & C"
    },
    {
        "uid": "a1Xd0000001IOkgEAG",
        "year": 2016,
        "name": "STAMP IT! Camp",
        "contact_email": "randyfayartist@yahoo.com",
        "hometown": "Pittsburg",
        "description": "STAMP IT! is the place to get yourself and your stuff stamped with Da Vinci's 2016 BM related stamps and CultureIT stamps - Ten BM Principles stamps.  We provide the stamps and inks and you bring yourself and souvenir items to stamp and take home with you.\r\nStamp your hats, packs, t-shirts, or whatever. Sample stampings: BM 2016, BM logo man with flames, Da Vinci related stamps, and  variety of other BM themed logos and sayings.  Family friendly camp with stamps for our younger aged Burners.\r\nMini Social Lounge for Burners providing a shady hangout area with refreshments and music from 3-6pm Mon-Fri.",
        "location": {
            "string": "3:00 & D",
            "frontage": "3:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.77930776797406,
            "gps_longitude": -119.19713449128632
        },
        "location_string": "3:00 & D"
    },
    {
        "uid": "a1Xd0000001IVrkEAG",
        "year": 2016,
        "name": "Ganesh Camp",
        "url": "http://www.johnkane.com/2014-04-26-GaneshCamp/",
        "contact_email": "4jamjones@gmail.com",
        "hometown": "Oakland",
        "description": "Ganesh Camp is a lush retreat for dusty desert denizens. Play volleyball or shoot hoops during the day. Noon-5, Tue-Fri, celebrate and beat the heat in the bar in a large, cool desert tent from India. Interact with the Cosmic Theatre or sit by the fire at\r\nnight!",
        "location": {
            "string": "2:30 & B",
            "frontage": "2:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.78204253887612,
            "gps_longitude": -119.19653354023222
        },
        "location_string": "2:30 & B"
    },
    {
        "uid": "a1Xd0000001IM4VEAW",
        "year": 2016,
        "name": "Deep C",
        "url": "http://campdeepc.com",
        "contact_email": "contact@campdeepc.com",
        "hometown": "Seattle",
        "description": "Deep C, a collaboration from Seattle Washington, was conceived to share our love of creating interactive music and light displays with the Burner community. With our flagship art project, the Zahnica, we let the viewer bend the sound and light to their will amidst a variety of other collective and creative visual and musical arts and activities.",
        "location": {
            "string": "3:00 & F",
            "frontage": "3:00",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.778377583027975,
            "gps_longitude": -119.19590637619434
        },
        "location_string": "3:00 & F"
    },
    {
        "uid": "a1Xd0000001IDSdEAO",
        "year": 2016,
        "name": "Dark Carnival Community Cafe",
        "hometown": "Tucson",
        "description": "Dark Carnival Community Cafe offers Coffee as black as our humor 24hrs a day. Come enjoy a hot beverage, conversation and the unexpected.",
        "location": {
            "string": "2:30 & C",
            "frontage": "2:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.781713639088856,
            "gps_longitude": -119.1957814076638
        },
        "location_string": "2:30 & C"
    },
    {
        "uid": "a1Xd0000001IXZaEAO",
        "year": 2016,
        "name": "GRAVITY",
        "url": "https://www.facebook.com/campgravity/",
        "contact_email": "gravitycampbrc@gmail.com",
        "hometown": "San Francisco",
        "description": "Step into a digital realm of perceptual vastness, defying the physical and mental limitations of your perceived reality. Gravitate towards your dream experience in one of many time and space altering attractions. You will surely find your true center of gravity here.\r\n\r\nAn engaging, interactive sensory experience of the highest order, Gravity tickles your curiosity and opens new doors of perception.\r\n\r\nThis is an experience produced by the collective creative output of an intellectually diverse group of artists, musicians, engineers, healers, builders, and futurists who are inspired by the life of polymath Leonardo Da Vinci. Gravity is a hub of brain jazz, self-discovery, and soul centering.",
        "location": {
            "string": "3:00 & H",
            "frontage": "3:00",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.777447385062814,
            "gps_longitude": -119.19467829549622
        },
        "location_string": "3:00 & H"
    },
    {
        "uid": "a1Xd0000001IWJpEAO",
        "year": 2016,
        "name": "Empire of DIrt",
        "hometown": "Oakland",
        "description": "Empire of DIrt is the homebase for for making and creating",
        "location": {
            "string": "2:30 & D",
            "frontage": "2:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.781384734418374,
            "gps_longitude": -119.1950292825442
        },
        "location_string": "2:30 & D"
    },
    {
        "uid": "a1Xd0000001IVn4EAG",
        "year": 2016,
        "name": "Camp Ho-Down",
        "hometown": "Reno-Spanish Springs",
        "description": "Camp Ho-Down - home of the Cozmic Cowboy Art Car!  Come visit the Nambi Tower & Mechanical Bull!",
        "location": {
            "string": "2:30 & G",
            "frontage": "2:30",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.780397991108615,
            "gps_longitude": -119.19277295187766
        },
        "location_string": "2:30 & G"
    },
    {
        "uid": "a1Xd0000001IJZHEA4",
        "year": 2016,
        "name": "Emergency Services Station 3",
        "location": {
            "string": "3:00 & C",
            "frontage": "3:00",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.77977285556469,
            "gps_longitude": -119.19774856173052
        },
        "location_string": "3:00 & C"
    },
    {
        "uid": "a1Xd0000001IXMIEA4",
        "year": 2016,
        "name": "Gamelan X",
        "url": "http://gamelanx.com",
        "contact_email": "gxbooking@gmail.com",
        "hometown": "Oakland",
        "description": "Hands-on experience of the Indonesian performing arts with Gamelan X. Music, dance, and chant workshops will be held regularly."
    },
    {
        "uid": "a1Xd0000001IRqIEAW",
        "year": 2016,
        "name": "The Moon Under Water",
        "hometown": "London",
        "description": "The Moon Under Water\r\n\r\nYour perfect Pub.",
        "location": {
            "string": "3:00 Plaza @ 2:45",
            "frontage": "3:00 Plaza",
            "intersection": "2:45",
            "intersection_type": "@",
            "gps_latitude": 40.78050929980614,
            "gps_longitude": -119.198087297712
        },
        "location_string": "3:00 Plaza @ 2:45"
    },
    {
        "uid": "a1Xd0000001IGWYEA4",
        "year": 2016,
        "name": "Bar Mactropolis",
        "contact_email": "barmacktropolis@gmail.com",
        "hometown": "oakland",
        "description": "BAR MACTROPOLIS  \r\n      A  FUN FREINDLY REFRESHING OASIS",
        "location": {
            "string": "3:00 & K",
            "frontage": "3:00",
            "intersection": "K",
            "intersection_type": "&",
            "gps_latitude": 40.77605206370598,
            "gps_longitude": -119.19283623893406
        },
        "location_string": "3:00 & K"
    },
    {
        "uid": "a1Xd0000001IW9fEAG",
        "year": 2016,
        "name": "Tower of Slackjaw",
        "hometown": "Olympia",
        "description": "Visit the spaceship for a view from SPACE!",
        "location": {
            "string": "3:00 & K",
            "frontage": "3:00",
            "intersection": "K",
            "intersection_type": "&",
            "gps_latitude": 40.77605206370598,
            "gps_longitude": -119.19283623893406
        },
        "location_string": "3:00 & K"
    },
    {
        "uid": "a1Xd0000001IXiIEAW",
        "year": 2016,
        "name": "Geodesia",
        "hometown": "Olympia, WA/Reno, NV",
        "description": "Come visit Geodesia and climb our tower for one of the best views in Black Rock City!",
        "location": {
            "string": "3:00 Portal & 3:00 Portal",
            "frontage": "3:00 Portal",
            "intersection": "3:00 Portal",
            "intersection_type": "&"
        },
        "location_string": "3:00 Portal & 3:00 Portal"
    },
    {
        "uid": "a1Xd0000001IXaJEAW",
        "year": 2016,
        "name": "Voodoo Shooting Gallery",
        "url": "http://www.facebook.com/satanisyourpal",
        "contact_email": "vooodookuntrol@gmail.com",
        "hometown": "Portland",
        "description": "Visit Voodoo Shooting Gallery to exercise your demons by shooting voodoo dolls and shrunken heads to win plastic 16oz glow cups emblazoned with our 2016 camp logo. Hosted by the best collection of French voodoo priestesses and their zombie slaves that cheer and award you prizes and treats.",
        "location": {
            "string": "3:00 Portal & 3:00 Portal",
            "frontage": "3:00 Portal",
            "intersection": "3:00 Portal",
            "intersection_type": "&"
        },
        "location_string": "3:00 Portal & 3:00 Portal"
    },
    {
        "uid": "a1Xd0000001IHI2EAO",
        "year": 2016,
        "name": "French Maid Brigade",
        "url": "https://www.facebook.com/groups/88124456049/",
        "hometown": "Santa Cruz",
        "description": "The French Maid Brigade- dedicated to eradicating dust and bad spirits in Black Rock City! We facilitate events and the famous French Maid Brigade Parade (Thursday 2PM, 3/Esplanade)",
        "location": {
            "string": "3:00 & J",
            "frontage": "3:00",
            "intersection": "J",
            "intersection_type": "&",
            "gps_latitude": 40.77651717407934,
            "gps_longitude": -119.19345024919038
        },
        "location_string": "3:00 & J"
    },
    {
        "uid": "a1Xd0000001IWScEAO",
        "year": 2016,
        "name": "Westburner Baptist Church",
        "url": "http://www.antitrump.com",
        "contact_email": "westburnerbaptistchurch@gmail.com",
        "hometown": "OLYMPIA",
        "description": "Interactive performance art comedy theme camp. Modeled after the Westboro Baptist Church in the spirit of the Cacophony Society",
        "location": {
            "string": "3:00 Portal & 3:00 Portal",
            "frontage": "3:00 Portal",
            "intersection": "3:00 Portal",
            "intersection_type": "&"
        },
        "location_string": "3:00 Portal & 3:00 Portal"
    },
    {
        "uid": "a1Xd0000001IXNLEA4",
        "year": 2016,
        "name": "La Calaca Village",
        "url": "https://www.facebook.com/groups/110739525682835/?ref=bookmarks",
        "contact_email": "pinatasrevengecamp@gmail.com",
        "hometown": "Reno",
        "description": "Come Visit La Calaca Village at the 3:00 Plaza in 2016; we will be offering a comprehensive healing dome and community spaces for lounging, playing and conversing with our fellow Burners.  On Thursday (and possibly impromptu on other Sunsts), our Sunset Block Party will be rocking with Day of the Dead Remembrance Ceremonies, live music and our now famous (or, infamous) home-made Sangria.   Come join us for lots of fun!",
        "location": {
            "string": "3:00 & L",
            "frontage": "3:00",
            "intersection": "L",
            "intersection_type": "&",
            "gps_latitude": 40.77558695007835,
            "gps_longitude": -119.19222223727517
        },
        "location_string": "3:00 & L"
    },
    {
        "uid": "a1Xd0000001IXZLEA4",
        "year": 2016,
        "name": "Playalescence",
        "location": {
            "string": "3:00 & J",
            "frontage": "3:00",
            "intersection": "J",
            "intersection_type": "&",
            "gps_latitude": 40.77651717407934,
            "gps_longitude": -119.19345024919038
        },
        "location_string": "3:00 & J"
    },
    {
        "uid": "a1Xd0000001IYR2EAO",
        "year": 2016,
        "name": "St. Squishy's",
        "hometown": "Los Angeles",
        "description": "Giant LED Ball Pit, Human Kaleidoscope, Squishy Stage, Campfire Barrel :D Come play with us!",
        "location": {
            "string": "3:00 Portal & 3:00 Portal",
            "frontage": "3:00 Portal",
            "intersection": "3:00 Portal",
            "intersection_type": "&"
        },
        "location_string": "3:00 Portal & 3:00 Portal"
    },
    {
        "uid": "a1Xd0000001IBvfEAG",
        "year": 2016,
        "name": "Northwest Mist",
        "url": "http://www.northwestmist.com",
        "contact_email": "mistme@northwestmist.com",
        "hometown": "Greater Portland/Vancouver area",
        "description": "Providing a soothing Northwest atmosphere to escape the mid-day heat with misting, music and body paint artists. Step through the Northwest Mist portal and transcend the heat of the day for a momentary refreshing encounter.",
        "location": {
            "string": "3:00 Public Plaza @ 2:45",
            "frontage": "3:00 Public Plaza",
            "intersection": "2:45",
            "intersection_type": "@",
            "gps_latitude": 40.792289864784486,
            "gps_longitude": -119.21491380853163
        },
        "location_string": "3:00 Public Plaza @ 2:45"
    },
    {
        "uid": "a1Xd0000001IItGEAW",
        "year": 2016,
        "name": "Gypsy Nebula Village",
        "url": "https://www.facebook.com/groups/GypsyNebula/permalink/806098426168637/?comment_id=811823032262843&notif_t=group_comment",
        "contact_email": "gypsymonkeyman@yahoo.com",
        "hometown": "The Gypsy Nebula",
        "description": "The Gypsy Monkeys, the BRC Boardwalk, Bad Lands Shaved Ice and Morning Cock 'n Tails are going polycamperous for Burning Man 2016! Come by and get your fortune told, make a sock monkey or adopt a mutant monkey, have a mimosa or a coffee and then a shaved ice all in one convenient place.",
        "location": {
            "string": "3:00 Public Plaza @ 3:15",
            "frontage": "3:00 Public Plaza",
            "intersection": "3:15",
            "intersection_type": "@",
            "gps_latitude": 40.792352979352394,
            "gps_longitude": -119.21499728426735
        },
        "location_string": "3:00 Public Plaza @ 3:15"
    },
    {
        "uid": "a1Xd0000001IX4xEAG",
        "year": 2016,
        "name": "Da PlayaGround",
        "hometown": "Healdsburg",
        "description": "At Da PlayaGround, you can experience the physics and dynamics of spinning and swinging on our multi swing playground and get your photo taken as Mona Lisa. Thirsty, sit at our table for your \"Last Supper\" and drink some wine, nibble some bread.",
        "location": {
            "string": "3:30 & D",
            "frontage": "3:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.77771409960112,
            "gps_longitude": -119.19987774416956
        },
        "location_string": "3:30 & D"
    },
    {
        "uid": "a1Xd0000001IXAHEA4",
        "year": 2016,
        "name": "Skinny Kitty Teahouse",
        "contact_email": "aqiwi@hotmail.com",
        "hometown": "Ukiah, CA",
        "description": "Skinny Kitty Teahouse serves tea 24 hours a day all week long. We offer a refuge from the hustle and bustle: shade, shelter, couches, a piano, performance space for spontaneous use and the company of several unfortunately emaciated felines.",
        "location": {
            "string": "3:00 Public Plaza @ 8:45",
            "frontage": "3:00 Public Plaza",
            "intersection": "8:45",
            "intersection_type": "@",
            "gps_latitude": 40.79283288692738,
            "gps_longitude": -119.21436354175313
        },
        "location_string": "3:00 Public Plaza @ 8:45"
    },
    {
        "uid": "a1Xd0000001IVs4EAG",
        "year": 2016,
        "name": "Molotov Cocktail",
        "hometown": "Tacoma",
        "description": "Welcome home, have a homebrew. Ice cold homebrews on draft and other libations day and night in our shaded chill space.",
        "location": {
            "string": "3:30 & E",
            "frontage": "3:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.777144519137565,
            "gps_longitude": -119.19944355839093
        },
        "location_string": "3:30 & E"
    },
    {
        "uid": "a1Xd0000001IMK4EAO",
        "year": 2016,
        "name": "Cereal Thrillers",
        "hometown": "San Francisco",
        "description": "Cereal Thrillers a Breakfast Cereal Bar\r\nWhere you can have that sugary breakfast cereal your mom would not let you have as a kid.",
        "location": {
            "string": "3:00 Public Plaza @ 10:30",
            "frontage": "3:00 Public Plaza",
            "intersection": "10:30",
            "intersection_type": "@",
            "gps_latitude": 40.79256133313418,
            "gps_longitude": -119.2141864372901
        },
        "location_string": "3:00 Public Plaza @ 10:30"
    },
    {
        "uid": "a1Xd0000001IM88EAG",
        "year": 2016,
        "name": "S'mores N Amour",
        "url": "http://tribes.tribe.net/b1e2bf96-a3bf-4a91-b145-9a9b0fdff718",
        "contact_email": "smoresnamour@yahoo.com",
        "hometown": "North Hollywood",
        "description": "S'MORES at sundown!  All ages are invited...come roast a marshmallow and we'll make you a S'more.  Doctor Who says these are the best S'mores in all of Time and Space!  Warning: marshmallows will be burned.",
        "location": {
            "string": "3:30 & A",
            "frontage": "3:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.77942283122764,
            "gps_longitude": -119.20118034618002
        },
        "location_string": "3:30 & A"
    },
    {
        "uid": "a1Xd0000001IGZIEA4",
        "year": 2016,
        "name": "PolyParadise",
        "url": "http://www.polyparadise.com",
        "contact_email": "scotto@burningman.org",
        "hometown": "Phoenix",
        "description": "The Village of PolyParadise has been influencing the Hearts & Minds and Washing the Bodies of Playa Citizens from '2:00 - 10:00' since 1999 celebrating 18 years in BRC in 2016.\r\n\r\nPolyamory involves openness to multiple loving relationships, with honesty among all partners. We welcome ALL Poly & Poly Friendly folks to camp within our borders.\r\n\r\nThe Village of PolyParadise 2016 welcomes the addition of three Theme Camps within in it's borders Sugar Bitch | 9 Energies | Twisted Swan.\r\n\r\nPolyParadise is NOT a Swinger Camp. Being Poly or Practicing Poly is NOT a requirement for camping with us, but being OPEN MINDED about other people's lifestyle choices IS!!",
        "location": {
            "string": "3:30 & E",
            "frontage": "3:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.777144519137565,
            "gps_longitude": -119.19944355839093
        },
        "location_string": "3:30 & E"
    },
    {
        "uid": "a1Xd0000001IJVjEAO",
        "year": 2016,
        "name": "Wanderer's Camp",
        "url": "http://www.thewandererscamp.com/",
        "contact_email": "bodie992000@yahoo.com",
        "hometown": "Reno",
        "description": "Our Camp is an oasis on the playa for the Wandering Burner who happens upon our camp and finds HUGS, ice cold Gin/Tonic's, and Hot Dogs,  Come by every afternoon from 4 to 6 for a hot dog or veggie dog, a gin/tonic and enjoy the shade, great company and music.",
        "location": {
            "string": "3:30 & F",
            "frontage": "3:30",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.77657493704676,
            "gps_longitude": -119.19900938005765
        },
        "location_string": "3:30 & F"
    },
    {
        "uid": "a1Xd0000001IBAHEA4",
        "year": 2016,
        "name": "Camp D.O.A.",
        "url": "https://sites.google.com/site/campdoa/",
        "contact_email": "camp.doa.2010@gmail.com",
        "hometown": "Cameron Park",
        "description": "Camp D.O.A is hosted by outdoor adventurists that offer music, conversation, dancing, hooping, and a shady spot to relax with a glass of wine, champagne, or cocktail. We treat everyone like they are a welcome guest in our home, so come in, have a seat, and share with us the decadent outdoor adventures you like to do while you enjoy the best decadence in Black Rock City!",
        "location": {
            "string": "3:30 & C",
            "frontage": "3:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.77828367843735,
            "gps_longitude": -119.20031193739376
        },
        "location_string": "3:30 & C"
    },
    {
        "uid": "a1Xd0000001ISOlEAO",
        "year": 2016,
        "name": "Happy Hour",
        "url": "https://www.facebook.com/pages/Camp-Happy-Hour/350219491736402",
        "contact_email": "camphappyhour@gmail.com",
        "hometown": "We are global!",
        "description": "Hard day on the playa? Unwind at Happy Hour, where you'll be greeted by one of a kind refreshing spirits served with smiles! Enjoy our lounge, bar, and gigantic jungle gym! Climb, dance on our Kaleidoshade structure or groove on tallest rotating \"exotic dancing\" pole! Start your evening with Happy Hour!",
        "location": {
            "string": "3:00 Portal & A",
            "frontage": "3:00 Portal",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.78070302098065,
            "gps_longitude": -119.19897672841634
        },
        "location_string": "3:00 Portal & A"
    },
    {
        "uid": "a1Xd0000001IOJpEAO",
        "year": 2016,
        "name": "Arctica Ice Sales - Ice Cubed",
        "contact_email": "gentle@burningman.org",
        "hometown": "Iceland",
        "description": "Ice Cubed is the ice sales igloo located on the 3 o'clock side of the city.  This year it is located a few streets back from where you normally find it.  Crushed and block ice are available for $3 per bag/block or $18 for a 6-pack of crushed ice.  Ice Cubed sales hours are Mon-Sat 9am-6pm and Sun Noon-6pm.",
        "location": {
            "string": "3:00 Public Plaza @ 5:45",
            "frontage": "3:00 Public Plaza",
            "intersection": "5:45",
            "intersection_type": "@",
            "gps_latitude": 40.79276962520508,
            "gps_longitude": -119.21499766263501
        },
        "location_string": "3:00 Public Plaza @ 5:45"
    },
    {
        "uid": "a1Xd0000001IVIeEAO",
        "year": 2016,
        "name": "SAKENOMA",
        "hometown": "Sonoma",
        "description": "Come get cold sake on a hot day at one of the playa's longest running sake bar and newly added tea lounge!",
        "location": {
            "string": "3:00 Public Plaza @ 12:15",
            "frontage": "3:00 Public Plaza",
            "intersection": "12:15",
            "intersection_type": "@",
            "gps_latitude": 40.79228990344843,
            "gps_longitude": -119.21436386372233
        },
        "location_string": "3:00 Public Plaza @ 12:15"
    },
    {
        "uid": "a1Xd0000001IWiDEAW",
        "year": 2016,
        "name": "Whisker Biscuit",
        "hometown": "Denver",
        "description": "Let our beautiful crew make your day with aerial performances, delicious cocktails and snacks at our comfy compound.  Join us every day for happy hour and maybe learn a trick or two!",
        "location": {
            "string": "3:30 & B",
            "frontage": "3:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.778853255646204,
            "gps_longitude": -119.20074613806385
        },
        "location_string": "3:30 & B"
    },
    {
        "uid": "a1Xd0000001IX1tEAG",
        "year": 2016,
        "name": "Go Home",
        "contact_email": "zeemox@gmail.com",
        "hometown": "North Bend, WA, near Seattle",
        "description": "Go Home is the playa's home for the ancient Chinese game of Go, featuring a giant 9'x9' Go board. Come join us to relax, learn, and play board games during the hot dusty day.",
        "location": {
            "string": "3:45 & E",
            "frontage": "3:45",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77652504386816,
            "gps_longitude": -119.20110360969608
        },
        "location_string": "3:45 & E"
    },
    {
        "uid": "a1Xd0000001IXLoEAO",
        "year": 2016,
        "name": "Helioz",
        "hometown": "San Francisco",
        "description": "Helioz.  Have your mind blown in the Soundnasium, a participatory synaesthetic audiovisual experience.  Come into our dome and experience this moment as you create it along with your friends.",
        "location": {
            "string": "3:30 & B",
            "frontage": "3:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.778853255646204,
            "gps_longitude": -119.20074613806385
        },
        "location_string": "3:30 & B"
    },
    {
        "uid": "a1Xd0000001IWOVEA4",
        "year": 2016,
        "name": "Camp SPF / Syncytium",
        "url": "http://www.campspf.org",
        "contact_email": "webmaster@campspf.org",
        "hometown": "Milwaukee Wisconsin but people in our camp are from all over the United States and even a few from Canada.",
        "description": "Camp SPF is a sunscreen camp. Come over for organic SPF 30 sunscreen and a cool drink of lemonade.\r\n\r\ncampspf.org",
        "location": {
            "string": "3:30 & B",
            "frontage": "3:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.778853255646204,
            "gps_longitude": -119.20074613806385
        },
        "location_string": "3:30 & B"
    },
    {
        "uid": "a1Xd0000001INUdEAO",
        "year": 2016,
        "name": "People's Art Congress",
        "contact_email": "jamesdochs@gmail.com",
        "hometown": "Garwin",
        "description": "People's Art Congress welcomes Burners to 3 exciting Interactive Art Projects: Black Light Portrait Painting, Ride the Wave, and Awesome Blossom. We will also offer 3 scheduled seminars on \"A Meeting of Minds\", exploring the mind via current neuroscience and psychology. Come paint our faces, enjoy the experience of riding the wave, help us with the illumination of The Awesome Blossom, and participate in seminars on the mind.",
        "location": {
            "string": "4:00 & A",
            "frontage": "4:00",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.77861808293547,
            "gps_longitude": -119.20374637791872
        },
        "location_string": "4:00 & A"
    },
    {
        "uid": "a1Xd0000001IXb2EAG",
        "year": 2016,
        "name": "Rumi's Tea House",
        "hometown": "Brooklyn",
        "description": "Join us in exploring the beauty of Persian poetry over tea and hookah in our peaceful tea-house.",
        "location": {
            "string": "B & 3:15",
            "frontage": "B",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77948400945133,
            "gps_longitude": -119.19949888151989
        },
        "location_string": "B & 3:15"
    },
    {
        "uid": "a1Xd0000001IVAGEA4",
        "year": 2016,
        "name": "Flaming Ugly Cowboy Saloon",
        "hometown": "Reno",
        "description": "The Flaming Ugly Cowboy Saloon is the kind of cowboy bar that you would see in a movie made by the bastard love child of Sergio Leone and Frederico Fellini. We whoop. We holler. We lasso each other. And we poor the finest handcrafted beer you will find this side of the Quinn River.",
        "location": {
            "string": "B & 2:45",
            "frontage": "B",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78109131518967,
            "gps_longitude": -119.19737375201369
        },
        "location_string": "B & 2:45"
    },
    {
        "uid": "a1Xd0000001IXD6EAO",
        "year": 2016,
        "name": "Haze Laze",
        "hometown": "Bay Area",
        "description": "Shade, pillows, hookah, music, good conversation.",
        "location": {
            "string": "B & 2:45",
            "frontage": "B",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78109131518967,
            "gps_longitude": -119.19737375201369
        },
        "location_string": "B & 2:45"
    },
    {
        "uid": "a1Xd0000001IVSLEA4",
        "year": 2016,
        "name": "Melon of Troy",
        "url": "http://www.burningmelon.org",
        "hometown": "Chicago",
        "description": "A seriously silly, tangentially Trojan, ridiculously organized patch for melons of all varietals.",
        "location": {
            "string": "A & 3:45",
            "frontage": "A",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.778955784635805,
            "gps_longitude": -119.2024319422714
        },
        "location_string": "A & 3:45"
    },
    {
        "uid": "a1Xd0000001IIo6EAG",
        "year": 2016,
        "name": "Burning Man Studios",
        "contact_email": "burningmanstudios@gmail.com",
        "hometown": "LA/San Fran/Florida/South Africa",
        "description": "Burning Man Studios is a diverse group of crazies from across the country and across space and time that love movies, bad writing, and self-expression in all its forms.  Come by for a drink, some shade, or just to tell us a story.",
        "location": {
            "string": "B & 2:45",
            "frontage": "B",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78109131518967,
            "gps_longitude": -119.19737375201369
        },
        "location_string": "B & 2:45"
    },
    {
        "uid": "a1Xd0000001IW3NEAW",
        "year": 2016,
        "name": "Anita Cocktail",
        "url": "http://campanitacocktail.com/",
        "hometown": "NYC, Los Angeles, Sydney, Melbourne, Bunbury, San Juan, Auckland, Turkey, Saudi Arabia, Toronto",
        "description": "Camp Anita Cocktail: Hailing from 16+ countries around the globe, we contain traces of Australians, Kiwis, Chileans, Saudis, Turks, Nuyoricans, LA-LA Landers and other nutty products from afar. Serious reactions may occur. Activities abound all week in our chill space, bar, tea house, spiritual center and cuddle puddle tower. Our cups runneth over with welcome. Let's get down and boogie together!",
        "location": {
            "string": "A & 3:45",
            "frontage": "A",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.778955784635805,
            "gps_longitude": -119.2024319422714
        },
        "location_string": "A & 3:45"
    },
    {
        "uid": "a1Xd0000001IX28EAG",
        "year": 2016,
        "name": "Kamp Kaizen",
        "hometown": "LA/SF",
        "location": {
            "string": "A & 3:15",
            "frontage": "A",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.78000596237516,
            "gps_longitude": -119.20002725908707
        },
        "location_string": "A & 3:15"
    },
    {
        "uid": "a1Xd0000001IXMXEA4",
        "year": 2016,
        "name": "Galapagos",
        "hometown": "San Francisco",
        "description": "Dive into our colorful tropical sea environment featuring Darwin the tutle dome and Glitz the interactive LED jellyfish!",
        "location": {
            "string": "B & 2:45",
            "frontage": "B",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78109131518967,
            "gps_longitude": -119.19737375201369
        },
        "location_string": "B & 2:45"
    },
    {
        "uid": "a1Xd0000001IXLFEA4",
        "year": 2016,
        "name": "Camposanto",
        "url": "http://www.camposantito.com",
        "contact_email": "quixote@gmail.com",
        "hometown": "San Francisco",
        "description": "Camposanto is from all corners of the World, but we are mostly Latinos. We love to dance and celebrate friendship. We contribute to the playa experience with dope Latin Beats and Rhythm. Come and play beer-in-hand soccer in our stadium. Look for the Camposanto-mobile.",
        "location": {
            "string": "A & 2:45",
            "frontage": "A",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78149196190158,
            "gps_longitude": -119.19806251041214
        },
        "location_string": "A & 2:45"
    },
    {
        "uid": "a1Xd0000001IXGeEAO",
        "year": 2016,
        "name": "Black Rock Brewery",
        "url": "https://www.facebook.com/groups/445469468922048/",
        "contact_email": "quickdrawannie@gmail.com",
        "hometown": "Salt Lake City",
        "description": "In eternal devotion to the magic of hop and yeast, the Black Rock Brewery brings together home brewers to share their honey ales, lavender meads, ginger beers, bacon porters, and coffee stouts. Join us for daily tastings and learn more about the different styles of brews!  For something special, bring something for us to print on when you stop by to visit.",
        "location": {
            "string": "A & 2:45",
            "frontage": "A",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78149196190158,
            "gps_longitude": -119.19806251041214
        },
        "location_string": "A & 2:45"
    },
    {
        "uid": "a1Xd0000001IXUVEA4",
        "year": 2016,
        "name": "Magic Lantern Society",
        "contact_email": "hello@supermoni.ca",
        "hometown": "Pacifica",
        "location": {
            "string": "A & 3:45",
            "frontage": "A",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.778955784635805,
            "gps_longitude": -119.2024319422714
        },
        "location_string": "A & 3:45"
    },
    {
        "uid": "a1Xd0000001IJvdEAG",
        "year": 2016,
        "name": "WeScream",
        "hometown": "Boulder and Denver",
        "description": "Help us make -196 C / -321 F liquid nitrogen ice cream!  Come by to enjoy some cold ice cream made by YOU in the heat of the hot summer day.",
        "location": {
            "string": "A & 2:45",
            "frontage": "A",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78149196190158,
            "gps_longitude": -119.19806251041214
        },
        "location_string": "A & 2:45"
    },
    {
        "uid": "a1Xd0000001INppEAG",
        "year": 2016,
        "name": "Camp Luminos",
        "hometown": "Phoenix",
        "description": "Make your own lantern out of a gourd at Camp Luminos.",
        "location": {
            "string": "A & 3:15",
            "frontage": "A",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.78000596237516,
            "gps_longitude": -119.20002725908707
        },
        "location_string": "A & 3:15"
    },
    {
        "uid": "a1Xd0000001IAzNEAW",
        "year": 2016,
        "name": "Family Reunion Camp",
        "url": "http://www.artisticaura.org/family-reunion-camp.html",
        "contact_email": "artmobile@artisticaura.org",
        "hometown": "Page",
        "description": "An intimate camp providing activities for families to enjoy together, Family Reunion Camp welcomes all citizens of Black Rock City as members of our family and we look forward to our yearly reunion on the Playa! Join us for some fun and games, make some art, or just hang out with us.",
        "location": {
            "string": "B & 3:45",
            "frontage": "B",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.77834809836258,
            "gps_longitude": -119.20209985853667
        },
        "location_string": "B & 3:45"
    },
    {
        "uid": "a1Xd0000001IWw5EAG",
        "year": 2016,
        "name": "Flattery Camp",
        "hometown": "Diaspora!",
        "description": "Self-worth in the tube? Ego hit the deck, or the BM-blues got you down? Ha, we got this. Just swing by Flattery for your daily soul tune-up, and in no time our fully trained and certified id-mechanics will have you whistling on your way. With humor, sincerity, originality, shaded comforts and hospitality, we'll lovingly bend your psyche back into shape. And did I mention just how ridiculously lovely you are?",
        "location": {
            "string": "C & 3:15",
            "frontage": "C",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.778962057935686,
            "gps_longitude": -119.19897050537821
        },
        "location_string": "C & 3:15"
    },
    {
        "uid": "a1Xd0000001IAtoEAG",
        "year": 2016,
        "name": "Whiskey and Dust",
        "url": "http://www.whiskeyanddust.com/",
        "contact_email": "peter.leonard.jr@gmail.com",
        "hometown": "Denver",
        "description": "We are a Whiskey camp with a small habitual yoga problem.\r\nOur concept is simple. Capitalize on what the Burning Man community desires more of (Yoga, Lyra performances, Juggling, and Hooping). At the same time, be challenging and creative to show the community something; anything that is new and different.",
        "location": {
            "string": "D & 2:45",
            "frontage": "D",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78029002604831,
            "gps_longitude": -119.19599624257887
        },
        "location_string": "D & 2:45"
    },
    {
        "uid": "a1Xd0000001IUxREAW",
        "year": 2016,
        "name": "Zendo 3:00",
        "url": "http://www.zendoproject.org",
        "contact_email": "zendo@maps.org",
        "hometown": "Santa Cruz",
        "description": "Feeling out of sorts and looking for a place to recoup? Zendo volunteers are available 24/7 to offer psychological support and education for drug-related concerns. Come by one of our open-air yurts by the 9 o'clock & 3 o'clock ESD/RHQ stations.",
        "location": {
            "string": "D & 3:15",
            "frontage": "D",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77844010782816,
            "gps_longitude": -119.198442130662
        },
        "location_string": "D & 3:15"
    },
    {
        "uid": "a1Xd0000001IJnKEAW",
        "year": 2016,
        "name": "Temple Guardians",
        "url": "http://burningman.org/event/volunteering/teams/temple-guardians/",
        "contact_email": "templeguardians@templeguardians.org",
        "hometown": "San Francisco",
        "description": "If the Temple has a special place in your heart, join us and help hold the space so that others might experience the wonder that brings us back.",
        "location": {
            "string": "D & 2:45",
            "frontage": "D",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78029002604831,
            "gps_longitude": -119.19599624257887
        },
        "location_string": "D & 2:45"
    },
    {
        "uid": "a1Xd0000001IXTSEA4",
        "year": 2016,
        "name": "Yummy RUMInations",
        "hometown": "Los Angeles and Brooklyn",
        "description": "Playfully-mindful camp uniting burners through laughter, curiosity, and consciousness.  Daily experiments in vulnerability, intimacy, self-discovery, storytelling, workshops and home of The Yum Cart...people leave with a smile and often come back for seconds.",
        "location": {
            "string": "C & 3:45",
            "frontage": "C",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.77774041281026,
            "gps_longitude": -119.20176777519588
        },
        "location_string": "C & 3:45"
    },
    {
        "uid": "a1Xd0000001IVqDEAW",
        "year": 2016,
        "name": "Whynauts",
        "hometown": "New York City",
        "description": "Our mission is to inspire people to imagine what the world could be like by reconnecting with their sense of child-like wonderment. This year, we're inspiring people to see the world through the eyes of a child by creating an over sized \"What If? Diner\" in Black Rock City. Venture out into deep playa to dance to the 10ft jukebox, have your feet dangle in our booths & if your timing is right, partake in our delicious diner food.",
        "location": {
            "string": "D & 2:45",
            "frontage": "D",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78029002604831,
            "gps_longitude": -119.19599624257887
        },
        "location_string": "D & 2:45"
    },
    {
        "uid": "a1Xd0000001ISxlEAG",
        "year": 2016,
        "name": "Arrakis Spice Market",
        "hometown": "Seattle",
        "description": "Arrakis Spice Market, bringing the spice to the playa.",
        "location": {
            "string": "C & 2:45",
            "frontage": "C",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78069066990527,
            "gps_longitude": -119.19668499606931
        },
        "location_string": "C & 2:45"
    },
    {
        "uid": "a1Xd0000001ILviEAG",
        "year": 2016,
        "name": "Pathogen Trackers",
        "url": "http://www.pathogentrackers.com",
        "contact_email": "campleader@pathogentrackers.com",
        "hometown": "Reno",
        "description": "The vision of Pathogen Trackers is to bring attention to the very real threat humanity faces, that survival of future global epidemics, such as ignorance, apathy, and the Zika Virus, can only be combatted through community effort, on-going medical research, and interpretive dance.  The unified theme of our camp is meant to focus awareness. We want to share the message that without our continued vigilance, creativity, life long learning, and level-headed management of future crises, we all run the risk of falling victim to ever more virulent pathogens.  ",
        "location": {
            "string": "B & 3:45",
            "frontage": "B",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.77834809836258,
            "gps_longitude": -119.20209985853667
        },
        "location_string": "B & 3:45"
    },
    {
        "uid": "a1Xd0000001IRqrEAG",
        "year": 2016,
        "name": "Soul Mate",
        "hometown": "San Francisco",
        "description": "SOUL MATE (mah-tay) invites new friends and old to join us for mate tea ceremonies and soul music. Revitalize your soul with mate, music, and friendship.",
        "location": {
            "string": "D & 2:45",
            "frontage": "D",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78029002604831,
            "gps_longitude": -119.19599624257887
        },
        "location_string": "D & 2:45"
    },
    {
        "uid": "a1Xd0000002yk56EAA",
        "year": 2016,
        "name": "L3K, The One Ring",
        "description": "This is the support camp for the ring of lights around the man. We also do repair of lighting systems as needed.",
        "location": {
            "string": "C & 3:15",
            "frontage": "C",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.778962057935686,
            "gps_longitude": -119.19897050537821
        },
        "location_string": "C & 3:15"
    },
    {
        "uid": "a1Xd0000001IR9QEAW",
        "year": 2016,
        "name": "Head Space",
        "contact_email": "campheadspace@gmail.com",
        "hometown": "Vancouver",
        "description": "Come on by for our 3rd annual Case-of Ideas Night! Serving quesadillas and hot tasty pizza from our wood-fired oven. Fill your belly, relax in our shade and check out all things related to the neck up!",
        "location": {
            "string": "E & 3:15",
            "frontage": "E",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77791815912868,
            "gps_longitude": -119.19791375737117
        },
        "location_string": "E & 3:15"
    },
    {
        "uid": "a1Xd0000001IBjJEAW",
        "year": 2016,
        "name": "Floristonia",
        "hometown": "Floriston, CA and our sister city, Toronto, Canada",
        "description": "Floristonia provides a welcoming, nurturing environment with a place to relax, rehydrate and recharge while drinking a cold margarita and visiting with new friends.",
        "location": {
            "string": "D & 3:45",
            "frontage": "D",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.777132727978795,
            "gps_longitude": -119.20143569224902
        },
        "location_string": "D & 3:45"
    },
    {
        "uid": "a1Xd0000001IDTgEAO",
        "year": 2016,
        "name": "Soul Shakers",
        "contact_email": "simon_shea@hotmail.com",
        "hometown": "Haad Tien",
        "description": "Explore the depths of your soul with tarot, astral projection, raw cacao and sacred beats",
        "location": {
            "string": "E & 3:15",
            "frontage": "E",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77791815912868,
            "gps_longitude": -119.19791375737117
        },
        "location_string": "E & 3:15"
    },
    {
        "uid": "a1Xd0000001ISOqEAO",
        "year": 2016,
        "name": "Listen",
        "contact_email": "laubrens@gmail.com",
        "hometown": "Los Angeles",
        "description": "Come to Listen and be heard.",
        "location": {
            "string": "E & 3:15",
            "frontage": "E",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77791815912868,
            "gps_longitude": -119.19791375737117
        },
        "location_string": "E & 3:15"
    },
    {
        "uid": "a1Xd0000001IX7SEAW",
        "year": 2016,
        "name": "Cafe Calm",
        "contact_email": "cafecalmhq@gmail.com",
        "hometown": "London",
        "description": "\"Come find the tribe!\" A desert oasis is our vibe. Looking to discover a your vocation, prepare for a Playa exploration, examine that inner tribal sensation, or find respite on a jungle space station?\r\n\r\nWhere jungle meets the seaside meets the desert, there's a land called cafe calm, where they play hippie house to surreal sunsets and warm gusts of sea air in a utopia of radical self expression. \r\n\r\nMinimal yet enveloping, familiarly encompassing, join us at our jungle oasis for great London beats, deep yoga, workshops, smoothies, English tea and maybe...some snacks.",
        "location": {
            "string": "D & 3:15",
            "frontage": "D",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77844010782816,
            "gps_longitude": -119.198442130662
        },
        "location_string": "D & 3:15"
    },
    {
        "uid": "a1Xd0000001IXDBEA4",
        "year": 2016,
        "name": "Love Crunchers' Equal & Opposite",
        "hometown": "Los Angeles",
        "location": {
            "string": "E & 3:15",
            "frontage": "E",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77791815912868,
            "gps_longitude": -119.19791375737117
        },
        "location_string": "E & 3:15"
    },
    {
        "uid": "a1Xd0000001IVUlEAO",
        "year": 2016,
        "name": "Le Attrata by Therm, shop + camp",
        "url": "http://www.therm.cc",
        "hometown": "Oakland",
        "description": "Therm Presents Le Attrata!  three turbine engines powering three amazing stainless flying bugs!",
        "location": {
            "string": "D & 3:15",
            "frontage": "D",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77844010782816,
            "gps_longitude": -119.198442130662
        },
        "location_string": "D & 3:15"
    },
    {
        "uid": "a1Xd0000001IVo2EAG",
        "year": 2016,
        "name": "Plays Well With Others",
        "hometown": "Reno",
        "location": {
            "string": "E & 2:45",
            "frontage": "E",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77988938361874,
            "gps_longitude": -119.19530749154225
        },
        "location_string": "E & 2:45"
    },
    {
        "uid": "a1Xd0000001IXExEAO",
        "year": 2016,
        "name": "Black Rock City Bass & Brews",
        "hometown": "Reno",
        "description": "If you have the itch to get down right filthy we have the camp for YOU!!! Come join us at Black Rock City Bass & Brews for ground rattling beats and the tastiest home-brew and cocktails in the BRC. We will make sure you dance the day away with the most eargazmic beats while you mingle with the friendliest burners around.",
        "location": {
            "string": "D & 3:45",
            "frontage": "D",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.777132727978795,
            "gps_longitude": -119.20143569224902
        },
        "location_string": "D & 3:45"
    },
    {
        "uid": "a1Xd0000001IXEnEAO",
        "year": 2016,
        "name": "MOONDRIVE",
        "hometown": "San Francisco Bay Area",
        "description": "We are a group of people who enjoy taking things to the next level.",
        "location": {
            "string": "D & 3:45",
            "frontage": "D",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.777132727978795,
            "gps_longitude": -119.20143569224902
        },
        "location_string": "D & 3:45"
    },
    {
        "uid": "a1Xd0000001IVlmEAG",
        "year": 2016,
        "name": "Holi High Camp",
        "hometown": "San Francisco",
        "description": "Holi High Camp brings the madness and color kaleidoscope of the Indian festival of Holi to the boisterous masses of the playa through body-paint blasting cannons.",
        "location": {
            "string": "D & 3:45",
            "frontage": "D",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.777132727978795,
            "gps_longitude": -119.20143569224902
        },
        "location_string": "D & 3:45"
    },
    {
        "uid": "a1Xd0000001IXPbEAO",
        "year": 2016,
        "name": "Kamp Kimono",
        "hometown": "San Francisco",
        "description": "Love! Kimonos! Weirdness! Please visit our camp - or deep playa Kimonoasis - to write your own spontaneous desert haiku and have it mailed back to you. We'll be waiting with Prosecco and postage stamps up our sleeves! P.S. Please don't pet the Buffalo.",
        "location": {
            "string": "D & 3:15",
            "frontage": "D",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77844010782816,
            "gps_longitude": -119.198442130662
        },
        "location_string": "D & 3:15"
    },
    {
        "uid": "a1Xd0000001IXH3EAO",
        "year": 2016,
        "name": "Bao Chicka Wow Wow",
        "hometown": "San Francisco",
        "description": "Camp Bao Chicka Wow Wow is honored to provide the Playa with thousands of steamed Bao (delicious warm pork buns) and a comfortable, relaxing ambiance in which to enjoy them. We look forward to welcoming you into our Bao Haus!",
        "location": {
            "string": "D & 3:15",
            "frontage": "D",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77844010782816,
            "gps_longitude": -119.198442130662
        },
        "location_string": "D & 3:15"
    },
    {
        "uid": "a1Xd0000001IXoaEAG",
        "year": 2016,
        "name": "Disco Parlour",
        "contact_email": "rancidbry@gmail.com",
        "hometown": "San Francisco",
        "description": "We have a Climbing Dome!  Come get your disco on, enjoy our cafe/bar dome with climbing holds on the inside.  Challenge your body and mind!  If you make it to the top, you will be rewarded by the sky bar with a view of the playa and amazing people hanging by their finger tips.  :-)",
        "location": {
            "string": "D & 3:45",
            "frontage": "D",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.777132727978795,
            "gps_longitude": -119.20143569224902
        },
        "location_string": "D & 3:45"
    },
    {
        "uid": "a1Xd0000001IXRSEA4",
        "year": 2016,
        "name": "Gigsville",
        "url": "http://www.gigsville.org",
        "contact_email": "gigsmayors@gmail.com",
        "hometown": "Los Angeles, San Francisco, Austin, and Houston",
        "description": "Gigsville is one of the oldest villages on the Playa (18 or 19 years old, depending on how you do the math). We're dedicated to fire, fun, and good old fashion jackassery. You'll find us gathered around the car that's on fire in the center of camp. No ocelots or other violations of the Gigsville Code of Conduct are allowed.",
        "location": {
            "string": "E & 2:45",
            "frontage": "E",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77988938361874,
            "gps_longitude": -119.19530749154225
        },
        "location_string": "E & 2:45"
    },
    {
        "uid": "a1Xd0000001IXZGEA4",
        "year": 2016,
        "name": "Ultimate Celebration",
        "hometown": "San Francisco and New York City",
        "description": "The end is nigh! Come bounce while you can in the upholstered luxury of our Bungee Couch Garden, sip the ambrosia of perpetual motion (champagne and 5­-hour energy, the official libation of our Ultimate Celebration, available from 4­-6pm Monday-Friday), contemplate your own ultimate destination, join in a campfire sing­ along, or zip around on a Wiimote­-controlled electric armchair. In short, if your vision of the apocalypse is as lazy and carefree as ours, we've got you covered!",
        "location": {
            "string": "E & 2:45",
            "frontage": "E",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77988938361874,
            "gps_longitude": -119.19530749154225
        },
        "location_string": "E & 2:45"
    },
    {
        "uid": "a1Xd0000001IVyDEAW",
        "year": 2016,
        "name": "Cheese Camp",
        "hometown": "London",
        "description": "Cheese Camp",
        "location": {
            "string": "D & 3:15",
            "frontage": "D",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77844010782816,
            "gps_longitude": -119.198442130662
        },
        "location_string": "D & 3:15"
    },
    {
        "uid": "a1Xd0000001IBDBEA4",
        "year": 2016,
        "name": "Cingulata Camp",
        "hometown": "Seattle",
        "description": "Cingulata, home of the best grilled cheese on the playa!",
        "location": {
            "string": "F & 2:45",
            "frontage": "F",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77948874261647,
            "gps_longitude": -119.19461874295936
        },
        "location_string": "F & 2:45"
    },
    {
        "uid": "a1Xd0000001IXeBEAW",
        "year": 2016,
        "name": "The Black Rock Plyceum",
        "contact_email": "philosophyatbrc@gmail.com",
        "hometown": "Sacramento",
        "description": "We are a group of professionally trained philosophers employed at universities around the world. Our goal is to create a space for the discussion of philosophical concepts and ideas aimed at increasing understanding and awareness of the fundamental nature of knowledge and reality.",
        "location": {
            "string": "F & 2:45",
            "frontage": "F",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77948874261647,
            "gps_longitude": -119.19461874295936
        },
        "location_string": "F & 2:45"
    },
    {
        "uid": "a1Xd0000001IBn6EAG",
        "year": 2016,
        "name": "Aminal Earf",
        "contact_email": "opossumearf@gmail.com",
        "hometown": "South Lake Tahoe",
        "description": "Aminal Earf...A look into the hearts & spirituality of the true wildlife In Northern California..Yoga, meditation,healing,love!",
        "location": {
            "string": "F & 2:45",
            "frontage": "F",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77948874261647,
            "gps_longitude": -119.19461874295936
        },
        "location_string": "F & 2:45"
    },
    {
        "uid": "a1Xd0000001IX3aEAG",
        "year": 2016,
        "name": "Valhalla",
        "url": "http://valhalla.camp",
        "contact_email": "crutcher@gmail.com",
        "hometown": "San Francisco",
        "description": "Valhalla is a 24/7 Long House; a place to tell stories, to snuggle, and to plan new adventures. Come and have our Oracle guide you to your Destiny on the Playa.",
        "location": {
            "string": "F & 3:15",
            "frontage": "F",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77739621183719,
            "gps_longitude": -119.19738538550564
        },
        "location_string": "F & 3:15"
    },
    {
        "uid": "a1Xd0000001IWSIEA4",
        "year": 2016,
        "name": "Gallavant",
        "url": "http://www.rickmetz.com/Site/Gallavant.html",
        "contact_email": "ricksax1@aol.com",
        "hometown": "Reno",
        "description": "Ahoy from the Pirates of the Playa (infamous creators of the Mutant Vehicle, USS Nevada). We have the \"gall\" to \"Gallavant\" around the playa spreading fun and adventure, so, visit us, enjoy all the interactivity & hospitality we offer and hop a ride on a Mutant Vehicle!",
        "location": {
            "string": "E & 3:45",
            "frontage": "E",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.77652504386816,
            "gps_longitude": -119.20110360969608
        },
        "location_string": "E & 3:45"
    },
    {
        "uid": "a1Xd0000001IWRUEA4",
        "year": 2016,
        "name": "Green Goddess",
        "contact_email": "jessicaanutrition@yahoo.com",
        "hometown": "Las Vegas",
        "description": "The GREEN GODDESS invites everyone to reflect and refresh while getting nourished with delightful tastes of the Green Goddess' fermented foods and beverages.  Enjoy healthy, fermented refreshments while relaxing in our lounge space, listening to soothing mantras and classical-infused electronic vibes staying cool under the solar-powered water misters.",
        "location": {
            "string": "F & 3:15",
            "frontage": "F",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77739621183719,
            "gps_longitude": -119.19738538550564
        },
        "location_string": "F & 3:15"
    },
    {
        "uid": "a1Xd0000001IWMyEAO",
        "year": 2016,
        "name": "Be You, Do You",
        "hometown": "San Jose",
        "description": "Camp Be You, Do You brings together individuals to shine and thrive in being unapologetically human! Basking is self-love, we spread the confidence and courage of being uniquely 'You'.",
        "location": {
            "string": "E & 3:45",
            "frontage": "E",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.77652504386816,
            "gps_longitude": -119.20110360969608
        },
        "location_string": "E & 3:45"
    },
    {
        "uid": "a1Xd0000001IWQHEA4",
        "year": 2016,
        "name": "vyvn",
        "url": "http://vyvn.com",
        "contact_email": "hello@vyvn.com",
        "hometown": "New York City",
        "description": "Shimmy those hips over to vyvn's oasis where you'll experience the best day vibes paired with your pick of kava, coffee, champagne or beer at our seated bar. During the day we'll also be providing experiential workshops such as yoga, crafts, and poetry readings. Come be a part of what we've dreamt about!",
        "location": {
            "string": "F & 2:45",
            "frontage": "F",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77948874261647,
            "gps_longitude": -119.19461874295936
        },
        "location_string": "F & 2:45"
    },
    {
        "uid": "a1Xd0000001IXPCEA4",
        "year": 2016,
        "name": "Funnel Vision",
        "url": "http://funnelvision.camp",
        "contact_email": "info@funnelvision.camp",
        "hometown": "San Francisco",
        "description": "Fresh hot homemade funnel cakes Mon-Thurs evenings (4:30pm-6:30pm)!  Come Wednesday (4pm-7pm) for drinks and dancing as well!",
        "location": {
            "string": "E & 3:15",
            "frontage": "E",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77791815912868,
            "gps_longitude": -119.19791375737117
        },
        "location_string": "E & 3:15"
    },
    {
        "uid": "a1Xd0000001ITAiEAO",
        "year": 2016,
        "name": "Electric Renaissance Art-Support",
        "url": "http://www.electric-renaissance.org",
        "contact_email": "info@electric-renaissance.org",
        "hometown": "Santa Cruz (CA USA) and Aachen (Germany)",
        "description": "Electric Renaissance Art-Support Camp, affiliated with Two Lanterns Theme Camp.\r\nElectric Renaissance (a tribute to Cadillac Ranch) is a Burning-Man Arts sponsored installation on the Playa.",
        "location": {
            "string": "F & 2:45",
            "frontage": "F",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77948874261647,
            "gps_longitude": -119.19461874295936
        },
        "location_string": "F & 2:45"
    },
    {
        "uid": "a1Xd0000001IX5lEAG",
        "year": 2016,
        "name": "True Reflections Palace Camp",
        "hometown": "Accord",
        "description": "True Reflections Palace.   Mirrors don't lie?  No, actually they do.  Come see what happens when you can see your true nature  without being reversed in a true reflection mirror.  Don't Miss This - It's Magic!",
        "location": {
            "string": "F & 2:45",
            "frontage": "F",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77948874261647,
            "gps_longitude": -119.19461874295936
        },
        "location_string": "F & 2:45"
    },
    {
        "uid": "a1Xd0000001IXV9EAO",
        "year": 2016,
        "name": "Serenity Now",
        "hometown": "San Francisco",
        "description": "Serenity Now coffeehouse returns for its 4th year on the playa! Bringing its  smooth cold brew coffee, delicious teas, and welcoming atmosphere, Serenity Now has your caffeine fix.",
        "location": {
            "string": "E & 3:45",
            "frontage": "E",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.77652504386816,
            "gps_longitude": -119.20110360969608
        },
        "location_string": "E & 3:45"
    },
    {
        "uid": "a1Xd0000001IUn2EAG",
        "year": 2016,
        "name": "Camp Not For Prophets",
        "hometown": "Hood River",
        "description": "Camp Not For Prophets is the place to find the infamous Hot Donut Holes.  When we say hot...we mean right out of the oil, right there on the Playa.  You can cream those holes with a plethora of flavored icings.\r\nThis year, along with our morning sarcasm, we are offering hand massages from our lovely hand maidens.\r\nThere will be a photo pavilion, camp art, and lots more.  \r\nTuesday through Friday mornings, 8:30 until the donuts are gone.  Don't miss it.",
        "location": {
            "string": "G & 2:45",
            "frontage": "G",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.1939250969776
        },
        "location_string": "G & 2:45"
    },
    {
        "uid": "a1Xd0000001IWWAEA4",
        "year": 2016,
        "name": "Dick Shaped Foods",
        "hometown": "Reno",
        "description": "Camp Dick Shaped Foods.  Come enjoy and share our love of the best kind of food...the dick shaped kind!",
        "location": {
            "string": "H & 2:45",
            "frontage": "H",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77869228660995,
            "gps_longitude": -119.19323614115217
        },
        "location_string": "H & 2:45"
    },
    {
        "uid": "a1Xd0000001IOlPEAW",
        "year": 2016,
        "name": "Airstreameri and What Not",
        "hometown": "Genoa",
        "location": {
            "string": "I & 3:15",
            "frontage": "I",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.775833846319884,
            "gps_longitude": -119.19579403129325
        },
        "location_string": "I & 3:15"
    },
    {
        "uid": "a1Xd0000001IWVMEA4",
        "year": 2016,
        "name": "Panda Camp",
        "contact_email": "chrisconlu@yahoo.com",
        "hometown": "Chicago",
        "description": "Panda Camp - Home to the Loveable Panda Crew of Panda1 - the electronicopter.",
        "location": {
            "string": "G & 3:15",
            "frontage": "G",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77687746108339,
            "gps_longitude": -119.19685125933968
        },
        "location_string": "G & 3:15"
    },
    {
        "uid": "a1Xd0000001IUVcEAO",
        "year": 2016,
        "name": "Camp Morning Wood",
        "hometown": "Los Angeles",
        "location": {
            "string": "H & 2:45",
            "frontage": "H",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77869228660995,
            "gps_longitude": -119.19323614115217
        },
        "location_string": "H & 2:45"
    },
    {
        "uid": "a1Xd0000001IWSDEA4",
        "year": 2016,
        "name": "The Bleachers",
        "url": "http://facebook.com/bmbleachers",
        "hometown": "Vancouver",
        "description": "The Bleachers - Mutant Vehicle Parking - A mobile interactive work of art/improv stage that made its debut at Burning Man 2013. Take a break from participating and spectate with us. \r\nwww.burningmanads.com",
        "location": {
            "string": "I & 3:15",
            "frontage": "I",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.775833846319884,
            "gps_longitude": -119.19579403129325
        },
        "location_string": "I & 3:15"
    },
    {
        "uid": "a1Xd0000001IXBPEA4",
        "year": 2016,
        "name": "Dusty Taint",
        "url": "http://www.dustytaint.com",
        "contact_email": "info@dustytaint.com",
        "hometown": "Fort Lauderdale",
        "description": "The Dusty Taint Camp is born in the style of a 1940's \"Negro Juke Joint\" featuring music, games and drinking. A highly welcoming and social nexus where people passing by and coming to the area can join us for the annual Ginger Appreciation Party, and rousing rounds of 'The Game\", in addition, drink and get to know their fellow burners in a multi-cultural and adult space following an amazing day on the playa.",
        "location": {
            "string": "I & 2:45",
            "frontage": "I",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77829184442306,
            "gps_longitude": -119.19254719363302
        },
        "location_string": "I & 2:45"
    },
    {
        "uid": "a1Xd0000001IWwyEAG",
        "year": 2016,
        "name": "end0r",
        "hometown": "Chicago",
        "description": "Need a break from the sun and noise? Take a load off in the shady hammocks of End0r. Look to the WWW for more info on our night time offerings ;)",
        "location": {
            "string": "G & 2:45",
            "frontage": "G",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.1939250969776
        },
        "location_string": "G & 2:45"
    },
    {
        "uid": "a1Xd0000001IVq8EAG",
        "year": 2016,
        "name": "Math Camp @ Group W",
        "url": "http://mathcamp.us",
        "contact_email": "info@mathcamp.us",
        "hometown": "Bay Area",
        "description": "Math Camp @ Group W is A Safe Place for Mathematics: A small, social camp, offering a place to Drink and DErive!  Daily lectures and long-winded impromptu chats on all things Math related.  We are proud Purveyors of Crunchy Snacks, plus we have The Best Friday Morning Sunrise Cocktail Party on the playa (not to mention being home of the fabulous Electric Cupcakes).",
        "location": {
            "string": "G & 2:45",
            "frontage": "G",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.1939250969776
        },
        "location_string": "G & 2:45"
    },
    {
        "uid": "a1Xd0000001IPjXEAW",
        "year": 2016,
        "name": "Pixelstad/Tacoma is for Lovers",
        "hometown": "Seattle/Tacoma",
        "description": "International hub of Art, Music, Performance, Yoga, and the famous cocktail hour kissing booth.",
        "location": {
            "string": "G & 2:45",
            "frontage": "G",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.1939250969776
        },
        "location_string": "G & 2:45"
    },
    {
        "uid": "a1Xd0000001IXgREAW",
        "year": 2016,
        "name": "Furniture Car Rally Camp",
        "url": "http://mobilesofa.com",
        "contact_email": "info@mobilesofa.com",
        "hometown": "San Francisco",
        "description": "Furniture Car Rally Camp invites you to relax in the Chevy Chaise Lounge and celebrate in mobile furniture of all kinds. Be sure to join us on Thursday for the annual playa furniture car rally and sunset cruise!",
        "location": {
            "string": "G & 2:45",
            "frontage": "G",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.1939250969776
        },
        "location_string": "G & 2:45"
    },
    {
        "uid": "a1Xd0000001IRqmEAG",
        "year": 2016,
        "name": "Two Lanterns",
        "url": "https://www.facebook.com/twolanternsthemecamp/",
        "contact_email": "bobo@cruzio.com",
        "hometown": "Santa Cruz",
        "description": "Best weddings on playa, Unofficial Playa Civil Unions (incl. rings/certificate), Black Rock Temporary Divorce, Annulments, amazing interactive elwire sculpture",
        "location": {
            "string": "G & 2:45",
            "frontage": "G",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.1939250969776
        },
        "location_string": "G & 2:45"
    },
    {
        "uid": "a1Xd0000001IXRNEA4",
        "year": 2016,
        "name": "SERENDIPITEA",
        "url": "http://serendipitea.camp",
        "contact_email": "serendipitea@neverbland.com",
        "hometown": "London",
        "description": "TO UNEXPECTED ADVENTURES AND TEA, IN OUR DUSTY PARADISE.\r\nWe focus on surprise, and spontaneity with live performance artists mixed in with a range of carefully curated dj's to provide a camp that is filled with mystery, excitement and even some delightfully unexpected snacks and drinks. Let us linger in the beautiful foolishness of things, and revel in our ignorance.",
        "location": {
            "string": "I & 2:45",
            "frontage": "I",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77829184442306,
            "gps_longitude": -119.19254719363302
        },
        "location_string": "I & 2:45"
    },
    {
        "uid": "a1Xd0000001IWllEAG",
        "year": 2016,
        "name": "Kegel Kommandos",
        "hometown": "Reno",
        "description": "Kegel Kommandos - we're doing it now!\r\nFeaturing the annual Friday Grilled Cheese and Bacon party and the new Black Rock City, Ding Dong Sing Song Beer Bong Ping Pong World Championship.",
        "location": {
            "string": "H & 2:45",
            "frontage": "H",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77869228660995,
            "gps_longitude": -119.19323614115217
        },
        "location_string": "H & 2:45"
    },
    {
        "uid": "a1Xd0000001IAz8EAG",
        "year": 2016,
        "name": "Camp 11:11",
        "hometown": "Redding",
        "description": "Celebrate 11:11--11:11 is a catalyst to unite people. It's a totally vertical moment in time. Make a wish at 11:11. Have a shot, give a kiss, or smoke a smoke at 11:11. Flame on at 11:11. Orgasm at precisely 11:11. Does anyone know what time is it? Its 11:11. Come help us discover 11:11 at Camp 11:11",
        "location": {
            "string": "I & 2:45",
            "frontage": "I",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77829184442306,
            "gps_longitude": -119.19254719363302
        },
        "location_string": "I & 2:45"
    },
    {
        "uid": "a1Xd0000001INCOEA4",
        "year": 2016,
        "name": "Surly Camp",
        "contact_email": "silvia@burningman.org",
        "hometown": "Reno",
        "description": "Surly Camp is the home to the SurlyBird double decker art car. She first debuted on the playa in 2003 and has undergone some amazing and imaginative transformations since then.",
        "location": {
            "string": "J & 2:45",
            "frontage": "J",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77789139813902,
            "gps_longitude": -119.19185825442003
        },
        "location_string": "J & 2:45"
    },
    {
        "uid": "a1Xd0000001IWwZEAW",
        "year": 2016,
        "name": "Janky Barge",
        "url": "http://www.facebook.com/TheJankyBarge",
        "contact_email": "jankybargecomm@gmail.com",
        "hometown": "San Francisco",
        "description": "Come join us on a ride-a-long for some music and fun with the Janky Barge or hangout with us at our cafe/lounge!",
        "location": {
            "string": "J & 2:45",
            "frontage": "J",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77789139813902,
            "gps_longitude": -119.19185825442003
        },
        "location_string": "J & 2:45"
    },
    {
        "uid": "a1Xd0000001IUkXEAW",
        "year": 2016,
        "name": "dEOxidized",
        "contact_email": "tiliolagatta@gmail.com",
        "hometown": "Reno",
        "description": "dEOxidized Camp is dedicated to recharging the batteries of all hard working burners. The camp is comprised of members of an Entrepreneurs Organization along with guests from all over the world. Together, we will co-create an unforgettable experience with our community of friends old and new. Our main attraction will be a 50' parachute featuring a lounge type chill space with an open bar, live music and happy hour everyday from 3 to Sunset.  There will also be a stage for impromptu performance, educational talks and well planned workshops throughout the day, i.e.; Yoga, bicycle workshops.  We have members from all over the United States and as far as Dubai, New Zealand and Mexico. We are a diverse group of burners with much to share and look forward to meeting you!",
        "location": {
            "string": "J & 3:15",
            "frontage": "J",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.775312035320134,
            "gps_longitude": -119.19526542972596
        },
        "location_string": "J & 3:15"
    },
    {
        "uid": "a1Xd0000001INXNEA4",
        "year": 2016,
        "name": "Reverbia",
        "url": "https://www.facebook.com/Reverbia",
        "contact_email": "reverbia.bman@gmail.com",
        "hometown": "Pacific Coast",
        "description": "Reverbia- Known as the \"Portal of Live Music\" or \"Oasis of Live Music at Burning Man\", offers Live Music programming 18 hours a day/night including: Live Music Yoga in the Morning, Live Dance Workshops, David Bowie Tribute, Sing Alongs, Song, Dust, Sing (Black Rock City's popular singer/songwriter showcase and open mic), our Concert in the Shade Series, Sunset Classical Concerts (BYO Wine, Food Baskets, and Blanket), Reverbia Live Nights (featuring International, national, and regional festival bands), and After hours Jam and Chai in our new Teahouse.",
        "location": {
            "string": "Esplanade & 3:45",
            "frontage": "Esplanade",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.78006987800911,
            "gps_longitude": -119.20304076347497
        },
        "location_string": "Esplanade & 3:45"
    },
    {
        "uid": "a1Xd0000001IRIkEAO",
        "year": 2016,
        "name": "Death Guild Thunderdome",
        "contact_email": "deathguildthunderdome@gmail.com",
        "hometown": "Oakland",
        "description": "The dark beating heart of the playa since 1999.",
        "location": {
            "string": "Esplanade & 2:45",
            "frontage": "Esplanade",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.7822264845812,
            "gps_longitude": -119.19932524051674
        },
        "location_string": "Esplanade & 2:45"
    },
    {
        "uid": "a1Xd0000001IWBqEAO",
        "year": 2016,
        "name": "Cosmiquarium Village",
        "hometown": "Salt Lake City",
        "description": "Cosmiquarium Village is where the mysteries of the deep intermingle with the wonder of the stars.  Combining the galactic playground of Cosmic Recess and the aquatic antics of the fabulous mutant vessels: the Amazing Jelly Fish from the year 12000 and the Frog Prince.  Join us for adventures of sea and space…at our home sphere or on voyages into the deep Playa!",
        "location": {
            "string": "Esplanade & 4:00",
            "frontage": "Esplanade",
            "intersection": "4:00",
            "intersection_type": "&",
            "gps_latitude": 40.7797827277492,
            "gps_longitude": -119.20415844356913
        },
        "location_string": "Esplanade & 4:00"
    },
    {
        "uid": "a1Xd0000001ISd2EAG",
        "year": 2016,
        "name": "Jub Jub's Plastic Circus",
        "hometown": "Reno",
        "description": "Jub Jub's Plastic Circus",
        "location": {
            "string": "Esplanade & 2:30",
            "frontage": "Esplanade",
            "intersection": "2:30",
            "intersection_type": "&",
            "gps_latitude": 40.78297439508715,
            "gps_longitude": -119.19866462296086
        },
        "location_string": "Esplanade & 2:30"
    },
    {
        "uid": "a1Xd0000001IAxlEAG",
        "year": 2016,
        "name": "Camp Shrunken Heads",
        "contact_email": "campshrunkenheads@yahoo.com",
        "hometown": "Oakland",
        "description": "Camp Shrunken Heads is again making earrings and necklaces! Come by anytime.",
        "location": {
            "string": "6:00 & E",
            "frontage": "6:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77884267712845,
            "gps_longitude": -119.21647957055906
        },
        "location_string": "6:00 & E"
    },
    {
        "uid": "a1Xd0000001ISxbEAG",
        "year": 2016,
        "name": "Play with Barbie & Ken Camp",
        "description": "Welcome to our  camp- come by and experience the fun of our interactive toy boxes day or night.  Dress up or down with our Barbie wear.   Stay, relax and mingle with other burners while delighting in the smiles, amazement and laughter for everyone playing in the Toy boxes. Come play with us!!",
        "location": {
            "string": "6:00 & E",
            "frontage": "6:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77884267712845,
            "gps_longitude": -119.21647957055906
        },
        "location_string": "6:00 & E"
    },
    {
        "uid": "a1Xd0000001IWOGEA4",
        "year": 2016,
        "name": "Burning Velvet",
        "hometown": "New York City & Montreal",
        "description": "What could be nicer than sparkling seltzer water on a hot day in Black Rock?  Hint: Nothing.\r\n\r\nBut guys, I hate bringing cans and bottles of seltzer water to Burning Man because of all of the garbage and potential moop.  Don't fret boo, Burning Velvet got you covered at their \"VIP\" Bubble Lounge located at 6:00 and E (TBC in 2016).\r\n\r\nEvery afternoon Monday-Saturday thirsty citizens can walk our Red Carpet, grab your very own Burning Man VIP bracelet and sidle up to the Carbonation Bar.  Step under our pimped out silver disco shade structure, chill on our couches under our cooooool water misters, listen to chill house and disco as our Carbonation Experts serve you. Legend tells it even works to turn boxed white wine into 'champagne'.  Sit back and enjoy a simple luxury on playa!",
        "location": {
            "string": "6:00 & D",
            "frontage": "6:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.77930776797406,
            "gps_longitude": -119.21586550871372
        },
        "location_string": "6:00 & D"
    },
    {
        "uid": "a1Xd0000001IVnOEAW",
        "year": 2016,
        "name": "So Far So Good",
        "contact_email": "karpenko@gmail.com",
        "hometown": "Los Angeles",
        "description": "Possibly the only mini-golf course in all of Black Rock City! Come and putt around with or against your friends and prepare to go head-to-head in the Wednesday tournament.",
        "location": {
            "string": "5:30 & G",
            "frontage": "5:30",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.776005353328756,
            "gps_longitude": -119.21442479083059
        },
        "location_string": "5:30 & G"
    },
    {
        "uid": "a1Xd0000001IRRhEAO",
        "year": 2016,
        "name": "LightSweeper",
        "url": "http://lightsweeper.z3n.org",
        "contact_email": "lightsweeper@z3n.org",
        "hometown": "Seattle",
        "description": "Star in your own 80s-style arcade game! Step into our console and onto the light-up dance floor where you can play fun games like giant Minesweeper! Experience life-size, 8-bit immersion!",
        "location": {
            "string": "6:00 & E",
            "frontage": "6:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77884267712845,
            "gps_longitude": -119.21647957055906
        },
        "location_string": "6:00 & E"
    },
    {
        "uid": "a1Xd0000001IMPEEA4",
        "year": 2016,
        "name": "Pandora's Lounge & Fix-It Shoppe",
        "url": "https://sites.google.com/site/pandorascamp/",
        "contact_email": "aalcina@sbcglobal.net",
        "hometown": "Saint Louis",
        "description": "We specialize in educating participants in repairing their bikes and more. Our lounge is a great place to hangout and wile away the hours with a drink or two with friends old or new. Our camp runs on solar power and we recycle everything possible.",
        "location": {
            "string": "5:30 & Esplanade",
            "frontage": "5:30",
            "intersection": "Esplanade",
            "intersection_type": "&",
            "gps_latitude": 40.78046704889989,
            "gps_longitude": -119.21102358626698
        },
        "location_string": "5:30 & Esplanade"
    },
    {
        "uid": "a1Xd0000001IWRoEAO",
        "year": 2016,
        "name": "Stellar Dusty Moon",
        "description": "From the makers of SpinCycle comes Stellar Dusty Moon! Where the drinks are out of this world, as are the workshops and the fun!",
        "location": {
            "string": "6:00 & E",
            "frontage": "6:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77884267712845,
            "gps_longitude": -119.21647957055906
        },
        "location_string": "6:00 & E"
    },
    {
        "uid": "a1Xd0000001IIbvEAG",
        "year": 2016,
        "name": "BLACK ROCK CIRCUS SIDE SHOW",
        "hometown": "Sandpoint, Idaho",
        "description": "Camp Black Rock Circus Side Show. Celebrating the fun of the circus side show with photo opportunities and oddities exhibits.",
        "location": {
            "string": "5:30 & H",
            "frontage": "5:30",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.775435767983616,
            "gps_longitude": -119.21485895427396
        },
        "location_string": "5:30 & H"
    },
    {
        "uid": "a1Xd0000001IWvMEAW",
        "year": 2016,
        "name": "Serenity Valley Saloon",
        "hometown": "Oakland & Seattle",
        "description": "Welcome to Serenity Valley Saloon where we re-enact the joy and pain of our past including Jerk Church (and maybe Undercity)! We are still drinkers with a singing problem, so come share a cup and a song with the reformed Mudders at our church without religion but lots of spirit.... or is that spirits? Anyway come by for a drink & some adventure!",
        "location": {
            "string": "6:00 & E",
            "frontage": "6:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77884267712845,
            "gps_longitude": -119.21647957055906
        },
        "location_string": "6:00 & E"
    },
    {
        "uid": "a1Xd0000001IWv7EAG",
        "year": 2016,
        "name": "Art Car Camp",
        "url": "http://artcarfest.com",
        "hometown": "Douglas",
        "description": "Art Car Camp at Burning Man was started in 1994 by art car creator, documentarian and promoter, Harrod Blank. As the Burning Man Festival has grown, art vehicles have become more elaborate and fantastical (now known as \"Mutant Vehicles\"). Many of the original \"art cars\" that once roamed the playa freely can no longer get licensed by the Black Rock DMV. Art Car Camp celebrates these street legal, permanently altered \"daily drivers\".  Come and see the origin point of Art Cars at Black Rock City!",
        "location": {
            "string": "5:30 & C",
            "frontage": "5:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.77828367843735,
            "gps_longitude": -119.21268806260628
        },
        "location_string": "5:30 & C"
    },
    {
        "uid": "a1Xd0000001IW4kEAG",
        "year": 2016,
        "name": "F.A.R.T. Kamp",
        "url": "https://www.facebook.com/groups/FlatulenceAmplificationResearchTeam/",
        "contact_email": "odgreen@gmail.com",
        "hometown": "Sacramento",
        "description": "Flatulence Amplification Research Team (F.A.R.T.) Kamp provides hugs, a shaded place to sit and rest your feet, mentoring the 10 principles, interactive workshops for \"Hug like a greeter and other hugs\",  \"When to fart?\" Community awareness on farting, \"I fart, help me!\", Group therapy, \"Let one rip\", basic farting, \"kissing lessons\" learn to kiss like a pro and most nights will be improve/short subjects.  Fart into a megaphone if the timing is right, listen to FART radio at 107.3, or stop by and learn to tie a shemagh!",
        "location": {
            "string": "5:30 & H",
            "frontage": "5:30",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.775435767983616,
            "gps_longitude": -119.21485895427396
        },
        "location_string": "5:30 & H"
    },
    {
        "uid": "a1Xd0000001IRLFEA4",
        "year": 2016,
        "name": "The Capsule",
        "contact_email": "nevin.freeman@gmail.com",
        "hometown": "Oakland",
        "description": "Come by The Capsule to record a video message to your future self! You record the message on the playa, and we email it to you 6 months later.",
        "location": {
            "string": "6:00 & E",
            "frontage": "6:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77884267712845,
            "gps_longitude": -119.21647957055906
        },
        "location_string": "6:00 & E"
    },
    {
        "uid": "a1Xd0000001IM7KEAW",
        "year": 2016,
        "name": "Fuego's Karaoke Top Shelf Bar",
        "contact_email": "dean@deanhanley.net",
        "hometown": "Berkeley, CA",
        "description": "KARAOKE, OPEN MIC, TOP SHELF BAR, ORGANIC SNOW CONES! Camp Fuego invites 2016 Renaissance travelers into a free-thinking and personally expressive environment of striking art, prolific libations, songs of the heart and bold human acrobatics.  Fuego, a life-sized flaming stretched barbed wire horse, halts would-be passers by with her prancing form and fire-blazing eyes and mane. Top shelf drinks, Italian sodas and organic snow cones pour at our very danceable bar. Beautiful voices crone karaoke from the stage with 4 open mics.  Bodies gyrate with DJ NIKO from Verbier, Switzerland, and display perfect human form on the 24/7 slack line.  Minds, ages and cultures meld in the air-conditioned hookah lounge. Prizes are awarded for special performances on the Fuego Stage.",
        "location": {
            "string": "6:00 Public Plaza @ 3:15",
            "frontage": "6:00 Public Plaza",
            "intersection": "3:15",
            "intersection_type": "@",
            "gps_latitude": 40.792352979352394,
            "gps_longitude": -119.21499728426735
        },
        "location_string": "6:00 Public Plaza @ 3:15"
    },
    {
        "uid": "a1Xd0000001IM54EAG",
        "year": 2016,
        "name": "Xanadu",
        "hometown": "San Francisco",
        "description": "Welcome to Calico. Gateway to the Hualapai.",
        "location": {
            "string": "6:30 & D",
            "frontage": "6:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.781384734418374,
            "gps_longitude": -119.21797071745584
        },
        "location_string": "6:30 & D"
    },
    {
        "uid": "a1Xd0000001IR4QEAW",
        "year": 2016,
        "name": "Zen as Fuck",
        "contact_email": "enjoyjars@gmail.com",
        "hometown": "Fresno",
        "description": "Zen as Fuck - A shady place in your mind. An important step on your path to enlightenment is to stop by, relax and give your face an ego melting Dunkaroo. You'll leave wondering, \"Who am I?\"",
        "location": {
            "string": "6:00 & G",
            "frontage": "6:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.77791248567272,
            "gps_longitude": -119.2177076684539
        },
        "location_string": "6:00 & G"
    },
    {
        "uid": "a1Xd0000001IGUhEAO",
        "year": 2016,
        "name": "Tarwater",
        "url": "http://www.camptarwater.com",
        "contact_email": "retawrat@comcast.net",
        "hometown": "santa rosa",
        "description": "Tarwater welcomes you with Lady S's Boutique, Recycled Bowling, the Corn Hole, Ladder Toss and the Throwing Specific Things game.  Come by for a game and to write a poem, draw a sketch or an pen an essay about The Need to Believe. Science Fiction books will be given away during the middle of the week.  You can ask the author to sign one, if you want.",
        "location": {
            "string": "6:00 Public Plaza @ 4:45",
            "frontage": "6:00 Public Plaza",
            "intersection": "4:45",
            "intersection_type": "@",
            "gps_latitude": 40.7926059371871,
            "gps_longitude": -119.21508705089784
        },
        "location_string": "6:00 Public Plaza @ 4:45"
    },
    {
        "uid": "a1Xd0000001IP2lEAG",
        "year": 2016,
        "name": "LAFer Camp",
        "url": "https://www.facebook.com/groups/388666604579319/",
        "contact_email": "jess.ca.moore@gmail.com",
        "hometown": "Sacramento, Chicago, Lake Tahoe, Los Angeles, Buffalo, Yellowknife, New York City, Salt Lake City, Los Gatos",
        "description": "Show us your lazy ass!  We, the lazy ass fuckers do hereby permit you to be lazy on the playa.  Come, relax with us; work is not allowed here!  Enjoy our larger than life board games, massage tables and moop fishing all in the name of laziness.   Duck into the chill dome for some neon delight at night, and continue the lazy fun until morning.  Do nothing here! We don’t judge!",
        "location": {
            "string": "6:00 & H",
            "frontage": "6:00",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.777447385062814,
            "gps_longitude": -119.21832170450382
        },
        "location_string": "6:00 & H"
    },
    {
        "uid": "a1Xd0000001IVRDEA4",
        "year": 2016,
        "name": "Banya Camp",
        "hometown": "Toronto",
        "description": "Explore the purifying and bonding experience of a traditional Russian sauna: dry and steam heat with birch twig lashings",
        "location": {
            "string": "6:00 Public Plaza @ 8:00",
            "frontage": "6:00 Public Plaza",
            "intersection": "8:00",
            "intersection_type": "@",
            "gps_latitude": 40.79289233229075,
            "gps_longitude": -119.2145216911226
        },
        "location_string": "6:00 Public Plaza @ 8:00"
    },
    {
        "uid": "a1Xd0000001IOwIEAW",
        "year": 2016,
        "name": "Tortoise Town",
        "contact_email": "afyregirl-3@yahoo.com",
        "hometown": "san francisco",
        "description": "TortoiseTown is an International Village composed of people of all races, ages, and lifestyles.",
        "location": {
            "string": "6:30 & C",
            "frontage": "6:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.781713639088856,
            "gps_longitude": -119.21721859233622
        },
        "location_string": "6:30 & C"
    },
    {
        "uid": "a1Xd0000001IWFdEAO",
        "year": 2016,
        "name": "Blue Lotus",
        "hometown": "San Jose, CA",
        "location": {
            "string": "6:30 & C",
            "frontage": "6:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.781713639088856,
            "gps_longitude": -119.21721859233622
        },
        "location_string": "6:30 & C"
    },
    {
        "uid": "a1Xd0000001IUeyEAG",
        "year": 2016,
        "name": "Silicon Village",
        "url": "http://www.siliconvillageburners.org",
        "contact_email": "mayor@siliconvillageburners.org",
        "hometown": "San Jose",
        "description": "Visit Silicon Village for a mind-expanding experience! Enter through the flashing Stargate, dance, drink, and be entertained in our lavishly decorated Bedouin bar that provides shelter day and night. Watch or join in fire performances, have your fortune read, attend workshops, play games, get airbrush tattoos, fresh-baked cookies and spankings, stay hydrated and refreshed, and be inspired by our light and music art installation controlled entirely by your mind! Gaze in awe at our elaborate art cars, and catch a ride across the Playa. Listen to music, and sweat it out in our authentic Finnish Sauna, transported all the way from Europe for your health and well-being. We are looking forward to seeing you on Playa!",
        "location": {
            "string": "6:30 & E",
            "frontage": "6:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78105582486477,
            "gps_longitude": -119.21872283512668
        },
        "location_string": "6:30 & E"
    },
    {
        "uid": "a1Xd0000001IUmEEAW",
        "year": 2016,
        "name": "NO Name",
        "hometown": "We have no hometown.  Campmates come from several states and Canada",
        "description": "NO NAME plays an eclectic collection of rock, pop, soul, disco, and funk music from the 1950's to current. We play everything from ABBA to ZZTop.",
        "location": {
            "string": "6:30 & H",
            "frontage": "6:30",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.780069066906286,
            "gps_longitude": -119.22097914344731
        },
        "location_string": "6:30 & H"
    },
    {
        "uid": "a1Xd0000001IWlHEAW",
        "year": 2016,
        "name": "Sparkle Pop Kittens",
        "contact_email": "tyfu@me.com",
        "hometown": "Portland",
        "description": "A curious camp of galactic Kittens as well as base camp of the giant fallen robot, Mechan 9.  Meow!",
        "location": {
            "string": "6:30 & Rod's Road",
            "frontage": "6:30",
            "intersection": "Rod's Road",
            "intersection_type": "&",
            "gps_latitude": 40.77973833737035,
            "gps_longitude": -119.21628852611926
        },
        "location_string": "6:30 & Rod's Road"
    },
    {
        "uid": "a1Xd0000001IBuDEAW",
        "year": 2016,
        "name": "Time Camp",
        "hometown": "Mendocino",
        "description": "Tick... Tock.. Tick.. Tock...\r\nI'm late. I'm late! for an very important date.",
        "location": {
            "string": "D & 5:45",
            "frontage": "D",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.77844010782815,
            "gps_longitude": -119.21455786933802
        },
        "location_string": "D & 5:45"
    },
    {
        "uid": "a1Xd0000001IXMNEA4",
        "year": 2016,
        "name": "Storytelling Camp",
        "hometown": "Santa Clara",
        "description": "Be part of the enchantment at Storytelling Camp, where gatherers will be led in hearing legend and myth, true hard-to-believe tales and other, and perhaps burners will be inspired to share their own amazing stories, myth or true, playa stories or default world stories.  There may be spontaneous drumming, song, dance or flute or poetry and more, and above all, there will be soul-stirring unforgettable magic!",
        "location": {
            "string": "D & 5:45",
            "frontage": "D",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.77844010782815,
            "gps_longitude": -119.21455786933802
        },
        "location_string": "D & 5:45"
    },
    {
        "uid": "a1Xd0000001IRJYEA4",
        "year": 2016,
        "name": "The Space Whale Camp",
        "url": "http://www.thespacewhale.com",
        "contact_email": "info@thespacewhale.com",
        "hometown": "Reno",
        "description": "The Pier Group is best know for their art at Burning Man including the eponymous Pier in 2011, Pier 2 in 2012 and their monumental dedication to relationships, family and love, Embrace in 2014. The Space Whale is an environmental statement, a dedication to nature and science. A testament to the urgent need to preserve our environment. \r\nCome visit us where we rest, recharge and play after what we hope to be a pretty incredible build.",
        "location": {
            "string": "D & 6:15",
            "frontage": "D",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.780290026048306,
            "gps_longitude": -119.21700375742115
        },
        "location_string": "D & 6:15"
    },
    {
        "uid": "a1Xd0000001ILBGEA4",
        "year": 2016,
        "name": "Jankytown",
        "contact_email": "mtgordy@yahoo.com",
        "hometown": "Reno",
        "description": "Jankytown is an artists village consisting of Cirque du Cliche, Samba Stilt Circus, Ministry of Flow Fire Performers, and Fou Fou Ha Clowns.  Live music, performance and circus arts at camp an on our 35 foot mobile stage art car, the \"Jank\"",
        "location": {
            "string": "D & 6:15",
            "frontage": "D",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.780290026048306,
            "gps_longitude": -119.21700375742115
        },
        "location_string": "D & 6:15"
    },
    {
        "uid": "a1Xd0000001IXe1EAG",
        "year": 2016,
        "name": "Slippery Tentacle",
        "contact_email": "peter@peterhazel.com",
        "hometown": "Verdi",
        "description": "An art support camp for Peter Hazels' sculpture \"Octavius\":  a group of exhausted artists with nothing to offer but a welcome hug and an amazing sea creature sprawling on The Playa. Please stop by with smiles and sandwiches in hand, we'd love to say hi.",
        "location": {
            "string": "C & 5:45",
            "frontage": "C",
            "intersection": "5:45",
            "intersection_type": "&"
        },
        "location_string": "C & 5:45"
    },
    {
        "uid": "a1Xd0000001IXEJEA4",
        "year": 2016,
        "name": "IDEATE",
        "url": "http://ideate.org",
        "contact_email": "info@ideate.org",
        "hometown": "San Francisco",
        "description": "1.  Ideas to Reality & Burning Man to The World\r\n2.  IDEATE.org",
        "location": {
            "string": "E & 6:15",
            "frontage": "E",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77988938361873,
            "gps_longitude": -119.21769250845776
        },
        "location_string": "E & 6:15"
    },
    {
        "uid": "a1Xd0000001IAzDEAW",
        "year": 2016,
        "name": "Rogue Nation Village",
        "url": "https://www.facebook.com/RogueNationVilliage/",
        "contact_email": "bpcmhf@msn.com",
        "hometown": "Seattle",
        "description": "Rogue Nation Village is home to a group of camps from the Pacific Northwest: Kreme Burners, SeaWEED, and more.\r\n\r\nSeattle's village for large playa art, French desserts Crème Brulée, and big chill space known as \"Comfort\".",
        "location": {
            "string": "G & 6:15",
            "frontage": "G",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.21907490302245
        },
        "location_string": "G & 6:15"
    },
    {
        "uid": "a1Xd0000001IXQKEA4",
        "year": 2016,
        "name": "The Dusty Daycare",
        "contact_email": "joyce.jamiel@gmail.com",
        "hometown": "Orlando",
        "description": "The Dusty Daycare is a place to play or take a time-out from the Playa. Interact in a larger-than-life-size Daycare setting for adults.",
        "location": {
            "string": "G & 5:45",
            "frontage": "G",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.77687746108339,
            "gps_longitude": -119.21614874066034
        },
        "location_string": "G & 5:45"
    },
    {
        "uid": "a1Xd0000001IVsJEAW",
        "year": 2016,
        "name": "Platybus & The Band",
        "hometown": "Oakland",
        "description": "LIVE MUSIC. Come jam into the sunset on the roof of a '93 School Bus. Electric guitars, banjos, bass, full drum kit. You want it, we got it. Black Rock n Roll.",
        "location": {
            "string": "G & 6:15",
            "frontage": "G",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.21907490302245
        },
        "location_string": "G & 6:15"
    },
    {
        "uid": "a1Xd0000001ING2EAO",
        "year": 2016,
        "name": "Camp Shit Ain't Right",
        "description": "Camp Shit Ain't Right.  Because seriously; this shit ain't right.",
        "location": {
            "string": "H & 5:45",
            "frontage": "H",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.776355654907675,
            "gps_longitude": -119.21667735883563
        },
        "location_string": "H & 5:45"
    },
    {
        "uid": "a1Xd0000001IWI8EAO",
        "year": 2016,
        "name": "Short Bus XOXO",
        "url": "http://xoxovillage.com",
        "hometown": "San Diego",
        "description": "XOXO Village is truly about hugs and kisses. Year-round community is what we live for and joining our camp is a lifelong commitment. This year the village brings together several amazing camps including Shortbus, The Condo, Rawrtastic, and Welcome Home. We will be hosting a variety of beautiful and exciting events this year including Astrology Classes, Community Meals, Healing Workshops, Spiritual Dance Parties, Spa Days, and more!",
        "location": {
            "string": "H & 5:45",
            "frontage": "H",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.776355654907675,
            "gps_longitude": -119.21667735883563
        },
        "location_string": "H & 5:45"
    },
    {
        "uid": "a1Xd0000001IWZaEAO",
        "year": 2016,
        "name": "Welcome Home",
        "url": "http://infiniteexperience.com/",
        "contact_email": "laura@infiniteexperience.com",
        "hometown": "London",
        "description": "Welcome Home is an immersive theatre experience exploring a shift in awareness about our connection to each other and the earth.",
        "location": {
            "string": "H & 5:45",
            "frontage": "H",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.776355654907675,
            "gps_longitude": -119.21667735883563
        },
        "location_string": "H & 5:45"
    },
    {
        "uid": "a1Xd0000001IRJnEAO",
        "year": 2016,
        "name": "Jipangu",
        "contact_email": "jipangu@macklow.com",
        "hometown": "Las Vegas",
        "description": "Jipangu and Bijou Boutique will be serving the best Japanese green tea on the playa from 10 to 2 daily in our relaxing and calm tea house. Don't like green tea? How about cold sake?   Or come by and visit our Bijou Boutique; pick out a piece of jewelry, or sit down with one of our instructors and make your own one-of-a-kind piece!",
        "location": {
            "string": "G & 5:45",
            "frontage": "G",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.77687746108339,
            "gps_longitude": -119.21614874066034
        },
        "location_string": "G & 5:45"
    },
    {
        "uid": "a1Xd0000001IWT1EAO",
        "year": 2016,
        "name": "Anonymous Village",
        "url": "http://www.burnanon.org/",
        "contact_email": "postmaster@burnanon.org",
        "hometown": "Akron",
        "description": "Anonymous Village hosts \"Any A\" meetings, where AA, NA, OA, SLAA, and any other fellowships can support one anothers recovery while at Burning Man, as well as meetings that are fellowship specific.  Any citizen of Black Rock City who wishes to camp in a clean and sober village is welcome and may contact us at http://www.burnanon.org/",
        "location": {
            "string": "G & 5:45",
            "frontage": "G",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.77687746108339,
            "gps_longitude": -119.21614874066034
        },
        "location_string": "G & 5:45"
    },
    {
        "uid": "a1Xd0000001IWU9EAO",
        "year": 2016,
        "name": "Scar Bar",
        "contact_email": "melankenny@hotmail.com",
        "hometown": "Los Angeles",
        "description": "You provide the scars, we provide the drinks.",
        "location": {
            "string": "G & 6:15",
            "frontage": "G",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.21907490302245
        },
        "location_string": "G & 6:15"
    },
    {
        "uid": "a1Xd0000001IXMSEA4",
        "year": 2016,
        "name": "Fire Village",
        "contact_email": "husted49@gmail.com",
        "description": "Fire village is a place where people can come flow and learn from some of the best and most passionate fire artists in the world, all in one place! We will host numerous classes from fire flow to arial and yoga throughout the day. We have plenty of hang out space and a bar. Getting some conclaves and other flow artists together in one big space is a great opportunity to collaborate on playa events such as fire parades throughout the city, and deep playa renegade spins. Our mission is to really light up each night and bring something special to the playa for everyone to enjoy. We have 3 Conclave Camps merging together to create this environment; Hellfire Society(Los Angles, CA), PyroTex (Houston, TX), Pele's Fire (Hawaii), Incandescence Fire Conclave (Portland, Oregon), MythMaker (Canada), and Camp Hotel Rug (Orange County, CA). We are performers in the Great Circle and made up of concave members and friends.",
        "location": {
            "string": "G & 6:15",
            "frontage": "G",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.21907490302245
        },
        "location_string": "G & 6:15"
    },
    {
        "uid": "a1Xd0000001IXYhEAO",
        "year": 2016,
        "name": "A Transformation Station",
        "hometown": "Boston",
        "description": "A Transformation Station ...\r\n\r\nAn art school, A cultural exchange hub, A place of learning and shaing\r\n\r\nWe welcome Mermaids & Sailors, Fire Spinners and other Circus Freeks ... & also the normies that love them",
        "location": {
            "string": "G & 6:15",
            "frontage": "G",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.21907490302245
        },
        "location_string": "G & 6:15"
    },
    {
        "uid": "a1Xd0000001IXFHEA4",
        "year": 2016,
        "name": "Theme Camp Theme Camp",
        "hometown": "Chicago/Reno",
        "description": "A quirky bar with refreshingly tasty drinks and different themes everyday!",
        "location": {
            "string": "H & 5:45",
            "frontage": "H",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.776355654907675,
            "gps_longitude": -119.21667735883563
        },
        "location_string": "H & 5:45"
    },
    {
        "uid": "a1Xd0000001IVrVEAW",
        "year": 2016,
        "name": "Black Rock Public Library",
        "url": "http://brplib.org",
        "contact_email": "brplib@gmail.com",
        "hometown": "San Francisco",
        "description": "Come check out a book at the dustiest library in the world, the Black Rock Public Library! Strict one-year checkout with a one-week grace period. This year, add yourself to the Human Card Catalog to share what you know best, or look up someone who can teach you about a topic anywhere on the playa.",
        "location": {
            "string": "I & 5:45",
            "frontage": "I",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775833846319884,
            "gps_longitude": -119.21720596870679
        },
        "location_string": "I & 5:45"
    },
    {
        "uid": "a1Xd0000001IW5sEAG",
        "year": 2016,
        "name": "Button Up!",
        "hometown": "San Francisco",
        "description": "You know those 2-inch, round lapel pins often used for political candidates and such? Ever wanted to make one with your own design? Well we'd love to help you realize that dream!\r\n\r\nButton UP! camp has a couple events every Burn when you can come draw your own design or bring a small image you've printed (must be paper), and stamp it onto a pin.\r\n\r\nWe love having people come by, grab a drink, make a pin and stay for a chat so please put us on your calendar and come for a visit!",
        "location": {
            "string": "I & 5:45",
            "frontage": "I",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775833846319884,
            "gps_longitude": -119.21720596870679
        },
        "location_string": "I & 5:45"
    },
    {
        "uid": "a1Xd0000001IGPDEA4",
        "year": 2016,
        "name": "Witness re-location camp",
        "hometown": "Cayucos",
        "description": "Witness re-location camp (formerly silkscreen camp) You know who we are, you know what we do, don't tell anyone",
        "location": {
            "string": "H & 6:15",
            "frontage": "H",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77869228660995,
            "gps_longitude": -119.21976385884787
        },
        "location_string": "H & 6:15"
    },
    {
        "uid": "a1Xd0000001IWnIEAW",
        "year": 2016,
        "name": "Spoonful of Friends",
        "description": "Spoonful of Friends is like a spoon full of friends: so delicious you'll never want to leave us. We're campers, burners (!), foodies, dancers, explorers and lovers...\r\nAfter a long day strolling the playa, or before a long night dancing your ass off, come and enjoy with us a homemade hearty casserole diner every-night ! You bring the booze and we'll serve the food.",
        "location": {
            "string": "I & 5:45",
            "frontage": "I",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775833846319884,
            "gps_longitude": -119.21720596870679
        },
        "location_string": "I & 5:45"
    },
    {
        "uid": "a1Xd0000001IVHgEAO",
        "year": 2016,
        "name": "Second Star",
        "contact_email": "secondstarcamp@gmail.com",
        "hometown": "Brooklyn / London",
        "description": "Second Star to the right, and straight on 'til morning! Escape to Neverland and join us in our funk oasis for music, drinks, and good vibes. Lose your shadow at the Lost Boys Bangarang, or dance it out at our Second Annual Second Star FUNKtion. \r\n\r\nRemember - \"all you need is faith, trust, and a little bit of playa dust!\"",
        "location": {
            "string": "I & 6:15",
            "frontage": "I",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77829184442306,
            "gps_longitude": -119.22045280636702
        },
        "location_string": "I & 6:15"
    },
    {
        "uid": "a1Xd0000001ISNsEAO",
        "year": 2016,
        "name": "Leopard Martini Lounge",
        "url": "http://www.upwarp.com/lml/index.htm",
        "hometown": "Palo Alto",
        "description": "Leopard Martini Lounge, Palo Alto, CA, US",
        "location": {
            "string": "H & 6:15",
            "frontage": "H",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77869228660995,
            "gps_longitude": -119.21976385884787
        },
        "location_string": "H & 6:15"
    },
    {
        "uid": "a1Xd0000001IVAaEAO",
        "year": 2016,
        "name": "Disciples of the Dust",
        "contact_email": "tangenjeff@gmail.com",
        "hometown": "Seattle",
        "description": "We are an art support camp.  Members have been bring art to BRC for the past four years.  Disciples of the Dust have members in Seattle, Arlington and Port Townsend Washington.",
        "location": {
            "string": "I & 5:45",
            "frontage": "I",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775833846319884,
            "gps_longitude": -119.21720596870679
        },
        "location_string": "I & 5:45"
    },
    {
        "uid": "a1Xd0000001IJuzEAG",
        "year": 2016,
        "name": "Tin Foil Hat",
        "hometown": "Las Vegas",
        "description": "EVERYONE MUST BE SAVED! COME make your own way to TIN FOIL HAT!  You think its a fashion statement but it is soooo much more. Share your Talents in bending Aluminum Foils to your fantasy, and share them with the world!",
        "location": {
            "string": "J & 5:45",
            "frontage": "J",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775312035320134,
            "gps_longitude": -119.21773457027408
        },
        "location_string": "J & 5:45"
    },
    {
        "uid": "a1Xd0000001IMtyEAG",
        "year": 2016,
        "name": "Camp Ridiculicious",
        "hometown": "Fremantle",
        "description": "Let's meet & chat about dinosaurs, da vinci, death & door knobs @ Camp Ridiculicious",
        "location": {
            "string": "I & 5:45",
            "frontage": "I",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775833846319884,
            "gps_longitude": -119.21720596870679
        },
        "location_string": "I & 5:45"
    },
    {
        "uid": "a1Xd0000001INpLEAW",
        "year": 2016,
        "name": "You are Healer",
        "contact_email": "oleg8888@gmail.com",
        "hometown": "San Francisco",
        "description": "We offer to the playa our 40x40ft healing sanctuary. A quiet place to relax, receiving healing, body work, aromatherapy, ceremony, an occasional workshop, yoga and other mystically centered healing modalities. Come to rest and get out of the hot sun to refresh your body and your mind.",
        "location": {
            "string": "I & 6:15",
            "frontage": "I",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77829184442306,
            "gps_longitude": -119.22045280636702
        },
        "location_string": "I & 6:15"
    },
    {
        "uid": "a1Xd0000001IV9XEAW",
        "year": 2016,
        "name": "Face Of Venus",
        "contact_email": "shellybrush@att.net",
        "hometown": "Richmond",
        "description": "Daily 9:00 Am yoga. Henna. Come eat coconut rice and get layed",
        "location": {
            "string": "H & 6:15",
            "frontage": "H",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77869228660995,
            "gps_longitude": -119.21976385884787
        },
        "location_string": "H & 6:15"
    },
    {
        "uid": "a1Xd0000001IR5sEAG",
        "year": 2016,
        "name": "Floatie Paradiso",
        "hometown": "Walnut Creek",
        "description": "Visit our dry blue floatie oasis. Take pictures & sign our Year Book. On Tuesday, Wednesday at 9pm. join us for LED hula hoop/staff/ other LED toys Jam.",
        "location": {
            "string": "I & 5:45",
            "frontage": "I",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775833846319884,
            "gps_longitude": -119.21720596870679
        },
        "location_string": "I & 5:45"
    },
    {
        "uid": "a1Xd0000001IV8yEAG",
        "year": 2016,
        "name": "IMAGINEnation",
        "url": "http://campimaginenation.com",
        "contact_email": "campimaginenation@gmail.com",
        "hometown": "NYC",
        "description": "IMAGINEnation\r\nDedicated to the Power of Dreaming and Radical Honesty.",
        "location": {
            "string": "I & 6:15",
            "frontage": "I",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77829184442306,
            "gps_longitude": -119.22045280636702
        },
        "location_string": "I & 6:15"
    },
    {
        "uid": "a1Xd0000001IWSSEA4",
        "year": 2016,
        "name": "Bubble Camp",
        "contact_email": "quenton.cook@gmail.com",
        "hometown": "San Francisco",
        "description": "Bubbles, bubbles everywhere and drops to drink for all. Dispensing thai iced tea and cold pressed coffee for all you parched playa peeps.",
        "location": {
            "string": "I & 6:15",
            "frontage": "I",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77829184442306,
            "gps_longitude": -119.22045280636702
        },
        "location_string": "I & 6:15"
    },
    {
        "uid": "a1Xd0000001IV9cEAG",
        "year": 2016,
        "name": "The Last Word",
        "hometown": "SF Bay Area",
        "description": "Come in to play word games, have your fortune told, play Vetruvian nerf ball, or swap some lingerie for something new to you.",
        "location": {
            "string": "H & 6:15",
            "frontage": "H",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77869228660995,
            "gps_longitude": -119.21976385884787
        },
        "location_string": "H & 6:15"
    },
    {
        "uid": "a1Xd0000001IXf9EAG",
        "year": 2016,
        "name": "Black Rock Spatial Delivery",
        "url": "http://www.virginletters.com/",
        "hometown": "PortLand",
        "description": "Black Rock Spatial Delivery: \"WE TAKE STUFF PLACES\" We host the Virgin Letters Project. \r\nhttp://www.virginletters.com",
        "location": {
            "string": "I & 5:45",
            "frontage": "I",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775833846319884,
            "gps_longitude": -119.21720596870679
        },
        "location_string": "I & 5:45"
    },
    {
        "uid": "a1Xd0000001IOq2EAG",
        "year": 2016,
        "name": "Gerlach-Empire Bus Stop & Tickets",
        "url": "http://burningman.org/event/volunteering/teams/bus/",
        "contact_email": "humanjones@burningman.com",
        "hometown": "Black Rock City",
        "description": "Dusty Black Rock Denizens! Help your fellow participants get to town and back on the fun-loving shuttle bus service. Our crew is responsible for selling tickets, answering questions,  providing local info and chatting up drivers on the radio over the course of multiple, several hour, mid-day shifts.\r\n\r\nThe Empire-Gerlach Bus Ticket Office is located on the Center Camp ring road, and offers plenty of people watching, not to mention shelter and shade. We're looking for people who can work during the day for a responsible job that's also FUN. \r\n\r\nIf you're interested, fill out the Volunteer Questionnaire and check the box Bus Depot.",
        "location": {
            "string": "Rod's Road & D",
            "frontage": "Rod's Road",
            "intersection": "D",
            "intersection_type": "&"
        },
        "location_string": "Rod's Road & D"
    },
    {
        "uid": "a1Xd0000001INDMEA4",
        "year": 2016,
        "name": "Lamplighter Village",
        "url": "http://burningman.org/event/volunteering/teams/lamplighters/",
        "location": {
            "string": "Rod's Road @ 5:00",
            "frontage": "Rod's Road",
            "intersection": "5:00",
            "intersection_type": "@",
            "gps_latitude": 40.77878166352722,
            "gps_longitude": -119.21464059322732
        },
        "location_string": "Rod's Road @ 5:00"
    },
    {
        "uid": "a1Xd0000001IXfTEAW",
        "year": 2016,
        "name": "No me know. For reason.",
        "url": "http://www.dustyvisions.org/current-projects/no-me-know-for-reason/",
        "contact_email": "lucy@dustyvisions.org",
        "hometown": "Portland",
        "description": "No me know. For reason.\r\nArt support camp for the FLOCONS Project.",
        "location": {
            "string": "Rod's Road & C",
            "frontage": "Rod's Road",
            "intersection": "C",
            "intersection_type": "&"
        },
        "location_string": "Rod's Road & C"
    },
    {
        "uid": "a1Xd0000001ISeFEAW",
        "year": 2016,
        "name": "Spice n Vice",
        "url": "https://www.facebook.com/SpiceNVice",
        "contact_email": "spicenvice@gmail.com",
        "hometown": "Shanghai/Bahrain/Norfolk VA",
        "description": "Spice N Vice - offers Bedouin hospitality every day from 12-4 p.m. Visit us for some hot or cold chai tea. Talk to one of our travel sages for stories about life abroad and travel advice. New in 2016, Climb our viewing platform for magnificent vistas of BRC.",
        "location": {
            "string": "J & 5:45",
            "frontage": "J",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775312035320134,
            "gps_longitude": -119.21773457027408
        },
        "location_string": "J & 5:45"
    },
    {
        "uid": "a1Xd0000001IXcFEAW",
        "year": 2016,
        "name": "Camp Cut! Cut!",
        "hometown": "Los Angeles",
        "description": "An interactive camp where you can participate in our graffiti wall,  a wall that changes with new art each day by you!",
        "location": {
            "string": "J & 5:45",
            "frontage": "J",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775312035320134,
            "gps_longitude": -119.21773457027408
        },
        "location_string": "J & 5:45"
    },
    {
        "uid": "a1Xd0000001IJ56EAG",
        "year": 2016,
        "name": "Leonardo DaVinci",
        "url": "sparlingstudio.com",
        "contact_email": "artman@madriver.com",
        "hometown": "New Haven",
        "description": "\"The DaVinci Model for Creativity\"  A new teaching model based on re-marriage of Arts and Sciences as a for-profit embedded degree;  intended to get students out of college debt free.",
        "location": {
            "string": "Rod's Road & C",
            "frontage": "Rod's Road",
            "intersection": "C",
            "intersection_type": "&"
        },
        "location_string": "Rod's Road & C"
    },
    {
        "uid": "a1Xd0000001IPmlEAG",
        "year": 2016,
        "name": "Circus Boot Camp",
        "contact_email": "raymay2k@gmail.com",
        "hometown": "San Francisco Bay Area",
        "description": "Come earn your clown nose by participating at Circus Boot Camp!  We'll teach you to juggle, unicycle, hoop, slack line, trapeze, crack a whip and other circus-inspired arts",
        "location": {
            "string": "4:30 & B",
            "frontage": "4:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.7776859352447,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & B"
    },
    {
        "uid": "a1Xd0000001IX0vEAG",
        "year": 2016,
        "name": "Clusterf*ck United",
        "url": "http://clusterf.ckunited.org/",
        "contact_email": "clusterfuckers2016@googlegroups.com",
        "hometown": "San Francisco",
        "description": "Stranded in the Playa, you find an oasis, a court with decorative banners advertising for knights to come and test their courage within a jousting circle! Early morning refreshments will entice the night owls who need a nightcap before returning to their homesteads at sunrise. If you are looking for a more aesthetic experience, come to our art gala, where artists are welcome to come throughout the week to express themselves and show off their artistic talent.",
        "location": {
            "string": "4:00 & B",
            "frontage": "4:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.77798282151022,
            "gps_longitude": -119.20352162092674
        },
        "location_string": "4:00 & B"
    },
    {
        "uid": "a1Xd0000001IX0lEAG",
        "year": 2016,
        "name": "StarBarf",
        "contact_email": "lindleymease@gmail.com",
        "hometown": "San Francisco",
        "description": "Across the space/time continuum, through galactic upheaval and hiccups, we have evolved to this chaotic existence. Colliding and reforging, StarBarf weaves workshops, discussions, and movement into our shared vision of community. We strive to connect with beautiful and messy humanity; the humbling scales in which we exist; and the unbounded possibilities that we, as StarBarf, realize... You are StarBarf, too.",
        "location": {
            "string": "4:00 & C",
            "frontage": "4:00",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.777347559648916,
            "gps_longitude": -119.20329686823338
        },
        "location_string": "4:00 & C"
    },
    {
        "uid": "a1Xd0000001IXblEAG",
        "year": 2016,
        "name": "House of Maslow",
        "contact_email": "beccacamp@gmail.com",
        "hometown": "San Francisco",
        "description": "...because you have NEEDS!\r\n\r\nCome to House of Maslow and work your way through your own hierarchy: Physiological, Safety, Love/Belonging, Esteem, and Self-Actualization.",
        "location": {
            "string": "4:30 & A",
            "frontage": "4:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.77834360050925,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & A"
    },
    {
        "uid": "a1Xd0000001IWoaEAG",
        "year": 2016,
        "name": "Brand-ur-Ass",
        "url": "https://www.facebook.com/BrandURAss",
        "contact_email": "misscyndilou@gmail.com",
        "hometown": "Reno",
        "description": "Brand-UR-Ass 'N More will stimulate your entire being, from your mind to your ass. Bare your butt at the hitchin post and get a temporary brand. Bathe in gong vibrations, do some cock ropin', enjoy tunes, belly up to the saloon, enjoy the giving tree and hitch a ride on our vehicles. Y'all come N play!",
        "location": {
            "string": "4:00 & B",
            "frontage": "4:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.77798282151022,
            "gps_longitude": -119.20352162092674
        },
        "location_string": "4:00 & B"
    },
    {
        "uid": "a1Xd0000001IV1lEAG",
        "year": 2016,
        "name": "Wetspot",
        "hometown": "Reno",
        "description": "The WetSpot Bar & Faceplant Lounge: Welcome to the best place on the playa to enjoy a craft brew or SNG while relaxing in our unique lounge. WetSpot is about making new friends in an open to all setting while engaging in musings around one of our favorite pastimes: consuming libations. Our crew includes homebrewers and non-homebrewers alike and provides an inviting atmosphere to sample one of our concoctions as well as just having fun.",
        "location": {
            "string": "4:00 & D",
            "frontage": "4:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.776712297351594,
            "gps_longitude": -119.20307211983851
        },
        "location_string": "4:00 & D"
    },
    {
        "uid": "a1Xd0000001IO9mEAG",
        "year": 2016,
        "name": "Darwin Fish Tank",
        "url": "https://www.facebook.com/DarwinFishTank",
        "contact_email": "darwinfishtank@gmail.com",
        "hometown": "San Francisco/Los Angeles/Denver/Vancouver/London/NYC",
        "description": "Dive into the Darwin Fish Tank! When you are ready to grow a pair (of legs that is!) climb out of the primordial ooze and beat the heat with our misting system for a genuine adventure in the belly of the beast. Come for the flowing beats, stay and chill within the waves with some liquid joy.",
        "location": {
            "string": "4:30 & B",
            "frontage": "4:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.7776859352447,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & B"
    },
    {
        "uid": "a1Xd0000001IV7jEAG",
        "year": 2016,
        "name": "Unnecessarily High Five",
        "url": "http://www.unnecessarilyhighfive.com/",
        "contact_email": "uhighfive@gmail.com",
        "hometown": "Alameda / Puerto Rico",
        "description": "The Unnecessarily High Five is the ultimate high-five experience! This unique interactive art piece encourages burners of all ages to try and give the highest five that they can. Built from wood, conduit and mannequin parts, hands dangle at increasing heights and taunt burners as they run, jump, use silts and other constructs, stand on each other shoulders, throw each other, and even build human pyramids to try and reach the highest five they can. We also provide various assistive devices that will totally hinder you.  After more than 100,000 attempts, no one has ever hit the highest five unassisted. We're waiting for you.",
        "location": {
            "string": "4:00 & F",
            "frontage": "4:00",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.77544177144894,
            "gps_longitude": -119.20262263594348
        },
        "location_string": "4:00 & F"
    },
    {
        "uid": "a1Xd0000001INBpEAO",
        "year": 2016,
        "name": "Red Bar",
        "url": "https://www.facebook.com/RedBar2014",
        "hometown": "Boise",
        "description": "Red Bar (formerly Cornhole Bar, Farmopolis, ...), an oasis popping out of the desert, red and glowing at night, invites weary travelers to float through our halls to find the inner sanctum of libations and live music at the piano. Sit down and play, or listen and sing. Bring your instruments and see what develops. We are always open and will have daily drink specials plus games and entertainment. You will also find nooks to create art and walls to hang it on.  Every hour is happy hour at Red Bar!",
        "location": {
            "string": "4:30 & E",
            "frontage": "4:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77571293945105,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & E"
    },
    {
        "uid": "a1Xd0000001IWoBEAW",
        "year": 2016,
        "name": "HamsterCamp!",
        "url": "http://www.hamstercamp.com",
        "contact_email": "sparklespazhamstercamp@gmail.com",
        "hometown": "Everywhere",
        "description": "HamsterCamp! The eagles of the playa. Celebrating, birthdays, love letters, pranks, poop jokes, fart jokes, electric shocks, tea, coffee, games, the universe and so much more!!!",
        "location": {
            "string": "4:00 & G",
            "frontage": "4:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.77480650784362,
            "gps_longitude": -119.20239790044295
        },
        "location_string": "4:00 & G"
    },
    {
        "uid": "a1Xd0000001IBq1EAG",
        "year": 2016,
        "name": "I Love Elephants",
        "contact_email": "philip@savingganesh.org",
        "hometown": "Bend",
        "description": "We love Elephants and share our passion full time in the default world and live our elephant fantasies on the Playa. Ride our life-like elephant, as we take your picture, or even video you for inclusion in our fun website film! Enjoy jungle beverages like coconut water or beer. Draw elephants, trumpet for elephants and more. Meet our conservation group's director who is equally nuts for elephants. You'll love elephants even more as he shares stories over beverages and snacks. Oh, and we've been told our misting system is best ever on the playa! The misting equipment design is one of a kind!",
        "location": {
            "string": "4:00 & E",
            "frontage": "4:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77607703461826,
            "gps_longitude": -119.20284737574195
        },
        "location_string": "4:00 & E"
    },
    {
        "uid": "a1Xd0000001IXAWEA4",
        "year": 2016,
        "name": "Baconeers",
        "url": "https://www.facebook.com/groups/portapottypigs/",
        "hometown": "Reno",
        "description": "The Baconeers (& Porta Potty Pigs) return again to provide luxury and comfort during your potty visits. Lots of music, parties and libations, too!",
        "location": {
            "string": "4:00 & D",
            "frontage": "4:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.776712297351594,
            "gps_longitude": -119.20307211983851
        },
        "location_string": "4:00 & D"
    },
    {
        "uid": "a1Xd0000001IRElEAO",
        "year": 2016,
        "name": "Pink Spot",
        "hometown": "Phoenix/San Francisco/Park City",
        "description": "Pink Spot\r\n\r\nThe home of The Big Bunny mutant vehicle--come join us for great music, dancing and oodles of Bunny Love.  Slinging tasty drinks and tasty tunes from our hearts to yours since 1995.",
        "location": {
            "string": "4:00 & E",
            "frontage": "4:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77607703461826,
            "gps_longitude": -119.20284737574195
        },
        "location_string": "4:00 & E"
    },
    {
        "uid": "a1Xd0000001ISyUEAW",
        "year": 2016,
        "name": "Camp Safari",
        "url": "https://www.facebook.com/fundcampsafari/",
        "contact_email": "safaribar@formeremployee.com",
        "hometown": "Concord",
        "description": "Camp Safari: Home of the Safari Bar.  Come spin the Safari Wheel for your fate in a shot glass, or just stop by to use our safari games and photo ops.",
        "location": {
            "string": "4:30 & C",
            "frontage": "4:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.77702826998014,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & C"
    },
    {
        "uid": "a1Xd0000001IVkPEAW",
        "year": 2016,
        "name": "Short Stack & Om Skillet",
        "hometown": "San Francisco",
        "description": "Short Stack & Om Skillet bring you a chill park vibe and gourmet grilled cheese in the desert. Join us at 1pm on Tuesday and Thursday for full sandwich service and some groovy tunes. Tuesday afternoon is the Tutu Tuesday dance party!",
        "location": {
            "string": "4:30 & D",
            "frontage": "4:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.776370604715595,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & D"
    },
    {
        "uid": "a1Xd0000001IWUOEA4",
        "year": 2016,
        "name": "Dust Circus",
        "url": "http://dustcircus.org",
        "contact_email": "dustcircus@gmail.com",
        "hometown": "San Francisco Bay area, Sacramento",
        "description": "The Dust Circus - twisted mix of entertainment. Real Magic, Dancing, Mind and Bighting your Movement Lighting, Burn your bad thoughts away Machine...There are overwhelming, dazing and confusing shows.",
        "location": {
            "string": "4:30 & B",
            "frontage": "4:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.7776859352447,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & B"
    },
    {
        "uid": "a1Xd0000001IRJTEA4",
        "year": 2016,
        "name": "Fluid Fortune",
        "contact_email": "kaitfrasier@gmail.com",
        "hometown": "San Diego",
        "description": "This camp is about jet-fuel coffee and questionable clairvoyance. We'll send you off with grounds in your teeth, and a fortune you won't forget.",
        "location": {
            "string": "4:00 & E",
            "frontage": "4:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77607703461826,
            "gps_longitude": -119.20284737574195
        },
        "location_string": "4:00 & E"
    },
    {
        "uid": "a1Xd0000001ICZQEA4",
        "year": 2016,
        "name": "ReNarnia",
        "url": "http://www.renarnia.weebly.com",
        "contact_email": "renarniacamp@gmail.com",
        "hometown": "Edmonton",
        "description": "ReNarnia: Creating Janky Magic through Radical Sustainability. Within this brewing pot of possibility lies a place to ReConvene and ReImagine how we view waste.",
        "location": {
            "string": "4:00 & F",
            "frontage": "4:00",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.77544177144894,
            "gps_longitude": -119.20262263594348
        },
        "location_string": "4:00 & F"
    },
    {
        "uid": "a1Xd0000001IRCBEA4",
        "year": 2016,
        "name": "Hippocampus",
        "hometown": "Seattle and Minneapolis",
        "description": "Hippocampus is the place to make your playa memories stick. Find our mobile cafe as the sun rises over Black Rock City for the best coffee on the playa.",
        "location": {
            "string": "4:30 & I",
            "frontage": "4:30",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.77308227839284,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & I"
    },
    {
        "uid": "a1Xd0000001IOsmEAG",
        "year": 2016,
        "name": "Catification Camp",
        "url": "http://www.catificationcamp.com",
        "hometown": "Phoenix, Los Angeles",
        "description": "Come get cat-ified as we help inspire your creativity and exploration of BRC as a cat. Throughout the week, we will be having cat-themed crafts, meditation, and yoga to bring out your inner kitten. Purr against our human sized scratching post and chase some red dots under our giant disco ball. Communicating in meows is enthusiastically encouraged! It's going to be purrfect.",
        "location": {
            "string": "4:30 & K",
            "frontage": "4:30",
            "intersection": "K",
            "intersection_type": "&",
            "gps_latitude": 40.77176694786373,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & K"
    },
    {
        "uid": "a1Xd0000001IWggEAG",
        "year": 2016,
        "name": "Camp Cul-de-Sac",
        "hometown": "New York City",
        "description": "Est. 1997, Camp Cul-de-Sac provides an open-air cinema with a wide selection of crazy clips plus an video art experience.  Also, we have candy.",
        "location": {
            "string": "4:30 & F",
            "frontage": "4:30",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.77505527418649,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & F"
    },
    {
        "uid": "a1Xd0000001IWVqEAO",
        "year": 2016,
        "name": "Coconauts",
        "contact_email": "coconauts@googlegroups.com",
        "hometown": "San Francisco",
        "description": "An island oasis of scientific discovery.  Enjoy our tiki bar and lounge and learn about the brief history of rum.  Nightly demonstrations of the Large Piña Collider.",
        "location": {
            "string": "4:30 Plaza @ 11:00",
            "frontage": "4:30 Plaza",
            "intersection": "11:00",
            "intersection_type": "@",
            "gps_latitude": 40.77469416427703,
            "gps_longitude": -119.2067263411573
        },
        "location_string": "4:30 Plaza @ 11:00"
    },
    {
        "uid": "a1Xd0000001IFkAEAW",
        "year": 2016,
        "name": "DiscoFish Landing Strip",
        "url": "http://www.discofish.org/",
        "contact_email": "robin@discofish.org",
        "hometown": "Sunnyvale",
        "description": "Stayin' Alive on the Playa!  Come take a ride on the DiscoFish!",
        "location": {
            "string": "4:30 & K",
            "frontage": "4:30",
            "intersection": "K",
            "intersection_type": "&",
            "gps_latitude": 40.77176694786373,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & K"
    },
    {
        "uid": "a1Xd0000001IWKdEAO",
        "year": 2016,
        "name": "Compassion Pit",
        "location": {
            "string": "4:30 & L",
            "frontage": "4:30",
            "intersection": "L",
            "intersection_type": "&",
            "gps_latitude": 40.77110928259918,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & L"
    },
    {
        "uid": "a1Xd0000001IJapEAG",
        "year": 2016,
        "name": "Emergency Services Station 4:30",
        "location": {
            "string": "4:30 & H",
            "frontage": "4:30",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.7737399436574,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & H"
    },
    {
        "uid": "a1Xd0000001IWt6EAG",
        "year": 2016,
        "name": "Sunset Portal",
        "hometown": "San Francisco",
        "description": "Every sunset we welcome our fellow burners to Sunset Portal where we give thanks to the day, and welcome the night with open arms. We love to reflect, connect, and make new friends around our fire pits as we howl at the sun.",
        "location": {
            "string": "4:30 & L",
            "frontage": "4:30",
            "intersection": "L",
            "intersection_type": "&",
            "gps_latitude": 40.77110928259918,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & L"
    },
    {
        "uid": "a1Xd0000001IRptEAG",
        "year": 2016,
        "name": "COHESION",
        "hometown": "Los Angeles",
        "description": "Come by Cohesion for a drink from our bar or a nap in the shade. Get glammed up at the Pussy Pop Lock and Drop it Station or get stuck on our velcro wall. You'll always feel like part of the family at Cohesion.",
        "location": {
            "string": "4:30 Plaza @ 10:00",
            "frontage": "4:30 Plaza",
            "intersection": "10:00",
            "intersection_type": "@",
            "gps_latitude": 40.774568696461436,
            "gps_longitude": -119.20689184218564
        },
        "location_string": "4:30 Plaza @ 10:00"
    },
    {
        "uid": "a1Xd0000001IXPgEAO",
        "year": 2016,
        "name": "Hammock Hangout",
        "url": "http://thehammockhangout.com",
        "contact_email": "hh@thehammockhangout.com",
        "hometown": "San Francisco, LA, Portland OR",
        "description": "The Hammock Hangout is a very large passive solar shade structure with room for 90 hammocks. We have a full bar, a giant chill space and super friendly inhabitants called Space Cats. We karaoke most of the time, provide a cool relaxing retreat from the sun, give people cold drinks, snack people and get them to sing songs. It is a very happy and inviting place.",
        "location": {
            "string": "4:30 & E",
            "frontage": "4:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77571293945105,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & E"
    },
    {
        "uid": "a1Xd0000001IXN1EAO",
        "year": 2016,
        "name": "Camp Do Nothing",
        "contact_email": "dawsonjoe@live.com",
        "hometown": "seattle",
        "description": "360 swing hang 35 feet up by your feet then jump in the foam dome. Voted funnest camp for yards in any direction 4 years running",
        "location": {
            "string": "4:30 Plaza @ 1:00",
            "frontage": "4:30 Plaza",
            "intersection": "1:00",
            "intersection_type": "@",
            "gps_latitude": 40.77469416427707,
            "gps_longitude": -119.20627365884282
        },
        "location_string": "4:30 Plaza @ 1:00"
    },
    {
        "uid": "a1Xd0000001IVTnEAO",
        "year": 2016,
        "name": "Cosmic Giggle",
        "hometown": "Portland/San Francisco",
        "description": "Like fire?  Like muscles and sweat?  For a good time, call 1-800-Cosmic-Giggle.",
        "location": {
            "string": "4:30 Portal & 4:30 Portal",
            "frontage": "4:30 Portal",
            "intersection": "4:30 Portal",
            "intersection_type": "&"
        },
        "location_string": "4:30 Portal & 4:30 Portal"
    },
    {
        "uid": "a1Xd0000001IAy0EAG",
        "year": 2016,
        "name": "Siberian Electric Company",
        "url": "http://mesabear1967.tripod.com",
        "contact_email": "mesabear@hotmail.com",
        "hometown": "Santa Fe New Mexico",
        "description": "Cool drinks and radiation leaks. Stop by get contaminated, get de-contaminated. Your call.",
        "location": {
            "string": "4:30 Plaza @ 2:00",
            "frontage": "4:30 Plaza",
            "intersection": "2:00",
            "intersection_type": "@",
            "gps_latitude": 40.77456869646148,
            "gps_longitude": -119.20610815781441
        },
        "location_string": "4:30 Plaza @ 2:00"
    },
    {
        "uid": "a1Xd0000001ISy0EAG",
        "year": 2016,
        "name": "1st Bank of BRC",
        "contact_email": "wheres-waldo-camp@googlegroups.com",
        "hometown": "San Francisco",
        "description": "Come to the 1st bank of BRC! Get it poppin!!!",
        "location": {
            "string": "5:00 & B",
            "frontage": "5:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.77798282151022,
            "gps_longitude": -119.2094783790733
        },
        "location_string": "5:00 & B"
    },
    {
        "uid": "a1Xd0000001IOm8EAG",
        "year": 2016,
        "name": "BRC HOA",
        "url": "http://www.brchoa.com",
        "contact_email": "brchoa@brchoa.com",
        "hometown": "Everywhere",
        "description": "The BRC HOA prides itself on offering a wide range of options for any prospective Black Rock City homeowner. Hydration! Dehydration! Art! Craft! Heckling (the good kind AND the bad kind) and so much more!",
        "location": {
            "string": "5:00 & B",
            "frontage": "5:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.77798282151022,
            "gps_longitude": -119.2094783790733
        },
        "location_string": "5:00 & B"
    },
    {
        "uid": "a1Xd0000001IWMtEAO",
        "year": 2016,
        "name": "Plunderground",
        "hometown": "Various Villages",
        "description": "A place to interact with fire, found objects and friends and home of The Bonerpillar. Come visit the Museum of Obsolete Technology and Dead things and share your talents on the Vitruvian Stage.",
        "location": {
            "string": "4:30 Portal & A",
            "frontage": "4:30 Portal",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.77834360050925,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 Portal & A"
    },
    {
        "uid": "a1Xd0000001IWmoEAG",
        "year": 2016,
        "name": "MOSAIC",
        "hometown": "San Francisco",
        "description": "Bounded by a finite colors spread across the spectrum, we invite you to come and be a part of our beautiful, bright, and loving space known as Mosaic.",
        "location": {
            "string": "5:00 & D",
            "frontage": "5:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.776712297351594,
            "gps_longitude": -119.20992788016152
        },
        "location_string": "5:00 & D"
    },
    {
        "uid": "a1Xd0000001IXBjEAO",
        "year": 2016,
        "name": "Ancient Cult of the Alligator",
        "url": "https://www.facebook.com/groups/705136196225882/",
        "contact_email": "ancientcultofthealligator@gmail.com",
        "hometown": "Los Angeles",
        "description": "The Ancient Cult of the Alligator is a place for worshippers to find their inner artist by living in the NOW. Come by for daily afternoon activities, featuring an open bar providing specialty drinks (Alligator Bites!), music to replenish your soul, activities to refresh your mind and body, and, the hallmark of any good cult, a soupcon of brainwashing so light you won't notice till it's too late and you're an Alligator for life.",
        "location": {
            "string": "5:00 & D",
            "frontage": "5:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.776712297351594,
            "gps_longitude": -119.20992788016152
        },
        "location_string": "5:00 & D"
    },
    {
        "uid": "a1Xd0000001IJHqEAO",
        "year": 2016,
        "name": "Lotus Ranch",
        "url": "http://www.gypsyandrocket.com/#!lotus-ranch/iyzyc",
        "contact_email": "lotus.ranch.tx@gmail.com",
        "hometown": "Dallas",
        "location": {
            "string": "5:00 & F",
            "frontage": "5:00",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.77544177144894,
            "gps_longitude": -119.21037736405654
        },
        "location_string": "5:00 & F"
    },
    {
        "uid": "a1Xd0000001IMjZEAW",
        "year": 2016,
        "name": "RhythmWave",
        "url": "http://www.rhythmwave.org/",
        "contact_email": "info@rhythmwave.org",
        "description": "Proud to return to Black Rock City for our 10th anniversary year! RhythmWave is dedicated to the practice of Conscious Dance as a moving meditation. With no experience necessary and no \"steps\" to learn, Conscious Dance offers a path - the destination is the discovery of ourselves and a return to our center.\r\n\r\nFacilitators from around the world offer multiple daily sessions of Conscious Dance and movement on our 2,000 sq. ft., fully shaded, and easily-accessible bamboo dance floor. RW also hosts morning yoga and meditation, as well as workshops and intention circles throughout the week. All citizens of Black Rock City are invited to bless the bamboo at RhythmWave. Please join us!",
        "location": {
            "string": "5:00 & A",
            "frontage": "5:00",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.77861808293547,
            "gps_longitude": -119.20925362208132
        },
        "location_string": "5:00 & A"
    },
    {
        "uid": "a1Xd0000001IN64EAG",
        "year": 2016,
        "name": "Yellow Bike Shop",
        "url": "https://www.facebook.com/BlackRockCommunityTransitYellowBikes",
        "description": "Black Rock Community Transit runs and operates the BRC Yellow Bike Program. The Yellow Bikes are community bikes to mobilize all citizens of Black Rock City.",
        "location": {
            "string": "5:30 & A",
            "frontage": "5:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.77942283122764,
            "gps_longitude": -119.21181965382002
        },
        "location_string": "5:30 & A"
    },
    {
        "uid": "a1Xd0000001IVkAEAW",
        "year": 2016,
        "name": "Liminal Labs",
        "url": "http://www.liminallabs.com",
        "contact_email": "zorca@zorca.com",
        "hometown": "San Francisco",
        "description": "Do mornings on the playa find you a little dazed and hazy? Do you wish there were some middle-of-the-night place where you could grab a seat and let your mind be doubly warped? Liminal Labs have you covered! From 10-noon each morning, we happily throw open the Liminal Apothakary Pharmakon where you are invited to choose from an apothecary menu full of salubrious nostrums, elixirs and vitamin-rich restoratives. After dark, all night long, Tuesday through Saturday, we invite you to Liminal Cinema Obscura, where daring cinephiles grab a seat and watch the same movie—frontwards and backwards! So many films to choose from: BARBARELLA, LOGAN'S RUN, THE HUNGER, ONLY LOVERS LEFT ALIVE, DUMBO, CAROUSEL, REPO MAN, PULP FICTION, SCAPE FROM NEW YORK & THE WARRIORS! STAR WARS & STAR TREK! And more! Talk us into showing your own movie picks from our extensive roster of fine films, tv shows and ridiculous youtube videos. All this and free popcorn, too!",
        "location": {
            "string": "5:00 & F",
            "frontage": "5:00",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.77544177144894,
            "gps_longitude": -119.21037736405654
        },
        "location_string": "5:00 & F"
    },
    {
        "uid": "a1Xd0000001IWnrEAG",
        "year": 2016,
        "name": "Salute Your Jorts!",
        "url": "https://saluteyour-jorts.squarespace.com",
        "contact_email": "saluteyourjorts.burningman@gmail.com",
        "hometown": "San Francisco",
        "description": "Our camp is about good ole' fashion summer fun! The care-free friendly competition of lawn games, combined with the best pair of jorts you'll ever own will take you away from the pounding beats of adulthood. Join us to laugh, play, sing and have a ball!",
        "location": {
            "string": "5:00 & G",
            "frontage": "5:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.77480650784362,
            "gps_longitude": -119.2106020995571
        },
        "location_string": "5:00 & G"
    },
    {
        "uid": "a1Xd0000001IVuUEAW",
        "year": 2016,
        "name": "Burning Sky",
        "url": "https://burningsky.org",
        "hometown": "San Francisco bay area",
        "description": "Burning Sky: Sky divers over Burning Man",
        "location": {
            "string": "5:00 & G",
            "frontage": "5:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.77480650784362,
            "gps_longitude": -119.2106020995571
        },
        "location_string": "5:00 & G"
    },
    {
        "uid": "a1Xd0000001IIQ9EAO",
        "year": 2016,
        "name": "Corny's Party Pole Palace",
        "url": "https://www.facebook.com/groups/CampCorny",
        "contact_email": "iampaulanthony@gmail.com",
        "hometown": "Portland, Oregon",
        "description": "Corny's Party Pole Palace - Meet your party pole spirit animal, put em on a stick, discover 2nd level dance parties, get sweaty, bubbles!!!  Come to the Party Pole Palace and create the party pole of your dreams, take a pic in our photo-booth and then dance your ass off on the dance floor.  We'll even help you make a bike stand so you can ride with your incredible creation off into the sunset and beyond.",
        "location": {
            "string": "5:00 & G",
            "frontage": "5:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.77480650784362,
            "gps_longitude": -119.2106020995571
        },
        "location_string": "5:00 & G"
    },
    {
        "uid": "a1Xd0000001IWmZEAW",
        "year": 2016,
        "name": "Kidsville",
        "url": "http://kidsville.org",
        "contact_email": "queenkidsville@gmail.com",
        "hometown": "No central base",
        "description": "Kidsville is a welcoming community of families with children 0-17. Parental/adult supervision is required at all times.",
        "location": {
            "string": "5:30 & E",
            "frontage": "5:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.777144519137565,
            "gps_longitude": -119.2135564416091
        },
        "location_string": "5:30 & E"
    },
    {
        "uid": "a1Xd0000001INzvEAG",
        "year": 2016,
        "name": "CAMP JUICY",
        "url": "https://www.facebook.com/groups/988468674542751/",
        "contact_email": "mcwitmer@hotmail.com",
        "hometown": "los angeles",
        "description": "CAMP JUICY!\r\nFRUIT! ICE! MIX!\r\nNoon-4 -fresh smoothies and filthy BEATS.",
        "location": {
            "string": "B & 4:45",
            "frontage": "B",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.777760358083235,
            "gps_longitude": -119.2080006182041
        },
        "location_string": "B & 4:45"
    },
    {
        "uid": "a1Xd0000001IX8qEAG",
        "year": 2016,
        "name": "Roasted Breaux and Coffee Heaux",
        "hometown": "Auburn, CA; Spokane, WA; Ojai, CA",
        "description": "Roasted Breaux and Coffee Heaux",
        "location": {
            "string": "A & 4:15",
            "frontage": "A",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77841240608523,
            "gps_longitude": -119.20511263592279
        },
        "location_string": "A & 4:15"
    },
    {
        "uid": "a1Xd0000001IVqhEAG",
        "year": 2016,
        "name": "Plaisance",
        "contact_email": "plaisancecamp@gmail.com",
        "hometown": "Washington DC area and the world",
        "description": "Plaisance is a camp of Healers and Da Vinci artisans. We'll offer Reiki, Massage, Energy Healing, Emotional and Mental Health, Meditation, Sign Language and more. Parties include Fireball, Fireball, Fireball, Get ready for the Weekend , Chili cook-off  and will have a Bloody Mary bar with everybody in camp bringing their favorite hot sauce or other accoutrements.  With shade for public chill space and workshops. \r\n\r\nIf you find yourself on walkabout in the morning, the Coffee Goddess may gift a cup of joe.",
        "location": {
            "string": "5:30 & D",
            "frontage": "5:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.77771409960112,
            "gps_longitude": -119.21312225583048
        },
        "location_string": "5:30 & D"
    },
    {
        "uid": "a1Xd0000001IXIfEAO",
        "year": 2016,
        "name": "Present Camp",
        "hometown": "San Francisco",
        "description": "Your presence is requested!  Come to Present Camp and delight in the joy of the now.",
        "location": {
            "string": "5:30 & G",
            "frontage": "5:30",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.776005353328756,
            "gps_longitude": -119.21442479083059
        },
        "location_string": "5:30 & G"
    },
    {
        "uid": "a1Xd0000001IVyrEAG",
        "year": 2016,
        "name": "Monks of Funk",
        "hometown": "San Francsico",
        "location": {
            "string": "A & 4:15",
            "frontage": "A",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77841240608523,
            "gps_longitude": -119.20511263592279
        },
        "location_string": "A & 4:15"
    },
    {
        "uid": "a1Xd0000001IPIoEAO",
        "year": 2016,
        "name": "Geckos",
        "location": {
            "string": "A & 4:45",
            "frontage": "A",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77841240608523,
            "gps_longitude": -119.20788736407722
        },
        "location_string": "A & 4:45"
    },
    {
        "uid": "a1Xd0000001IXZuEAO",
        "year": 2016,
        "name": "D'Oro da Sacramenti Regionale",
        "contact_email": "sacbmproject@gmail.com",
        "hometown": "Sacramento",
        "description": "D'Oro da Sacramenti Regionale Art Support Camp. Bringing the Art of Da Vinci Weapons Guild to the Playa.",
        "location": {
            "string": "A & 4:45",
            "frontage": "A",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77841240608523,
            "gps_longitude": -119.20788736407722
        },
        "location_string": "A & 4:45"
    },
    {
        "uid": "a1Xd0000001IBloEAG",
        "year": 2016,
        "name": "Spaghetti Burritos Camp",
        "location": {
            "string": "B & 4:45",
            "frontage": "B",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.777760358083235,
            "gps_longitude": -119.2080006182041
        },
        "location_string": "B & 4:45"
    },
    {
        "uid": "a1Xd0000001IXKlEAO",
        "year": 2016,
        "name": "Cuddle Oasis",
        "hometown": "San Francisco",
        "description": "Too hot? Too cold? Partied out? Need a break? Want a cuddle or two? Or ten?\r\n\r\nYou've come to the right place.\r\n\r\nCuddle Oasis is bringing you the best chillaxation and rechargation on the playa. Hang with us, stay a while, get misted, do some yoga, take a party nap, rejuvenate your senses with our fresh tropical drinks, and let us liven up your spirits with some chill tropical tunes.\r\n\r\nNow you are ready carry on with your burn.",
        "location": {
            "string": "A & 4:15",
            "frontage": "A",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77841240608523,
            "gps_longitude": -119.20511263592279
        },
        "location_string": "A & 4:15"
    },
    {
        "uid": "a1Xd0000001IKXIEA4",
        "year": 2016,
        "name": "Eridu Society",
        "url": "http://www.eridusociety.org",
        "hometown": "San Francisco",
        "description": "In 2016 we present Eridu's Brainy Bar - a watering hole for big thinkers.  We are an explorer's club for time travelers, creators, makers, designers and builders.",
        "location": {
            "string": "C & 4:45",
            "frontage": "C",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.7771083101538,
            "gps_longitude": -119.20811387231836
        },
        "location_string": "C & 4:45"
    },
    {
        "uid": "a1Xd0000001IX15EAG",
        "year": 2016,
        "name": "Teddies on Teddys",
        "hometown": "San Francisco",
        "description": "Teddies on Teddys?  Oh my!",
        "location": {
            "string": "C & 4:45",
            "frontage": "C",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.7771083101538,
            "gps_longitude": -119.20811387231836
        },
        "location_string": "C & 4:45"
    },
    {
        "uid": "a1Xd0000001IXDLEA4",
        "year": 2016,
        "name": "Camp Afterglow",
        "contact_email": "wearecampafterglow@gmail.com",
        "hometown": "Oakland",
        "description": "Afterglow, that wonderful feeling that lingers long after the experience has elapsed—a feeling that only occurs when the mind, body, and soul has been ever so stimulated. Our gift to the Playa and to its dear citizens is Afterglow!",
        "location": {
            "string": "C & 4:45",
            "frontage": "C",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.7771083101538,
            "gps_longitude": -119.20811387231836
        },
        "location_string": "C & 4:45"
    },
    {
        "uid": "a1Xd0000001IX2NEAW",
        "year": 2016,
        "name": "Lost Boys",
        "contact_email": "thelostboys2016@gmail.com",
        "hometown": "Eugene",
        "location": {
            "string": "C & 5:15",
            "frontage": "C",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77774041281025,
            "gps_longitude": -119.21123222480414
        },
        "location_string": "C & 5:15"
    },
    {
        "uid": "a1Xd0000001IXgMEAW",
        "year": 2016,
        "name": "The MURAL Camp",
        "url": "http://www.muralfestival.com",
        "contact_email": "gabrielle@lndmrk.ca",
        "hometown": "Montreal",
        "description": "The MURAL camp is made out of visionary creators and artists from Montreal, Canada. They're the ones behind the MURAL Festival, a north-american destination for all things urban art. They are the festive and innovative soul of a city burning with artistry.",
        "location": {
            "string": "C & 5:15",
            "frontage": "C",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77774041281025,
            "gps_longitude": -119.21123222480414
        },
        "location_string": "C & 5:15"
    },
    {
        "uid": "a1Xd0000001IQR5EAO",
        "year": 2016,
        "name": "Spirit Dream",
        "url": "http://spiritdream.org/",
        "description": "13 is prime and our time and your time to visit.  Spirit Dream has been your place of peace, comfort, transition, awakening, restoration and more for 13 years now.  Come spend some time with us.  The cafe will once again be serving cups of fresh ground love and providing a place to rest and recharge.  Outside there's water in the desert and next door an awaiting encounter with life giving spirits.  Let us embrace you and draw out your essence with our offerings of love and revelation.  Come visit our well that runs deep and draw life that will sustain you.  Drink deep until it overflows.",
        "location": {
            "string": "C & 4:45",
            "frontage": "C",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.7771083101538,
            "gps_longitude": -119.20811387231836
        },
        "location_string": "C & 4:45"
    },
    {
        "uid": "a1Xd0000001IEH8EAO",
        "year": 2016,
        "name": "Ludus Symposium",
        "url": "https://www.facebook.com/LudusSymposium",
        "contact_email": "ludussymposium@gmail.com",
        "hometown": "Sacramento, CA",
        "description": "Come by our spot on the playa for a beer and a great view of the playa off our deck!",
        "location": {
            "string": "C & 4:45",
            "frontage": "C",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.7771083101538,
            "gps_longitude": -119.20811387231836
        },
        "location_string": "C & 4:45"
    },
    {
        "uid": "a1Xd0000001IXNGEA4",
        "year": 2016,
        "name": "Pirate Ninja Training Camp",
        "hometown": "Sacramento",
        "location": {
            "string": "C & 5:15",
            "frontage": "C",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77774041281025,
            "gps_longitude": -119.21123222480414
        },
        "location_string": "C & 5:15"
    },
    {
        "uid": "a1Xd0000001IQO1EAO",
        "year": 2016,
        "name": "Hooville Hummuside",
        "hometown": "Portland",
        "description": "Hop on over to Hooville for a chant, a drink, a dance, a nap. You bet your ass we are happy to have you!",
        "location": {
            "string": "C & 5:15",
            "frontage": "C",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77774041281025,
            "gps_longitude": -119.21123222480414
        },
        "location_string": "C & 5:15"
    },
    {
        "uid": "a1Xd0000001IWVREA4",
        "year": 2016,
        "name": "Camp BORING",
        "url": "https://www.facebook.com/campboring",
        "hometown": "Mill Valley",
        "description": "Camp BORING: art support camp for BORING sign. Promoters of sarcasm and shenanigans. Come by for a sunset happy hour!",
        "location": {
            "string": "C & 4:45",
            "frontage": "C",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.7771083101538,
            "gps_longitude": -119.20811387231836
        },
        "location_string": "C & 4:45"
    },
    {
        "uid": "a1Xd0000001IWZEEA4",
        "year": 2016,
        "name": "StarFist",
        "contact_email": "starfist.brc@gmail.com",
        "hometown": "Black Rock City",
        "description": "StarFist presents:\r\n\r\nThe Infamous International Tea Service! \r\nMonday-Friday 2-5pm – serving a delightful selection of hot and cold infusions from around the world, served by the Stars themselves.\r\n\r\nCome by the Star Tower anytime – by day survey the city or by night the bright lights as BRC comes to light and life.\r\n\r\nAnd last but not least, home to the infamous GO POSTAL! \t- independent message delivery service (at your service!). Our streetfront booth is open for you to send a message across the playa to the recipient of your choice. Our international fleet of mystery is at your service!",
        "location": {
            "string": "C & 4:15",
            "frontage": "C",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.7771083101538,
            "gps_longitude": -119.20488612768166
        },
        "location_string": "C & 4:15"
    },
    {
        "uid": "a1Xd0000001IXE9EAO",
        "year": 2016,
        "name": "Camp to be Continued...",
        "url": "http://mike831anderson.wix.com/arttobecontinued",
        "hometown": "Santa Cruz",
        "description": "Camp to be Continued... is the home of the art collective, Art to be Continued..., making The 10 Benches of Sitting Man this year.",
        "location": {
            "string": "C & 4:15",
            "frontage": "C",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.7771083101538,
            "gps_longitude": -119.20488612768166
        },
        "location_string": "C & 4:15"
    },
    {
        "uid": "a1Xd0000001IT19EAG",
        "year": 2016,
        "name": "Camp Orange",
        "url": "https://www.facebook.com/BMCampOrange",
        "hometown": "San Francisco",
        "description": "Fruit lovers rejoice for Camp Orange (you glad we didn't say banana) is back! Cool off with a refreshing treat from our enormous banana stand,relax in one of our banana hammocks, enjoy a banana flavored cocktail all while hearing every fruit pun imaginable!",
        "location": {
            "string": "D & 4:45",
            "frontage": "D",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.776456262296946,
            "gps_longitude": -119.20822712642001
        },
        "location_string": "D & 4:45"
    },
    {
        "uid": "a1Xd0000001IDrTEAW",
        "year": 2016,
        "name": "Astral Headwash",
        "hometown": "Denver",
        "description": "Greetings dirty desert dwellers!  We are Astral Headwash and we do the amazing!  We will wash your head for you again this year.  That's right, clean, fresh water warmed in the desert sun with wonderful smelling shampoo and a bit of leave-in condition to send you on your way!  Bring your happy selves to us Monday - Friday noon until 4 pm!  Participation is required!",
        "location": {
            "string": "D & 4:45",
            "frontage": "D",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.776456262296946,
            "gps_longitude": -119.20822712642001
        },
        "location_string": "D & 4:45"
    },
    {
        "uid": "a1Xd0000001IVkZEAW",
        "year": 2016,
        "name": "Café Sŭrprïsé",
        "hometown": "San Francisco",
        "description": "Café Sŭrprïsé lives to feed our many great friends in BRC. Please come by at 2pm Mon-Fri for Deeply Hungover Deep Fried Goodness, where we serve french fries and other fried treats for your poor tired hungover body. In the early evening, be on the lookout for our Maitre D' in the streets of BRC, as they will be giving out tickets to our fine French Dining Experience. You'll want to do anything they ask to score one of those golden tickets- the escargot is not to be believed! Finally, late at night, in the wilds of BRC, come find the Sammie Wagon and we'll make you a grilled cheese sandwich.",
        "location": {
            "string": "D & 4:45",
            "frontage": "D",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.776456262296946,
            "gps_longitude": -119.20822712642001
        },
        "location_string": "D & 4:45"
    },
    {
        "uid": "a1Xd0000001IWs3EAG",
        "year": 2016,
        "name": "Twisted \"G\" Spot",
        "hometown": "Currently that's BRC! Default World: Reno, Nevada City, Tahoe, Truckee and Green Bay",
        "description": "Tightly knit group of burners offer for your pleasure the Twisted G Spot Bar serving up PVD's (Playa Vodka Drinks) w/mostly organic fruit juices and a \"Twist\" of lime or lemon.  Dudeist Priest and Priestess available for playa confessions \"Penance is Hell\" and ordained marriages, bigamy is good.  DJ N8Tron spinning his music.  Otter Pops upon request, or street side at various intervals, served cold and hard!  Human Twister played all day with kinetic spinner wheel. Early morning powdered donuts, that's not just playa powder, served Wednesday through Saturday delivered on a silver platter by Kristi Kreams .  PandJ sandwiches offered by Miss Prepared and foamy things for your ears always available at the bar.  If you need a horsey fix, come find Margie and check out Horse, our camp mascot and resident mutant vehicle. Horse will deliver mail on playa too! Check our mailbox for schedule of planned events.  Stay Twisted",
        "location": {
            "string": "D & 4:15",
            "frontage": "D",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.776456262296946,
            "gps_longitude": -119.20477287358
        },
        "location_string": "D & 4:15"
    },
    {
        "uid": "a1Xd0000001IX60EAG",
        "year": 2016,
        "name": "Oontz Pouch",
        "hometown": "San Francisco",
        "description": "OONTZ OONTZ OONTZ!",
        "location": {
            "string": "D & 4:45",
            "frontage": "D",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.776456262296946,
            "gps_longitude": -119.20822712642001
        },
        "location_string": "D & 4:45"
    },
    {
        "uid": "a1Xd0000001IBHrEAO",
        "year": 2016,
        "name": "Devachan Lounge",
        "url": "http://www.devachanlounge.com",
        "contact_email": "contact@devachanlounge.com",
        "hometown": "San Diego, Bay Area, Oregon",
        "description": "The \"dwelling of the gods\" of Indo-Tibetan theosophy\r\nA place of authenticity, love, and connection. \r\nA home on the playa where we get to be our best selves.",
        "location": {
            "string": "E & 4:45",
            "frontage": "E",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77580421451263,
            "gps_longitude": -119.20834038050907
        },
        "location_string": "E & 4:45"
    },
    {
        "uid": "a1Xd0000001IPNKEA4",
        "year": 2016,
        "name": "Camp Peace of Ass",
        "hometown": "Reno",
        "description": "Camp Peace of Ass supports the vulnerable, sumptuous, cheeks of biking Burners as they travel the vast, course playa environment. The repetitive motion propelling your steed, up and down, fast or slow, hard or soft over and over again demands the protection and shield available only from Camp Peace of Ass; colorful, hand-crafted fleece bicycle seat covers that are guaranteed to soothe and caress your precious assets all day and all night long! Free installation included!!",
        "location": {
            "string": "D & 5:15",
            "frontage": "D",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77713272797879,
            "gps_longitude": -119.21156430775099
        },
        "location_string": "D & 5:15"
    },
    {
        "uid": "a1Xd0000001IXP2EAO",
        "year": 2016,
        "name": "Boom Boom Womb",
        "url": "http://boomboomwomb.com",
        "hometown": "San Francisco",
        "description": "Collective celebration and rebirth with an elevated dash of the soulful, feminine and funky.",
        "location": {
            "string": "E & 4:45",
            "frontage": "E",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77580421451263,
            "gps_longitude": -119.20834038050907
        },
        "location_string": "E & 4:45"
    },
    {
        "uid": "a1Xd0000001IXZ6EAO",
        "year": 2016,
        "name": "We Traffic In Dreams",
        "hometown": "Austin",
        "description": "Home base for a magical traveling medicine show from 1902. Elixirs and potions available for the low, low price of one dream each!",
        "location": {
            "string": "E & 4:15",
            "frontage": "E",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77580421451263,
            "gps_longitude": -119.20465961949094
        },
        "location_string": "E & 4:15"
    },
    {
        "uid": "a1Xd0000001IWIIEA4",
        "year": 2016,
        "name": "Planetarium Aquarium: Swan Swamp",
        "hometown": "San Francisco",
        "description": "This year, Planetarium Aquarium aims to create an experience unlike anything we've done before -- providing our fellow burners with a place of fun, comfort, adventure and intentional self-discovery -- encouraging them to celebrate their inner-swan.\r\n\r\nLuckily for us, this desire corresponds with an unprecedented astronomical occurrence that only aligns with the playa calendar once in a lifetime. With that in mind, we would like to use this mystical opportunity to host our fellow burners as Planetarium Aquarium Presents: Suzanne's Swan Lake Swamp!\r\n\r\nGet set up at the Burner Bog welcome station, lounge swampside or live a little and test out Suzanne's patented Swamp Launcher -- diving into the world's only cuddle-puddle of mystical misfit creatures -- likely right where you belong.\r\n\r\nBe sure to join us swampside Wednesday for happy hour(s) with only the best summer jams -- and don only your finest playa formal for Thursday night's grand finale: THE SWAN LAKE BALL!!!",
        "location": {
            "string": "D & 5:15",
            "frontage": "D",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77713272797879,
            "gps_longitude": -119.21156430775099
        },
        "location_string": "D & 5:15"
    },
    {
        "uid": "a1Xd0000001IXCcEAO",
        "year": 2016,
        "name": "The Temple of UniTea",
        "url": "http://www.templeofunitea.com/",
        "contact_email": "info@templeofunitea.com",
        "hometown": "Austin",
        "description": "Our tea mission is to promote participation in, and appreciation of, world tea traditions as well as otherworldly tea traditions. To throw tea parteas by offering a relaxed, convivial and harmonious space to make and take tea.",
        "location": {
            "string": "E & 4:15",
            "frontage": "E",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77580421451263,
            "gps_longitude": -119.20465961949094
        },
        "location_string": "E & 4:15"
    },
    {
        "uid": "a1Xd0000001IWlgEAG",
        "year": 2016,
        "name": "sake to me",
        "hometown": "Las Vegas",
        "description": "Sake To Me is your neighborhood sake bar! Stop by for a comfortable shady pitstop, some great chilled sake, and test your skills at a giant version of Jenga.",
        "location": {
            "string": "E & 4:15",
            "frontage": "E",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77580421451263,
            "gps_longitude": -119.20465961949094
        },
        "location_string": "E & 4:15"
    },
    {
        "uid": "a1Xd0000001INYBEA4",
        "year": 2016,
        "name": "FAFA Camp",
        "hometown": "San Francisco/Paris",
        "description": "FAFAs from a galaxy fa-fa away coalesce around a love of all things Burning Man in the spirit of fun, adventure, and multi-lingual friendship.",
        "location": {
            "string": "E & 4:45",
            "frontage": "E",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77580421451263,
            "gps_longitude": -119.20834038050907
        },
        "location_string": "E & 4:45"
    },
    {
        "uid": "a1Xd0000001IUnWEAW",
        "year": 2016,
        "name": "Arrête ton Cirque !",
        "contact_email": "w.fourcault@gmail.com",
        "hometown": "Grenoble",
        "description": "Come and turn our prize wheel to start playing with us, then you will deserve a ladle of fresh punch!",
        "location": {
            "string": "D & 5:15",
            "frontage": "D",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77713272797879,
            "gps_longitude": -119.21156430775099
        },
        "location_string": "D & 5:15"
    },
    {
        "uid": "a1Xd0000001IXAgEAO",
        "year": 2016,
        "name": "Ofosho",
        "url": "http://www.campofosho.com",
        "hometown": "Seattle",
        "description": "We are a spirited group of burners who deep within our souls are artists, creators, constructors, experimenters, poets, photographers, videographers, dancers, musicians, singers, foodies, theorists, geeks, givers, lovers and above all else burners.",
        "location": {
            "string": "E & 4:15",
            "frontage": "E",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77580421451263,
            "gps_longitude": -119.20465961949094
        },
        "location_string": "E & 4:15"
    },
    {
        "uid": "a1Xd0000001ISM6EAO",
        "year": 2016,
        "name": "Space Hole: Mist Opportunity",
        "hometown": "San Francisco",
        "description": "Visit Space Hole: Mist Opportunity.  Get misted and see some cool no-RV Burning Man camping tech!",
        "location": {
            "string": "E & 4:45",
            "frontage": "E",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77580421451263,
            "gps_longitude": -119.20834038050907
        },
        "location_string": "E & 4:45"
    },
    {
        "uid": "a1Xd0000001IRoMEAW",
        "year": 2016,
        "name": "Playa Circuit Boogie",
        "description": "Here at Playa Circuit Boogie we use circuits and science to spark ideas and bring strangers together, all while jamming out to groovy tunes. Come play with our Collaborative Funk Machine and experience the beauty that can be created through human connection.",
        "location": {
            "string": "E & 4:45",
            "frontage": "E",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77580421451263,
            "gps_longitude": -119.20834038050907
        },
        "location_string": "E & 4:45"
    },
    {
        "uid": "a1Xd0000001IQjPEAW",
        "year": 2016,
        "name": "Iron Monkeys",
        "contact_email": "info@ironmonkeyarts.org",
        "hometown": "Seattle",
        "description": "Artists camp for the Piazza Di Ferro",
        "location": {
            "string": "D & 5:15",
            "frontage": "D",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77713272797879,
            "gps_longitude": -119.21156430775099
        },
        "location_string": "D & 5:15"
    },
    {
        "uid": "a1Xd0000001IV4uEAG",
        "year": 2016,
        "name": "The Future",
        "url": "http://thefuture.camp",
        "hometown": "San Francisco",
        "description": "A collection of whimsical thinkers and engineers who are building interactive art for the future, one journey at a time. Come visit us, and you too can climb into the skies and watch the world from above, or stay on the ground and share a party or two with us!",
        "location": {
            "string": "D & 5:15",
            "frontage": "D",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77713272797879,
            "gps_longitude": -119.21156430775099
        },
        "location_string": "D & 5:15"
    },
    {
        "uid": "a1Xd0000001IRMwEAO",
        "year": 2016,
        "name": "Idol Hands",
        "hometown": "San Francisco",
        "description": "Not all idols are false.  Come craft your own idol or bow down to ours.",
        "location": {
            "string": "F & 4:15",
            "frontage": "F",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20454636541449
        },
        "location_string": "F & 4:15"
    },
    {
        "uid": "a1Xd0000001IQfcEAG",
        "year": 2016,
        "name": "BLM NCA Interpretive Camp",
        "hometown": "Gerlach",
        "description": "Displays explaining details about the Black Rock Desert High Rock Canyon Emigrant Trails National Conservation Area and  BLM.  Presentations and information about Leave No Trace Principles.",
        "location": {
            "string": "Esplanade & 5:15",
            "frontage": "Esplanade",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.78006987800911,
            "gps_longitude": -119.20995923652504
        },
        "location_string": "Esplanade & 5:15"
    },
    {
        "uid": "a1Xd0000001IWDwEAO",
        "year": 2016,
        "name": "SPACE COWBOYS",
        "url": "http://www.spacecowboys.org/",
        "hometown": "San Francisco",
        "description": "The Space Cowboys are opening the stargates to our very own Rocket Ranch this year, so step out of the cold vacuum of space and kick up your moonboots in the Supernova Saloon, or float up to the Bolide Brothel for some high altitude decadence. Don't worry, you'll still find us out on the range wranglin' all those dirty breaks you love, but if your bike requires mending and your thirst quenched, come find Inflation Station serving up just what you need.",
        "location": {
            "string": "Esplanade & 5:00",
            "frontage": "Esplanade",
            "intersection": "5:00",
            "intersection_type": "&",
            "gps_latitude": 40.7797827277492,
            "gps_longitude": -119.2088415564309
        },
        "location_string": "Esplanade & 5:00"
    },
    {
        "uid": "a1Xd0000001IOqqEAG",
        "year": 2016,
        "name": "Breakaway Republic",
        "hometown": "San Francisco",
        "description": "Giving out automated playa names since 2015, heckling since 2000.",
        "location": {
            "string": "F & 4:15",
            "frontage": "F",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20454636541449
        },
        "location_string": "F & 4:15"
    },
    {
        "uid": "a1Xd0000001IPLOEA4",
        "year": 2016,
        "name": "Wind Propulsion Lab",
        "contact_email": "windpropulsionlab@gmail.com",
        "hometown": "Philadephia and Chicago",
        "description": "At Wind Propulsion Lab we celebrate the power of the wind.  Blow by on Tuesday between 10 AM and Noon where our WPL artist will indoctrinate you into our windsical world by painting your face with a one of kind design.   You will agree that face painting is not just for kids.  On Wednesday at 2 PM join our WPL Lab Experts to build and decorate your own super simple kite at our workshop.  On Friday at 1 PM come with us to fly your favorite kite during our Kavalcade of Kites as we parade together to wind play on the playa.  The rest of the week stop by and shoot the breeze with us in our chill space and pick up one our windsical gifts.",
        "location": {
            "string": "E & 5:15",
            "frontage": "E",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.776525043868155,
            "gps_longitude": -119.21189639030393
        },
        "location_string": "E & 5:15"
    },
    {
        "uid": "a1Xd0000001IWTkEAO",
        "year": 2016,
        "name": "Awakening",
        "url": "https://www.facebook.com/AwakeningBurningMan2016/",
        "contact_email": "yetiroot@gmail.com",
        "hometown": "Denver",
        "description": "Awakening is the art support camp for the 2016 honorarium art project of the same name.  In addition to housing the build crew there will be an interactive inflatable solar observatory.",
        "location": {
            "string": "E & 5:15",
            "frontage": "E",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.776525043868155,
            "gps_longitude": -119.21189639030393
        },
        "location_string": "E & 5:15"
    },
    {
        "uid": "a1Xd0000001IVFzEAO",
        "year": 2016,
        "name": "Frogma",
        "hometown": "SF, LA, Mammoth, London & Seattle",
        "description": "Frogma is the little theme camp that could, where everyone is your friend and neighbor! Hop on over to our lily pads Monday and Wednesday at 5:00pm for BRC's one and only Hoppy Hour. Serving up ice cold slushy Frogaritas in our dome sweet dome. You're guaranteed to make a rainbow of connections.",
        "location": {
            "string": "F & 4:15",
            "frontage": "F",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20454636541449
        },
        "location_string": "F & 4:15"
    },
    {
        "uid": "a1Xd0000001IYHpEAO",
        "year": 2016,
        "name": "Atlantis",
        "url": "http://www.atlantissunsets.com",
        "contact_email": "underthetrident@gmail.com",
        "hometown": "SF",
        "description": "Our on-playa, under-the-sea home.",
        "location": {
            "string": "Esplanade & 4:30 Portal",
            "frontage": "Esplanade",
            "intersection": "4:30 Portal",
            "intersection_type": "&",
            "gps_latitude": 40.77954932016092,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "Esplanade & 4:30 Portal"
    },
    {
        "uid": "a1Xd0000001IT0kEAG",
        "year": 2016,
        "name": "Hushville",
        "url": "http://www.hushville.com",
        "contact_email": "info@hushville.com",
        "hometown": "Seattle and the surrounding Planet",
        "description": "Hushville, an aural oasis in an undulating sea of chaos, is open to any camper who pre-registers and can abide our three simple rules: 1) No Generators; 2) No Amplified Sound; and 3) Leave No Trace. Because Hushville is a village in Black Rock City, we can't promise that it will be quiet... just quieter.",
        "location": {
            "string": "E & 5:15",
            "frontage": "E",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.776525043868155,
            "gps_longitude": -119.21189639030393
        },
        "location_string": "E & 5:15"
    },
    {
        "uid": "a1Xd0000001IN1dEAG",
        "year": 2016,
        "name": "Walkover",
        "url": "https://www.facebook.com/walkover.camp",
        "contact_email": "f1k@aol.com",
        "hometown": "Wilseyville",
        "location": {
            "string": "F & 4:15",
            "frontage": "F",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20454636541449
        },
        "location_string": "F & 4:15"
    },
    {
        "uid": "a1Xd0000001IXcyEAG",
        "year": 2016,
        "name": "Artists of Burntanical Garden",
        "contact_email": "richard@burntanicalgarden.com",
        "hometown": "Reno",
        "description": "A gathering place for Metal & Flame Artists, Pyrocents who safeguard their creations, and the crew that supports Burntanical Garden.",
        "location": {
            "string": "E & 4:45",
            "frontage": "E",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77580421451263,
            "gps_longitude": -119.20834038050907
        },
        "location_string": "E & 4:45"
    },
    {
        "uid": "a1Xd0000001IREbEAO",
        "year": 2016,
        "name": "Encounter",
        "contact_email": "burner_forever@yahoo.com",
        "hometown": "Redding",
        "description": "A Family style house to come hang out, eat, drink,play games be family and encounter one of our interactive rooms. You may come as a stranger but you will leave as family!!",
        "location": {
            "string": "E & 5:15",
            "frontage": "E",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.776525043868155,
            "gps_longitude": -119.21189639030393
        },
        "location_string": "E & 5:15"
    },
    {
        "uid": "a1Xd0000001IM3wEAG",
        "year": 2016,
        "name": "MOOP Map Headquarters",
        "hometown": "Black Rock City",
        "description": "Moop Map Headquarters is the Playa Restoration interactive education camp.\r\n\r\n• Visit the Moop Gardens, learn about the most common types of Moop found during Playa Restoration.\r\n • View GPS data and photos from past event site Restoration operations.\r\n • Get familiar with the tools used to Leave No Trace on the Playa.\r\n • See every Moop Map 2006 - 2014 on display.\r\n\r\nVisit any evening after Sunset to enjoy the Fireside Circle, a place for the community to congregate around an open fire.",
        "location": {
            "string": "Esplanade & 5:30",
            "frontage": "Esplanade",
            "intersection": "5:30",
            "intersection_type": "&",
            "gps_latitude": 40.78046704889989,
            "gps_longitude": -119.21102358626698
        },
        "location_string": "Esplanade & 5:30"
    },
    {
        "uid": "a1Xd0000001IXdhEAG",
        "year": 2016,
        "name": "Black Rock French Quarter",
        "url": "http://www.blackrockfrenchquarter.org",
        "contact_email": "ignatius@blackrockfrenchquarter.org",
        "hometown": "Los Angeles",
        "description": "The heart of the Big Easy come to Black Rock City, including cocktails, bakery, fresh roasted coffee, live music and burlesque, wine cellar, vineyard, Mardi Gras, Jazz Funeral for the Man, and a few other surprises. Our French Quarter buildings are based on an open design that your camp can build to join us!",
        "location": {
            "string": "Esplanade & 4:30 Portal",
            "frontage": "Esplanade",
            "intersection": "4:30 Portal",
            "intersection_type": "&",
            "gps_latitude": 40.77954932016092,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "Esplanade & 4:30 Portal"
    },
    {
        "uid": "a1Xd0000001IJaBEAW",
        "year": 2016,
        "name": "Emergency Services Rampart Urgent Care",
        "location": {
            "string": "Esplanade & 5:15",
            "frontage": "Esplanade",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.78006987800911,
            "gps_longitude": -119.20995923652504
        },
        "location_string": "Esplanade & 5:15"
    },
    {
        "uid": "a1Xd0000001IJh2EAG",
        "year": 2016,
        "name": "Loveland",
        "url": "https://www.facebook.com/loveland.brc/",
        "contact_email": "lovelandvillage@gmail.com",
        "hometown": "Los Angeles, San Barbara, SF",
        "location": {
            "string": "F & 4:15",
            "frontage": "F",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20454636541449
        },
        "location_string": "F & 4:15"
    },
    {
        "uid": "a1Xd0000001IY4dEAG",
        "year": 2016,
        "name": "BLM/PershingCounty LawEnforcement",
        "description": "Bureau of Land Management and the Pershing County Sheriff's Office will have a substation at 5:15 and the Esplanade. You can report a crime to the officers stationed at this substation. If you have any additional questions or wish to say hello, please stop by and visit.",
        "location": {
            "string": "Esplanade & 5:15",
            "frontage": "Esplanade",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.78006987800911,
            "gps_longitude": -119.20995923652504
        },
        "location_string": "Esplanade & 5:15"
    },
    {
        "uid": "a1Xd0000001IXRDEA4",
        "year": 2016,
        "name": "Camp Caribou",
        "hometown": "Vancouver & Toronto",
        "description": "Camp Caribou - meet the northerners through games, body stenciling, dance and some distinctively Canadian drinks!",
        "location": {
            "string": "F & 4:45",
            "frontage": "F",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20845363458552
        },
        "location_string": "F & 4:45"
    },
    {
        "uid": "a1Xd0000001IGjbEAG",
        "year": 2016,
        "name": "BRINY DEPTHS!",
        "hometown": "Alameda",
        "location": {
            "string": "G & 4:15",
            "frontage": "G",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20443126133077
        },
        "location_string": "G & 4:15"
    },
    {
        "uid": "a1Xd0000001IX4EEAW",
        "year": 2016,
        "name": "Community Improvement Association",
        "hometown": "Scotia",
        "description": "The Community Improvement Association is a recognized leader in making everywhere a better place to live. Stop by our information booth to consult our large-scale map of the city, get guidance on what to see, and receive encouragement for your own mission to improve the community. We will also be broadcasting Community Improvement Radio on the FM dial (frequency tbd), with a mix of music and conversation. From Tuesday - Friday, tune in or stop by for our 4:33 Concert Series, featuring fresh, sun-baked sounds in analog and electronic media.",
        "location": {
            "string": "F & 4:15",
            "frontage": "F",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20454636541449
        },
        "location_string": "F & 4:15"
    },
    {
        "uid": "a1Xd0000001IXFWEA4",
        "year": 2016,
        "name": "Improba Putti",
        "url": "https://www.facebook.com/Khans-Asylum-619100008179731",
        "hometown": "San Diego, San Francisco",
        "description": "Formerly known as Khan's Asylum, in 2016 we are devoting full attention to our art project by Vulfie Munson, called Improba Putti. We'll still have tribbles to make and/or adopt, our famous Lego bar, and a gifting bazaar where you can take and/or leave whatever your heart desires.",
        "location": {
            "string": "F & 4:15",
            "frontage": "F",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20454636541449
        },
        "location_string": "F & 4:15"
    },
    {
        "uid": "a1Xd0000001IXl2EAG",
        "year": 2016,
        "name": "Black Rock Blind Tiger",
        "url": "http://www.blackrockblindtiger.com",
        "hometown": "Austin",
        "description": "Art Support camp for a puzzle and riddle locked Speakeasy full of art inventions in the deep open Playa.",
        "location": {
            "string": "F & 4:15",
            "frontage": "F",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20454636541449
        },
        "location_string": "F & 4:15"
    },
    {
        "uid": "a1Xd0000001IVl8EAG",
        "year": 2016,
        "name": "Fire In Balance",
        "url": "https://www.facebook.com/FireInBalance",
        "hometown": "Los Angeles",
        "description": "We the very proud group of people bringing your Fire In Balance - IN THE ROUND! Please feel free to stop by any time to say Hi and definitely check the piece out... we built it for YOU!",
        "location": {
            "string": "F & 4:45",
            "frontage": "F",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20845363458552
        },
        "location_string": "F & 4:45"
    },
    {
        "uid": "a1Xd0000001IGqSEAW",
        "year": 2016,
        "name": "Slumberdome Piano Lounge",
        "hometown": "Encinitas",
        "description": "Slumberdome Piano Lounge is a calm and quiet escape where the dusty traveler can relax and enjoy the music of our beautiful Wurlitzer piano and assortment of other instruments. Whether to come and play, or come and listen, all are invited within the comfortable and serene environment of the Slumderdome. Featuring calm and subdued lighting and bedecked in beautiful fabrics, we hope to provide a resplendent respite from the elements.  Join us every sunset for a Slumbered Aum session! There will be yoga, live musical performances and flaming slackline routines throughout the week.",
        "location": {
            "string": "G & 4:15",
            "frontage": "G",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20443126133077
        },
        "location_string": "G & 4:15"
    },
    {
        "uid": "a1Xd0000001INmgEAG",
        "year": 2016,
        "name": "A-Playa Mask Camp",
        "hometown": "Los Angeles",
        "description": "Breathe easy with the Maskman's quality N95 dust masks with their psychedelic Burning Man logo.",
        "location": {
            "string": "F & 4:45",
            "frontage": "F",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20845363458552
        },
        "location_string": "F & 4:45"
    },
    {
        "uid": "a1Xd0000001IVpoEAG",
        "year": 2016,
        "name": "Be There Now",
        "url": "https://www.facebook.com/Be-There-Now-433480140072139/",
        "contact_email": "bob.dow@addis.com",
        "hometown": "Oakland",
        "description": "Be There Now invites you to come and hang out in tour video cube for 9 minutes of story driven interactive fun. \r\n\r\n8 projectors, 2 couches, you and your friends. Perfect.",
        "location": {
            "string": "F & 4:15",
            "frontage": "F",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20454636541449
        },
        "location_string": "F & 4:15"
    },
    {
        "uid": "a1Xd0000001IXMrEAO",
        "year": 2016,
        "name": "Lituanica Birds",
        "url": "http://www.degantiszmogus.lt",
        "contact_email": "burningvilnius@gmail.com",
        "hometown": "Vilnius",
        "description": "Lituanica Birds camp - a place for many different kinds of birds and nestworking",
        "location": {
            "string": "F & 4:15",
            "frontage": "F",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20454636541449
        },
        "location_string": "F & 4:15"
    },
    {
        "uid": "a1Xd0000001IVzGEAW",
        "year": 2016,
        "name": "Brokedown Palace",
        "url": "https://www.facebook.com/BrokedownPalaceOnThePlaya/",
        "contact_email": "fredgoss@mac.com",
        "hometown": "Los Angeles",
        "description": "The Brokedown Palace fan page can be found on Facebook at--\r\nBrokedown Palace at Burning Man\r\nPlease 'Like' us.  We have just about 20,000 likes so far!",
        "location": {
            "string": "F & 4:15",
            "frontage": "F",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20454636541449
        },
        "location_string": "F & 4:15"
    },
    {
        "uid": "a1Xd0000001IE0GEAW",
        "year": 2016,
        "name": "Virgin Hooper Camp",
        "contact_email": "ajinnoho@gmail.com",
        "hometown": "North Hollywood",
        "description": "Learn how to hula hoop like a boss at Virgin Hooper Camp. Drop it every time you try? Come by and let us fit you for just the right hoop to have you spinning and laughing in no time. We teach basic beginner hooping for fun and fitness.",
        "location": {
            "string": "G & 4:15",
            "frontage": "G",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20443126133077
        },
        "location_string": "G & 4:15"
    },
    {
        "uid": "a1Xd0000001IDbtEAG",
        "year": 2016,
        "name": "SPIN ART CAMP",
        "contact_email": "captaincarburetor@gmail.com",
        "hometown": "Steamboat Springs, Colorado.",
        "description": "SPIN ART CAMP IS BACK !!!   Remember Spin-Art when you were a kid? We built a 4-FOOT DIAMETER MACHINE for you to make your own Spin Art. Bring a t-shirt or take-off what you have to create a work of art. We provide the machine and the paints for you to create an awesome Burning Man Souvenir.\r\nPlease see the What-Where-When for times and location.",
        "location": {
            "string": "G & 4:15",
            "frontage": "G",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20443126133077
        },
        "location_string": "G & 4:15"
    },
    {
        "uid": "a1Xd0000001IVJcEAO",
        "year": 2016,
        "name": "Camp FingerBang!",
        "hometown": "San Francisco, Los Angeles",
        "description": "Camp Fingerbang is dedicated to raising the level of inappropriateness on the playa - Cheer team and All! We are a delightfully ridiculous group. We do not take ourselves seriously at all and neither will you when you come to visit.",
        "location": {
            "string": "G & 4:15",
            "frontage": "G",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20443126133077
        },
        "location_string": "G & 4:15"
    },
    {
        "uid": "a1Xd0000001IO9hEAG",
        "year": 2016,
        "name": "Fresh Squeezed!",
        "contact_email": "hello@lemonadeart.com",
        "hometown": "Portland",
        "description": "Art & Lemonade since 2006. Come join us for ice cold lemonade and group painting. Lend a hand creating a 12' tall replica of the Mona Lisa!",
        "location": {
            "string": "G & 4:45",
            "frontage": "G",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20856873866927
        },
        "location_string": "G & 4:45"
    },
    {
        "uid": "a1Xd0000001IXDuEAO",
        "year": 2016,
        "name": "Camp Catalyst",
        "contact_email": "sam_webster@me.com",
        "hometown": "Salt Lake City",
        "description": "For those missing the endless days of drinking on the lift, drinking in the parking lot, drinking in the lodge, and bragging about your mad skills, Come climb our mountain, listen to some deep bass, tip back the shot ski, and strap on skis or a board and hit our ramp into the the avalanche of dusty fluffy puppies, at the playa's Apres ski headquarters.",
        "location": {
            "string": "G & 4:15",
            "frontage": "G",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20443126133077
        },
        "location_string": "G & 4:15"
    },
    {
        "uid": "a1Xd0000001IX1eEAG",
        "year": 2016,
        "name": "Floasis",
        "hometown": "New York / SF",
        "location": {
            "string": "G & 4:15",
            "frontage": "G",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20443126133077
        },
        "location_string": "G & 4:15"
    },
    {
        "uid": "a1Xd0000001IXIGEA4",
        "year": 2016,
        "name": "Camp Shark Cage",
        "hometown": "Sacramento",
        "description": "The playa's one and only nautical Nicolas Cage theme camp.  Find out the answer to life's greatest riddle: You can cage a shark, but can you shark a Cage?",
        "location": {
            "string": "G & 4:15",
            "frontage": "G",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20443126133077
        },
        "location_string": "G & 4:15"
    },
    {
        "uid": "a1Xd0000001IVvDEAW",
        "year": 2016,
        "name": "Alice in Slumberland",
        "hometown": "San Francisco & New York City",
        "description": "Alice in Slumberland is the home of the Caterpillar's Hookah Lounge and the Red Queen's Croquet Court. Do you play...Croquet? Come on any of your unbirthdays!",
        "location": {
            "string": "G & 4:15",
            "frontage": "G",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20443126133077
        },
        "location_string": "G & 4:15"
    },
    {
        "uid": "a1Xd0000001IQzQEAW",
        "year": 2016,
        "name": "Whiskey Division",
        "contact_email": "sick.jon@gmail.com",
        "hometown": "Seattle",
        "location": {
            "string": "G & 4:15",
            "frontage": "G",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20443126133077
        },
        "location_string": "G & 4:15"
    },
    {
        "uid": "a1Xd0000001IVA1EAO",
        "year": 2016,
        "name": "Bitchin' Braid Camp",
        "url": "https://sites.google.com/site/braidcamp/",
        "hometown": "Reno/Tahoe",
        "description": "Out of control hair taking over your life? Come on over to Bitchin' Braid Camp and K-Bar (or Bar-K)  to enjoy a refreshment, music, conversation while we braid your nappy locks in the shade.",
        "location": {
            "string": "H & 4:45",
            "frontage": "H",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77384823164088,
            "gps_longitude": -119.20868207279557
        },
        "location_string": "H & 4:45"
    },
    {
        "uid": "a1Xd0000001IREREA4",
        "year": 2016,
        "name": "Penny Smashing Point",
        "url": "http://www.obolensky.us",
        "contact_email": "info@obolensky.us",
        "hometown": "Sherman Oaks",
        "description": "Dear Burners! Bring you penny and we will smash it for you or take one we have for you.",
        "location": {
            "string": "H & 4:15",
            "frontage": "H",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77384823164088,
            "gps_longitude": -119.20431792720447
        },
        "location_string": "H & 4:15"
    },
    {
        "uid": "a1Xd0000001IONIEA4",
        "year": 2016,
        "name": "What Would You Do For A Pickle?",
        "hometown": "San Francisco",
        "description": "What Would You Do For A Pickle?",
        "location": {
            "string": "H & 4:15",
            "frontage": "H",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77384823164088,
            "gps_longitude": -119.20431792720447
        },
        "location_string": "H & 4:15"
    },
    {
        "uid": "a1Xd0000001IW59EAG",
        "year": 2016,
        "name": "Fish Out of Water",
        "hometown": "Danbury",
        "description": "Fish Out of Water Camp bringing bacon tamales to the Playa. Bring a plate and a companion.",
        "location": {
            "string": "H & 4:45",
            "frontage": "H",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77384823164088,
            "gps_longitude": -119.20868207279557
        },
        "location_string": "H & 4:45"
    },
    {
        "uid": "a1Xd0000001IPhMEAW",
        "year": 2016,
        "name": "Yeah Man!",
        "hometown": "Los Angeles",
        "description": "Have you ever exclaimed \"Yeah Man!\"?  Come share your story or experience a new one in the Yeah Man! dome, grab a drink at our Tramp Bar and enjoy an eclectic music selection.",
        "location": {
            "string": "G & 4:45",
            "frontage": "G",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20856873866927
        },
        "location_string": "G & 4:45"
    },
    {
        "uid": "a1Xd0000001II2dEAG",
        "year": 2016,
        "name": "Post Nuclear Family",
        "url": "http://www.postnuclearfamily.com",
        "contact_email": "camp@postnuclearfamily.com",
        "hometown": "Los Angeles",
        "description": "Come for a sticker, stay for a cup of “shut up and drink it!\"\r\n\r\nAvailable throughout the week at PNF:\r\n=Free Electroshock Therapy=\r\n=Consultations with the Philosoraptor=\r\n\r\n9PM Thursday: Ultra Violet Night\r\n>>energetic<< portraits \r\n(with black light body and face paint & props)\r\n\r\nNoon Sunday: Electric Dunkaroos!!!!!!!!!!",
        "location": {
            "string": "H & 4:45",
            "frontage": "H",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77384823164088,
            "gps_longitude": -119.20868207279557
        },
        "location_string": "H & 4:45"
    },
    {
        "uid": "a1Xd0000001IMR5EAO",
        "year": 2016,
        "name": "Mom Camp",
        "hometown": "Sun City",
        "description": "Mom Camp welcomes all to stop in for some non-judgmental, motherly advice, about anything on your mind, doled out with plenty of lemonade, cookies and \"been there, done that\" hindsight. Show up on Tuesday, at noon, for an introductory lesson in 108 Yang style tai chi.",
        "location": {
            "string": "G & 5:15",
            "frontage": "G",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77531107774246,
            "gps_longitude": -119.21256530891797
        },
        "location_string": "G & 5:15"
    },
    {
        "uid": "a1Xd0000001IV5sEAG",
        "year": 2016,
        "name": "DaVinci's Playground",
        "contact_email": "etothepi@gmail.com",
        "hometown": "San Francisco",
        "description": "Join us at DaVinci's Playground and attempt to solve our puzzle room. If you escape in time you will receive the highest honor bestowed upon any Renaissance Woman or Man. If you fail, you shall receive the greatest punishment befitting any mammering, ill-nurtured, malt-worm.",
        "location": {
            "string": "H & 4:45",
            "frontage": "H",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77384823164088,
            "gps_longitude": -119.20868207279557
        },
        "location_string": "H & 4:45"
    },
    {
        "uid": "a1Xd0000001IBLPEA4",
        "year": 2016,
        "name": "Corporation Chaos",
        "contact_email": "reality.apologist@gmail.com",
        "hometown": "Reno",
        "description": "Corporation Chaos is an insectile hivemind of academic philosophers, artists, aggressively nihilistic robots, and other diverse individuals.  As a result of several astute market activities, we own you, whether you like it or not.",
        "location": {
            "string": "H & 4:45",
            "frontage": "H",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77384823164088,
            "gps_longitude": -119.20868207279557
        },
        "location_string": "H & 4:45"
    },
    {
        "uid": "a1Xd0000001IVwaEAG",
        "year": 2016,
        "name": "Amulet",
        "contact_email": "campamulet@gmail.com",
        "hometown": "Castro Valley and Pebble Beach",
        "description": "Amulet- An ornament or small piece of jewelry thought to give protection against evil, anger or disease, power for stirring creative juices for new ideas, and bringing love and hope to a dreary life.  It is said that Da Vinci possessed an unusual amulet that he always kept close to him.  We wish to empower participants with similar protection and positive energy.  \r\n\r\nEntering our dome, our guests are invited to emboss letters, numbers, and symbols onto a brass plate (aka dog tag) or a brass disc; creating an Amulet to carry with them around their neck, or perhaps to gift to another.",
        "location": {
            "string": "G & 5:15",
            "frontage": "G",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77531107774246,
            "gps_longitude": -119.21256530891797
        },
        "location_string": "G & 5:15"
    },
    {
        "uid": "a1Xd0000001IT01EAG",
        "year": 2016,
        "name": "The Holding Pen",
        "location": {
            "string": "G & 5:15",
            "frontage": "G",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77531107774246,
            "gps_longitude": -119.21256530891797
        },
        "location_string": "G & 5:15"
    },
    {
        "uid": "a1Xd0000001IVSaEAO",
        "year": 2016,
        "name": "Sweet Dreams are made of Cheese",
        "hometown": "San Francisco",
        "description": "Grilled cheese to please your tastebuds!",
        "location": {
            "string": "G & 4:45",
            "frontage": "G",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20856873866927
        },
        "location_string": "G & 4:45"
    },
    {
        "uid": "a1Xd0000001IXlWEAW",
        "year": 2016,
        "name": "French Manila Legends Lore & Lumpia",
        "contact_email": "tanyareth@gmail.com",
        "hometown": "SAN FRANCISCO",
        "location": {
            "string": "G & 4:45",
            "frontage": "G",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20856873866927
        },
        "location_string": "G & 4:45"
    },
    {
        "uid": "a1Xd0000001IXLPEA4",
        "year": 2016,
        "name": "Cosmic Casbah",
        "contact_email": "cosmic.casbah@gmail.com",
        "hometown": "Concord",
        "description": "Cosmic Casbah provides to all wandering burners of the playa. Calling all adventurers to come relax under our palatial shade structure, and sip Persian tea at sunset, while adorning your body for the night's adventures. Come Rock the Casbah with us on Thursday, help us dance up a big ole cloud of dust!",
        "location": {
            "string": "G & 4:45",
            "frontage": "G",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20856873866927
        },
        "location_string": "G & 4:45"
    },
    {
        "uid": "a1Xd0000001IWtVEAW",
        "year": 2016,
        "name": "It's More Fun In The Philippines",
        "url": "http://www.jeepneyartcar.org",
        "contact_email": "jeepneyartcar@gmail.com",
        "hometown": "Manila / Los Angeles",
        "description": "The home base of the Jeepney Eagle Art Car, we're the only place on the playa serving chicken adobo. If you don't know what that is then bring a hungry tummy and let us inject you with island culture, food, and authentic Filipino coconut water!",
        "location": {
            "string": "I & 4:15",
            "frontage": "I",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77319619060326,
            "gps_longitude": -119.20420459530268
        },
        "location_string": "I & 4:15"
    },
    {
        "uid": "a1Xd0000001IXIVEA4",
        "year": 2016,
        "name": "Society for Temporal Preservation",
        "url": "https://www.facebook.com/groups/267817396884607/",
        "hometown": "DISTRICT 47, WESTERN PROVINCE, TERRA (located on former site of Reno, NV)",
        "description": "The Society for Temporal Preservation consists of time travelers tasked with preserving the fabric of space-time. The society welcomes travelers from any era or dimension and is ready to assist the temporally locked in altering their place within the framework of time and space.",
        "location": {
            "string": "H & 5:15",
            "frontage": "H",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.774703456388195,
            "gps_longitude": -119.21289759609604
        },
        "location_string": "H & 5:15"
    },
    {
        "uid": "a1Xd0000001IWPdEAO",
        "year": 2016,
        "name": "Shine Town",
        "contact_email": "shinetown2016@gmail.com",
        "hometown": "Seattle, Painesville, and Parker",
        "description": "Shine Town - Does it Burn? We have a Shot for that! Visit our Moonshine Bar for happy hour specials and daily themed events all week long in our shady dome!",
        "location": {
            "string": "H & 5:15",
            "frontage": "H",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.774703456388195,
            "gps_longitude": -119.21289759609604
        },
        "location_string": "H & 5:15"
    },
    {
        "uid": "a1Xd0000001ILomEAG",
        "year": 2016,
        "name": "Art Virgins XPO",
        "hometown": "San Jose CA & Portland OR",
        "description": "Visit the Art Virgins XPO camp to play a few games, relax on a bench engaging in conversation or even relax on the porch swing.  Be careful, you may be asked to step into the Banter Booth to engage the passerby to find out about how their burn is going.",
        "location": {
            "string": "I & 4:15",
            "frontage": "I",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77319619060326,
            "gps_longitude": -119.20420459530268
        },
        "location_string": "I & 4:15"
    },
    {
        "uid": "a1Xd0000001IXCDEA4",
        "year": 2016,
        "name": "Dr. Placebo's Snake Oil Emporium",
        "contact_email": "dazoulai@gmail.com",
        "hometown": "San Francisco",
        "description": "Feeling sad, tired, ill, weird, or anything else bad? Stop by for some snake oil medicine, and we'll turn you right around! You'll be carousing with renewed energy soon enough!",
        "location": {
            "string": "I & 4:45",
            "frontage": "I",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77319619060326,
            "gps_longitude": -119.20879540469736
        },
        "location_string": "I & 4:45"
    },
    {
        "uid": "a1Xd0000001IVIUEA4",
        "year": 2016,
        "name": "Solnishko",
        "url": "http://solnishko.webnode.com//",
        "contact_email": "mhmeln57@gmail.com",
        "hometown": "Berkeley",
        "description": "Solnishko - russian word for baby-sun. We are an eclectic group of Bay\r\nArea touchy-feelers, international russian affectionados and\r\nuncategorizable veteran burners. We will offer space for\r\nself-reflection and contact, rest and challenge, olfactory and body\r\nstimulation and facilitate sensory and sensible connections. We will\r\nrecreate the life-giving atmosphere of the Sun in our cozy dome,\r\nbeverages and snacks, in unapologetic soul mating rituals",
        "location": {
            "string": "H & 5:15",
            "frontage": "H",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.774703456388195,
            "gps_longitude": -119.21289759609604
        },
        "location_string": "H & 5:15"
    },
    {
        "uid": "a1Xd0000001IBVFEA4",
        "year": 2016,
        "name": "Dusty Disco",
        "url": "http://www.facebook.com/dustyd2016",
        "contact_email": "dustyd2016@gmail.com",
        "hometown": "Seattle",
        "location": {
            "string": "5:00 & F",
            "frontage": "5:00",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.77544177144894,
            "gps_longitude": -119.21037736405654
        },
        "location_string": "5:00 & F"
    },
    {
        "uid": "a1Xd0000001ILUrEAO",
        "year": 2016,
        "name": "Ski Patrol",
        "contact_email": "heyu420@gmail.com",
        "hometown": "Chicago/Phoenix",
        "description": "Ski Patrol : Procurers of WTF Moments",
        "location": {
            "string": "J & 4:45",
            "frontage": "J",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77254414945478,
            "gps_longitude": -119.2089087343747
        },
        "location_string": "J & 4:45"
    },
    {
        "uid": "a1Xd0000001IAz3EAG",
        "year": 2016,
        "name": "ZaZen",
        "url": "https://www.facebook.com/CampZaZen/",
        "hometown": "Park City",
        "description": "We know the playa can be overwhelming so let us be your sanctuary. Come \"Zen\" out in our Om Dome or Chill in Siddhartha's Lounge. Your sure to see a friendly face around Camp ZaZen",
        "location": {
            "string": "4:30 & D",
            "frontage": "4:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.776370604715595,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & D"
    },
    {
        "uid": "a1Xd0000001IR7ZEAW",
        "year": 2016,
        "name": "HARDLY",
        "url": "http://www.hardlybrc.com",
        "contact_email": "fuser@hardlybrc.com",
        "hometown": "Mountain View",
        "description": "for your convenience, whisky, salsa dancing, and welding..all in one spot.",
        "location": {
            "string": "4:30 & C",
            "frontage": "4:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.77702826998014,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & C"
    },
    {
        "uid": "a1Xd0000001IRr1EAG",
        "year": 2016,
        "name": "Pam's Parlor",
        "url": "http://pamsparlor.dance",
        "hometown": "Los Angeles",
        "description": "Come one, come all to Pam the Albino Mastodon's Tattoo Parlor! Burners are invited to take refuge from the heat and decorate themselves with silver-and-gold flash tattoos that will last the entire week of the Burn. Tattoo Time at Pam's Parlor will take place Monday-Friday from Noon-to-Sunset, but feel free to come by any time and say hello. We will also be hosting various events in the mornings, afternoons, and evenings throughout the week, including yoga classes, kung fu lessons, story time, DJ sets, and more!\r\n\r\nJust look for the shiny tent covered in intricately painted patterns! Inside you will find a plush arrangement of carpets, cushions, and couches, as well as several mirrors so that you can regard your beautifying handwork. We look forward to your visit!",
        "location": {
            "string": "7:00 & C",
            "frontage": "7:00",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.783973800845395,
            "gps_longitude": -119.21845544316932
        },
        "location_string": "7:00 & C"
    },
    {
        "uid": "a1Xd0000001ISOWEA4",
        "year": 2016,
        "name": "Orphan/Endorphin",
        "url": "http://orphanendorphin.com/index2.html",
        "contact_email": "orphanendorphin@gmail.com",
        "hometown": "Denver",
        "description": "We are the heart of the Renaissance, and the social NEXUS of the Orphanage camps. Orphan/Endorphin camp is where the \"medici\" reside and it's craftsmen build a haven of relaxation and entertainment. Our THEME camp will feature OVER (200) feet of street front interactivity for the citizens of Black Rock City to partake in.",
        "location": {
            "string": "7:00 & C",
            "frontage": "7:00",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.783973800845395,
            "gps_longitude": -119.21845544316932
        },
        "location_string": "7:00 & C"
    },
    {
        "uid": "a1Xd0000001IVlNEAW",
        "year": 2016,
        "name": "Mystopia",
        "url": "http://www.mystopia.camp",
        "contact_email": "mystopia@gmail.com",
        "hometown": "San Francisco",
        "description": "We're a desert experiment. A French Toast Mecca. A home for mysterious misters. A Burner family that tastes the rainbow. Come play with us!",
        "location": {
            "string": "7:00 & F",
            "frontage": "7:00",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.78346286486039,
            "gps_longitude": -119.22097226725704
        },
        "location_string": "7:00 & F"
    },
    {
        "uid": "a1Xd0000001IV2tEAG",
        "year": 2016,
        "name": "Kindergarten Kamp",
        "hometown": "Auburn",
        "description": "Kindergarten Kamp is bringing it's playground out for your enjoyment - kids of all ages (families, friends and all playa peeps) are welcome to enjoy our swings, trampoline, and teeter-totter, mini teeter totter, and the big games tent.  In the Gnome dome, hookah time and Swag poker will happen two nights - bring lots of swag!  You will also be able to relax in our Moroccan themed Monkey-Hut complex.",
        "location": {
            "string": "6:30 & A",
            "frontage": "6:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.78237143378006,
            "gps_longitude": -119.21571431975059
        },
        "location_string": "6:30 & A"
    },
    {
        "uid": "a1Xd0000001IXNuEAO",
        "year": 2016,
        "name": "Anahasana Village",
        "url": "http://anahasanavillage.org",
        "contact_email": "dance@campcontact.org",
        "description": "Anahasana Village brings awareness to a fully embodied knowing of the power and the wisdom of our own hearts.  We dance with lyrical sensitivity of our selves in relationship to others as the infinite echo of radiant appreciation.",
        "location": {
            "string": "7:00 & E",
            "frontage": "7:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78363318293099,
            "gps_longitude": -119.22013333019713
        },
        "location_string": "7:00 & E"
    },
    {
        "uid": "a1Xd0000001IRhQEAW",
        "year": 2016,
        "name": "Camp NYCHI",
        "contact_email": "karla@wearenychi.com",
        "hometown": "New York City",
        "description": "Welcome to Camp NYCHI, where you can find the best of NYC right here on the playa. Come enjoy classic bodega treats & essentials, boogie to your favorite NY hip hop and dancehall beats in our chill dome and enjoy a periscope view of the playa from our viewing platform.",
        "location": {
            "string": "6:30 & B",
            "frontage": "6:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.78204253887612,
            "gps_longitude": -119.21646645976782
        },
        "location_string": "6:30 & B"
    },
    {
        "uid": "a1Xd0000001IO3OEAW",
        "year": 2016,
        "name": "Contraptionists",
        "url": "http://contraptionists.com/",
        "hometown": "Black Rock City",
        "description": "Contraptionists are hosting Morning Yoga, afternoon snowcones and firefries 1-3 m.-sa., 2kimmies Boutique, Lecture hall subjects, Get drunk and Fix your ,, stuff, and evening movies and astronomy lessons. Stop by and check the schedule of events for details.",
        "location": {
            "string": "7:00 & E",
            "frontage": "7:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78363318293099,
            "gps_longitude": -119.22013333019713
        },
        "location_string": "7:00 & E"
    },
    {
        "uid": "a1Xd0000001IGuZEAW",
        "year": 2016,
        "name": "Dodgeball Addiction",
        "url": "https://www.facebook.com/DodgeballAddiction/",
        "contact_email": "m@hifm.us",
        "hometown": "San Diego",
        "description": "Nighttime dodgeball is back! Music, heckling, yelling and dodgeball! 14 or older please.",
        "location": {
            "string": "6:30 & C",
            "frontage": "6:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.781713639088856,
            "gps_longitude": -119.21721859233622
        },
        "location_string": "6:30 & C"
    },
    {
        "uid": "a1Xd0000001IJFuEAO",
        "year": 2016,
        "name": "Barbie Death Village",
        "url": "https://facebook.com/barbiedeathvillage",
        "contact_email": "jimdrpyro@aol.com",
        "hometown": "Newcastle",
        "description": "www.barbiedeathcamp.com",
        "location": {
            "string": "6:30 & E",
            "frontage": "6:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78105582486477,
            "gps_longitude": -119.21872283512668
        },
        "location_string": "6:30 & E"
    },
    {
        "uid": "a1Xd0000001IPk6EAG",
        "year": 2016,
        "name": "Radio Electra",
        "url": "http://www.radio-electra.com",
        "contact_email": "rockstar@burningman.org",
        "hometown": "Tucson",
        "description": "Radio Electra 89.9 FM. Once again we return offering an Electra Eclectic array of music, mayhem, commentary and art. Camps, villages,and artists wishing to make radio announcements about events may stop in or contact us by email prior to the event. Please feel free to email us or drop off any prerecorded announcements you may have. You can even come in for a live interview. We want to hear from you about what you do to participate. Stop in, Tune in, Participate, Enjoy!",
        "location": {
            "string": "6:30 & A",
            "frontage": "6:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.78237143378006,
            "gps_longitude": -119.21571431975059
        },
        "location_string": "6:30 & A"
    },
    {
        "uid": "a1Xd0000001IWSwEAO",
        "year": 2016,
        "name": "Polegasm",
        "url": "http://www.polegasm.org",
        "contact_email": "burningman@freemovementzone.com",
        "hometown": "Seattle",
        "description": "Come over to our exclusive facility. We provide the best equipment and instruction there is for creative essence, existential growth, and Polegasms!",
        "location": {
            "string": "7:30 Plaza @ 2:30",
            "frontage": "7:30 Plaza",
            "intersection": "2:30",
            "intersection_type": "@",
            "gps_latitude": 40.774486075049204,
            "gps_longitude": -119.20606303960487
        },
        "location_string": "7:30 Plaza @ 2:30"
    },
    {
        "uid": "a1Xd0000001IVvhEAG",
        "year": 2016,
        "name": "Do More Now",
        "url": "http://www.do-more-now.com/",
        "contact_email": "chad@do-more-now.com",
        "hometown": "Everett",
        "description": "Each year camp Do-More-Now brings to Burning Man the Firehouse, a five story building providing a relaxing hangout, one of the best views on the playa, a bar, and a space and materials for people to create awesome art. In addition we host bands, fire dancers and hold themed parties most evenings and award winning morning Mimosa bar.",
        "location": {
            "string": "7:30 & B",
            "frontage": "7:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.786399428284064,
            "gps_longitude": -119.21800903146068
        },
        "location_string": "7:30 & B"
    },
    {
        "uid": "a1Xd0000001IPJ3EAO",
        "year": 2016,
        "name": "Decadent Oasis",
        "url": "http://www.decadentoasis.com",
        "contact_email": "info@dcdnt.org",
        "hometown": "San Francisco / Oakland",
        "description": "A glowing multicolored oasis in the dark of night, a windswept grove of white palm trees by day--our magical oasis and sheltered lounge welcome you to dance, play, perform, and chill. Slack lines, giant twister, games, DJ's, day/night dance parties, hula hoops, and friendly folks all around--in an eco-conscious camp made from mostly reclaimed/reused materials.",
        "location": {
            "string": "7:30 Plaza @ 10:30",
            "frontage": "7:30 Plaza",
            "intersection": "10:30",
            "intersection_type": "@",
            "gps_latitude": 40.77463967096871,
            "gps_longitude": -119.20682001399814
        },
        "location_string": "7:30 Plaza @ 10:30"
    },
    {
        "uid": "a1Xd0000001IT14EAG",
        "year": 2016,
        "name": "PANORAMA",
        "url": "https://www.facebook.com/PANORAMAplatform",
        "contact_email": "camppanorama@gmail.com",
        "hometown": "Seattle",
        "description": "PANORAMA offers 24 hour unobstructed 360 degree views of Black Rock City and the surrounding environment from 30 feet above the playa. Most climb stairs every day, but rarely do we do it with a sense of excitement over what we can gain by reaching the top! Join your fellow citizens in elevating your perspective!",
        "location": {
            "string": "7:30 & H",
            "frontage": "7:30",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.78639879327029,
            "gps_longitude": -119.22322066824192
        },
        "location_string": "7:30 & H"
    },
    {
        "uid": "a1Xd0000001IWReEAO",
        "year": 2016,
        "name": "Vault 21+",
        "hometown": "Seattle",
        "description": "We have emerged from our vault to find wasteland denizens are much friendlier than anticipated. With any luck we will be able to convince them to help us fix our Large Hardon Collider and dispose of radioactive insects that plague us. Our soda fountain serves only the finest in golden age beverages, music, and karaoke.",
        "location": {
            "string": "7:30 Plaza @ 12:30",
            "frontage": "7:30 Plaza",
            "intersection": "12:30",
            "intersection_type": "@",
            "gps_latitude": 40.774728443266795,
            "gps_longitude": -119.20638281371313
        },
        "location_string": "7:30 Plaza @ 12:30"
    },
    {
        "uid": "a1Xd0000001IBfvEAG",
        "year": 2016,
        "name": "Crackwhore Camp",
        "contact_email": "drameowing@hotmail.com",
        "hometown": "Portland",
        "location": {
            "string": "7:30 & E",
            "frontage": "7:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78639914008551,
            "gps_longitude": -119.22061484986375
        },
        "location_string": "7:30 & E"
    },
    {
        "uid": "a1Xd0000001IZ0rEAG",
        "year": 2016,
        "name": "Lenivets Park",
        "url": "https://www.facebook.com/groups/1741566139411438/",
        "contact_email": "makhalych2016@gmail.com",
        "hometown": "Nikola-Lenivets, GPS 54.75782,35.60123",
        "description": "Lenivets Park is the first Burning Man camp-site of the largest art-park in Russia Nikola-Lenivets (~from rus. ленивец [lenivets] = slothful, sloth). The first project being brought this year by our team is a kinetic sculpture MAHALYCH (Birding Man) designed by the co-founder of Nicola-Lenivets, architect Vasily Shchetinin.",
        "location": {
            "string": "7:30 & J",
            "frontage": "7:30",
            "intersection": "J",
            "intersection_type": "&",
            "gps_latitude": 40.78639852949534,
            "gps_longitude": -119.22495788047792
        },
        "location_string": "7:30 & J"
    },
    {
        "uid": "a1Xd0000001IErgEAG",
        "year": 2016,
        "name": "Emergency Services Station 7:30",
        "location": {
            "string": "7:30 & H",
            "frontage": "7:30",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.78639879327029,
            "gps_longitude": -119.22322066824192
        },
        "location_string": "7:30 & H"
    },
    {
        "uid": "a1Xd0000001IWWPEA4",
        "year": 2016,
        "name": "RealDilla",
        "contact_email": "semper_paratus@rocketmail.com",
        "hometown": "sacrmento",
        "description": "RealDilla. A fun loving group of burners from Sacramento geared up to serve you Quesadillas and libations and dance, party and play with you!",
        "location": {
            "string": "7:30 & B",
            "frontage": "7:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.786399428284064,
            "gps_longitude": -119.21800903146068
        },
        "location_string": "7:30 & B"
    },
    {
        "uid": "a1Xd0000001IV38EAG",
        "year": 2016,
        "name": "Interaction Café",
        "hometown": "Oakland",
        "description": "At the Interaction Cafe we create a space where servers get to create their ideal burning man experience by choosing interactions to guests who come by, and guests in turn get to choose whichever of their offerings tickles their fancy. The result is consensual weird and wonderful experiences. It's hard to leave our camp, because you never know what might happen next. One moment it's sweet and moving, and the next it's rowdy and hysterical.",
        "location": {
            "string": "7:30 & I",
            "frontage": "7:30",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.786398664639286,
            "gps_longitude": -119.22408927436165
        },
        "location_string": "7:30 & I"
    },
    {
        "uid": "a1Xd0000001IXNkEAO",
        "year": 2016,
        "name": "The New Barbarians",
        "url": "https://www.facebook.com/jurassicporkofficial/",
        "contact_email": "thenewbarbarianscamp@gmail.com",
        "hometown": "San Francisco",
        "description": "Moving beyond the confines of a traditional food camp, The New Barbarians quest to provide subsistence and endless comfort in a desert land full of desire, self-discovery, and radical transformation.  Come join our barbarian tribe from 1-2pm daily to participate in our dusty savage nourishment project!",
        "location": {
            "string": "7:30 & A",
            "frontage": "7:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.78639951132433,
            "gps_longitude": -119.21714042532156
        },
        "location_string": "7:30 & A"
    },
    {
        "uid": "a1Xd0000001IXQyEAO",
        "year": 2016,
        "name": "Wrongtown",
        "url": "http://wrongtown.wikia.com/wiki/Wrongtown_Wikia",
        "contact_email": "wrongtown.burningman@gmail.com",
        "hometown": "Oakland, LA",
        "description": "Old school ravers, festival kids, and burners from the U.S., Canada, Australia, Germany and Japan. The most seasoned of our crew have been to almost every burn since 1999. Wrongtown is back and supporting \"Dream Machine Guild\" from Japan at the base of the man.",
        "location": {
            "string": "A & 6:45",
            "frontage": "A",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.783312752183654,
            "gps_longitude": -119.21632781749565
        },
        "location_string": "A & 6:45"
    },
    {
        "uid": "a1Xd0000001IZQpEAO",
        "year": 2016,
        "name": "Artech",
        "url": "http://www.artechreno.org",
        "contact_email": "quinn@artechreno.org",
        "hometown": "Reno",
        "description": "Artech, facilitating the relationship between sustainable artistic creativity, broad collaborative endeavors and technology.",
        "location": {
            "string": "A & 6:45",
            "frontage": "A",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.783312752183654,
            "gps_longitude": -119.21632781749565
        },
        "location_string": "A & 6:45"
    },
    {
        "uid": "a1Xd0000001IWjuEAG",
        "year": 2016,
        "name": "Eastern Lights",
        "url": "http://eastern-lights.com",
        "hometown": "Beijing",
        "description": "At Burning Man we want to break down barriers and embrace and welcome everyone to exchange thoughts, ideas and creativity with us. To do so, we want to set up our camp called \"Eastern Lights\".",
        "location": {
            "string": "8:00 & F",
            "frontage": "8:00",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.78933532694866,
            "gps_longitude": -119.22097354706476
        },
        "location_string": "8:00 & F"
    },
    {
        "uid": "a1Xd0000001IWRFEA4",
        "year": 2016,
        "name": "The G-Spot",
        "hometown": "SF Bay, L.A., Seattle, Pollock Pines, CT, GB",
        "description": "The G-Spot, stop by and enjoy our pleasures. Remember if you can't find us you are not coming!",
        "location": {
            "string": "A & 7:15",
            "frontage": "A",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.785344061740865,
            "gps_longitude": -119.21704843724241
        },
        "location_string": "A & 7:15"
    },
    {
        "uid": "a1Xd0000001IX52EAG",
        "year": 2016,
        "name": "Chameleon Camp",
        "url": "http://chameleoncamp.com",
        "hometown": "Corvallis",
        "description": "Chameleon Camp is your home for amazing company and food! Swing by in the morning Monday through Friday to get some delicious, multicolored, chameleon-shaped pancakes. Feel free to come by anytime to relax in our Ham-Dome, visit the Inflatable Chameleon, or just chill in the shade with some amazing people. Come visit!",
        "location": {
            "string": "A & 6:45",
            "frontage": "A",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.783312752183654,
            "gps_longitude": -119.21632781749565
        },
        "location_string": "A & 6:45"
    },
    {
        "uid": "a1Xd0000001IOBJEA4",
        "year": 2016,
        "name": "Firmament",
        "url": "http://pbase.com/schardt/firmament",
        "hometown": "Oakland",
        "description": "Home base for the art piece, Firmament.",
        "location": {
            "string": "A & 7:45",
            "frontage": "A",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.787447181052784,
            "gps_longitude": -119.2170501269583
        },
        "location_string": "A & 7:45"
    },
    {
        "uid": "a1Xd0000001IXaEEAW",
        "year": 2016,
        "name": "DeMaTerial",
        "contact_email": "campdematerial@gmail.com",
        "hometown": "San Francisco (primary), Los Angeles, Sydney, Cape Town",
        "description": "DeMaTerial once again returns to the playa! Our international diaspora of American, Australian, South African, and other burners from across the globe welcomes you to our fantastic dome. Featuring a Bloody Mary bar in the morning, Licensing Bureau during the day, and Silent Disco at night. (Rumor has it our Aussies are setting up a low-water hair salon and running morning yoga on Wednesday, too!)",
        "location": {
            "string": "7:30 Plaza @ 8:30",
            "frontage": "7:30 Plaza",
            "intersection": "8:30",
            "intersection_type": "@",
            "gps_latitude": 40.774308770783165,
            "gps_longitude": -119.20693682818681
        },
        "location_string": "7:30 Plaza @ 8:30"
    },
    {
        "uid": "a1Xd0000001IUwYEAW",
        "year": 2016,
        "name": "MacGyvers' Union",
        "url": "http://www.macgyversunion.com",
        "contact_email": "contact@macgyversunion.com",
        "hometown": "Oakland",
        "description": "Every camp has a MacGyver -- now the MacGyvers have a union. We provide all MacGyvers with recognition, thanks, tools, training, entertainment, emotional and moral support, chill space away from their home camp, and an official ID card.",
        "location": {
            "string": "A & 7:15",
            "frontage": "A",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.785344061740865,
            "gps_longitude": -119.21704843724241
        },
        "location_string": "A & 7:15"
    },
    {
        "uid": "a1Xd0000001IXG5EAO",
        "year": 2016,
        "name": "Gears & Beers",
        "hometown": "Seattle",
        "description": "Gears & Beers Returns for another round.  Come join us for the best beer on the playa,  or better yet come learn how to weld!\r\n\r\nTuesdays & Thursdays we will be available to teach you the craft!\r\n\r\nBar is almost always,  nearly just about, most of the time.... OPEN!",
        "location": {
            "string": "7:30 Portal & 7:30 Portal",
            "frontage": "7:30 Portal",
            "intersection": "7:30 Portal",
            "intersection_type": "&"
        },
        "location_string": "7:30 Portal & 7:30 Portal"
    },
    {
        "uid": "a1Xd0000001IWscEAG",
        "year": 2016,
        "name": "Shipwreck Tiki Lounge",
        "url": "http://www.facebook.com/shipwrecktikilounge",
        "hometown": "Oakland",
        "description": "While working passage on a Norwegian steamer we picked up a castaway from the water, he'd been drifting for weeks way west of Sumatra, a thousand miles outside the shipping lanes his ship had run aground on on a uncharted island hidden in deep fog.  They said there's nothing out there but back then there were many blank spaces on the map, a place thought only to exist in myth until now...",
        "location": {
            "string": "7:30 Plaza @ 9:30",
            "frontage": "7:30 Plaza",
            "intersection": "9:30",
            "intersection_type": "@",
            "gps_latitude": 40.77448607504918,
            "gps_longitude": -119.20693696039518
        },
        "location_string": "7:30 Plaza @ 9:30"
    },
    {
        "uid": "a1Xd0000001IWk4EAG",
        "year": 2016,
        "name": "Mazu",
        "url": "http://dreamcommunity.tw/mazu-theme-camp/",
        "contact_email": "campmazu@gmail.com",
        "hometown": "New Taipei City",
        "description": "In Taiwan, people place faith in Mazu, the Taoist deity of the sea, to give them courage against adversity and confidence to pursue better lives. Come participate in Mazu purification rites that release negative energy and help one find inner balance.",
        "location": {
            "string": "8:00 & G",
            "frontage": "8:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.78950543537275,
            "gps_longitude": -119.22181263250638
        },
        "location_string": "8:00 & G"
    },
    {
        "uid": "a1Xd0000001IV2UEAW",
        "year": 2016,
        "name": "Phil-Tea Bitches",
        "contact_email": "swampy@burningman.org",
        "hometown": "Tu Madre",
        "description": "Camp [Phil] in the Blank & Bitch 'n' Tea bring you: Phil-Tea Bitches Village! Stupidity to be expected: Phil's Putt Putt in the Butt Butt (mini golf course) &  the ability to unload your burdens in exchange for some bitchin' tea. See your whiney asses there.",
        "location": {
            "string": "8:00 & B",
            "frontage": "8:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.788654832474464,
            "gps_longitude": -119.21761724829089
        },
        "location_string": "8:00 & B"
    },
    {
        "uid": "a1Xd0000001IVovEAG",
        "year": 2016,
        "name": "Mission Country Club",
        "url": "http://www.missioncountryclub.com",
        "contact_email": "birdsandblokes@missioncountryclub.com",
        "hometown": "San Francisco",
        "description": "Mission Country Club is an organically-grown camp, consisting of friends and family from San Francisco, Reno, Los Angeles, Washington DC, Boston, New York, Ireland, Germany, Belgium and beyond. 2016 will be our 13th year on the playa as an organized camp. We've been the home of the Magic Kurry Cart, Sangria Soundclash, BRC Hip-Hop Playa Ball and Bugaboo the MV over the years. We're here to bring a taste of San Francisco's Mission District to Black Rock City. Don't forget to check the book for MCC's 2016 events like the BRC Hip-Hop Playa Ball and the Sangria Soundclash!",
        "location": {
            "string": "8:00 & A",
            "frontage": "8:00",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.78848469366183,
            "gps_longitude": -119.2167781843461
        },
        "location_string": "8:00 & A"
    },
    {
        "uid": "a1Xd0000001IRinEAG",
        "year": 2016,
        "name": "Cross-World Camp",
        "hometown": "Moscow",
        "location": {
            "string": "A & 7:45",
            "frontage": "A",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.787447181052784,
            "gps_longitude": -119.2170501269583
        },
        "location_string": "A & 7:45"
    },
    {
        "uid": "a1Xd0000001IOx1EAG",
        "year": 2016,
        "name": "Twilight Spaghetti Theatre",
        "url": "http://twilight-spaghetti-theatre.blogspot.com/",
        "contact_email": "twilightspaghetti@gmail.com",
        "hometown": "San Francisco",
        "description": "Perform for your chance to slurp our hot wet noodles. This is your chance to show off your under-appreciated talents on our custom built stage for a spaghetti dinner!",
        "location": {
            "string": "A & 6:45",
            "frontage": "A",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.783312752183654,
            "gps_longitude": -119.21632781749565
        },
        "location_string": "A & 6:45"
    },
    {
        "uid": "a1Xd0000001IX49EAG",
        "year": 2016,
        "name": "Dusty Lusty",
        "contact_email": "dustylustybrc@gmail.com",
        "hometown": "San Francisco",
        "description": "Find your dusty lover with our playa grindr matchmaking board! Join us for tasty quesadillas and badminton, geared for queers and friends to dance, eat, and make plans for later. Quesadillas served Tuesday through Friday, 12pm-1pm.",
        "location": {
            "string": "A & 7:15",
            "frontage": "A",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.785344061740865,
            "gps_longitude": -119.21704843724241
        },
        "location_string": "A & 7:15"
    },
    {
        "uid": "a1Xd0000002ygwVEAQ",
        "year": 2016,
        "name": "BAAAHS Station",
        "url": "http://baaahs.org",
        "contact_email": "info@baaahs.org",
        "hometown": "San Francisco",
        "description": "BAAAHS Station is the central depot and homo-licious home on the range to BAAAHS, the Big-Ass Amazingly Awesome Homosexual Sheep - part mutant vehicle, part penetrable sculpture and part rolling disco. Weary travelers: come set for a spell, kick up your hooves and dance, or begin a new journey as you slide through a pulsing pink sphincter into the luscious cocoon of his polyphonic peritoneum.",
        "location": {
            "string": "8:00 & H",
            "frontage": "8:00",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.78967553771895,
            "gps_longitude": -119.22265172224701
        },
        "location_string": "8:00 & H"
    },
    {
        "uid": "a1Xd0000001IR3mEAG",
        "year": 2016,
        "name": "Tickled Mink",
        "url": "http://www.tickledmink.com",
        "contact_email": "wink@tickledmink.com",
        "hometown": "San Francisco",
        "description": "At Tickled Mink (where everyone is a star!) we are here to help you pretty yourself at our our movie star mirror before you start channeling your inner diva. If you don't know how, we'll teach you to smeyes so once you step into our plush, fake fur lined photo booth you'll be ready to strike a glamorous cover page pose when the flashes pop.",
        "location": {
            "string": "B & 7:15",
            "frontage": "B",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78525786330597,
            "gps_longitude": -119.21790952809974
        },
        "location_string": "B & 7:15"
    },
    {
        "uid": "a1Xd0000001IVJhEAO",
        "year": 2016,
        "name": "Bike Gods",
        "url": "http://thebikegods.com",
        "contact_email": "info@thebikegods.com",
        "hometown": "Reno and Boulder",
        "description": "Bike trouble got ya down? Come visit the Bike Gods, where we practice holistic bike medicine; we treat both the bike and the owner. During our full service repair hours you will never stand in line. Simply take a number, grab a refreshment, chillax, socialize in our lounge/day spa, and let our attentive staff wait on you. When our Gods are off duty or if you can handle simple repairs, our DIY Bike Portals are stocked and available 24x7. Out on the Playa, look for our Lanterne Rouge art car for Artery art tours. After midnight, look for our bike-drawn Shangri-Lounge martini bar \"somewhere\" out in deep playa. If you can find it, we offer classy, table-side cocktails in lounge comfort while listening to the sounds of Frank Sinatra and other great analog waves of goodness.",
        "location": {
            "string": "C & 6:45",
            "frontage": "C",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.782808722545894,
            "gps_longitude": -119.21793232467711
        },
        "location_string": "C & 6:45"
    },
    {
        "uid": "a1Xd0000001ITA4EAO",
        "year": 2016,
        "name": "dust & stars",
        "hometown": "los angeles",
        "description": "~* dust & stars *~ is a celestial experience! come play a round of queer-friendly Spin the Bottle Rocket, enjoy seven minutes of fun in star-spangled Heaven, or pose in front of our giant Rainbow Galaxy Wings. you can also take or leave something at our Gifting Tree, cool down in an Intergalactic water gun fight, or join us for a late-night warm-up around our fire pit -- and of course, enjoy a Cosmic Cocktail or Sparkle Shot (with edible glitter!) at our Star Bar.",
        "location": {
            "string": "B & 6:45",
            "frontage": "B",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.783060736985135,
            "gps_longitude": -119.2171300722949
        },
        "location_string": "B & 6:45"
    },
    {
        "uid": "a1Xd0000001IVuZEAW",
        "year": 2016,
        "name": "Camp Pendant",
        "url": "https://www.facebook.com/CampPendant",
        "hometown": "Laguna Niguel",
        "description": "Camp Pendant, where everybody knows your name... once you tell us what it us. Come by and pick up one of this year's awesome pendants, rest your weary feet, tell us how your year has been, andVitruviMan yourself. While you're here, don't forget to pay the Gifting Tree a visit. Whether you take a little something or leave a little something, she's here to make everyone's day a little brighter.",
        "location": {
            "string": "B & 7:15",
            "frontage": "B",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78525786330597,
            "gps_longitude": -119.21790952809974
        },
        "location_string": "B & 7:15"
    },
    {
        "uid": "a1Xd0000001IRsdEAG",
        "year": 2016,
        "name": "Pink Lightning",
        "url": "http://www.burningman50k.com",
        "hometown": "brooklyn",
        "description": "Pink Lightning is the home of the Burning Man Ultramarathon, the Black Rock City 5k, the Beer Mile, and lots of yoga. We're a home for runners, and those who love them!",
        "location": {
            "string": "C & 6:45",
            "frontage": "C",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.782808722545894,
            "gps_longitude": -119.21793232467711
        },
        "location_string": "C & 6:45"
    },
    {
        "uid": "a1Xd0000001IPdeEAG",
        "year": 2016,
        "name": "Astro Cats",
        "url": "https://www.facebook.com/groups/Astrocats.2014/",
        "contact_email": "astrocatscamp@gmail.com",
        "hometown": "San Francisco",
        "description": "We invite all burners to chill at the Astro Lounge with special drinks in the day and hot or cold sake at the DaVinci's Dragon Lounge for at night. You can enjoy acrobatic performance and workshops at scheduled time, and a place to practice and spin fire with us. If you like to join our kitties for morning yoga, bring your mat to stretch and pose with us. You can swing on our swinging-chairs and watch people passing by while sipping our special drinks. Or you can challenge yourself to manipulate the LED Matrix, walking on plank and play the game of Simon Says while enjoy sake.",
        "location": {
            "string": "B & 6:45",
            "frontage": "B",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.783060736985135,
            "gps_longitude": -119.2171300722949
        },
        "location_string": "B & 6:45"
    },
    {
        "uid": "a1Xd0000001IX44EAG",
        "year": 2016,
        "name": "Its All Fun and Gaymes",
        "hometown": "Sacramento",
        "description": "Its All Fun and Gaymes.. until someone pokes their eye out.. then its a Game #FindTheEyeball Stop by anytime day or night to play in our Giant game garden filled with all of your childhood favorites!",
        "location": {
            "string": "B & 7:45",
            "frontage": "B",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78753266605781,
            "gps_longitude": -119.21791137024913
        },
        "location_string": "B & 7:45"
    },
    {
        "uid": "a1Xd0000001IXRIEA4",
        "year": 2016,
        "name": "Bierdhaus",
        "hometown": "San Francisco",
        "description": "Bierdhaus. Home of the Beard Love.",
        "location": {
            "string": "B & 7:45",
            "frontage": "B",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78753266605781,
            "gps_longitude": -119.21791137024913
        },
        "location_string": "B & 7:45"
    },
    {
        "uid": "a1Xd0000001IXIkEAO",
        "year": 2016,
        "name": "Cubhouse",
        "url": "https://www.facebook.com/CBHSSF",
        "hometown": "San Francisco",
        "description": "Cubhouse brings house party vibes to the Playa. Music, dancing, games and best of all good company.  ¡Mi casa es su casa! So come over and make yourself at home in the Cubhouse!",
        "location": {
            "string": "B & 7:45",
            "frontage": "B",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78753266605781,
            "gps_longitude": -119.21791137024913
        },
        "location_string": "B & 7:45"
    },
    {
        "uid": "a1Xd0000001IX23EAG",
        "year": 2016,
        "name": "FUN-DO BAR!",
        "url": "https://www.facebook.com/Fun-Do-Bar-223999570977223/?ref=aymt_homepage_panel",
        "hometown": "San Diego",
        "description": "Serving Cheese and Chocolate Fondue and a whole lot of FUN!",
        "location": {
            "string": "B & 6:45",
            "frontage": "B",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.783060736985135,
            "gps_longitude": -119.2171300722949
        },
        "location_string": "B & 6:45"
    },
    {
        "uid": "a1Xd0000001IB2mEAG",
        "year": 2016,
        "name": "Mudskippers Urban Decay Cafe",
        "url": "http://www.mudskippercafe.com",
        "contact_email": "info2016@mudskippercafe.com",
        "hometown": "Palm Springs, CA & San Franciso, CA",
        "description": "The Mudskipper Urban Decay Cafe is a close knit gay-friendly diverse camp with a history at burning man that goes back to 1993, Come chill out in our jungle themed smoothie cafe or get a finger & toe nail make over in our amazing Beauty Bar, all are welcome!!!!",
        "location": {
            "string": "B & 7:45",
            "frontage": "B",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78753266605781,
            "gps_longitude": -119.21791137024913
        },
        "location_string": "B & 7:45"
    },
    {
        "uid": "a1Xd0000001IXNpEAO",
        "year": 2016,
        "name": "Pretentious Fox",
        "url": "http://www.facebook.com/pretentiousfox",
        "contact_email": "info@pretentiousfox.com",
        "hometown": "San Francisco, Chicago, LA, NYC",
        "description": "A very international and inter-state gathering of pretentious foxes and other eclectic and venerable animals! We provide an essential neighborhood BAR with good MUSIC, a giant SWINGSET, and several EVENTS including Bloody Mary Brunch!",
        "location": {
            "string": "C & 6:45",
            "frontage": "C",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.782808722545894,
            "gps_longitude": -119.21793232467711
        },
        "location_string": "C & 6:45"
    },
    {
        "uid": "a1Xd0000001IKGLEA4",
        "year": 2016,
        "name": "Dilated Peoples",
        "url": "https://www.facebook.com/dilatedpeeps",
        "contact_email": "dilatedpeeps@gmail.com",
        "hometown": "San Francisco",
        "description": "Expand your inner vision while indulging your senses. A soothing treatment of refreshing eye drops, cucumber slices and a cooling facial gel-pack awaits you...followed by a meditative lavender-scented eye pillow surrounded by the enchanting healing powers of the Dilated Peoples Eye Spa. Before and after your spa experience, enjoy herbal tea in our lounge.",
        "location": {
            "string": "C & 7:45",
            "frontage": "C",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78761815118928,
            "gps_longitude": -119.21877261481393
        },
        "location_string": "C & 7:45"
    },
    {
        "uid": "a1Xd0000001IOxaEAG",
        "year": 2016,
        "name": "Inconvenience Camp",
        "url": "https://www.facebook.com/groups/168166330201564/",
        "contact_email": "piperpunk17@yahoo.com",
        "hometown": "Reno",
        "description": "Your home for fabulous 50's themed game shows, cocktails, and atomic age distractions. Participation is encouraged, Inconvenience is mandatory.",
        "location": {
            "string": "C & 7:15",
            "frontage": "C",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78517166496261,
            "gps_longitude": -119.21877061804274
        },
        "location_string": "C & 7:15"
    },
    {
        "uid": "a1Xd0000001IOalEAG",
        "year": 2016,
        "name": "Valhalla on the Playa",
        "location": {
            "string": "D & 6:45",
            "frontage": "D",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78255670886589,
            "gps_longitude": -119.2187345746424
        },
        "location_string": "D & 6:45"
    },
    {
        "uid": "a1Xd0000001IQSDEA4",
        "year": 2016,
        "name": "Pigmalions",
        "hometown": "San Francisco",
        "description": "Calling all piggies and pork lovers. Bacon and bloodies when you squeal -- Soowee!",
        "location": {
            "string": "D & 7:15",
            "frontage": "D",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78508546671077,
            "gps_longitude": -119.21963170707147
        },
        "location_string": "D & 7:15"
    },
    {
        "uid": "a1Xd0000001IT2PEAW",
        "year": 2016,
        "name": "Essence",
        "url": "http://www.essentia.com/cards/introduction.htm",
        "hometown": "San Diego",
        "description": "Essence is home of the Essentia Card Deck and the Light Seed Lamps.  Look for our beautiful color changing lamps that illuminate the inspiring mural in front of our camp, and stop by for a personal card reading.",
        "location": {
            "string": "D & 7:15",
            "frontage": "D",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78508546671077,
            "gps_longitude": -119.21963170707147
        },
        "location_string": "D & 7:15"
    },
    {
        "uid": "a1Xd0000001IRKMEA4",
        "year": 2016,
        "name": "Simian Akademy",
        "url": "http://simianakademy.com",
        "contact_email": "email@simianakademy.com",
        "hometown": "Boulder",
        "description": "Bike broken and nowhere to turn?  Well, you may be 'all thumbs' but if at least two are opposable, we can help you fix it!  (And if not, we'll help you break it altogether!)  Here at Simian Akademy, our mission is to help you gain the skills necessary to adapt to today's dynamic, ever-changing playa environment.  Our dedicated team of trained monkeys will show you where it goes and how to work it.  If a trained monkey can do it, you can too!\r\n\r\nLooking for a truly unique and interactive experience?  Come visit the Olfactorium where our Mistress of Scent will concoct a custom perfume just for you, based on your unique, personal preferences.\r\n\r\nFeeling cranky from the heat?  Your new best friend getting on your nerves already?  You need to CHILL THE FUCK OUT AND COLOR!  Come visit our shaded dome to relax and color your frustrations away.  Choose your favorite, beautifully embellished swear word, or perhaps a picture of unicorns being total jerks!",
        "location": {
            "string": "C & 7:15",
            "frontage": "C",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78517166496261,
            "gps_longitude": -119.21877061804274
        },
        "location_string": "C & 7:15"
    },
    {
        "uid": "a1Xd0000001IKf7EAG",
        "year": 2016,
        "name": "WHITE BRONCO",
        "url": "http://www.whitebronco.life",
        "contact_email": "crimeguy220@gmail.com",
        "hometown": "San Francisco",
        "description": "Welcome to White Bronco!\r\n\r\nCheck out our DJ line-ups and other interactive events. Also, if you're looking for a place to camp, feel free to contact me. \r\n\r\n\r\n-CONNECT!!",
        "location": {
            "string": "C & 7:15",
            "frontage": "C",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78517166496261,
            "gps_longitude": -119.21877061804274
        },
        "location_string": "C & 7:15"
    },
    {
        "uid": "a1Xd0000001IWWoEAO",
        "year": 2016,
        "name": "Champagne Chandeliers",
        "hometown": "San Francisco",
        "description": "CHAMPAGNE CHANDELIERS  is a multicultural theme camp in its second year with members hailing from four different continents. We are an oasis for inspiration and connection. Here we invite you to decouple your mind from its daily routine and create new connections with others, yourself, and the world through guided experiences designed to inspire new perspectives.",
        "location": {
            "string": "D & 6:45",
            "frontage": "D",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78255670886589,
            "gps_longitude": -119.2187345746424
        },
        "location_string": "D & 6:45"
    },
    {
        "uid": "a1Xd0000001IXBeEAO",
        "year": 2016,
        "name": "Cirque Du So Gay",
        "hometown": "Joshua Tree",
        "description": "We are a circus group from Southern California, we will bring a 30 ft tall aerial rig that features 4000 sqft of shaded and circus shows during the week.",
        "location": {
            "string": "C & 7:45",
            "frontage": "C",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78761815118928,
            "gps_longitude": -119.21877261481393
        },
        "location_string": "C & 7:45"
    },
    {
        "uid": "a1Xd0000001IXHXEA4",
        "year": 2016,
        "name": "Pit Stop",
        "contact_email": "deborahcolotti@gmail.com",
        "hometown": "Sonoma County, CA",
        "description": "Building PIT STOP is a team effort that includes a diverse group of art friends who willingly share their skills to help bring AbracaDeborah's sculptural dreams to the playa.",
        "location": {
            "string": "D & 6:45",
            "frontage": "D",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78255670886589,
            "gps_longitude": -119.2187345746424
        },
        "location_string": "D & 6:45"
    },
    {
        "uid": "a1Xd0000001IBnpEAG",
        "year": 2016,
        "name": "Dragoncamp Armory",
        "contact_email": "dragoncamparmory@gmail.com",
        "hometown": "Los Angeles",
        "description": "Dragoncamp Armory. A hands-on workshop for women to make and decorate their own amazing, sexy Metal Bikini. Yours to keep!",
        "location": {
            "string": "D & 7:15",
            "frontage": "D",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78508546671077,
            "gps_longitude": -119.21963170707147
        },
        "location_string": "D & 7:15"
    },
    {
        "uid": "a1Xd0000001IOSNEA4",
        "year": 2016,
        "name": "Camp Fiasco",
        "location": {
            "string": "C & 7:45",
            "frontage": "C",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78761815118928,
            "gps_longitude": -119.21877261481393
        },
        "location_string": "C & 7:45"
    },
    {
        "uid": "a1Xd0000001IWNwEAO",
        "year": 2016,
        "name": "Jar of Sand Art support camp",
        "hometown": "Vancouver/San Francisco",
        "location": {
            "string": "D & 7:15",
            "frontage": "D",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78508546671077,
            "gps_longitude": -119.21963170707147
        },
        "location_string": "D & 7:15"
    },
    {
        "uid": "a1Xd0000001IXNQEA4",
        "year": 2016,
        "name": "Living Room",
        "contact_email": "riley.simas@gmail.com",
        "hometown": "Park City Ut and Los Angeles CA",
        "description": "THE LIVING ROOM is an amplified parody of the  Norman Rockwell's iconic visualization of the 1920s \"family room\" / \"den\". Come enjoy a safe haven from the dust and sun and play on our Radical TV",
        "location": {
            "string": "C & 7:15",
            "frontage": "C",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78517166496261,
            "gps_longitude": -119.21877061804274
        },
        "location_string": "C & 7:15"
    },
    {
        "uid": "a1Xd0000001IO1hEAG",
        "year": 2016,
        "name": "Cosmic Ranch",
        "location": {
            "string": "C & 7:45",
            "frontage": "C",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78761815118928,
            "gps_longitude": -119.21877261481393
        },
        "location_string": "C & 7:45"
    },
    {
        "uid": "a1Xd0000001IUb6EAG",
        "year": 2016,
        "name": "Camp Lazer Brigade",
        "contact_email": "jacki.a.bailey@gmail.com",
        "hometown": "Denver",
        "description": "We're a hodgepodge group of freaks, geeks, and cool cats, bonded together by our love for hot sauce and LAZERS! Stop in for one of our laid back events or classes, but don't leave without a vial of our sacred Lazer Sauce to save your dusty meals from the dangers of blandness!",
        "location": {
            "string": "E & 7:15",
            "frontage": "E",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78499926855044,
            "gps_longitude": -119.220492795186
        },
        "location_string": "E & 7:15"
    },
    {
        "uid": "a1Xd0000001IVHlEAO",
        "year": 2016,
        "name": "Camp Make Good Choices",
        "contact_email": "cmgc208@gmail.com",
        "hometown": "Boise",
        "description": "Camp Make Good Choices is here to provide fun and interactive events that are inclusive and encourage participation! Come join us for refreshing beverages, learn about black rock natural history, or to be the human hungry hippo! :)",
        "location": {
            "string": "D & 7:45",
            "frontage": "D",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78770363644721,
            "gps_longitude": -119.2196338606528
        },
        "location_string": "D & 7:45"
    },
    {
        "uid": "a1Xd0000001ICZGEA4",
        "year": 2016,
        "name": "Mr. Peepers Closet",
        "description": "Let Mr. Peepers help you find your Playa persona.Expert Body Painting, with many moons of experience.Hand made one of a kind tutus for Tutu Tuesday.",
        "location": {
            "string": "E & 7:45",
            "frontage": "E",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.787789121831615,
            "gps_longitude": -119.22049510776583
        },
        "location_string": "E & 7:45"
    },
    {
        "uid": "a1Xd0000001IXCSEA4",
        "year": 2016,
        "name": "Perihelion",
        "hometown": "Chicago",
        "description": "At Perihelion, you will reach the point in your journey closest to the sun. Enjoy a bright morning at our Intergalactic Pancake Massacres, and find yourself drawn into the orbit of the Star Bar for a stellar elixir!",
        "location": {
            "string": "E & 7:45",
            "frontage": "E",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.787789121831615,
            "gps_longitude": -119.22049510776583
        },
        "location_string": "E & 7:45"
    },
    {
        "uid": "a1Xd0000001IS8dEAG",
        "year": 2016,
        "name": "Fractal Rock",
        "contact_email": "fractalrock2016@gmail.com",
        "hometown": "Fremont",
        "description": "We created Fractal Rock, and are excited to share it on the playa this year. Come say hi if you want to learn more about us and our art!",
        "location": {
            "string": "D & 7:45",
            "frontage": "D",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78770363644721,
            "gps_longitude": -119.2196338606528
        },
        "location_string": "D & 7:45"
    },
    {
        "uid": "a1Xd0000001IPjwEAG",
        "year": 2016,
        "name": "Lavender Lounge",
        "hometown": "North Bay",
        "location": {
            "string": "E & 7:15",
            "frontage": "E",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78499926855044,
            "gps_longitude": -119.220492795186
        },
        "location_string": "E & 7:15"
    },
    {
        "uid": "a1Xd0000001IXhKEAW",
        "year": 2016,
        "name": "Guild of Mile Higher Knowledge",
        "contact_email": "coburners@gmail.com",
        "hometown": "Denver",
        "description": "Supporting camp for the Colorado Regional Guild Workshop.  Come by and visit, we will have a few tricks up our sleeve in our camp too.",
        "location": {
            "string": "E & 6:45",
            "frontage": "E",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78230469594509,
            "gps_longitude": -119.21953682219086
        },
        "location_string": "E & 6:45"
    },
    {
        "uid": "a1Xd0000001IWm5EAG",
        "year": 2016,
        "name": "Shiny - a Support Camp for Autism",
        "url": "http://campshiny.org",
        "contact_email": "campshiny@gmail.com",
        "hometown": "Monterey",
        "description": "Burning Man is an intense experience for anyone.  For those on the autism spectrum, or with other neuro-diversities or sensory sensitivities it can be overwhelming.  Camp Shiny is here as a refuge for sensory overload, to help manage the intensity, and facilitate interaction for anyone feeling \"socially challenged\" -- no one should go it alone, come here instead.",
        "location": {
            "string": "E & 7:15",
            "frontage": "E",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78499926855044,
            "gps_longitude": -119.220492795186
        },
        "location_string": "E & 7:15"
    },
    {
        "uid": "a1Xd0000001IDo0EAG",
        "year": 2016,
        "name": "Settle This Like Men",
        "contact_email": "gary.raydon@gmail.com",
        "hometown": "Reno",
        "description": "Settle This Like Men is about one thing: Beatings. \r\nWhether you're learning to mete out justice during one of our classes, smashing that camp mate who just won't pick up his moop in our Ring of Justice, choking out your best friend in our Jiu Jitsu matches, or kicking your own ass in our fitness classes, you will get beat.",
        "location": {
            "string": "D & 7:45",
            "frontage": "D",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78770363644721,
            "gps_longitude": -119.2196338606528
        },
        "location_string": "D & 7:45"
    },
    {
        "uid": "a1Xd0000001IOx6EAG",
        "year": 2016,
        "name": "Psychic Taxi",
        "url": "https://www.facebook.com/thepsychictaxicamp/?fref=ts",
        "contact_email": "tres.fontaine@gmail.com",
        "hometown": "Oakland",
        "description": "Psychic Taxi camp - providing an interactive playground, hammock pavilion, chill space, random taxi service on the playa, delicious craft tea cocktails, and hours of adventurous activity.",
        "location": {
            "string": "D & 7:45",
            "frontage": "D",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78770363644721,
            "gps_longitude": -119.2196338606528
        },
        "location_string": "D & 7:45"
    },
    {
        "uid": "a1Xd0000001IVjgEAG",
        "year": 2016,
        "name": "Catacomb of Veils",
        "url": "https://www.facebook.com/CatacombofVeils/",
        "hometown": "San Francisco",
        "description": "We are the art support camp for The Catacomb of Veils - CATACOMB OF VEILS is a descent into a subterranean world. The journey begins with a climb up a mountain, drops through an inner cavern, and culminates in a sanctuary from the playa's cacophony- a space for stillness and thought, where we indulge our rituals of reflection and remembrance",
        "location": {
            "string": "D & 7:45",
            "frontage": "D",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78770363644721,
            "gps_longitude": -119.2196338606528
        },
        "location_string": "D & 7:45"
    },
    {
        "uid": "a1Xd0000001IXHSEA4",
        "year": 2016,
        "name": "P3 Oasis",
        "location": {
            "string": "D & 7:15",
            "frontage": "D",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78508546671077,
            "gps_longitude": -119.21963170707147
        },
        "location_string": "D & 7:15"
    },
    {
        "uid": "a1Xd0000001IX8uEAG",
        "year": 2016,
        "name": "Da Dirty Hands",
        "hometown": "San Francisco",
        "description": "Da Dirty Hands is the home of Black Rock City's largest signing contigent of Burners.  We welcome all to come visit, play, and learn with us.",
        "location": {
            "string": "D & 7:15",
            "frontage": "D",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78508546671077,
            "gps_longitude": -119.21963170707147
        },
        "location_string": "D & 7:15"
    },
    {
        "uid": "a1Xd0000001IVGsEAO",
        "year": 2016,
        "name": "The Embassy",
        "hometown": "Boston",
        "description": "The Embassy is the center for relations between Black Rock City and the Default World. Come by to ease into life as a burner, learn about the strange customs of the Default World, and prepare for inter-world travel.",
        "location": {
            "string": "D & 7:45",
            "frontage": "D",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78770363644721,
            "gps_longitude": -119.2196338606528
        },
        "location_string": "D & 7:45"
    },
    {
        "uid": "a1Xd0000001IWQ2EAO",
        "year": 2016,
        "name": "Camp Rainblo Fishy",
        "hometown": "Los Angeles",
        "location": {
            "string": "E & 7:45",
            "frontage": "E",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.787789121831615,
            "gps_longitude": -119.22049510776583
        },
        "location_string": "E & 7:45"
    },
    {
        "uid": "a1Xd0000001IXOiEAO",
        "year": 2016,
        "name": "Gnome Camp",
        "hometown": "San Francisco",
        "description": "Gnome Camp is the home and refuge for an unheralded breed of desert-loving gnome. Hailing from shrinking urban green space on two coasts, we gather once a year to propagate our species through gnome adoptions and conversions, and to share our traditions of mischievous merrymaking.",
        "location": {
            "string": "D & 7:45",
            "frontage": "D",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78770363644721,
            "gps_longitude": -119.2196338606528
        },
        "location_string": "D & 7:45"
    },
    {
        "uid": "a1Xd0000001IUdgEAG",
        "year": 2016,
        "name": "Burning Man T-Shirt Factory",
        "contact_email": "brcmiles@yahoo.com",
        "hometown": "Campbell",
        "description": "Burning Man T-Shirt Factory.  We supply the paint and BM stencils.  You supply the body, clothing, or gear to paint your own  masterpiece. Totally interactive, quick, easy, and fun.  Open 24/7.",
        "location": {
            "string": "E & 7:15",
            "frontage": "E",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78499926855044,
            "gps_longitude": -119.220492795186
        },
        "location_string": "E & 7:15"
    },
    {
        "uid": "a1Xd0000001IWsSEAW",
        "year": 2016,
        "name": "Latchkey Club",
        "hometown": "San Francisco",
        "description": "Nostalgic and whimsical camp of kids that never grew up.",
        "location": {
            "string": "F & 7:15",
            "frontage": "F",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.784913070481615,
            "gps_longitude": -119.22135388238645
        },
        "location_string": "F & 7:15"
    },
    {
        "uid": "a1Xd0000001IVJmEAO",
        "year": 2016,
        "name": "Camp Stella",
        "url": "http://www.soberstella.com",
        "hometown": "San Francisco",
        "description": "Camp Stella hosts 6 open AA meetings during the week. All are welcome to attend.",
        "location": {
            "string": "F & 7:15",
            "frontage": "F",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.784913070481615,
            "gps_longitude": -119.22135388238645
        },
        "location_string": "F & 7:15"
    },
    {
        "uid": "a1Xd0000001IWTGEA4",
        "year": 2016,
        "name": "Vietnamese Iced Coffee Experience",
        "url": "https://www.facebook.com/groups/111107568995459/",
        "contact_email": "brcrangersundancer@gmail.com",
        "hometown": "San Francisco, Los Angeles, Albuquerque, Seattle, New York City, Houston, Philadelphia, Washington DC",
        "description": "Vietnamese Iced Coffee Experience is an all inclusive Burning Man Theme Camp. We encourage diversity, participation, and acceptance and welcome new members from all locales and walk of life.  Our camp commitments are minimal, as such we do expect members to be radically self sufficient when it comes to personal needs although we're more than happy to help out with pre-event planning and support in extreme situations.  Participating in our afternoon coffee service is more reward than obligation and we also offer several community directed activities for those that wish to participate.  We have camp events during the week to ensure everyone feels included.  We'd be happy to welcome you to join our group.  Contact us for more information!",
        "location": {
            "string": "F & 7:15",
            "frontage": "F",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.784913070481615,
            "gps_longitude": -119.22135388238645
        },
        "location_string": "F & 7:15"
    },
    {
        "uid": "a1Xd0000001IXKCEA4",
        "year": 2016,
        "name": "AstroPup Labs:DogVinci's Workshop",
        "hometown": "San Francisco",
        "description": "AstroPups - Fun, Frisky, n Fabulous! Exploring the PupVerse one lick at a time!",
        "location": {
            "string": "F & 7:45",
            "frontage": "F",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.7878746073425,
            "gps_longitude": -119.22135635615312
        },
        "location_string": "F & 7:45"
    },
    {
        "uid": "a1Xd0000001IOr5EAG",
        "year": 2016,
        "name": "Tectonic",
        "url": "http://tectonic.camp/",
        "contact_email": "info@tectonic.camp",
        "hometown": "Portland",
        "description": "Come bask in the shade of our fire-poofing volcano, and dance to our ground-shaking beats while we serve you a drink—or not!  Don't forget to bring us your playa virgins to sacrifice to the volcano god!",
        "location": {
            "string": "Esplanade & 7:30 Portal",
            "frontage": "Esplanade",
            "intersection": "7:30 Portal",
            "intersection_type": "&",
            "gps_latitude": 40.7863996466492,
            "gps_longitude": -119.21554798072792
        },
        "location_string": "Esplanade & 7:30 Portal"
    },
    {
        "uid": "a1Xd0000001ISIdEAO",
        "year": 2016,
        "name": "Paella Cosmos",
        "hometown": "Madrid, Spain",
        "description": "A piece of Spain just around the corner. Hometown of the fluorescent brotherhood. The place to find El Duende.",
        "location": {
            "string": "F & 7:45",
            "frontage": "F",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.7878746073425,
            "gps_longitude": -119.22135635615312
        },
        "location_string": "F & 7:45"
    },
    {
        "uid": "a1Xd0000001IXUQEA4",
        "year": 2016,
        "name": "AudioSpa Beach Club",
        "hometown": "San Francisco",
        "description": "AudioSpa Beach Club is an oasis of sound-based rest and relaxation.",
        "location": {
            "string": "F & 7:15",
            "frontage": "F",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.784913070481615,
            "gps_longitude": -119.22135388238645
        },
        "location_string": "F & 7:15"
    },
    {
        "uid": "a1Xd0000001IRMIEA4",
        "year": 2016,
        "name": "Conception",
        "url": "http://www.campconception.com",
        "hometown": "Seattle",
        "description": "Conception believes everyone has an innate spark of creativity and we foster a fertile environment for that creativity to take root. Conception is a cocktail of experiences (including cocktails!) ranging from spa treatments to dance to singing to painting, and lots of interesting things in between, so let us nurture your body and mind and perhaps send you away with a story to tell.",
        "location": {
            "string": "F & 7:15",
            "frontage": "F",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.784913070481615,
            "gps_longitude": -119.22135388238645
        },
        "location_string": "F & 7:15"
    },
    {
        "uid": "a1Xd0000001IN2CEAW",
        "year": 2016,
        "name": "Black Rock Roller Disco",
        "url": "http://www.cora.org/BlackRockRollerDisco2016.html",
        "contact_email": "sk8godfather@earthlink.net",
        "hometown": "San Francisco",
        "description": "A roller disco in the middle of the desert?  That's exactly what we are!!!",
        "location": {
            "string": "Esplanade & 7:00",
            "frontage": "Esplanade",
            "intersection": "7:00",
            "intersection_type": "&",
            "gps_latitude": 40.78462658391771,
            "gps_longitude": -119.21523944492934
        },
        "location_string": "Esplanade & 7:00"
    },
    {
        "uid": "a1Xd0000001IXHNEA4",
        "year": 2016,
        "name": "FreeStyle Palace",
        "url": "http://freestylepalace.com",
        "contact_email": "info@freestylepalace.com",
        "hometown": "Mountain View",
        "description": "FreeStyle Palace 2016: Playa Talent Incubator. Ten years in the making, a collaborative music play space and sound stage featuring Live Open Jams, dj and nightly Hip Hop shows from sunset to about 2:00 am. Our stage and our microphones are open to all comers. Part alchemy and part black magic, FreeStyle Palace is an amalgam of sophisticated and authentic Urban Underground music and culture forged by the heat of the Black Rock Desert and polished by the collective talent of the Burning Man Community.",
        "location": {
            "string": "Esplanade & 6:45",
            "frontage": "Esplanade",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78377478201974,
            "gps_longitude": -119.21485701075231
        },
        "location_string": "Esplanade & 6:45"
    },
    {
        "uid": "a1Xd0000001IWsrEAG",
        "year": 2016,
        "name": "Sparkle Love Oasis",
        "contact_email": "sparkleloveoasis@gmail.com",
        "hometown": "BRC",
        "description": "Welcome to our Oasis Sky Lodge, a beautiful chill lounge to enjoy a drink out of the sun. Come play with us, get your Booty Appreciated, take a spin on the TallyWhacker and make new friends!",
        "location": {
            "string": "F & 7:15",
            "frontage": "F",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.784913070481615,
            "gps_longitude": -119.22135388238645
        },
        "location_string": "F & 7:15"
    },
    {
        "uid": "a1Xd0000001IXfxEAG",
        "year": 2016,
        "name": "Kostume Kult",
        "url": "http://kostumekult.com/",
        "contact_email": "campleads@kostumekult.com",
        "hometown": "New York City",
        "description": "Kostume Kult presents: Da Vinci's Kloset! A celebration of interactive costuming and creativity, against the backdrop of New York City as a modern day renaissance city: a center of art and commerce!",
        "location": {
            "string": "Esplanade & 8:00",
            "frontage": "Esplanade",
            "intersection": "8:00",
            "intersection_type": "&",
            "gps_latitude": 40.78817275672073,
            "gps_longitude": -119.21523991161457
        },
        "location_string": "Esplanade & 8:00"
    },
    {
        "uid": "a1Xd0000001IIt1EAG",
        "year": 2016,
        "name": "Prometheatrics",
        "url": "http://www.prometheatrics.com",
        "contact_email": "info@prometheatrics.com",
        "hometown": "Los Angeles",
        "description": "Bringing the gift of Fire to humanity since the dawn of time, Prometheatrics has been a part of Black Rock City since 2002. Historically located on the Esplanade, our theme camp hosts a fine collection of interactive installations and helpful hosts ready to surprise and delight you!\r\n\r\nStep inside the temporally anomalous Tesseract, where you'll experience yourself as you truly are: infinite! Trace your face with our Self Portrait Studio and take home your very own masterpiece! Enjoy a bounce on our delightful Danpoline, find paradise in our glittering Light Forest, or enter the dream-space of our relaxing Infinitipi. On your way in or out of our domain, admire all the colors Burning Man has to offer through the radiant Rainbow Scrim.\r\n\r\nJoin us at dusk and dawn at our mirrored stage for twice-daily fire spinning jams, where there's always a safety on duty and all wicks are welcome. We're honored to be a part of what makes our city magical, and eager to share what makes us shine!",
        "location": {
            "string": "Esplanade & 6:30",
            "frontage": "Esplanade",
            "intersection": "6:30",
            "intersection_type": "&",
            "gps_latitude": 40.78297439508715,
            "gps_longitude": -119.21433537703916
        },
        "location_string": "Esplanade & 6:30"
    },
    {
        "uid": "a1Xd0000001IUwOEAW",
        "year": 2016,
        "name": "Silver City",
        "url": "https://www.facebook.com/profile.php?id=100012029221863",
        "contact_email": "blackrocksilvercity@gmail.com",
        "hometown": "Reno",
        "description": "Black Rock Silver City",
        "location": {
            "string": "G & 7:45",
            "frontage": "G",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78796556023548,
            "gps_longitude": -119.22221681630182
        },
        "location_string": "G & 7:45"
    },
    {
        "uid": "a1Xd0000001INLgEAO",
        "year": 2016,
        "name": "HoloDreamers",
        "contact_email": "harinama@hotmail.com",
        "hometown": "Seattle",
        "description": "Drop by HoloDreamers to make your very own practice spinning poi! We supply the craft supplies and you walk away with a pair of spinning poi you can enjoy all week and beyond. Add blinkies and dazzle your friends at night. Crafting assistance is provided in the mornings with impromptu spinning tips given upon completion. The Poi-making studio will have instructional materials present and be open 24hrs/day for your late nite crafting fun.",
        "location": {
            "string": "G & 6:45",
            "frontage": "G",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78180595810437,
            "gps_longitude": -119.22114438293958
        },
        "location_string": "G & 6:45"
    },
    {
        "uid": "a1Xd0000001IWRtEAO",
        "year": 2016,
        "name": "Love Puddle",
        "hometown": "San Jose",
        "description": "Every afternoon serving the most refreshing drink and the best conversation on the playa. Once you come you won't want to leave.",
        "location": {
            "string": "G & 7:45",
            "frontage": "G",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78796556023548,
            "gps_longitude": -119.22221681630182
        },
        "location_string": "G & 7:45"
    },
    {
        "uid": "a1Xd0000001IXdNEAW",
        "year": 2016,
        "name": "Cult of Heroes",
        "hometown": "Oakland",
        "description": "Cult Of Heroes is a place to get in touch with and develop your inner hero. We all have special powers - observation, intuition, love, dance, ego, math, connection. Cult of Heroes is a place where we are growing those powers and being awesome.  Come be awesome with us!",
        "location": {
            "string": "G & 7:45",
            "frontage": "G",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78796556023548,
            "gps_longitude": -119.22221681630182
        },
        "location_string": "G & 7:45"
    },
    {
        "uid": "a1Xd0000001IWP9EAO",
        "year": 2016,
        "name": "STEEP",
        "url": "https://www.facebook.com/CampSteep/",
        "contact_email": "campsteep@gmail.com",
        "hometown": "Los Angeles",
        "description": "Stop by Camp STEEP for a fresh cup of hot, iced, creamed or straight herbal and traditional loose leaf teas. Over 40 herbs and teas mixed by hand in front of your eyes! Dreams interpreted, conversations to be had, pillows to be lounged upon - come Drink in the Love!",
        "location": {
            "string": "G & 7:45",
            "frontage": "G",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78796556023548,
            "gps_longitude": -119.22221681630182
        },
        "location_string": "G & 7:45"
    },
    {
        "uid": "a1Xd0000001IBJYEA4",
        "year": 2016,
        "name": "Heavy Petting Zoo",
        "hometown": "Portsmouth",
        "description": "The Heavy Petting Zoo is back! Come ride our furry mustache, drink our delicious apple pie moonshine or ride our art car across the playa in musical HPZ style!",
        "location": {
            "string": "H & 6:45",
            "frontage": "H",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78155417628542,
            "gps_longitude": -119.22194675633338
        },
        "location_string": "H & 6:45"
    },
    {
        "uid": "a1Xd0000001IXM8EAO",
        "year": 2016,
        "name": "Christian Science Camp 2gthr as 1",
        "contact_email": "itsaboutgood@gmail.com",
        "hometown": "Boston",
        "description": "Christian Science Camp 2Gthr As 1 is a place to receive healing.",
        "location": {
            "string": "G & 7:15",
            "frontage": "G",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78483230749839,
            "gps_longitude": -119.22221607478929
        },
        "location_string": "G & 7:15"
    },
    {
        "uid": "a1Xd0000001IWCtEAO",
        "year": 2016,
        "name": "Brass Tax Radio Malibu",
        "url": "http://brasstax.samo.org/",
        "hometown": "San Francisco",
        "description": "We're back, and hopefully not ever leaving!  Tune in to our 24-hour coverage of Brass Tax shenanigans on Radio Malibu (or stop by the on-playa studio): music, sing-a-longs, live interviews, morning calisthenics, and intraplaya sunrise traffic cone sports reportage. Winners every day - you could be next!",
        "location": {
            "string": "G & 6:45",
            "frontage": "G",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78180595810437,
            "gps_longitude": -119.22114438293958
        },
        "location_string": "G & 6:45"
    },
    {
        "uid": "a1Xd0000001IWWFEA4",
        "year": 2016,
        "name": "Preservation Society",
        "hometown": "LA / SF / NYC / London",
        "description": "The Preservation Society: An oasis amidst ephemeral modernity; shelter from progress, efficiency and cruel indifference. Here for the preservation of mind, body and soul.",
        "location": {
            "string": "G & 6:45",
            "frontage": "G",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78180595810437,
            "gps_longitude": -119.22114438293958
        },
        "location_string": "G & 6:45"
    },
    {
        "uid": "a1Xd0000001IOUiEAO",
        "year": 2016,
        "name": "Tropical Treehouse",
        "contact_email": "tropics@thirdpyramid.com",
        "hometown": "San Francisco",
        "description": "A verdant home alive with the warmth of aloha!  Castaways welcomed to paddle up to the tiki lights and toast the night with a Mai Tai.",
        "location": {
            "string": "G & 7:15",
            "frontage": "G",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78483230749839,
            "gps_longitude": -119.22221607478929
        },
        "location_string": "G & 7:15"
    },
    {
        "uid": "a1Xd0000001IVqIEAW",
        "year": 2016,
        "name": "Camp Aerial Screw",
        "contact_email": "campaerialscrew@yahoo.com",
        "hometown": "San Francisco",
        "description": "Wind down or wind up! Come join us for low key acro-yoga classes or meet someone new and dance while operating heavy machinery!",
        "location": {
            "string": "G & 7:15",
            "frontage": "G",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78483230749839,
            "gps_longitude": -119.22221607478929
        },
        "location_string": "G & 7:15"
    },
    {
        "uid": "a1Xd0000001IO85EAG",
        "year": 2016,
        "name": "Reno Housewives",
        "contact_email": "renohousewives@gmail.com",
        "hometown": "Reno",
        "description": "Helping costume BRC since 1998. Do you need bridesmaids for your playa wedding, or are looking for the perfect outfit for that party? ASK US -- From frumpy to fabulous, we have you covered. Home of the world-famous Sillisculpt Museum.",
        "location": {
            "string": "H & 6:45",
            "frontage": "H",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78155417628542,
            "gps_longitude": -119.22194675633338
        },
        "location_string": "H & 6:45"
    },
    {
        "uid": "a1Xd0000001IVHWEA4",
        "year": 2016,
        "name": "Hotel California",
        "url": "http://hotel-california.org",
        "hometown": "San Francisco",
        "location": {
            "string": "G & 7:15",
            "frontage": "G",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78483230749839,
            "gps_longitude": -119.22221607478929
        },
        "location_string": "G & 7:15"
    },
    {
        "uid": "a1Xd0000001IXb7EAG",
        "year": 2016,
        "name": "That Camp Over There",
        "contact_email": "that-camp-over-there-2016@googlegroups.com",
        "hometown": "San Francisco",
        "description": "Swing by and draw with UV light, enjoy Spanking & Pringles, climb our scaffold and Moon The Man, chill in the shade in Las Hamacas, 7-11am enjoy coffee, pancakes and unidentifiable fried pig parts. Snowconeokie will be roaming deep playa, catch us, do a forfeit, get a cone. Entirely Amateur since 2001",
        "location": {
            "string": "G & 7:15",
            "frontage": "G",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78483230749839,
            "gps_longitude": -119.22221607478929
        },
        "location_string": "G & 7:15"
    },
    {
        "uid": "a1Xd0000001IWmAEAW",
        "year": 2016,
        "name": "Dodo's Nest",
        "url": "http://dodobus.com/",
        "hometown": "San Francisco",
        "description": "The Dodo's Nest is a camp of wigs and ruffles, music and affected accents based around the fabulous Dodo Pleasure Barge art car.",
        "location": {
            "string": "G & 7:15",
            "frontage": "G",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78483230749839,
            "gps_longitude": -119.22221607478929
        },
        "location_string": "G & 7:15"
    },
    {
        "uid": "a1Xd0000001IXJxEAO",
        "year": 2016,
        "name": "CampProper",
        "url": "http://www.campproper.org",
        "contact_email": "info@campproper.org",
        "hometown": "San Francisco Bay Area",
        "description": "Do you think of yourself as a Proper Burner? Have you always wanted to become a Proper Burner? Stop by CampProper to take your Proper Burner exam and earn your Burner License while enjoying some ProperTea! Think you can pass the exam? Stop by and find out! Oh…and don't miss our regular ProperTea Dances!",
        "location": {
            "string": "G & 7:45",
            "frontage": "G",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78796556023548,
            "gps_longitude": -119.22221681630182
        },
        "location_string": "G & 7:45"
    },
    {
        "uid": "a1Xd0000001IXEiEAO",
        "year": 2016,
        "name": "Vagabonds and Tagalongs",
        "hometown": "The internet",
        "description": "A camp for lost and wayward travelers",
        "location": {
            "string": "G & 6:45",
            "frontage": "G",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78180595810437,
            "gps_longitude": -119.22114438293958
        },
        "location_string": "G & 6:45"
    },
    {
        "uid": "a1Xd0000001IX78EAG",
        "year": 2016,
        "name": "Dusty Justice",
        "hometown": "Palo Alto",
        "description": "Camp Dusty Justice is bringing an open, slightly impartial, fun venue for Burners of all stripes to get their dusty dirty day in court. Come solve your dispute and spin the wheel of punishment.",
        "location": {
            "string": "G & 6:45",
            "frontage": "G",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78180595810437,
            "gps_longitude": -119.22114438293958
        },
        "location_string": "G & 6:45"
    },
    {
        "uid": "a1Xd0000001IWFTEA4",
        "year": 2016,
        "name": "Back To Camp",
        "url": "https://www.facebook.com/groups/317812728412969/",
        "contact_email": "backtocampbrc@gmail.com",
        "hometown": "Oakland",
        "description": "Back to Camp is a summer camp - a playground in the forest where you can be a kid or adult and enjoy timeless camp activities. Stop by at any time all week to relax and sit in the shade while listening to the birds chirp and water flow. Enjoy your coffee at sunrise in our adirondack chairs or take an afternoon nap in the hammock. Come by Monday & Wednesday afternoons for happy hour snacks & beverages, postcards to send home, corn hole, lifesize jenga, friendship bracelets and the CAMP DANCE with line dance lessons from camp counselors. Join us Friday night under the stars around a campfire, to tell ghost stories and sing songs.",
        "location": {
            "string": "I & 7:45",
            "frontage": "I",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78813699883062,
            "gps_longitude": -119.22393925217301
        },
        "location_string": "I & 7:45"
    },
    {
        "uid": "a1Xd0000001IWVHEA4",
        "year": 2016,
        "name": "Classy Village",
        "contact_email": "classyvillage@gmail.com",
        "hometown": "Oakland, California",
        "description": "The Cla$$y Village is an ensemble of intergenerational thinkers and doers from Aging Insurrection, artisanal chefs from Camp Enchanted Charcuterie, and wilderness adventurers from LubClub. We are an eclectic group of 75 artists, frisbee players, policy wonks, elder wise men and women, thinkers, doers, and teachers from the Bay Area, SoCal and East Coast, excited to provide fun, entertainment and love to all inhabitants of Black Rock City.",
        "location": {
            "string": "H & 7:45",
            "frontage": "H",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78805128273441,
            "gps_longitude": -119.22307803312573
        },
        "location_string": "H & 7:45"
    },
    {
        "uid": "a1Xd0000001IWTzEAO",
        "year": 2016,
        "name": "Baggage Check",
        "contact_email": "pb207a@gmail.com",
        "hometown": "Seattle",
        "description": "Experience Burning Man free of emotional baggage! Check your baggage with us---emotional baggage only!---by writing it in our book, which we will burn at the Temple Burn. Stop by any time of the day or night, get a drink of water, treat yourself to our pamper station, get out of the sun, or join a dance party in progress.",
        "location": {
            "string": "H & 7:45",
            "frontage": "H",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78805128273441,
            "gps_longitude": -119.22307803312573
        },
        "location_string": "H & 7:45"
    },
    {
        "uid": "a1Xd0000001IUyFEAW",
        "year": 2016,
        "name": "Fun Yay Fun",
        "contact_email": "weirdwendy@gmail.com",
        "hometown": "San Francisco",
        "description": "We're Black Rock City's only solar-lit Patrick Swayze Memorial Altar & Life Celebration site. Don't worry, we have mullets.",
        "location": {
            "string": "H & 7:15",
            "frontage": "H",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78474634492448,
            "gps_longitude": -119.22307720812522
        },
        "location_string": "H & 7:15"
    },
    {
        "uid": "a1Xd0000001IRDTEA4",
        "year": 2016,
        "name": "Stories of the MIR",
        "url": "https://www.facebook.com/theownway/",
        "contact_email": "sadsema@gmail.com",
        "hometown": "Moscow",
        "description": "Our lives are the best scripts! Let's share them together behind one table. We provide food, you provide stories. Our food is the best traditional Russian dishes, your stories are something interesting happened in your life. Because, hey, your life is a beautiful journey and we want to have it written down. After the Burn we will release the project called 'The scripts' that will show the world that our lives are the best scripts ever and no movie, show or book can beat it!",
        "location": {
            "string": "I & 7:45",
            "frontage": "I",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78813699883062,
            "gps_longitude": -119.22393925217301
        },
        "location_string": "I & 7:45"
    },
    {
        "uid": "a1Xd0000001IXjuEAG",
        "year": 2016,
        "name": "Glory Whole",
        "url": "http://tiny.cc/GloryWhole",
        "contact_email": "campglorywhole@gmail.com",
        "hometown": "San Francisco",
        "description": "Embrace yourself into a completely dark and exciting room at camp Glory Whole. Interact with a stranger that you will never see or find out who s/he was. All judgments are dropped, be yourself, discover and express feelings and emotions from deep inside and feel your inner bliss unified with another beautiful soul.",
        "location": {
            "string": "H & 7:15",
            "frontage": "H",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78474634492448,
            "gps_longitude": -119.22307720812522
        },
        "location_string": "H & 7:15"
    },
    {
        "uid": "a1Xd0000001IUf3EAG",
        "year": 2016,
        "name": "Elvis Wedding Chapel",
        "contact_email": "elvispresley@gmail.com",
        "hometown": "Los Angeles",
        "description": "\"Happily Ever After\" can only officially start once you tie-the-knot in a full-throttle playa-wedding at the Elvis Wedding Chapel... Uh-huh!  Returning and expanding for our 6th year serving the nuptially needy of BRC! No tux? NO problem! Let our Glam Squad help you dress your best for the big day turning cold feet into bold feet! Choose from plentiful selections in our legendary Bridezilla Lounge, the most glamorous pond on the playa! After your ceremony please exit through the GIFT SHOP and enjoy a sojourn in the Mona Lisa-Marie's Renaissance Rock Gardens. Hours: 2pm to sunset, Tutu-Tuesday through Friday.",
        "location": {
            "string": "H & 6:45",
            "frontage": "H",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78155417628542,
            "gps_longitude": -119.22194675633338
        },
        "location_string": "H & 6:45"
    },
    {
        "uid": "a1Xd0000001IWVgEAO",
        "year": 2016,
        "name": "Pearl Cove",
        "hometown": "Fairbanks",
        "description": "The home base of the gypsy pirates, crew of The Pearl Necklace",
        "location": {
            "string": "H & 7:45",
            "frontage": "H",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78805128273441,
            "gps_longitude": -119.22307803312573
        },
        "location_string": "H & 7:45"
    },
    {
        "uid": "a1Xd0000001IXOEEA4",
        "year": 2016,
        "name": "Camp Numbskull",
        "url": "https://www.facebook.com/skullcar/",
        "hometown": "San Francisco",
        "description": "The veteran heads of Camp Numbskull invite you to our Soul Shakedown party on Tuesday at 4pm to bump your booties to the deepest cuts of roots, rock, reggae on the playa and sip mojitos til the sun says good night.  Drop by any evening to unwind the mind with delicious dub sessions under the stars.",
        "location": {
            "string": "H & 7:45",
            "frontage": "H",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78805128273441,
            "gps_longitude": -119.22307803312573
        },
        "location_string": "H & 7:45"
    },
    {
        "uid": "a1Xd0000001ISJWEA4",
        "year": 2016,
        "name": "Life Rulez",
        "url": "http://www.liferulez.org",
        "contact_email": "liferulez@gmail.com",
        "hometown": "San Francisco and Los Angeles",
        "description": "The collective effort of ordinary people with exceptional imaginations. A band of souls seeking perpetual happiness in life's little moments. The life ruleS at LIFE RULEZ is that...LIFE RULEZZZ!",
        "location": {
            "string": "H & 7:15",
            "frontage": "H",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78474634492448,
            "gps_longitude": -119.22307720812522
        },
        "location_string": "H & 7:15"
    },
    {
        "uid": "a1Xd0000001IXjBEAW",
        "year": 2016,
        "name": "I NEED AN ADULT VILLAGE",
        "hometown": "lakewood",
        "location": {
            "string": "8:30 & D",
            "frontage": "8:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.7914141295786,
            "gps_longitude": -119.21797244993033
        },
        "location_string": "8:30 & D"
    },
    {
        "uid": "a1Xd0000001IQRUEA4",
        "year": 2016,
        "name": "Camp Sass",
        "description": "Camp Sass",
        "location": {
            "string": "8:00 & G",
            "frontage": "8:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.78950543537275,
            "gps_longitude": -119.22181263250638
        },
        "location_string": "8:00 & G"
    },
    {
        "uid": "a1Xd0000001IXHwEAO",
        "year": 2016,
        "name": "Nectar Village",
        "url": "http://www.nectarvillage.com",
        "contact_email": "questions@nectarvillage.com",
        "hometown": "San Francisco, Boulder, & Boston",
        "description": "Nectar Village is about you. It is about what you need… to survive, refuel, and revitalize. Mind, body and spirit are all served, and you'll find the nectar you seek for any of them, in the camps at our oasis. Offerings continuously from 10am to 7pm.",
        "location": {
            "string": "8:00 & E",
            "frontage": "8:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78916521244671,
            "gps_longitude": -119.22013446592231
        },
        "location_string": "8:00 & E"
    },
    {
        "uid": "a1Xd0000001IAwEEAW",
        "year": 2016,
        "name": "Star Star Roadhouse",
        "url": "http://www.starstarroadhouse.com/",
        "contact_email": "starstarroadhouse@gmail.com",
        "hometown": "Placerville",
        "description": "We bring a risque mix of cabaret-style theater and live rock and roll to the playa. Sexy, physical, thematic. Daytime acting, movement, yoga, and twerkshops throughout burn week in our shaded venue. Night time shows and public bar with custom cocktails to wet your mouth and loosen you up!",
        "location": {
            "string": "8:30 & A",
            "frontage": "8:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.79042783320644,
            "gps_longitude": -119.2157154376413
        },
        "location_string": "8:30 & A"
    },
    {
        "uid": "a1Xd0000001IUurEAG",
        "year": 2016,
        "name": "Kaleidoscope",
        "url": "http://kaleidoscope.wtf",
        "contact_email": "kaleidoscope.wtf@gmail.com",
        "hometown": "SAN FRANCISCO",
        "description": "Welcome to Kaleidoscope. On the surface we serve fresh pour over coffee and offer a shaded game lounge for socializing and play. Stay longer and enjoy our full-size, walk-in kaleidoscope or lounge on our roadside stoop. Here you may also become involved something much bigger, which transcends the scope of the camp itself.",
        "location": {
            "string": "8:30 & F",
            "frontage": "8:30",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.79207163606192,
            "gps_longitude": -119.2194771620409
        },
        "location_string": "8:30 & F"
    },
    {
        "uid": "a1Xd0000001IOwcEAG",
        "year": 2016,
        "name": "Vomiting Sparrows",
        "hometown": "Portland",
        "description": "We are the Sparrows!  We serve the best bloody mary on the playa.  We entertain, we make friends, we make fun, we welcome all.  Chirp Chirp Blarf!",
        "location": {
            "string": "8:30 & B",
            "frontage": "8:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.79075660354997,
            "gps_longitude": -119.2164677676208
        },
        "location_string": "8:30 & B"
    },
    {
        "uid": "a1Xd0000001IVruEAG",
        "year": 2016,
        "name": "Dream Society",
        "hometown": "San Francisco",
        "location": {
            "string": "8:00 & A",
            "frontage": "8:00",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.78848469366183,
            "gps_longitude": -119.2167781843461
        },
        "location_string": "8:00 & A"
    },
    {
        "uid": "a1Xd0000001IXETEA4",
        "year": 2016,
        "name": "Camp Soft Landing",
        "url": "http://www.campsoftlanding.com",
        "contact_email": "info@campsoftlanding.com",
        "hometown": "San Francisco",
        "description": "Camp Soft Landing offers a comfortable space to drink tea, hydrate, rest, tell stories and participate in workshops. Soft Landing sponsors and staffs the Full Circle Tea House which is planning to return to the playa for the 6th year to offer fine pu'erh tea and herbal infusions in the Chinese Gung Fu tradition. Servers provide tea and empathy and comfortable spaces for rest, hydration and quiet conversation 24 hours a day. Soft Landing also presents the Palenque Norte speaker series featuring 40 visionary talks and stories spanning concepts such as technology, medicine, art, science, design and entheobotany. These events take place in the Palenque Norte circus tent which also hosts small musical performances and yoga.",
        "location": {
            "string": "8:00 & B",
            "frontage": "8:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.788654832474464,
            "gps_longitude": -119.21761724829089
        },
        "location_string": "8:00 & B"
    },
    {
        "uid": "a1Xd0000001IRkZEAW",
        "year": 2016,
        "name": "Mountain Mayhem",
        "contact_email": "andy.f.high@gmail.com",
        "hometown": "Durango",
        "description": "Mountain Mayhem: A camp for the adventurous.",
        "location": {
            "string": "8:00 & A",
            "frontage": "8:00",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.78848469366183,
            "gps_longitude": -119.2167781843461
        },
        "location_string": "8:00 & A"
    },
    {
        "uid": "a1Xd0000001IOt6EAG",
        "year": 2016,
        "name": "Ice Sauna",
        "hometown": "San Leandro",
        "location": {
            "string": "8:30 & C",
            "frontage": "8:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.791085369007384,
            "gps_longitude": -119.21722010505046
        },
        "location_string": "8:30 & C"
    },
    {
        "uid": "a1Xd0000001IN8wEAG",
        "year": 2016,
        "name": "Vinyl Bunker",
        "location": {
            "string": "8:30 & C",
            "frontage": "8:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.791085369007384,
            "gps_longitude": -119.21722010505046
        },
        "location_string": "8:30 & C"
    },
    {
        "uid": "a1Xd0000001IXAbEAO",
        "year": 2016,
        "name": "Campoline",
        "url": "https://www.facebook.com/Campoline.Tribe/",
        "contact_email": "jez@sonic.net",
        "hometown": "Santa Rosa",
        "description": "Come drink at our circular bar! Bounce on the finest trampolines in the history of humanity! Campoline is more fun than a barrel full of monkeys on a roller coaster. We has music! If you can walk, you can dance, so get in here! No? How about art? Everybody loves art! Come into the art tent and get creative. Come one, come all, and get radically Campolined!",
        "location": {
            "string": "8:30 & B",
            "frontage": "8:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.79075660354997,
            "gps_longitude": -119.2164677676208
        },
        "location_string": "8:30 & B"
    },
    {
        "uid": "a1Xd0000001IVoWEAW",
        "year": 2016,
        "name": "Draft Punk at the Trashed Fence",
        "url": "https://www.facebook.com/CheezyPcamp",
        "hometown": "San Diego",
        "description": "Draft Punk at the Trashed Fence. Bring us your hot, your dusty, your thirsty, and discover the coldest, fastest beer on the playa, every afternoon from Monday to Friday.",
        "location": {
            "string": "8:30 & E",
            "frontage": "8:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.791742885263474,
            "gps_longitude": -119.21872480226047
        },
        "location_string": "8:30 & E"
    },
    {
        "uid": "a1Xd0000001IWJGEA4",
        "year": 2016,
        "name": "Shangri-Lawless",
        "url": "http://www.facbook.com/pages/shangri-lawless/270167463002683",
        "contact_email": "info@shangri-lawless.com",
        "hometown": "San Diego",
        "description": "A forgotten paradise to soothe the wary adventurer, or a lawless land of risk & Reward?  We are both.  A yin and yang.  An amalgamation of two elements, each playing off each other.",
        "location": {
            "string": "8:00 & E",
            "frontage": "8:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78916521244671,
            "gps_longitude": -119.22013446592231
        },
        "location_string": "8:00 & E"
    },
    {
        "uid": "a1Xd0000001IWKnEAO",
        "year": 2016,
        "name": "Pink Mammoth",
        "url": "http://www.pinkmammoth.org",
        "hometown": "San Francisco",
        "description": "Pink Mammoth is a not for profit house music and creative arts collective based in San Francisco. We strive to create an environment of love and compassion, selflessness and support, health and vitality, that encourages everyone we encounter to shine and thrive.",
        "location": {
            "string": "8:30 & F",
            "frontage": "8:30",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.79207163606192,
            "gps_longitude": -119.2194771620409
        },
        "location_string": "8:30 & F"
    },
    {
        "uid": "a1Xd0000001INY6EAO",
        "year": 2016,
        "name": "Playa Pete's Plaza",
        "hometown": "Alameda",
        "description": "Playa Pete's Plaza is the home port for the Artship PV Monaco. The PV stands for Playa Vessel and she makes Playa Pete's Plaza her home.\r\nhttps://www.facebook.com/groups/114999981871269/",
        "location": {
            "string": "8:30 & G",
            "frontage": "8:30",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.79240038197383,
            "gps_longitude": -119.22022952927168
        },
        "location_string": "8:30 & G"
    },
    {
        "uid": "a1Xd0000001IXP7EAO",
        "year": 2016,
        "name": "Illuminaughty",
        "url": "http://bit.ly/campilluminaughty",
        "contact_email": "camp-illuminaughty@googlegroups.com",
        "hometown": "Sunnyvale",
        "description": "Welcome to Camp Illuminaughty! Come by at dusk for our music and light-filled activities, then follow us and the Wall of Light out into the night to dance 'til dawn!",
        "location": {
            "string": "9:00 & J",
            "frontage": "9:00",
            "intersection": "J",
            "intersection_type": "&",
            "gps_latitude": 40.796281355415935,
            "gps_longitude": -119.21955363512441
        },
        "location_string": "9:00 & J"
    },
    {
        "uid": "a1Xd0000001IM70EAG",
        "year": 2016,
        "name": "Ranger Outpost Tokyo",
        "location": {
            "string": "9:00 & C",
            "frontage": "9:00",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.79302648316614,
            "gps_longitude": -119.21525318500149
        },
        "location_string": "9:00 & C"
    },
    {
        "uid": "a1Xd0000001IXefEAG",
        "year": 2016,
        "name": "Destiny of Fire",
        "contact_email": "welcome@destinyoffire.com",
        "hometown": "Los Angeles Mexico City",
        "location": {
            "string": "8:30 & K",
            "frontage": "8:30",
            "intersection": "K",
            "intersection_type": "&",
            "gps_latitude": 40.79371531675404,
            "gps_longitude": -119.22323907269939
        },
        "location_string": "8:30 & K"
    },
    {
        "uid": "a1Xd0000001IT0uEAG",
        "year": 2016,
        "name": "The Green Hour",
        "hometown": "Portland",
        "description": "The Green Hour Absinthe Bar and Root Beer Saloon serves the Red Baron's finest 1855-recipe hausgemacht at sunset, and ice-cold root beer to participants of all ages during the day. Welcome Home!",
        "location": {
            "string": "9:00 & D",
            "frontage": "9:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.79349147469058,
            "gps_longitude": -119.215867509203
        },
        "location_string": "9:00 & D"
    },
    {
        "uid": "a1Xd0000001IWL7EAO",
        "year": 2016,
        "name": "JOBI: Coffee, Tea or Me?",
        "hometown": "Bay Area",
        "description": "\"Coffee, Tea or Me?\"  Join us for fine coffee, teas and hot chocolate every day at 7:00 a.m. in our chill space with sofas, pillows and a firepit to warm your tush whether you are just getting up or on the glidepath down.",
        "location": {
            "string": "9:00 & D",
            "frontage": "9:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.79349147469058,
            "gps_longitude": -119.215867509203
        },
        "location_string": "9:00 & D"
    },
    {
        "uid": "a1Xd0000001IXi3EAG",
        "year": 2016,
        "name": "Tetrix Village",
        "hometown": "Sydney",
        "description": "Tetrix Village - Explore the mystical 140ft wooden labyrinth of Armone Galaxy, Experience the Stargazer Artcar, Kitty Litter Bar cocktails and jump wild on the trampoline park of Camp Meow. Pimp my pushie; A bike decoration workshop housed inside our giant robot head resident spaceman \"RubberArmstrong\".",
        "location": {
            "string": "9:00 & J",
            "frontage": "9:00",
            "intersection": "J",
            "intersection_type": "&",
            "gps_latitude": 40.796281355415935,
            "gps_longitude": -119.21955363512441
        },
        "location_string": "9:00 & J"
    },
    {
        "uid": "a1Xd0000001IJZqEAO",
        "year": 2016,
        "name": "Emergency Services Station 9:00",
        "location": {
            "string": "9:00 & C",
            "frontage": "9:00",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.79302648316614,
            "gps_longitude": -119.21525318500149
        },
        "location_string": "9:00 & C"
    },
    {
        "uid": "a1Xd0000001IWVlEAO",
        "year": 2016,
        "name": "Meow Now",
        "url": "http://www.meownow.org",
        "hometown": "Denver",
        "description": "Meow Now provides photo-cut-outs featuring concepts involving food and sex (separately). Come get a photo of yourself that would be very inappropriate to use professionally.",
        "location": {
            "string": "9:00 & F",
            "frontage": "9:00",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.79442144796539,
            "gps_longitude": -119.21709618342128
        },
        "location_string": "9:00 & F"
    },
    {
        "uid": "a1Xd0000001IVsnEAG",
        "year": 2016,
        "name": "Cirque de Moop",
        "hometown": "Reno",
        "description": "Cirque de Moop presents \"The Snark Bar\" is back to promote leaving no trace in a fun and entertaining ways. Come by and get rewarded for being a responsible Black Rock Resident by spinning the prize wheel!",
        "location": {
            "string": "9:00 & D",
            "frontage": "9:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.79349147469058,
            "gps_longitude": -119.215867509203
        },
        "location_string": "9:00 & D"
    },
    {
        "uid": "a1Xd0000001INMjEAO",
        "year": 2016,
        "name": "Discordia",
        "url": "https://discordia.camp",
        "contact_email": "info@discordia.camp",
        "hometown": "London, UK and Melbourne, Australia",
        "description": "Discordia is a 100% international camp of crazy Kiwis, Aussies and Brits who fly half-way around the world to build awesome things.\r\n\r\nCome have a frosty beverage in our huge misting pyramid, climb the 3-story high tower for the awesome views or just chill out to some of the best music on the playa from our resident DJs and interactive music system.",
        "location": {
            "string": "9:00 & I",
            "frontage": "9:00",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.79581638344092,
            "gps_longitude": -119.21893925928977
        },
        "location_string": "9:00 & I"
    },
    {
        "uid": "a1Xd0000001IOALEA4",
        "year": 2016,
        "name": "Ego Trip",
        "url": "https://www.facebook.com/campegotrip",
        "hometown": "San Diego",
        "description": "At Ego Trip we want you looking and feeling your best! Get pampered at our beauty bar, capture that stunning playa outfit at our photo booth, check out all your good sides in the EgoNOMitron, dance to our sexy beats and get drunk on your own vanity (and our delicious drinks) until everyone looks as good as you!",
        "location": {
            "string": "9:00 & E",
            "frontage": "9:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.793956462957034,
            "gps_longitude": -119.21648184200953
        },
        "location_string": "9:00 & E"
    },
    {
        "uid": "a1Xd0000001IQRjEAO",
        "year": 2016,
        "name": "Burners @ the End of the Universe",
        "url": "http://theendoftheuniverse.net",
        "contact_email": "burners@theendoftheuniverse.net",
        "hometown": "Area, Las Vegas, Los Angeles, Orange County",
        "description": "Burners at the End of the Universe proudly present: Astral Thruster Lounge.\r\n\r\nTheEndoftheUniverse.net",
        "location": {
            "string": "9:00 & K",
            "frontage": "9:00",
            "intersection": "K",
            "intersection_type": "&",
            "gps_latitude": 40.79674632413234,
            "gps_longitude": -119.22016801956524
        },
        "location_string": "9:00 & K"
    },
    {
        "uid": "a1Xd0000001IReCEAW",
        "year": 2016,
        "name": "GYST (Get Your Shit Together)",
        "hometown": "Sacramento",
        "description": "A collection of like-minded seekers all trying to Get Your Shit Together!",
        "location": {
            "string": "9:00 & I",
            "frontage": "9:00",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.79581638344092,
            "gps_longitude": -119.21893925928977
        },
        "location_string": "9:00 & I"
    },
    {
        "uid": "a1Xd0000001IYRWEA4",
        "year": 2016,
        "name": "DISTRIKT",
        "url": "http://distrikt.org",
        "contact_email": "info@distrikt.org",
        "hometown": "San Francisco",
        "description": "Bringing art & beat together - A rambunctious playa day party of vociferous beats from live DJ's, original art, and luscious blended libations from a shaded bar.  Your daytime dance, debaucherous and disorderly, DISTRIKT.",
        "location": {
            "string": "9:00 Public Plaza @ 10:30",
            "frontage": "9:00 Public Plaza",
            "intersection": "10:30",
            "intersection_type": "@",
            "gps_latitude": 40.79256133313418,
            "gps_longitude": -119.2141864372901
        },
        "location_string": "9:00 Public Plaza @ 10:30"
    },
    {
        "uid": "a1Xd0000001IOJzEAO",
        "year": 2016,
        "name": "Arctica Ice Sales - Ice Nine",
        "contact_email": "gentle@burningman.org",
        "hometown": "Iceland",
        "description": "Ice Nine is the ice sales igloo located on the 9 o'clock side of the city.  We'll be in a new location this year, back a few blocks from our original location.  Crushed and block ice are available for $3 per bag/block and $18 for a 6-pack of crushed.  Ice9 sales hours are Mon-Sat 9am-6pm and Sun Noon-6pm.",
        "location": {
            "string": "9:00 Public Plaza @ 5:45",
            "frontage": "9:00 Public Plaza",
            "intersection": "5:45",
            "intersection_type": "@",
            "gps_latitude": 40.79276962520508,
            "gps_longitude": -119.21499766263501
        },
        "location_string": "9:00 Public Plaza @ 5:45"
    },
    {
        "uid": "a1Xd0000001IXO9EAO",
        "year": 2016,
        "name": "Chop Shop",
        "hometown": "Flagstaff",
        "description": "Chop Shop is the best Playa neighborhood repair garage in BRC! We are ready to repair a wide variety of Playa transportation with parts, repairs and advice.",
        "location": {
            "string": "9:00 Public Plaza @ 3:15",
            "frontage": "9:00 Public Plaza",
            "intersection": "3:15",
            "intersection_type": "@",
            "gps_latitude": 40.792352979352394,
            "gps_longitude": -119.21499728426735
        },
        "location_string": "9:00 Public Plaza @ 3:15"
    },
    {
        "uid": "a1Xd0000001IViJEAW",
        "year": 2016,
        "name": "Mo's Mini Martini and Erotica",
        "contact_email": "tilt@earthlink.net",
        "hometown": "Santa Cruz",
        "description": "Mohammeds serves the coldest martini's and the hottest erotica on the playa. Stop by for an ice cold martini in our Bedouin tent and lounge around on our pillows and watch the world go by. If the mood hits you write a true erotic story to be included in our 300 year old book. We are THE daytime chill bedouin lounge on the playa according to us.",
        "location": {
            "string": "9:00 Portal & A",
            "frontage": "9:00 Portal",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.79209649034368,
            "gps_longitude": -119.21402456241272
        },
        "location_string": "9:00 Portal & A"
    },
    {
        "uid": "a1Xd0000001IRwDEAW",
        "year": 2016,
        "name": "Black Rock Yacht Club",
        "contact_email": "bryc@gmx.com",
        "hometown": "San Francisco",
        "description": "Black Rock Yacht Club - a camp for aeolian celebrants.",
        "location": {
            "string": "9:00 & L",
            "frontage": "9:00",
            "intersection": "L",
            "intersection_type": "&",
            "gps_latitude": 40.797211289590074,
            "gps_longitude": -119.2207824126125
        },
        "location_string": "9:00 & L"
    },
    {
        "uid": "a1Xd0000001IXVEEA4",
        "year": 2016,
        "name": "Above The Limit",
        "url": "http://www.campabovethelimit.com/",
        "contact_email": "info@campabovethelimit.com",
        "hometown": "Reno",
        "description": "City of Light, Guild of Flight\r\n\r\nWelcome aboard!\r\n\r\nWhat caused the light to go off 500 years ago in Da Vinci's mind to inspire dreams of flight? Come visit an illuminated tribute to human attempts to fly, from the fanciful ideas to modern aviation. Learn to make paper airplanes, stroll through images of flight, and enjoy flying-inspired music while enjoying water and beverages. Test your knowledge of aviation, and you may find yourself flying around the playa in the Black Rock Air Force F-15 Interceptor that calls Above The Limit home. \r\n\r\nBy night, enjoy the colorful lights, popcorn, beverages and music while you contemplate soaring off into the stars and beyond. Fly safe, may your journey be epic, and we look forward to welcoming you back aboard.",
        "location": {
            "string": "9:00 Public Plaza @ 6:15",
            "frontage": "9:00 Public Plaza",
            "intersection": "6:15",
            "intersection_type": "@",
            "gps_latitude": 40.792832848233445,
            "gps_longitude": -119.21491426366346
        },
        "location_string": "9:00 Public Plaza @ 6:15"
    },
    {
        "uid": "a1Xd0000001IXILEA4",
        "year": 2016,
        "name": "The Cove",
        "hometown": "Los Angeles",
        "description": "The Cove is a 14' tall tower designed for climbing and interaction among Burners, inside the tower is lined with cushions, blankets and pillows for lounging, sleeping and spending time with each other.",
        "location": {
            "string": "9:30 & E",
            "frontage": "9:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.79565505090518,
            "gps_longitude": -119.21355840874297
        },
        "location_string": "9:30 & E"
    },
    {
        "uid": "a1Xd0000001IOfHEAW",
        "year": 2016,
        "name": "Calico",
        "hometown": "Redwood City California and Oak Creek Colorado (aka Calico)",
        "description": "Camp Calico offers, yoga, tap dance and \"Mindful\" wine tasting. Come join us in these 3 great engaging art forms.",
        "location": {
            "string": "9:30 & E",
            "frontage": "9:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.79565505090518,
            "gps_longitude": -119.21355840874297
        },
        "location_string": "9:30 & E"
    },
    {
        "uid": "a1Xd0000001IVtgEAG",
        "year": 2016,
        "name": "FANDANGO!",
        "url": "http://www.fandangobrc.com/",
        "contact_email": "info@fandangobrc.com",
        "hometown": "San Luis Obispo",
        "description": "FANDANGO!: A 24 hour bar that provides a nice place to cool down (or warm up!). We welcome everyone (21+) 24 hours a day to come in and have a cocktail made fresh, there's no everclear and tang coolers here! We have shade, seating, pool, piano, music (with words) from music players or periodically live performances and we have a loving sassy attitude, FANDANGO loves you drunk after all.",
        "location": {
            "string": "9:30 & A",
            "frontage": "9:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.79337692443453,
            "gps_longitude": -119.21182077171073
        },
        "location_string": "9:30 & A"
    },
    {
        "uid": "a1Xd0000001IXg2EAG",
        "year": 2016,
        "name": "Infinite Bloom",
        "url": "http://www.infinitebloom.org/burningman",
        "hometown": "Santa Cruz",
        "description": "Infinite Bloom offers us a vision of ourselves as part of an infinite, blossoming, ever-transforming universe, illuminated by the full spectrum of color and enfolded and surrounded by the sacred geometry of life. We invite  you to join us to discover what it feels like to bloom beyond singular experience into infinity!",
        "location": {
            "string": "9:30 & D",
            "frontage": "9:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.7950855217312,
            "gps_longitude": -119.21312398830506
        },
        "location_string": "9:30 & D"
    },
    {
        "uid": "a1Xd0000001IX7NEAW",
        "year": 2016,
        "name": "Black Rock City Science Center",
        "contact_email": "cowpunchartillery@gmail.com",
        "hometown": "Seattle",
        "description": "Pool tables, multiple bars, hug machines, cool environmental art, tabletop gaming, laser tag, a shadow wall, and more!  Come check us out day or night!",
        "location": {
            "string": "B & 8:15",
            "frontage": "B",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.78973011696535,
            "gps_longitude": -119.21713560963664
        },
        "location_string": "B & 8:15"
    },
    {
        "uid": "a1Xd0000001IQfmEAG",
        "year": 2016,
        "name": "KSA Disco Katz",
        "url": "https://www.facebook.com/discokatz/",
        "contact_email": "meow@discokatz.com",
        "hometown": "San Francisco",
        "description": "Frisky felines that throw furrocious pawties in our gLitter Box. Keep Screwin Around.",
        "location": {
            "string": "9:30 & F",
            "frontage": "9:30",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.79622457844993,
            "gps_longitude": -119.21399283663455
        },
        "location_string": "9:30 & F"
    },
    {
        "uid": "a1Xd0000001IKY1EAO",
        "year": 2016,
        "name": "Camp Samovar",
        "url": "https://www.facebook.com/Camp-Samovar-224458257645409/",
        "contact_email": "azarh@yahoo.com",
        "hometown": "Oakland",
        "description": "Please come by for Persian tea and delicious dates and fabulous company during sunset every day from 6-8pm.  On different days during our tea ceremony, we will offer, \"Bollywood Bellydance\" lessons, hookah's and soothing music.  In addition to our tea serves, we are offering a special event on Friday from 2-4pm called, Moscow Mules and Madonna, where we will serve Moscow Mules and sing and dance to Madonna's music.",
        "location": {
            "string": "A & 8:15",
            "frontage": "A",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.789478782063355,
            "gps_longitude": -119.216332905127
        },
        "location_string": "A & 8:15"
    },
    {
        "uid": "a1Xd0000001IXChEAO",
        "year": 2016,
        "name": "Cirque Du Formage",
        "contact_email": "stevenh@cvlt-la.com",
        "hometown": "Long Beach",
        "description": "Come visit Cirque du Formage for some great wine, cheese and sunrise Bloody Marys provided by Big Cheese and our Family Formage!",
        "location": {
            "string": "B & 8:15",
            "frontage": "B",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.78973011696535,
            "gps_longitude": -119.21713560963664
        },
        "location_string": "B & 8:15"
    },
    {
        "uid": "a1Xd0000001IXLjEAO",
        "year": 2016,
        "name": "Yes, And.",
        "hometown": "Seattle",
        "description": "Come join us for a drink, to play giant Jenga. or just to take a nap in a pillow pit filled with stuffed animals.  If you do stop by for a drink, be prepared w/ a secret to tell the mannequin, but be careful, he's untrustworthy... On an unrelated note, there may be periodic spoken word pieces performed by the mannequin.",
        "location": {
            "string": "9:30 & E",
            "frontage": "9:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.79565505090518,
            "gps_longitude": -119.21355840874297
        },
        "location_string": "9:30 & E"
    },
    {
        "uid": "a1Xd0000001IB27EAG",
        "year": 2016,
        "name": "Organization",
        "hometown": "San Francisco",
        "description": "The Organization: Espresso Martini Parties 1-3pm Tuesday-Saturday!",
        "location": {
            "string": "A & 8:45",
            "frontage": "A",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.791300695156856,
            "gps_longitude": -119.21494555440992
        },
        "location_string": "A & 8:45"
    },
    {
        "uid": "a1Xd0000001IQPYEA4",
        "year": 2016,
        "name": "PLAYA 54",
        "url": "http://www.facebook.com/playa54",
        "contact_email": "jd8812@aol.com",
        "hometown": "Los Angeles",
        "description": "PLAYA 54 - An Afternoon Delight",
        "location": {
            "string": "A & 8:45",
            "frontage": "A",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.791300695156856,
            "gps_longitude": -119.21494555440992
        },
        "location_string": "A & 8:45"
    },
    {
        "uid": "a1Xd0000001IPOoEAO",
        "year": 2016,
        "name": "KashyyyK",
        "hometown": "New York City",
        "description": "Welcome to the Wookiee Planet of KashyyyK, known for great music, dancing, big furry hugs, & Wookiee Juice! Beware of meteor showers...",
        "location": {
            "string": "B & 9:15",
            "frontage": "B",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.793310525070154,
            "gps_longitude": -119.21351125468065
        },
        "location_string": "B & 9:15"
    },
    {
        "uid": "a1Xd0000001IQMyEAO",
        "year": 2016,
        "name": "Identity Awareness",
        "url": "http://www.identity-awareness.com",
        "hometown": "Sammamish",
        "description": "Camp Identity Awareness is a art support camp for the art installation Identity Awareness - Union.  We may not always be there as we are interacting with fellow burners but please feel free to utilize our hammocks and maybe pond your identity.",
        "location": {
            "string": "B & 8:45",
            "frontage": "B",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79170076257172,
            "gps_longitude": -119.21563500580646
        },
        "location_string": "B & 8:45"
    },
    {
        "uid": "a1Xd0000001IXF2EAO",
        "year": 2016,
        "name": "PlayaNauts",
        "url": "http://www.playanauts.com",
        "contact_email": "playanauts@gmail.com",
        "hometown": "Eugene, Oregon, South Lake Tahoe.",
        "description": "We are the PlayaNauts! Come play with us! Games, Parties, a Bar,\r\nWe have tons of events throughout the week, Giant Beer Pong tournaments, Giant Drinking Jenga, Ball Pit Pool, and so much more\r\nlook for our ArtCar \"Scarabis Beetalius\" or seek our Secret Bus Stops for an experience of a lifetime ;)",
        "location": {
            "string": "A & 9:15",
            "frontage": "A",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79278896602692,
            "gps_longitude": -119.21298209325717
        },
        "location_string": "A & 9:15"
    },
    {
        "uid": "a1Xd0000001IRzvEAG",
        "year": 2016,
        "name": "Possible Project",
        "url": "https://www.facebook.com/groups/possibleproject",
        "contact_email": "possibleproject@groups.facebook.com",
        "hometown": "New York, Houston",
        "description": "Swing by the Possible Project's Piazza di Photo for refreshments, music and instant photographs. Refill your canteen any time, and visit our PhotoDuomo, where you can capture the moment and take it with you.",
        "location": {
            "string": "C & 8:15",
            "frontage": "C",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.78998145273607,
            "gps_longitude": -119.2179383169208
        },
        "location_string": "C & 8:15"
    },
    {
        "uid": "a1Xd0000001IVsTEAW",
        "year": 2016,
        "name": "Anywhere",
        "hometown": "SF",
        "description": "Good people getting together to play and co-create. Maybe here. Maybe there. Really. It can happen Anywhere.",
        "location": {
            "string": "C & 8:45",
            "frontage": "C",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.792100831597146,
            "gps_longitude": -119.21632445997854
        },
        "location_string": "C & 8:45"
    },
    {
        "uid": "a1Xd0000001IRJJEA4",
        "year": 2016,
        "name": "7 Deadly Gins",
        "url": "https://www.facebook.com/The7DeadlyGins",
        "contact_email": "7deadlygins@gmail.com",
        "hometown": "Bend",
        "description": "Come enjoy a premium, ice-cold gin & tonic in our famously lush desert oasis bar (we have a big surprise for the gin aficionados of BRC this year!), and get your groove on to quality tunes. Plus, you won't want to miss the Wednesday night \"Speak Sleazy\" Gin Tasting of the world of boutique gins! And of course our beloved mascot - Special Ed, the vibrating, girating giraffe – will be providing devious entertainment again! It's all happening Monday - Sunday; 3.30-6.30pm. (Check our FB page for a full schedule of other daytime and nighttime events.)",
        "location": {
            "string": "C & 8:45",
            "frontage": "C",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.792100831597146,
            "gps_longitude": -119.21632445997854
        },
        "location_string": "C & 8:45"
    },
    {
        "uid": "a1Xd0000001IUyeEAG",
        "year": 2016,
        "name": "Altitude Lounge",
        "url": "https://www.facebook.com/pages/Altitude-Lounge/127966623902091",
        "hometown": "Boise",
        "description": "Have you ever dreamt of flying over BRC? Now imagine flying over BRC while in a cushy couch surrounded by friends. Altitude Lounge can make your dreams come true. Climb our 50-ft tower and see the City you are a part of. We offer magnificent views, downtempo music, and couches that will suck you in as you watch the world go by. We're open 24hrs a day, and we will keep our tower beacon lit so you can navigate the entire playa in the dark of night, and eventually find your way home.",
        "location": {
            "string": "D & 8:45",
            "frontage": "D",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79250090223318,
            "gps_longitude": -119.21701391692622
        },
        "location_string": "D & 8:45"
    },
    {
        "uid": "a1Xd0000001IBwxEAG",
        "year": 2016,
        "name": "Hangar 4",
        "hometown": "San Diego",
        "description": "Challenge yourself to climb one of many routes up Intention 1 Rocket.  When you are done bouldering stop by the bar and tell us your best adventure story!",
        "location": {
            "string": "C & 8:45",
            "frontage": "C",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.792100831597146,
            "gps_longitude": -119.21632445997854
        },
        "location_string": "C & 8:45"
    },
    {
        "uid": "a1Xd0000001IRrpEAG",
        "year": 2016,
        "name": "Frozen Oasis",
        "hometown": "San Francisco Bay Area",
        "description": "Frozen Oasis Lounge\r\nShelter from the storm and relax under the misters with a frozen yummy slushy drink and a live classical music performance by the Playa Pops Symphony",
        "location": {
            "string": "C & 8:15",
            "frontage": "C",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.78998145273607,
            "gps_longitude": -119.2179383169208
        },
        "location_string": "C & 8:15"
    },
    {
        "uid": "a1Xd0000001IS6hEAG",
        "year": 2016,
        "name": "BRC Hash House Harriers (BRCH3)",
        "url": "http://brch3.com/",
        "description": "We are the BRC Hash House Harriers Bike Repair Camp, a drinking club with a running problem.  Our mission is to share our love of hashing with Black Rock City while keeping the beer cold and bikes running smoothly.\r\n\r\nhttp://brch3.com/",
        "location": {
            "string": "C & 9:15",
            "frontage": "C",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79383208574335,
            "gps_longitude": -119.21404041775784
        },
        "location_string": "C & 9:15"
    },
    {
        "uid": "a1Xd0000001IWW0EAO",
        "year": 2016,
        "name": "Space Virgins",
        "url": "http://www.spacevirgin.org",
        "contact_email": "info@spacevirgin.org",
        "hometown": "Seattle",
        "description": "The Space Virgin Arts Collective is a 501c3 non-profit arts group with the mission of building community through collaboration. We started as a Seattle-based Burning Man theme camp in 1994, but we have since grown and our projects include off-playa art projects and events. In keeping with the Burning Man philosophy \"no observers, only participants\", our art is often interactive and experiential, plunging participants into theatrical-style sets and engendering joyful, transformative experiences. www.spacevirgin.org",
        "location": {
            "string": "C & 8:15",
            "frontage": "C",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.78998145273607,
            "gps_longitude": -119.2179383169208
        },
        "location_string": "C & 8:15"
    },
    {
        "uid": "a1Xd0000001IXa4EAG",
        "year": 2016,
        "name": "Soul City",
        "url": "http://www.campsoulcity.com",
        "hometown": "Fairfax Station",
        "description": "Soul City is bringing that backyard cookout vibe to the playa, complete with spades and dominoes tournaments and lots of sh*t-talking. Or drop by for some heavily incensed, finger-snapping spoken word.",
        "location": {
            "string": "D & 8:15",
            "frontage": "D",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79023278937556,
            "gps_longitude": -119.21874102697954
        },
        "location_string": "D & 8:15"
    },
    {
        "uid": "a1Xd0000001IVVjEAO",
        "year": 2016,
        "name": "Stag Camp 10.0",
        "url": "https://www.facebook.com/groups/stagcamp/",
        "contact_email": "stagcamp9@gmail.com",
        "hometown": "Everywhere",
        "description": "Stag Camp continues celebrating radical self-reliance though offering our spirit of social inclusiveness mixed with personal responsibility. We offer a large group shade, music, games, a happening neighborhood bar, and friendship.",
        "location": {
            "string": "D & 8:15",
            "frontage": "D",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79023278937556,
            "gps_longitude": -119.21874102697954
        },
        "location_string": "D & 8:15"
    },
    {
        "uid": "a1Xd0000001IOipEAG",
        "year": 2016,
        "name": "Camp Yes Please",
        "hometown": "San Francisco",
        "description": "Yes: adv - Used to express affirmation, agreement, positive affirmation, or consent. Please: adv - Give pleasure to or to be pleasing to; give satisfaction. Yes Please is the answer to every question. Come chill in our calm and revitalizing sanctuary, dance with new friends and experience our inclusive oasis of sex-positivity, queer empowerment and love. Be sure to visit our infamous Non-Monogamy Advice Booth, and experience our Labyrinth and Apparent Horizon art installations.",
        "location": {
            "string": "D & 8:15",
            "frontage": "D",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79023278937556,
            "gps_longitude": -119.21874102697954
        },
        "location_string": "D & 8:15"
    },
    {
        "uid": "a1Xd0000001IXfiEAG",
        "year": 2016,
        "name": "Clue Bar",
        "url": "https://www.facebook.com/cluebar/",
        "hometown": "Bend",
        "description": "Clue Bar Murder Mystery Adventure and Bar.  Come drink our salty mystery beverages.",
        "location": {
            "string": "D & 9:15",
            "frontage": "D",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.794353648046624,
            "gps_longitude": -119.21456958248888
        },
        "location_string": "D & 9:15"
    },
    {
        "uid": "a1Xd0000001IVHHEA4",
        "year": 2016,
        "name": "Rum Amok",
        "hometown": "San Francisco",
        "description": "Come relax, refresh and enjoy our booster exotic Rum Cocktails in our tropical oasis in the midst of Black Rock City! Life is a Beach, long live Rum and Burning Man!",
        "location": {
            "string": "D & 9:15",
            "frontage": "D",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.794353648046624,
            "gps_longitude": -119.21456958248888
        },
        "location_string": "D & 9:15"
    },
    {
        "uid": "a1Xd0000001IXD1EAO",
        "year": 2016,
        "name": "Fucking Flamingos",
        "url": "http://www.fuckingflamingos.com",
        "contact_email": "emorysimson@gmail.com",
        "hometown": "Phoenix",
        "description": "Celebrating our 10th year on Playa this year, we are a group of veteran Burner's that regularly incorporates virgins into our camp and impress upon them our vision of a Burner lifestyle filled with fun, irreverence, creativity, participation and semi-responsible-ish adventure.",
        "location": {
            "string": "E & 8:45",
            "frontage": "E",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.792900974479906,
            "gps_longitude": -119.21770337664968
        },
        "location_string": "E & 8:45"
    },
    {
        "uid": "a1Xd0000001IWVbEAO",
        "year": 2016,
        "name": "Eyes of the Soul",
        "hometown": "San Francisco",
        "description": "Eyes of the Soul is a unique Burning Man experience that combines providing Eye Make-up by former professional make-up artist, Astrology Readings, and Tea all in a rejuvenating space with soothing sounds and aroma-therapy.",
        "location": {
            "string": "E & 8:15",
            "frontage": "E",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79048412688384,
            "gps_longitude": -119.21954373981305
        },
        "location_string": "E & 8:15"
    },
    {
        "uid": "a1Xd0000001IQSwEAO",
        "year": 2016,
        "name": "Shrumen Lumen Camp",
        "hometown": "San Francisco",
        "description": "Home of the Shrumens",
        "location": {
            "string": "E & 8:15",
            "frontage": "E",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79048412688384,
            "gps_longitude": -119.21954373981305
        },
        "location_string": "E & 8:15"
    },
    {
        "uid": "a1Xd0000001IR5TEAW",
        "year": 2016,
        "name": "Camp Cleopatra",
        "contact_email": "rex_with_no_t@yahoo.com",
        "hometown": "Sacramento",
        "description": "Stop by Camp Cleopatra any day between 11 am and 2 pm (or any other time you see someone around) and enjoy a Cleopatra with friends. In case you didn't know, a Cleopatra is a health drink with rum...",
        "location": {
            "string": "D & 9:15",
            "frontage": "D",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.794353648046624,
            "gps_longitude": -119.21456958248888
        },
        "location_string": "D & 9:15"
    },
    {
        "uid": "a1Xd0000001IX6FEAW",
        "year": 2016,
        "name": "Hen House",
        "hometown": "Reno",
        "description": "The Hen House is made up of solely girls who build their camp and host some fun events complete with omelets, booze, and booty shaking.",
        "location": {
            "string": "E & 8:45",
            "frontage": "E",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.792900974479906,
            "gps_longitude": -119.21770337664968
        },
        "location_string": "E & 8:45"
    },
    {
        "uid": "a1Xd0000001IVj7EAG",
        "year": 2016,
        "name": "Pink Fuzzy Monkey",
        "url": "http://pinkfuzzymonkey.org",
        "hometown": "Reno",
        "description": "Get twisted at Camp Pink Fuzzy Monkey with one of the funnest themed twister boards on the Playa, lounge dj sessions, and join in our crazy fun monkey parties. And if you really wanna get charged up, stop in at our Banana Bunch Fruit Salad phone charging stations and plug yourself in!",
        "location": {
            "string": "E & 8:15",
            "frontage": "E",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79048412688384,
            "gps_longitude": -119.21954373981305
        },
        "location_string": "E & 8:15"
    },
    {
        "uid": "a1Xd0000001IXDpEAO",
        "year": 2016,
        "name": "Bring a Pheromone",
        "url": "http://bringapheromone.com",
        "contact_email": "jumper@bringapheromone.com",
        "hometown": "San Francisco",
        "description": "Are pheromones the secret to lasting love and connection? Or, do you just want an excuse to smell a stranger's armpit? Not Sure? Just Bring a Pheromone!",
        "location": {
            "string": "D & 8:45",
            "frontage": "D",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79250090223318,
            "gps_longitude": -119.21701391692622
        },
        "location_string": "D & 8:45"
    },
    {
        "uid": "a1Xd0000001IUxbEAG",
        "year": 2016,
        "name": "Zendo 9:00",
        "url": "http://www.zendoproject.org",
        "contact_email": "zendo@maps.org",
        "hometown": "Santa Cruz",
        "description": "Feeling out of sorts and looking for a place to recoup? Zendo volunteers are available 24/7 to offer psychological support and education for drug-related concerns. Come by one of our open-air yurts by the 9 o'clock & 3 o'clock ESD/RHQ stations.",
        "location": {
            "string": "D & 9:15",
            "frontage": "D",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.794353648046624,
            "gps_longitude": -119.21456958248888
        },
        "location_string": "D & 9:15"
    },
    {
        "uid": "a1Xd0000001IV3mEAG",
        "year": 2016,
        "name": "Stardust Lounge",
        "contact_email": "stardust@gettorussia.com",
        "hometown": "San Francisco",
        "description": "Go all-in at the Stardust Lounge Casino, Spa, and Chapel! Double down on some dirty martinis and dirtier games of chance and skill at the Casino, get your playa wedding on at the Chapel, then clean up and cool off with rejuvenating treatments at the Spa.",
        "location": {
            "string": "E & 8:45",
            "frontage": "E",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.792900974479906,
            "gps_longitude": -119.21770337664968
        },
        "location_string": "E & 8:45"
    },
    {
        "uid": "a1Xd0000001IX1yEAG",
        "year": 2016,
        "name": "The Fastest Pizza Stand",
        "url": "http://fps.interchang.es/",
        "contact_email": "fps@misfit-media.com",
        "hometown": "NYC & SF",
        "description": "The Fastest Pizza Stand",
        "location": {
            "string": "D & 9:15",
            "frontage": "D",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.794353648046624,
            "gps_longitude": -119.21456958248888
        },
        "location_string": "D & 9:15"
    },
    {
        "uid": "a1Xd0000001IWx8EAG",
        "year": 2016,
        "name": "aLittle",
        "hometown": "Oakland",
        "description": "There's aLittle something for everyone: potent libations, colorful spontaneity, self-paced creative expression, and more!",
        "location": {
            "string": "D & 8:45",
            "frontage": "D",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79250090223318,
            "gps_longitude": -119.21701391692622
        },
        "location_string": "D & 8:45"
    },
    {
        "uid": "a1Xd0000001IXF7EAO",
        "year": 2016,
        "name": "Friendlandia",
        "contact_email": "friendlandiacamp@gmail.com",
        "hometown": "San Francisco",
        "description": "We have many customs and traditions for celebrating and recognizing romantic relationships. However, friendships are often longer lasting and as strong as many marriages, and yet we often don't spend the time to celebrate and honor those relationships.\r\n\r\nWhat if Friends could get \"Friendgaged\"? What if they could commit to each other in ceremony? Wouldn't it be a better world if Friends more often expressed their dedication and love to one another?\r\n\r\nFriendlandia is a place to celebrate new and long-time Friendships in ceremony by sharing vows, exchanging Friendship Bracelets, and expressing love for the Friendships in your life. Come have a ceremony at our Temple of Friendgagement, create a Friendship Bracelet for your friend on our Friendship Loom, and become BFFs (Burner Friends Forever).",
        "location": {
            "string": "D & 9:15",
            "frontage": "D",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.794353648046624,
            "gps_longitude": -119.21456958248888
        },
        "location_string": "D & 9:15"
    },
    {
        "uid": "a1Xd0000001IXj6EAG",
        "year": 2016,
        "name": "Dawn Patrol",
        "location": {
            "string": "E & 8:45",
            "frontage": "E",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.792900974479906,
            "gps_longitude": -119.21770337664968
        },
        "location_string": "E & 8:45"
    },
    {
        "uid": "a1Xd0000001IVQKEA4",
        "year": 2016,
        "name": "Camp YNot",
        "hometown": "West Hollywood, CA",
        "description": "Camp YNot is Burning Man's center for Unicorn \"uni-fication\" and growth. Come experience the benefits of Unicorn Conversion Therapy and become the Unicorn that you've always wanted to be!",
        "location": {
            "string": "E & 8:15",
            "frontage": "E",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79048412688384,
            "gps_longitude": -119.21954373981305
        },
        "location_string": "E & 8:15"
    },
    {
        "uid": "a1Xd0000001IVtbEAG",
        "year": 2016,
        "name": "Bubbles and Bass",
        "url": "http://www.bubblesandbass.com/",
        "contact_email": "bubblesandbass@gmail.com",
        "hometown": "New York",
        "description": "Welcome to Bubbles and Bass where we rock you out from first light til midday with bubbly bass-tastic house music.  Dance the AM hours away, enjoy an interesting conversation with a new friend, and drink some bubbly while you watch the sun rise over the Playa!",
        "location": {
            "string": "Esplanade & 9:15",
            "frontage": "Esplanade",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.791832778680835,
            "gps_longitude": -119.21201196827568
        },
        "location_string": "Esplanade & 9:15"
    },
    {
        "uid": "a1Xd0000001IXbqEAG",
        "year": 2016,
        "name": "Lunar Fueling Station",
        "hometown": "San Francisco",
        "description": "The Lunar Fueling Station is a rest stop for astronauts en route to other planets.  Since water is scarce we gift hydrating drinks to travelers and our shade protects travelers from the harsh moon conditions.  We will also have a Moon Landing Hoax stage where you and your friends can re-enact NASA's faking of a moon landing (and photos will be e mailed to you after the event).  The Station also has a FM radio station at 90.9 on the dial to send communiqués to other planets.  Our team consists of multiple scientists, philosophers, physicians, and engineers who give lectures on planetary sciences, biology, neuroscience, and more.  A portable lab is set up for conducting experiments in chemistry and biology, to help educate travelers on terraforming technologies they'll need in their emigration. In the evenings we have a rocket fire sculpture for keeping warm in the harsh moon climate.",
        "location": {
            "string": "E & 9:15",
            "frontage": "E",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79487521198001,
            "gps_longitude": -119.2150987488738
        },
        "location_string": "E & 9:15"
    },
    {
        "uid": "a1Xd0000001IUXsEAO",
        "year": 2016,
        "name": "Shwar Town",
        "hometown": "Eugene",
        "description": "Shwar Town doesn't fuck around! We're all about gett'n down to some quality underground house, bass music, glitch hop, DNB, garage, and 2step. We are a Burning Man camp based out of Eugene Oregon and also have members from Colorado, Alaska and California. Our town is comprised of a Hexagon of carports with a large center pole and shaded lounge in the center. We have been on the playa for 10+ years and invite you to come by and enjoy free Kombucha all week long!",
        "location": {
            "string": "F & 8:45",
            "frontage": "F",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.7933010483374,
            "gps_longitude": -119.21839283914905
        },
        "location_string": "F & 8:45"
    },
    {
        "uid": "a1Xd0000002ycoSEAQ",
        "year": 2016,
        "name": "The Harmoniscope Project",
        "url": "http://www.harmoniscope.com",
        "contact_email": "harmoniscope@gmail.com",
        "hometown": "Seattle",
        "description": "The camp in support of the Harmoniscope Project \r\nwww.harmoniscope.com",
        "location": {
            "string": "E & 9:15",
            "frontage": "E",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79487521198001,
            "gps_longitude": -119.2150987488738
        },
        "location_string": "E & 9:15"
    },
    {
        "uid": "a1Xd0000001IXkYEAW",
        "year": 2016,
        "name": "What Would Leo Do?",
        "hometown": "Aspen and San Francisco",
        "description": "What would Leo do?  A Lot!",
        "location": {
            "string": "E & 9:15",
            "frontage": "E",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79487521198001,
            "gps_longitude": -119.2150987488738
        },
        "location_string": "E & 9:15"
    },
    {
        "uid": "a1Xd0000001IR9VEAW",
        "year": 2016,
        "name": "Camp Suburbia",
        "url": "http://www.facebook.com/CampSuburbia",
        "contact_email": "campsuburbia@gmail.com",
        "hometown": "Bend",
        "description": "The grass really is greener on this side of the fence.",
        "location": {
            "string": "Esplanade & 9:00 Portal",
            "frontage": "Esplanade",
            "intersection": "9:00 Portal",
            "intersection_type": "&",
            "gps_latitude": 40.791243985475894,
            "gps_longitude": -119.21289835527465
        },
        "location_string": "Esplanade & 9:00 Portal"
    },
    {
        "uid": "a1Xd0000001ICZLEA4",
        "year": 2016,
        "name": "Camp MisBeeHive",
        "hometown": "Denver",
        "description": "Bumble, Buzz and Humm in our Hive of  self expression, music, entertainment and dance parties!  Bee-friend our swarm over sweet nectar refreshments, and we'll bee sure you get some honey:)",
        "location": {
            "string": "E & 9:15",
            "frontage": "E",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79487521198001,
            "gps_longitude": -119.2150987488738
        },
        "location_string": "E & 9:15"
    },
    {
        "uid": "a1Xd0000001IT9VEAW",
        "year": 2016,
        "name": "Martini Village",
        "contact_email": "aadams1997@yahoo.com",
        "hometown": "Reno",
        "description": "Come to Martini Village and enjoy cold refreshments, entertainment and much more!  Look us up for our scheduled events or just stop by and check out a random happy hour.  Be prepared to be immersed in the 10 principles of the playa.",
        "location": {
            "string": "E & 9:15",
            "frontage": "E",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79487521198001,
            "gps_longitude": -119.2150987488738
        },
        "location_string": "E & 9:15"
    },
    {
        "uid": "a1Xd0000001ISvpEAG",
        "year": 2016,
        "name": "LoveCow",
        "hometown": "Toronto",
        "description": "LoveCow is a celebration of life on earth. We combine shamanic sound therapy with the world’s grooviest dance music to infuse humanity, the playa, and the universe with love.\r\n\r\nBeyond the transcendental musical magic, movement classes, yoga, delicious food, energy healings of all sorts (like Reiki, massage and shamanism), guided meditations, chill out space, and infinitely more are offered in our psychedelic sound sanctuary, healing sanctuary and jungly dance floor.\r\n\r\nWe love and welcome you as you are.",
        "location": {
            "string": "Esplanade & 9:30",
            "frontage": "Esplanade",
            "intersection": "9:30",
            "intersection_type": "&",
            "gps_latitude": 40.792332774424715,
            "gps_longitude": -119.21102439458956
        },
        "location_string": "Esplanade & 9:30"
    },
    {
        "uid": "a1Xd0000001IOmDEAW",
        "year": 2016,
        "name": "Bureau of Misinformation",
        "url": "http://www.bureauofmisinformation.com/",
        "contact_email": "bureauofmisinformation@gmail.com",
        "hometown": "Los Angeles",
        "description": "The Bureau of Misinformation is Black Rock City's leading source of radical ridiculosity, ambiguity, and factual inconsistency.",
        "location": {
            "string": "Esplanade & 9:00 Portal",
            "frontage": "Esplanade",
            "intersection": "9:00 Portal",
            "intersection_type": "&",
            "gps_latitude": 40.791243985475894,
            "gps_longitude": -119.21289835527465
        },
        "location_string": "Esplanade & 9:00 Portal"
    },
    {
        "uid": "a1Xd0000001IOAkEAO",
        "year": 2016,
        "name": "Camp Charcuterie",
        "hometown": "Greensboro",
        "description": "Our Camp is based on a wine, food, music, and games theme: Eat, Drink and be Merry!",
        "location": {
            "string": "E & 9:15",
            "frontage": "E",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79487521198001,
            "gps_longitude": -119.2150987488738
        },
        "location_string": "E & 9:15"
    },
    {
        "uid": "a1Xd0000001IGw6EAG",
        "year": 2016,
        "name": "Woop Woop",
        "hometown": "Boulder Colorado",
        "description": "Woop Woop means distant, remote even, from the daily default world.",
        "location": {
            "string": "F & 8:45",
            "frontage": "F",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.7933010483374,
            "gps_longitude": -119.21839283914905
        },
        "location_string": "F & 8:45"
    },
    {
        "uid": "a1Xd0000001IXVJEA4",
        "year": 2016,
        "name": "Pink Heart",
        "url": "http://pinkheartcamp.wordpress.com/",
        "contact_email": "everything@pinkheartcamp.com",
        "hometown": "San Diego",
        "description": "Pink Heart invites you to our oasis of shade, fur couches, chilled cucumber water and love. Recalibrate your body, mind, and spirit in our Pink Lounge while connecting with fellow travelers.  Connect & share experiences while gazing upon the open Playa, or enjoy carnival games and vegan ice cream!",
        "location": {
            "string": "Esplanade & 8:00",
            "frontage": "Esplanade",
            "intersection": "8:00",
            "intersection_type": "&",
            "gps_latitude": 40.78817275672073,
            "gps_longitude": -119.21523991161457
        },
        "location_string": "Esplanade & 8:00"
    },
    {
        "uid": "a1Xd0000001IBkHEAW",
        "year": 2016,
        "name": "Club Neu Verboten",
        "contact_email": "clubverboten@aol.com",
        "hometown": "reno",
        "description": "Club Neu Verboten provides our usual retro avant garde parties under the massive star tent. This year in particular should be a great one for our loyal patrons!",
        "location": {
            "string": "Esplanade & 8:45",
            "frontage": "Esplanade",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79056724241226,
            "gps_longitude": -119.21368156739108
        },
        "location_string": "Esplanade & 8:45"
    },
    {
        "uid": "a1Xd0000001INXXEA4",
        "year": 2016,
        "name": "Disco Space Shuttle",
        "url": "https://www.facebook.com/discospaceshuttle/?fref=ts",
        "hometown": "San Francisco",
        "description": "Join us in the late mornings and early afternoons to confess your sins and rejuvenate your mind and body with a tasty Blood Mary.  Then join us at night to fly across the Playa on the Disco Space Shuttle",
        "location": {
            "string": "F & 8:45",
            "frontage": "F",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.7933010483374,
            "gps_longitude": -119.21839283914905
        },
        "location_string": "F & 8:45"
    },
    {
        "uid": "a1Xd0000001IX4OEAW",
        "year": 2016,
        "name": "Camp Darwin",
        "hometown": "San Francisco, CA",
        "description": "Camp Darwin supports a giant kinetic art piece - a sailboat that evolved legs to survive on a dry lakebed.",
        "location": {
            "string": "G & 8:45",
            "frontage": "G",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79370590997052,
            "gps_longitude": -119.21907767038495
        },
        "location_string": "G & 8:45"
    },
    {
        "uid": "a1Xd0000001IXPMEA4",
        "year": 2016,
        "name": "Phasmantis",
        "hometown": "We have two hometowns: Los Angeles & Seattle",
        "description": "Phasmantis is an eccentric combination of music, drinks, food, and fun. Boisterous yet reserved, Phasmantis may or may not be what you expected.",
        "location": {
            "string": "G & 8:15",
            "frontage": "G",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.790992190347644,
            "gps_longitude": -119.22114640878951
        },
        "location_string": "G & 8:15"
    },
    {
        "uid": "a1Xd0000001IJxKEAW",
        "year": 2016,
        "name": "Black Rock Piano Lounge",
        "contact_email": "bell.matt@gmail.com",
        "hometown": "seattle",
        "description": "The Black Rock Piano Lounge, a place to drop in, enjoy and share music while relaxing.",
        "location": {
            "string": "G & 8:15",
            "frontage": "G",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.790992190347644,
            "gps_longitude": -119.22114640878951
        },
        "location_string": "G & 8:15"
    },
    {
        "uid": "a1Xd0000001IWLCEA4",
        "year": 2016,
        "name": "Bedouins",
        "contact_email": "pluminessence@gmail.com",
        "hometown": "Brooklyn",
        "description": "Bedoiuns i.e. desert wanderers",
        "location": {
            "string": "F & 9:15",
            "frontage": "F",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79539677754363,
            "gps_longitude": -119.21562791691271
        },
        "location_string": "F & 9:15"
    },
    {
        "uid": "a1Xd0000001IOqMEAW",
        "year": 2016,
        "name": "Antevasin",
        "hometown": "Tahoe/Truckee",
        "description": "Antevasin is the place to leave the bustling city and live at the edge of transcendence. Venture into the unknown through sound healing and guided meditation....arise and awaken to a new world!",
        "location": {
            "string": "H & 8:15",
            "frontage": "H",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.791243763698084,
            "gps_longitude": -119.22194901027675
        },
        "location_string": "H & 8:15"
    },
    {
        "uid": "a1Xd0000001IXU1EAO",
        "year": 2016,
        "name": "Lunar Disco",
        "contact_email": "lunacywithapinchofdisco@gmail.com",
        "hometown": "San Fransisco",
        "description": "Lunacy with a Pinch of Disco. Follow the sound, follow the moon. \r\nFor all intergalactic Burners on the dark side of the moon: Zero Gravity. Disco Nap. Time, Space & Heart Exploration. Teleport your body & mind with Art, Dance & Music.",
        "location": {
            "string": "G & 8:15",
            "frontage": "G",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.790992190347644,
            "gps_longitude": -119.22114640878951
        },
        "location_string": "G & 8:15"
    },
    {
        "uid": "a1Xd0000001IJUlEAO",
        "year": 2016,
        "name": "Mighty Misfits",
        "hometown": "Livermore",
        "description": "Speakeasy not loudly and you may be invited in. Knowing the password is crucial to enter the door. Moonshine is expected high in the sky, so get dolled up in your glad rags and head off to our joint.",
        "location": {
            "string": "F & 9:15",
            "frontage": "F",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79539677754363,
            "gps_longitude": -119.21562791691271
        },
        "location_string": "F & 9:15"
    },
    {
        "uid": "a1Xd0000001IQfNEAW",
        "year": 2016,
        "name": "Zerodrome",
        "url": "http://www.zerodrome.com",
        "contact_email": "info@zerodrome.com",
        "hometown": "American Canyon",
        "location": {
            "string": "G & 8:15",
            "frontage": "G",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.790992190347644,
            "gps_longitude": -119.22114640878951
        },
        "location_string": "G & 8:15"
    },
    {
        "uid": "a1Xd0000001ISciEAG",
        "year": 2016,
        "name": "Iceberg Cowboys",
        "description": "Iceberg Cowboys\r\nWranglin' them desert icebergs and riding 'em off into the sunset",
        "location": {
            "string": "G & 8:15",
            "frontage": "G",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.790992190347644,
            "gps_longitude": -119.22114640878951
        },
        "location_string": "G & 8:15"
    },
    {
        "uid": "a1Xd0000001IGKDEA4",
        "year": 2016,
        "name": "MIMOSA SUNRISE",
        "url": "http://mimosasunrise.org/",
        "hometown": "Santa Cruz",
        "description": "Come celebrate the birth of a new day with Mimosas at sunrise. Join us for drinks, stories and jokes every sunrise with some awesome people and great vibes. Stop by during the day for frozen margaritas and make some new friends.",
        "location": {
            "string": "G & 9:15",
            "frontage": "G",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79592173502304,
            "gps_longitude": -119.21615150802292
        },
        "location_string": "G & 9:15"
    },
    {
        "uid": "a1Xd0000001IWShEAO",
        "year": 2016,
        "name": "Pink Lagoon Flamingos",
        "hometown": "Los Angeles",
        "description": "Chill with Flamingos in our Pink Lagoon! Join us during our flavor tripping parties where we give you Miracle Berries that change your taste buds, and the flavors that you're used to get warped and you just might like it! We'll blast music for you to trip out on and then hang out in our giant, man-sized birds nests when you want to just hang and relax after.",
        "location": {
            "string": "H & 8:45",
            "frontage": "H",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.794106194335654,
            "gps_longitude": -119.21976693779182
        },
        "location_string": "H & 8:45"
    },
    {
        "uid": "a1Xd0000001IXX0EAO",
        "year": 2016,
        "name": "Camp Cuddle Cult",
        "url": "http://www.cuddlecult.org/",
        "contact_email": "campcuddle2016@gmail.com",
        "hometown": "Portland/San Francisco",
        "description": "Camp Cuddle Cult aims to foster a stronger Burning Man community through cuddling and interactivity. Drop by and immerse yourself in a cuddle puddle or some fun games! If you want to make some new friends on the playa this is the camp for you!",
        "location": {
            "string": "H & 8:15",
            "frontage": "H",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.791243763698084,
            "gps_longitude": -119.22194901027675
        },
        "location_string": "H & 8:15"
    },
    {
        "uid": "a1Xd0000001IIuiEAG",
        "year": 2016,
        "name": "Dusty Cobra Art Car & UCBR",
        "url": "http://www.dustycobra.com",
        "hometown": "Truckee",
        "description": "Come learn more about our exciting Art Car and Camp!",
        "location": {
            "string": "H & 8:45",
            "frontage": "H",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.794106194335654,
            "gps_longitude": -119.21976693779182
        },
        "location_string": "H & 8:45"
    },
    {
        "uid": "a1Xd0000001IDwsEAG",
        "year": 2016,
        "name": "Dusty Cantina",
        "contact_email": "andres_zd6@hotmail.com",
        "hometown": "LOS ANGELES",
        "description": "We will be hosting a beautiful high energy \"bar\" where you can zip fancy tequila or take a dusty shot a la go!",
        "location": {
            "string": "H & 8:45",
            "frontage": "H",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.794106194335654,
            "gps_longitude": -119.21976693779182
        },
        "location_string": "H & 8:45"
    },
    {
        "uid": "a1Xd0000001IBwEEAW",
        "year": 2016,
        "name": "Atomic Pussy Photo Studio Lounge",
        "contact_email": "drtom64@hotmail.com",
        "hometown": "We are a collection of wayward mutts gathered from all over the country: Seattle, Salt Lake, Connecticut, Nantucket, New Jersey",
        "description": "This dedicated group of goofy, veteran Burners want you to come to our photo studio to get your portrait done or to come to our lounge for a shot (fireballs and tequila). We will fall all over ourselves to \"Welcome You Home\".",
        "location": {
            "string": "I & 8:45",
            "frontage": "I",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.794506474599395,
            "gps_longitude": -119.22045621351006
        },
        "location_string": "I & 8:45"
    },
    {
        "uid": "a1Xd0000001IWXNEA4",
        "year": 2016,
        "name": "Zerzura Camp",
        "url": "http://www.xuzaartcar.com/",
        "contact_email": "info@xuzaartcar.com",
        "hometown": "Las Vegas",
        "description": "#Zerzura Camp\r\nHome of XUZA Art Car",
        "location": {
            "string": "H & 9:15",
            "frontage": "H",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79644345068721,
            "gps_longitude": -119.21668043777967
        },
        "location_string": "H & 9:15"
    },
    {
        "uid": "a1Xd0000001IWNrEAO",
        "year": 2016,
        "name": "Yozh Camp",
        "hometown": "San Francisco",
        "description": "We are camp Yozh, and we are fun, we like singing in the sun.\r\nDance a little, dance with us, we will prick your little arse.\r\nWe play really silly games, join us in a prickly haze.\r\n\r\nWe're a group of ruski speaking, techno playing, hula-hooping, chillers. Come for the vodka bar, stay for the prickly vibes.\r\n\r\nYozh is pronounced Yo+ZH - as in Massage (massaZH). Yozhiki are cute little hedgehogs. For more info, check out Yozhik v Tumane.",
        "location": {
            "string": "I & 8:45",
            "frontage": "I",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.794506474599395,
            "gps_longitude": -119.22045621351006
        },
        "location_string": "I & 8:45"
    },
    {
        "uid": "a1Xd0000001IVHCEA4",
        "year": 2016,
        "name": "ToneAge - The Last Pickler",
        "hometown": "San Frandencouver",
        "description": "ToneAge - The Last Pickler, a great mix of new and old alike, primarily from Vancouver, Denver and San Francisco, but always happy to see and welcome new participants from wherever they call home.",
        "location": {
            "string": "H & 8:45",
            "frontage": "H",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.794106194335654,
            "gps_longitude": -119.21976693779182
        },
        "location_string": "H & 8:45"
    },
    {
        "uid": "a1Xd0000001IMNXEA4",
        "year": 2016,
        "name": "Friends Without Benefits Guild",
        "hometown": "Vancouver",
        "description": "Come by and learn how great it can be to have no benefits in your friendships! Get hydrated, fed and relax in our lovely faux pool!",
        "location": {
            "string": "I & 9:15",
            "frontage": "I",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.796965163936136,
            "gps_longitude": -119.21720937584996
        },
        "location_string": "I & 9:15"
    },
    {
        "uid": "a1Xd0000001IXc5EAG",
        "year": 2016,
        "name": "BC Village",
        "url": "https://www.facebook.com/SpaceJamBC/?fref=ts",
        "hometown": "Vancouver",
        "description": "BC Village! Home to Pacific North Westerners with a passion for SPACE and BUTTS",
        "location": {
            "string": "H & 9:15",
            "frontage": "H",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79644345068721,
            "gps_longitude": -119.21668043777967
        },
        "location_string": "H & 9:15"
    },
    {
        "uid": "a1Xd0000001IB1OEAW",
        "year": 2016,
        "name": "Kamp Blintzkrieg",
        "url": "http://blintzkrieg.shonic.net",
        "contact_email": "blintzkrieg@shonic.net",
        "hometown": "Davis",
        "description": "Kamp Blintzkrieg is a theme camp dedicated to serving delectable playa-blintzes to all those in need of sustenance after a rough night out on the playa.",
        "location": {
            "string": "H & 9:15",
            "frontage": "H",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79644345068721,
            "gps_longitude": -119.21668043777967
        },
        "location_string": "H & 9:15"
    },
    {
        "uid": "a1Xd0000001IXFCEA4",
        "year": 2016,
        "name": "OK Korral",
        "url": "https://www.facebook.com/ThorArtCar",
        "hometown": "Denver",
        "description": "OK Korral - Denver based camp supporting the mutant vehicle Thor.",
        "location": {
            "string": "K & 9:15",
            "frontage": "K",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.798008583187986,
            "gps_longitude": -119.21826727693222
        },
        "location_string": "K & 9:15"
    },
    {
        "uid": "a1Xd0000001IBurEAG",
        "year": 2016,
        "name": "THE MINISTRY OF DOUCHEBAGGERY!",
        "url": "http://tribes.tribe.net/purgatorycruiser",
        "contact_email": "tcrillc@gmail.com",
        "hometown": "Nevada City",
        "location": {
            "string": "K & 9:15",
            "frontage": "K",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.798008583187986,
            "gps_longitude": -119.21826727693222
        },
        "location_string": "K & 9:15"
    },
    {
        "uid": "a1Xd0000001IXc0EAG",
        "year": 2016,
        "name": "Kaliva",
        "contact_email": "info@campkaliva.com",
        "hometown": "Brooklyn",
        "description": "Camp Kaliva is a community of creatives from every corner of the planet unified through art, music and good vibes. Kaliva is the Greek for for \"imperfect hut\" and we hope to create a home that encourages harmony, synchronicity and sustainability on the playa.",
        "location": {
            "string": "K & 8:45",
            "frontage": "K",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79530702282228,
            "gps_longitude": -119.22183478988129
        },
        "location_string": "K & 8:45"
    },
    {
        "uid": "a1Xd0000001IMdREAW",
        "year": 2016,
        "name": "Mayan Warrior",
        "url": "http://mayanwarrior.mx",
        "contact_email": "info@mayanwarrior.mx",
        "hometown": "Mexico City",
        "description": "We are using love, art, and music to unite people and cultures.",
        "location": {
            "string": "K & 9:15",
            "frontage": "K",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.798008583187986,
            "gps_longitude": -119.21826727693222
        },
        "location_string": "K & 9:15"
    },
    {
        "uid": "a1Xd0000001IC53EAG",
        "year": 2016,
        "name": "Bojon",
        "contact_email": "mcullen2@gmail.com",
        "hometown": "San Francisco",
        "description": "Bojon represents the quest for creativity, fun, community, and connection in all aspects of our lives. Climb aboard Sil-vi for a tour of the desert or drop by late night to our in-camp bowls of fire.",
        "location": {
            "string": "K & 8:45",
            "frontage": "K",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79530702282228,
            "gps_longitude": -119.22183478988129
        },
        "location_string": "K & 8:45"
    },
    {
        "uid": "a1Xd0000001IFDmEAO",
        "year": 2016,
        "name": "Cult of the Last Unicorn",
        "url": "http://cinemaoffury.wordpress.com",
        "contact_email": "cultofthelastunicorn@gmail.com",
        "hometown": "Santa Rosa Beach",
        "description": "Cult of the Last Unicorn Presents: The Cinema of Fury -  interactive art experience.",
        "location": {
            "string": "K & 9:15",
            "frontage": "K",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.798008583187986,
            "gps_longitude": -119.21826727693222
        },
        "location_string": "K & 9:15"
    },
    {
        "uid": "a1Xd0000001IJLYEA4",
        "year": 2016,
        "name": "Two-Stroke Transit",
        "hometown": "Redding",
        "description": "Got questions about your two-stroke engine?  Maybe you just like to rev up your engine and make a lot of noise?  Come on down to Two-Stroke Transit to talk to us and show us your awesome mechanical creations based on this year's theme.  While here, you can find out how to prevent playa damage from dripping oil while improving your engine's performance.",
        "location": {
            "string": "K & 9:15",
            "frontage": "K",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.798008583187986,
            "gps_longitude": -119.21826727693222
        },
        "location_string": "K & 9:15"
    },
    {
        "uid": "a1Xd0000001IHm1EAG",
        "year": 2016,
        "name": "Dusty Bumm",
        "url": "https://www.facebook.com/thedustybumm/",
        "contact_email": "missyqt@yahoo.com",
        "hometown": "South Bay Area",
        "description": "Trade in your dusty tookus for a warm shot and a cold slap in the face or plow it up with a snowboardski or three, then try your hand at Giant Beer Pong/Jenga! Afterwards cuddle up in our oasis puddle, then puff on some hooka in the Tuchus Dome or just relax under hundreds of G-Strings!  Face it, out here, there's no escaping a Dusty Bumm!",
        "location": {
            "string": "7:00 & D",
            "frontage": "7:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.78380349492602,
            "gps_longitude": -119.21929438883451
        },
        "location_string": "7:00 & D"
    },
    {
        "uid": "a1Xd0000001IBXNEA4",
        "year": 2016,
        "name": "Universe University",
        "hometown": "Issaquah, Washington. Apart of the Greater Seattle Area.",
        "description": "Universe University; Come find yourself and join in our shenanigans. We will show you how \"U of U\" can put the U in yoU.",
        "location": {
            "string": "C & 2:45",
            "frontage": "C",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78069066990527,
            "gps_longitude": -119.19668499606931
        },
        "location_string": "C & 2:45"
    },
    {
        "uid": "a1Xd0000002yjJtEAI",
        "year": 2016,
        "name": "Hell Station"
    },
    {
        "uid": "a1Xd0000001IBBKEA4",
        "year": 2016,
        "name": "Go The Fuck To Sleep Camp",
        "hometown": "Portland and Eugene",
        "description": "Go The Fuck To Sleep Camp offers the weary citizens of Black Rock City a bar meant to dull your senses and send you the fuck TO SLEEP!  Go The Fuck To Sleep Camp will also provide visitors with the opportunity to make a color  photocopy of their legal id, which can then be taped to their drinking cup, helping to avoid lost id's!",
        "location": {
            "string": "E & 5:15",
            "frontage": "E",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.776525043868155,
            "gps_longitude": -119.21189639030393
        },
        "location_string": "E & 5:15"
    },
    {
        "uid": "a1Xd0000001IBTxEAO",
        "year": 2016,
        "name": "Swish Embassy",
        "url": "https://www.facebook.com/groups/174170769334791/",
        "contact_email": "ncollide@hotmail.com",
        "hometown": "Provo",
        "description": "Theme Night parties, breathtaking costumes, amazing music, and a rockin' bar will be the hallmarks of BRC's awesome Den of Divine Decadence. We welcome divas of all genders, orientations, and experience - just be fabulous, bay-bee!",
        "location": {
            "string": "C & 2:45",
            "frontage": "C",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78069066990527,
            "gps_longitude": -119.19668499606931
        },
        "location_string": "C & 2:45"
    },
    {
        "uid": "a1Xd0000001IMScEAO",
        "year": 2016,
        "name": "Greeters Station",
        "contact_email": "toplessdeb@burningman.org",
        "hometown": "Los Angeles",
        "description": "Greeters Station"
    },
    {
        "uid": "a1Xd0000001IFDIEA4",
        "year": 2016,
        "name": "Hellfire Society",
        "hometown": "Orange County",
        "location": {
            "string": "G & 6:15",
            "frontage": "G",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.21907490302245
        },
        "location_string": "G & 6:15"
    },
    {
        "uid": "a1Xd0000001IHXREA4",
        "year": 2016,
        "name": "SugarBitch Camp",
        "hometown": "Boston MA",
        "description": "Come join SugarBitches to learn how to do low-carb diets, with frozen strawberries + whipped cream at 5pm on Thursday and Friday at the SugarBitch camp! Look for the SugarBitch Flag at PolyParadise Village. Be prepared to genuflect (if you can!)!!",
        "location": {
            "string": "3:30 & E",
            "frontage": "3:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.777144519137565,
            "gps_longitude": -119.19944355839093
        },
        "location_string": "3:30 & E"
    },
    {
        "uid": "a1Xd0000001IFjlEAG",
        "year": 2016,
        "name": "Barbie Day Spa",
        "hometown": "Austin",
        "description": "Barbie Day Spa -- Pampering on the Playa  -- Fingernail painting, massage, chill space, and wine.  (located in the Barbie Death Village)",
        "location": {
            "string": "6:30 & E",
            "frontage": "6:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78105582486477,
            "gps_longitude": -119.21872283512668
        },
        "location_string": "6:30 & E"
    },
    {
        "uid": "a1Xd0000001IHXqEAO",
        "year": 2016,
        "name": "Black Rock Travel Agency",
        "hometown": "Everywhere",
        "description": "The Black Rock Travel Agency exists to serve the pilots, passengers, volunteers and visitors of the Black Rock City Municipal Airport. We are not directly involved in flight operations nor the gifting of flights, rather we facilitate travel experiences on other planes of existence. We provide respite, solace and guidance to travelers of all sorts, some of which may be relied upon to enhance ones journey. Our solemn and singular goal is that, having interacted with the agency, travelers will depart with the distinct feeling, \" Now *that* was a trip!",
        "location": {
            "string": "Airport Rd & Airport Rd",
            "frontage": "Airport Rd",
            "intersection": "Airport Rd",
            "intersection_type": "&"
        },
        "location_string": "Airport Rd & Airport Rd"
    },
    {
        "uid": "a1Xd0000001IB14EAG",
        "year": 2016,
        "name": "Unicorner",
        "hometown": "California Bay Area",
        "description": "A haven for creativity, light-hearted fun, sharing, and gallivanting about!  Part of 404: Village Not Found.",
        "location": {
            "string": "C & 2:45",
            "frontage": "C",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78069066990527,
            "gps_longitude": -119.19668499606931
        },
        "location_string": "C & 2:45"
    },
    {
        "uid": "a1Xd0000001IBw9EAG",
        "year": 2016,
        "name": "Shack of Sit",
        "url": "https://www.facebook.com/groups/215133971881354/",
        "hometown": "Portland / San Jose",
        "description": "Shack of Sit, a Mensa SIG, featuring the Embiginator - a means to project yourself to the world.",
        "location": {
            "string": "Esplanade & 6:45",
            "frontage": "Esplanade",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78377478201974,
            "gps_longitude": -119.21485701075231
        },
        "location_string": "Esplanade & 6:45"
    },
    {
        "uid": "a1Xd0000001IMp8EAG",
        "year": 2016,
        "name": "Black Rock City Municipal Airport",
        "url": "http://airport.burningman.org",
        "contact_email": "airport@burningman.org",
        "hometown": "n/a",
        "description": "The airport for burners arriving and departing by air."
    },
    {
        "uid": "a1Xd0000001IBVPEA4",
        "year": 2016,
        "name": "Dye with Dignity",
        "url": "http://www.dyewithdignity.com",
        "hometown": "Fredericksburg",
        "description": "Come dye with us! We provide silk/dye and all materials for you to create your own piece of playa art magic.",
        "location": {
            "string": "C & 2:45",
            "frontage": "C",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78069066990527,
            "gps_longitude": -119.19668499606931
        },
        "location_string": "C & 2:45"
    },
    {
        "uid": "a1Xd0000001ICGWEA4",
        "year": 2016,
        "name": "The Copper Egg",
        "url": "http://coppertheater.com",
        "contact_email": "dirty@coppertheater.com",
        "hometown": "Oakland",
        "description": "How do you like your eggs? Your answer to this age-old question grants you a front seat for the performance that is as delicious as it is unforgettable.",
        "location": {
            "string": "9:00 Portal & A",
            "frontage": "9:00 Portal",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.79209649034368,
            "gps_longitude": -119.21402456241272
        },
        "location_string": "9:00 Portal & A"
    },
    {
        "uid": "a1Xd0000001IIBsEAO",
        "year": 2016,
        "name": "9 Energies - Know Your Superpower",
        "url": "https://www.9energies.com",
        "hometown": "Bozeman",
        "description": "Join 9 Energies to find out your Superpower. Open daily from 10-4ish, come sober please.  Morning 9 Energies Meditation at opening will also be offered, come experience your Natural Energy and the other 8!  It will enhance your Burning Man experience, and give you home-base within yourself to come back to.",
        "location": {
            "string": "3:30 & E",
            "frontage": "3:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.777144519137565,
            "gps_longitude": -119.19944355839093
        },
        "location_string": "3:30 & E"
    },
    {
        "uid": "a1Xd0000001IGxsEAG",
        "year": 2016,
        "name": "PlayaWaste Raiders",
        "url": "https://www.facebook.com/groups/playawasteraiders/",
        "contact_email": "playawasteraiders@groups.facebook.com",
        "hometown": "Capital Wasteland (Various)",
        "description": "Playawaste Raiders features a visually appealing frontage reminiscent of an apocalyptic wasteland outpost.  A return of our grisly street games with a post-nuclear twist!",
        "location": {
            "string": "C & 2:45",
            "frontage": "C",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78069066990527,
            "gps_longitude": -119.19668499606931
        },
        "location_string": "C & 2:45"
    },
    {
        "uid": "a1Xd0000001IHo7EAG",
        "year": 2016,
        "name": "Twisted Swan",
        "contact_email": "jrichardson6769@gmail.com",
        "hometown": "Apache Junction",
        "description": "Twisted Swan Celtic Pub, a true celtic experience on playa!",
        "location": {
            "string": "3:30 & E",
            "frontage": "3:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.777144519137565,
            "gps_longitude": -119.19944355839093
        },
        "location_string": "3:30 & E"
    },
    {
        "uid": "a1Xd0000001ICofEAG",
        "year": 2016,
        "name": "M*A*S*H 4207th",
        "hometown": "Van Nuys",
        "description": "We're not Doctors. \r\n\r\nThe least disciplined military unit on the playa. Random security Checkpoints will occur. Terrorists & Loyal Citizens will be labled. Propaganda & commentary provided for the prevention of communism. Nightly viewings of old episodes & movies from the show, this year featuring thematic nights. Signpost project open to all.\r\n\r\nSince 1999, your bastion of Democracy in a sea of fifth column communist/socialist/lawless infiltrators and barbarian mutants! Daytime martinis, PBR, and maybe even grape Nehi at Rosie's Bar. Life, liberty, and the pursuit of Happy Hour.",
        "location": {
            "string": "C & 2:45",
            "frontage": "C",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78069066990527,
            "gps_longitude": -119.19668499606931
        },
        "location_string": "C & 2:45"
    },
    {
        "uid": "a1Xd0000001IFEBEA4",
        "year": 2016,
        "name": "Home Sweet Dome",
        "hometown": "Redding",
        "description": "Home Sweet Dome is a public chill space at the heart of Hushville, next to the Town Round.\r\nWe offer shade in the daytime, lighted area at night, solar powered battery charging for cell phones, computers and the like.\r\nWe host various activities by Hushville residents throughout the event. Stop by and check out the schedule of events for Hushville posted on the bulletin in the Town Round.",
        "location": {
            "string": "E & 5:15",
            "frontage": "E",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.776525043868155,
            "gps_longitude": -119.21189639030393
        },
        "location_string": "E & 5:15"
    },
    {
        "uid": "a1Xd0000001ISPjEAO",
        "year": 2016,
        "name": "TrampStampCamp",
        "hometown": "Las Vegas",
        "description": "Trampolines to show off your skills and a special one enclosed with tent cover, sheer curtains, led lights, disco light and fog machine for cuddling fun.",
        "location": {
            "string": "7:00 & D",
            "frontage": "7:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.78380349492602,
            "gps_longitude": -119.21929438883451
        },
        "location_string": "7:00 & D"
    },
    {
        "uid": "a1Xd0000001IVDtEAO",
        "year": 2016,
        "name": "Camp Charlie the Unicorn",
        "url": "http://djdivadanielle.com/campcharlie/",
        "contact_email": "info@campcharlie.org",
        "hometown": "Los Angeles",
        "description": "Where art, music and mythology intersect in Black Rock City to celebrate Burning Man.... \r\n\r\nCharlie The Unicorn Art Car is an homage to the most infamous unicorn in the history of popular culture.\r\n\r\nInspired by great balls of fire, candy cane stripper poles and rainbow glitter, this one of a kind land-yacht is as unique as the phenomenon that inspired it.\r\n\r\nOn the playa, Charlie The Unicorn Art Car is known for epic DJ sets, mesmerizing laser light shows and massive fire balls that shoot from his horn.\r\n\r\nCharlie The Unicorn Art Car is a creation of Camp Charlie which is an L.A. based collection of dreamers, artists and adventurers who decided that \"Yes, the world DOES need a 20' tall unicorn on wheels!\"\r\n\r\nLet's go CHAAARRLLIIIEEEEE!!!!!!\r\n\r\nArt: http://www.facebook.com/media/set/?set=a.493476937330113.123369.360053894005752&type=3\r\n\r\nMusic: http://soundcloud.com/campcharlie\r\n\r\nMythology: http://en.wikipedia.org/wiki/Charlie_the_Unicorn",
        "location": {
            "string": "8:30 & G",
            "frontage": "8:30",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.79240038197383,
            "gps_longitude": -119.22022952927168
        },
        "location_string": "8:30 & G"
    },
    {
        "uid": "a1Xd0000001IV4QEAW",
        "year": 2016,
        "name": "Camp Hotel Rug",
        "hometown": "Everywhere!!",
        "description": "We are an eclectic group of like minded wayward souls drawn by fate into the nexus of Black Rock City. We began our Burn in 2013 as a group of strangers and left the playa one week later as a tight knit family. By counting on each other we magnify the love, healing, compassion and assholery that exists at Burning Man",
        "location": {
            "string": "G & 6:15",
            "frontage": "G",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.21907490302245
        },
        "location_string": "G & 6:15"
    },
    {
        "uid": "a1Xd0000001IV3cEAG",
        "year": 2016,
        "name": "SK8 KAMP",
        "url": "https://www.facebook.com/sk8kamp/?fref=ts",
        "hometown": "San Francisco",
        "description": "SK8 KAMP agrees, every community needs a skate park, why not bring a 24/7 skate park to the Playa? Bring your board or any other human-powered vehicle and witness gravity's technique of breaking the horse that is your self-doubt and blasting moves you dream of into the sky as your temporary pain is rewarded with bliss.",
        "location": {
            "string": "Esplanade & 7:00",
            "frontage": "Esplanade",
            "intersection": "7:00",
            "intersection_type": "&",
            "gps_latitude": 40.78462658391771,
            "gps_longitude": -119.21523944492934
        },
        "location_string": "Esplanade & 7:00"
    },
    {
        "uid": "a1Xd0000001IVqXEAW",
        "year": 2016,
        "name": "Academy of Arts and Sciences",
        "url": "https://www.facebook.com/brcbismuthcrystals/",
        "contact_email": "factor970@gmail.com",
        "hometown": "Seattle, Wichita, Boulder, OKC, Chico",
        "description": "Welcome to the Academy of Arts and Sciences. We have interactive classes teaching burners about science that can be used to create art, as well as art that makes science real. We strive to balance the left/right brain dichotomy with a range of activities to meet our fellow Burners' diverse tastes. You can also slake your thirst at the Bad Idea Bar, as long as you have a bad idea to contribute. Come visit!",
        "location": {
            "string": "B & 4:15",
            "frontage": "B",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77776035808324,
            "gps_longitude": -119.20499938179593
        },
        "location_string": "B & 4:15"
    },
    {
        "uid": "a1Xd0000001IVssEAG",
        "year": 2016,
        "name": "Scarbutts Coffee",
        "contact_email": "scarbuttscafe@gmail.com",
        "hometown": "Oakland",
        "description": "Scarbutts Coffee serves up hot and iced.Cold brewed coffee\r\n9:00 am to 12:00 noon Monday through Friday",
        "location": {
            "string": "9:00 Plaza @ 3:15",
            "frontage": "9:00 Plaza",
            "intersection": "3:15",
            "intersection_type": "@",
            "gps_latitude": 40.792352979352394,
            "gps_longitude": -119.21499728426735
        },
        "location_string": "9:00 Plaza @ 3:15"
    },
    {
        "uid": "a1Xd0000001ISGcEAO",
        "year": 2016,
        "name": "South Bay Burner Art Collective",
        "url": "http://www.southbayburners.org",
        "contact_email": "southbay@burningman.org",
        "hometown": "Santa Clara (but also the entire South Bay, including Redwood City, Palo Alto, Los Altos, Mountain View, Sunnyvale, Campbell, Los Gatos, and San Jose)",
        "description": "South Bay Burner Art Collective (BAC) - A meeting space for artists, makers, and dreamers from the South Bay (San Jose/Silicon Valley) who participate in playa art, and the year-round South Bay Region.",
        "location": {
            "string": "7:00 & D",
            "frontage": "7:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.78380349492602,
            "gps_longitude": -119.21929438883451
        },
        "location_string": "7:00 & D"
    },
    {
        "uid": "a1Xd0000001IV62EAG",
        "year": 2016,
        "name": "Spank The Monkey Bar",
        "url": "http://www.facebook.com/spankthemonkeylounge",
        "contact_email": "thxpunk+stmb@gmail.com",
        "hometown": "Salt Lake City",
        "description": "Wet your whistle at Spank the Monkey Bar, enjoy virgin burner shots, playa friendly poontang as well as other refreshing beverages.  They come with free harassment from our assortment of monkey clad bartenders, we'll try not to throw poo.",
        "location": {
            "string": "5:00 & B",
            "frontage": "5:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.77798282151022,
            "gps_longitude": -119.2094783790733
        },
        "location_string": "5:00 & B"
    },
    {
        "uid": "a1Xd0000001ISyjEAG",
        "year": 2016,
        "name": "Broken Compass",
        "hometown": "Oakland",
        "description": "Broken Compass is a collection of travelers from a far away world, and we have built this forum to share with you all that we have seen, heard, and learned during our travels. Our world is comprised of 5 continents, each with its own unique story, culture, climate, and aesthetic. Over the next 5 years, we will be investigating each of these strange lands, then reconvening back here to tell of our adventures.\r\n\r\nWhile our travels instilled in us a breadth of knowledge, the catharsis of adventure has left us with a desire to share our experiences with the world. Through workshops, lectures, performances, and merry making, our mission is to educate you in the ways of these 5 mysterious and foreign lands.  In addition to daily and nightly events, we will also be serving food and drink which we have discovered along the way.  And what of your travels?  Do you have stories to share with us?  Read through our story books, then add your own tales to be incorporated into our ever growing lore.",
        "location": {
            "string": "9:00 Portal & A",
            "frontage": "9:00 Portal",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.79209649034368,
            "gps_longitude": -119.21402456241272
        },
        "location_string": "9:00 Portal & A"
    },
    {
        "uid": "a1Xd0000001IV3DEAW",
        "year": 2016,
        "name": "Sacred Song Teahouse",
        "url": "http://sacredsongteahouse.com/Welcome.html",
        "contact_email": "info@sacredsongteahouse.com",
        "hometown": "San Luis Obispo",
        "description": "The Sacred Song Teahouse is a temple for devotional singing on the playa.\r\n\r\nThere are many traditions of devotional singing, sometimes known as bhajans or kirtan, which help to quiet the mind so that the heart can open to the divine, allowing us to taste the blissful reality that is our true nature. Rather than being a performance in which the audience listens to musicians, it is a participatory spiritual practice in which everyone is encouraged to sing and express their inner joy.\r\n\r\nThe Sacred Song Teahouse is a Burning Man camp dedicated to creating and maintaining a serene temple oasis for joining our voices and diving into the Divine... together. We welcome the keepers of tea wisdom to join us in our temple space to sooth our throats with their mystical infusions. We welcome musicians to join us on stage and have a safe and secure place for them to store their instruments during the Burn. Together we create Magic!",
        "location": {
            "string": "7:00 & E",
            "frontage": "7:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78363318293099,
            "gps_longitude": -119.22013333019713
        },
        "location_string": "7:00 & E"
    },
    {
        "uid": "a1Xd0000001IV2oEAG",
        "year": 2016,
        "name": "Tantra Mantra",
        "url": "http://tantramantracamp.com/Welcome.html",
        "contact_email": "honcho@tantramantracamp.com",
        "hometown": "San Luis Obispo",
        "description": "Tantra Mantra is a camp dedicated to the transformation and transcendence of the human condition. We integrate ancient esoteric teachings of tantra with modern self-development techniques to create a unique environment for experiences that prepare the ground for evolution. To envision and prepare the world of tomorrow we need to rewire our nervous systems and free ourselves from the old paradigm. Tantra is an accelerator of evolution. The context of Burning Man serves as an amplifier to these ancient Tantric techniques. The collective ambition towards freedom present during Burning Man is unique. It erases differences between individuals and supports the Tantric effort of transcending all false dualities. From regular morning energetic practices to one-of-a-kind ceremonies and ritual, Tantra Mantra embraces and promotes the change towards a new human agreement. We leave a great place for spontaneity... Expect the unexpected.",
        "location": {
            "string": "7:00 & E",
            "frontage": "7:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78363318293099,
            "gps_longitude": -119.22013333019713
        },
        "location_string": "7:00 & E"
    },
    {
        "uid": "a1Xd0000001IUcxEAG",
        "year": 2016,
        "name": "Fire Muse Circus Conclave",
        "contact_email": "adriane@firemusecircus.com",
        "hometown": "Salt Lake City",
        "description": "Fire Muse Circus is the art of life brought to the stage. The story, choreography, and artist's skills are all tools we use to share the human experience, bringing forth reflections and insights to wellness, purpose, and conscious alignment with the planet.\r\n\r\nOur performances are a unique collage of fire dancing, aerial and acrobatic acts, music and visual artistry to create a multi-sensory theater experience.",
        "location": {
            "string": "Esplanade & 4:00",
            "frontage": "Esplanade",
            "intersection": "4:00",
            "intersection_type": "&",
            "gps_latitude": 40.7797827277492,
            "gps_longitude": -119.20415844356913
        },
        "location_string": "Esplanade & 4:00"
    },
    {
        "uid": "a1Xd0000001IVsEEAW",
        "year": 2016,
        "name": "Cranky and Sons Bike Repair",
        "hometown": "Berkeley",
        "description": "Come to Cranky and Sons for assistance, education and advice for those \"Oh shit!\" cycling needs, from a flat tire to exploded derailer -- we'll help you get back out onto the playa. If you've got some free time and can lend a hand, grab a beer and a wrench and help us help those in need!  Mechanics on duty mornings until 1pm – DIY tools and supplies available any time.",
        "location": {
            "string": "3:00 & I",
            "frontage": "3:00",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.77698228119831,
            "gps_longitude": -119.19406426804439
        },
        "location_string": "3:00 & I"
    },
    {
        "uid": "a1Xd0000001IVsOEAW",
        "year": 2016,
        "name": "Kamp Kaos",
        "hometown": "Boston",
        "description": "Kaos brings a human-scale fabric art maze, flying space bar, and late night Death Marches back to the playa!",
        "location": {
            "string": "Esplanade & 8:30",
            "frontage": "Esplanade",
            "intersection": "8:30",
            "intersection_type": "&",
            "gps_latitude": 40.78982507488664,
            "gps_longitude": -119.21433618536174
        },
        "location_string": "Esplanade & 8:30"
    },
    {
        "uid": "a1Xd0000001IVrzEAG",
        "year": 2016,
        "name": "Image Node",
        "url": "http://www.imagenode.org",
        "contact_email": "imagenode.twina@gmail.com",
        "hometown": "Brooklyn",
        "description": "Camp Image Node is back!  Bringing you the finest in interactive blinkytronics, live improvised experimental electronic music and video, and mindbending immersive experiences since 2000.",
        "location": {
            "string": "Esplanade & 3:30",
            "frontage": "Esplanade",
            "intersection": "3:30",
            "intersection_type": "&",
            "gps_latitude": 40.78046704889989,
            "gps_longitude": -119.20197641373306
        },
        "location_string": "Esplanade & 3:30"
    },
    {
        "uid": "a1Xd0000001IVnJEAW",
        "year": 2016,
        "name": "badlands",
        "contact_email": "badandysoria@gmail.com",
        "hometown": "Los Angeles",
        "description": "BADLANDS funky tea house! Come and join us on the front porch and put a little bit of chicken grease on your ankle bone to get you shaking proper on the playa!",
        "location": {
            "string": "8:30 & G",
            "frontage": "8:30",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.79240038197383,
            "gps_longitude": -119.22022952927168
        },
        "location_string": "8:30 & G"
    },
    {
        "uid": "a1Xd0000001IVrfEAG",
        "year": 2016,
        "name": "SeaWEED Artist Collective",
        "url": "https://www.facebook.com/SeaweedArts",
        "hometown": "Seattle",
        "description": "SeaWEED Artist Collective. Seattle, WA - teaming up with Portland, OR and Vancouver, BC - to bring a monumental library to the Playa.",
        "location": {
            "string": "G & 6:15",
            "frontage": "G",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.21907490302245
        },
        "location_string": "G & 6:15"
    },
    {
        "uid": "a1Xd0000001IVGOEA4",
        "year": 2016,
        "name": "Ali Bar-Bar",
        "hometown": "Palo Alto",
        "description": "Visit Ali Bar-Bar, the 'hottest' place in Silicon Village, to chill, drink, and dance. Our cozy Bedouin tent provides comfort and shelter day and night, while we serve drinks and entertain you.",
        "location": {
            "string": "6:30 & E",
            "frontage": "6:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78105582486477,
            "gps_longitude": -119.21872283512668
        },
        "location_string": "6:30 & E"
    },
    {
        "uid": "a1Xd0000001IVrQEAW",
        "year": 2016,
        "name": "Barechested Baristas",
        "url": "http://barechestedbaristas.com/",
        "hometown": "San Francisco",
        "description": "The Barechested Baristas are all about the late afternoon vibe. The peak heat of the day has passed, the shadows are stretching out, and you can feel a beautiful sunset coming. We're here to help you recharge and recenter. Come enjoy our delicious iced coffee and skank to some conscious roots, inspired dub, and other creative sounds. The brew is served up by our snarky, friendly, and topless baristas, and the vibe is always on point. This is a place to be human; come and get inspired.",
        "location": {
            "string": "5:00 & B",
            "frontage": "5:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.77798282151022,
            "gps_longitude": -119.2094783790733
        },
        "location_string": "5:00 & B"
    },
    {
        "uid": "a1Xd0000001IVueEAG",
        "year": 2016,
        "name": "Snow Koan Solar",
        "url": "http://www.snowkoansolar.org/",
        "contact_email": "matthewfassberg@gmail.com",
        "hometown": "San Francisco",
        "description": "Snow cones served each afternoon around 4pm.  Hot dogs served late at night.  Solar-powered public charging station is open from 12-6pm.  Bring a phone or camera that needs charging.",
        "location": {
            "string": "8:00 & E",
            "frontage": "8:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78916521244671,
            "gps_longitude": -119.22013446592231
        },
        "location_string": "8:00 & E"
    },
    {
        "uid": "a1Xd0000001IV3SEAW",
        "year": 2016,
        "name": "Naked Heart",
        "url": "http://nakedheartcamp.com/Home.html",
        "contact_email": "dbraun@omnipost.com",
        "hometown": "San Luis Obispo",
        "description": "Naked Heart is devoted to the full embodiment of the divine feminine. We offer amazing experiential and experimental workshops that allow you to feel your feminine heart your radiance your inner goddess. This work requires the masculine as well; Everyone is welcome.\r\n\r\nAt Naked Heart we recognize the need to embrace both the light and the dark in our journeys. When we pursue the light we use movement, the senses, sensuality, sexuality and connection.  This beckons us in and brings the light of awareness back into the bodies we have vacated. We are particularly interested in the seat of power and intention housed in our bodies. To go there fully requires confronting our shadows. We embrace those as well as we dive into shame, fear, anger, unsavory memories from this life and past lives, and disempowering images of our bodies. Welcome home.",
        "location": {
            "string": "7:00 & E",
            "frontage": "7:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78363318293099,
            "gps_longitude": -119.22013333019713
        },
        "location_string": "7:00 & E"
    },
    {
        "uid": "a1Xd0000001IV3XEAW",
        "year": 2016,
        "name": "Super Friends Synaesthesia",
        "url": "https://www.facebook.com/SuperFriendsNeighborhood/",
        "hometown": "Los Angeles",
        "description": "Billowing white fabric surrounds our waterless pillow pools where the tired burner can take an afternoon nap. Learn new skills at one of our daytime workshops or groove to some tunes. My hand is holding your hand, but we're such Super Friends, you feel my hand on your heart...or in your brain.",
        "location": {
            "string": "5:00 & B",
            "frontage": "5:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.77798282151022,
            "gps_longitude": -119.2094783790733
        },
        "location_string": "5:00 & B"
    },
    {
        "uid": "a1Xd0000001IXE4EAO",
        "year": 2016,
        "name": "Trilogy Space",
        "url": "http://www.zeptospace.com",
        "contact_email": "trilogytribe@gmail.com",
        "hometown": "San Diego",
        "description": "As a collection of innovative culture crafters we intend on empowering the inner genius and inspiring others to do the same.",
        "location": {
            "string": "7:00 & E",
            "frontage": "7:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78363318293099,
            "gps_longitude": -119.22013333019713
        },
        "location_string": "7:00 & E"
    },
    {
        "uid": "a1Xd0000001IXAREA4",
        "year": 2016,
        "name": "Rejuvenation",
        "url": "http://www.facebook.com/playarejuvenation",
        "contact_email": "playarejuveantion@gmail.com",
        "hometown": "Eugene",
        "description": "Open daily most afternoons gifting coconut water and supplements.",
        "location": {
            "string": "5:00 & B",
            "frontage": "5:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.77798282151022,
            "gps_longitude": -119.2094783790733
        },
        "location_string": "5:00 & B"
    },
    {
        "uid": "a1Xd0000001IXKqEAO",
        "year": 2016,
        "name": "Octopus Garden",
        "url": "https://www.facebook.com/octopusgardenforever/",
        "contact_email": "octopusgardensf@gmail.com",
        "hometown": "San Francisco",
        "description": "Come play with us at the Octopus Garden... Swing set, trampolines, art gallery, O MY! ...At the bar you can enjoy some Pussy Punch whilst with some smooth grooves..",
        "location": {
            "string": "10:00 & E",
            "frontage": "10:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.79672285017505,
            "gps_longitude": -119.21015375998337
        },
        "location_string": "10:00 & E"
    },
    {
        "uid": "a1Xd0000001IXOnEAO",
        "year": 2016,
        "name": "Fabulous Disaster",
        "hometown": "San Francisco, Los Angeles, Pittsburgh, Wellington, Montreal, Malme, Amsterdam, etc.  We're spread all over.",
        "description": "The name says it all",
        "location": {
            "string": "E & 2:45",
            "frontage": "E",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77988938361874,
            "gps_longitude": -119.19530749154225
        },
        "location_string": "E & 2:45"
    },
    {
        "uid": "a1Xd0000001IWshEAG",
        "year": 2016,
        "name": "3SP (Third Space Place)",
        "hometown": "Washington, DC",
        "description": "3SP (Third Space Place), located in Home Rule Village, celebrates \"third spaces\" – social, relaxing locations that offer a sense of place beyond the two usual environments of home (\"first space\") and work (\"second space\"). A true \"third space,\" 3SP's comfortable retreat will offer shaded conversations throughout the day, warm fireside chats at night, and interactive events that 3SP hopes will entice our Black Rock City community to stop by, have a chat, and Participate!",
        "location": {
            "string": "F & 4:45",
            "frontage": "F",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20845363458552
        },
        "location_string": "F & 4:45"
    },
    {
        "uid": "a1Xd0000001IXDQEA4",
        "year": 2016,
        "name": "Golden Cafe",
        "url": "http://www.goldencafe.org/",
        "hometown": "Los Angeles",
        "description": "Celebrating its 14th year, the Golden Cafe is your home on the playa for exotic cocktails, home infused liquors, and live music since 2003. Swing by for elegant libations served in real glassware, jam with our house band, and sample strange infusions from our cellars. Donations of liquor and mixers keep the party going, and there may be something new in store this time around...",
        "location": {
            "string": "Esplanade & 4:30 Portal",
            "frontage": "Esplanade",
            "intersection": "4:30 Portal",
            "intersection_type": "&",
            "gps_latitude": 40.77954932016092,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "Esplanade & 4:30 Portal"
    },
    {
        "uid": "a1Xd0000001IX2wEAG",
        "year": 2016,
        "name": "Bring A Cup",
        "contact_email": "pecan.scul@gmail.com",
        "hometown": "Boston",
        "description": "Welcome to the grandest castle you'll see in the desert and rub elbows with wizards, dragons, and assorted travelers. Clank your cup with friends new and old while partaking of the most epically brewed potions. Drinking and Magic!  We're fucking wizards!",
        "location": {
            "string": "Esplanade & 8:30",
            "frontage": "Esplanade",
            "intersection": "8:30",
            "intersection_type": "&",
            "gps_latitude": 40.78982507488664,
            "gps_longitude": -119.21433618536174
        },
        "location_string": "Esplanade & 8:30"
    },
    {
        "uid": "a1Xd0000001IXFvEAO",
        "year": 2016,
        "name": "Kreme Burners",
        "url": "http://kremeburners.org/",
        "contact_email": "neo@kremeburners.org",
        "hometown": "Seattle",
        "description": "Rave de Creme Brulees: Enjoy some cool beats in the afternoon, turning into Dubstep or Psy Trance as the evening comes, while tasting the finest French style Creme Brulees on the playa. Show us your best tricks on the trampoline, get a cocktail refill when the fully stocked bar is open, or just come and chill with us in the dodecagon.",
        "location": {
            "string": "G & 6:15",
            "frontage": "G",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.21907490302245
        },
        "location_string": "G & 6:15"
    },
    {
        "uid": "a1Xd0000001IX94EAG",
        "year": 2016,
        "name": "Covered in Bees",
        "url": "https://www.facebook.com/bombusregius",
        "hometown": "Boston, LA, San Francisco",
        "location": {
            "string": "Esplanade & 8:30",
            "frontage": "Esplanade",
            "intersection": "8:30",
            "intersection_type": "&",
            "gps_latitude": 40.78982507488664,
            "gps_longitude": -119.21433618536174
        },
        "location_string": "Esplanade & 8:30"
    },
    {
        "uid": "a1Xd0000001IXEEEA4",
        "year": 2016,
        "name": "Bearwhalea",
        "contact_email": "bearwhalea@gmail.com",
        "hometown": "Reno",
        "description": "Once again the mighty BEARWHALE saunters forth from Kamchatka in search of migratory cucumbers, elk fairy dust, and playa shenanigans.  Stop by to bask in the glow of this evolutionary marvel!",
        "location": {
            "string": "5:00 & B",
            "frontage": "5:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.77798282151022,
            "gps_longitude": -119.2094783790733
        },
        "location_string": "5:00 & B"
    },
    {
        "uid": "a1Xd0000001IWsmEAG",
        "year": 2016,
        "name": "Horny Camp",
        "url": "http://www.hornycamp.com/",
        "hometown": "San Francisco, Los Angeles, New York",
        "description": "Horny People, release your inner devil, daemon, or unicorn and come make horns with us! We supply the clay, instructions, and gas fired oven. You supply your inner creativity and vision. Lounge in our shade structure while your masterpiece bakes (15 min) and when it's done, we'll help you fit them to your head, chest, nipples, or whatever body part you choose to adorn.\r\nREMEMBER: Classes only run from MON.-THU; Noon to 4pm. so come while supplies last!",
        "location": {
            "string": "8:30 & C",
            "frontage": "8:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.791085369007384,
            "gps_longitude": -119.21722010505046
        },
        "location_string": "8:30 & C"
    },
    {
        "uid": "a1Xd0000001IXLeEAO",
        "year": 2016,
        "name": "Black Rock Wine Cellar",
        "url": "http://www.blackrockwinecellar.org",
        "contact_email": "sommelier@blackrockwinecellar.org",
        "hometown": "LA",
        "description": "The unrelenting heat of the Black Rock Desert is no place for wine! If you have a special bottle in need of tender loving care we invite you to check your bottle into our refrigerated subterranean facility where it will await your return under lock and key. And while you're here why not join us for a tasting? And if you have construction skills our excavation crew always needs hand.",
        "location": {
            "string": "Esplanade & 4:30 Portal",
            "frontage": "Esplanade",
            "intersection": "4:30 Portal",
            "intersection_type": "&",
            "gps_latitude": 40.77954932016092,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "Esplanade & 4:30 Portal"
    },
    {
        "uid": "a1Xd0000001IX2mEAG",
        "year": 2016,
        "name": "Glittercamp",
        "description": "Glittercamp returns to make the masses shiny and sparkly as nature intended, with our shimmery body gel. New this year will be live music, including our house David Bowie cover band ZiggyPlayadust!",
        "location": {
            "string": "3:30 & D",
            "frontage": "3:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.77771409960112,
            "gps_longitude": -119.19987774416956
        },
        "location_string": "3:30 & D"
    },
    {
        "uid": "a1Xd0000001IXIzEAO",
        "year": 2016,
        "name": "Friendzied Serenity",
        "url": "http://www.facebook.com/FriendziedSerenity",
        "contact_email": "friendziedserenity@gmail.com",
        "hometown": "Vancouver",
        "description": "A Chill Lounge in the Suburbs\r\nCome relax in the shade and try one of the special \"Kiwi\" drinks away from the hustle & bustle of the Esplanade",
        "location": {
            "string": "I & 7:45",
            "frontage": "I",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78813699883062,
            "gps_longitude": -119.22393925217301
        },
        "location_string": "I & 7:45"
    },
    {
        "uid": "a1Xd0000001IXBoEAO",
        "year": 2016,
        "name": "Airpusher",
        "url": "http://www.airpushercollective.com",
        "hometown": "Oakland",
        "description": "Airships were one of the first crafts built to bring mankind up into the clouds, and Airpusher's Steampunk Airship is bringing this experience to Burning Man with a twist. It's a place for you to dance, laugh, stargaze, and get a breath of fresh air underneath the illuminated balloon of a classic airship.",
        "location": {
            "string": "7:00 & D",
            "frontage": "7:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.78380349492602,
            "gps_longitude": -119.21929438883451
        },
        "location_string": "7:00 & D"
    },
    {
        "uid": "a1Xd0000001IXDzEAO",
        "year": 2016,
        "name": "Heart-On!",
        "hometown": "Redwood City",
        "description": "Visit camp Heart-On! at Black Rock Power Co-op Village to have yourself decorated with beautifully stenciled heart body art in the form of airbrush body painting, ink stamps and hand drawn face painting. Come by and pick up a 2016 camp sticker and visit out giant gumball machine for a heart related prize! Everyone loves a Heart-On! Multiple Heart-On!s are good!!",
        "location": {
            "string": "4:30 & D",
            "frontage": "4:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.776370604715595,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & D"
    },
    {
        "uid": "a1Xd0000001IXI1EAO",
        "year": 2016,
        "name": "Black Rock Vineyards",
        "url": "http://www.blackrockvineyards.org",
        "contact_email": "vintner@blackrockvineyards.org",
        "hometown": "LA",
        "description": "Producers of the first and only wine grown pressed and aged entirely in Black Rock City! Established in 1999 the vineyards have nurtured a cutting of the nearly extinct carnivorous Cabernet Dionaea for 12 years to yield the acclaimed Vinum Pejorative - vintners and wine lovers stop by for a sip! We especially need experts and trainees to start our first batch of Dandelion and Lilac wines!",
        "location": {
            "string": "Esplanade & 4:30 Portal",
            "frontage": "Esplanade",
            "intersection": "4:30 Portal",
            "intersection_type": "&",
            "gps_latitude": 40.77954932016092,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "Esplanade & 4:30 Portal"
    },
    {
        "uid": "a1Xd0000001IXEOEA4",
        "year": 2016,
        "name": "More Carrot",
        "url": "https://www.facebook.com/MoreCarrot.BRC.FarmersMarket",
        "contact_email": "brcfarmersmarket@gmail.com",
        "hometown": "Baltimore, MD",
        "description": "More Carrot: Sure, you could live off protein bars and MREs all week if you really want to, but how about giving your dusty soul a treat? Come by the More Carrot Camp and get yourself something crunchy, cold and crisp! We gift fresh vegetables and fruit at the More Carrot Camp. Tues. - Fri., 8 - 10 a.m.",
        "location": {
            "string": "Esplanade & 4:30 Portal",
            "frontage": "Esplanade",
            "intersection": "4:30 Portal",
            "intersection_type": "&",
            "gps_latitude": 40.77954932016092,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "Esplanade & 4:30 Portal"
    },
    {
        "uid": "a1Xd0000001IXJ9EAO",
        "year": 2016,
        "name": "Bumblepuss",
        "url": "http://www.bumblepuss.com",
        "hometown": "San Francisco",
        "description": "Bumblepuss brings a spa theme to the playa. With the addition of the aromatherapy focused Lavender Lounge. Visit and soak in the aromas as you relax in the shade.",
        "location": {
            "string": "8:00 & E",
            "frontage": "8:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78916521244671,
            "gps_longitude": -119.22013446592231
        },
        "location_string": "8:00 & E"
    },
    {
        "uid": "a1Xd0000001IX7hEAG",
        "year": 2016,
        "name": "Infinity",
        "hometown": "Seattle, Portland, San Francisco",
        "description": "Come create art to gift to fellow burners or to burn at the Temple!  Daily Vipassana meditation, tea service and nail painting.\r\n\r\nYou are invited to our 50's Housewife Party Wednesday 1-4pm!",
        "location": {
            "string": "7:30 & B",
            "frontage": "7:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.786399428284064,
            "gps_longitude": -119.21800903146068
        },
        "location_string": "7:30 & B"
    },
    {
        "uid": "a1Xd0000001IX9EEAW",
        "year": 2016,
        "name": "Automatic Subconscious",
        "url": "https://www.automaticsubconscious.com/",
        "contact_email": "automatic.subconscious@gmail.com",
        "hometown": "Boston",
        "description": "Boston's longest running theme camp is back again! This year our Dome will be filled with offbeat events, daily happy hours, and high energy dance nights!",
        "location": {
            "string": "Esplanade & 8:30",
            "frontage": "Esplanade",
            "intersection": "8:30",
            "intersection_type": "&",
            "gps_latitude": 40.78982507488664,
            "gps_longitude": -119.21433618536174
        },
        "location_string": "Esplanade & 8:30"
    },
    {
        "uid": "a1Xd0000001IWo6EAG",
        "year": 2016,
        "name": "MIT Dance Music and Art (MDMA)",
        "contact_email": "ellalinda@gmail.com",
        "hometown": "Boston",
        "description": "A group of friends from MIT grad school and beyond, MDMA (MIT Dance Music and Art) brings the \"daybreaker\" to the playa - a black light dance dome that bundles great tunes and fascinating elements of glow in the dark body painting and clothing. A perfect place to escape the heat, express yourself through music, dance and art.",
        "location": {
            "string": "Esplanade & 8:30",
            "frontage": "Esplanade",
            "intersection": "8:30",
            "intersection_type": "&",
            "gps_latitude": 40.78982507488664,
            "gps_longitude": -119.21433618536174
        },
        "location_string": "Esplanade & 8:30"
    },
    {
        "uid": "a1Xd0000001IXNaEAO",
        "year": 2016,
        "name": "Jellyfish 12000",
        "url": "http://www.jellyfish12000.com",
        "contact_email": "happybug@jellyfish12000.com",
        "hometown": "Salt Lake City",
        "description": "The Jellyfish 12000 invites you to come explore the aquatic alien underground native to ancient Lake Lahotan. Our otherworldly time-traveling family of mutant vessels consists of The Amazing Jellyfish From The Year 12000 and Jelly Roll.",
        "location": {
            "string": "Esplanade & 4:00",
            "frontage": "Esplanade",
            "intersection": "4:00",
            "intersection_type": "&",
            "gps_latitude": 40.7797827277492,
            "gps_longitude": -119.20415844356913
        },
        "location_string": "Esplanade & 4:00"
    },
    {
        "uid": "a1Xd0000001IXlCEAW",
        "year": 2016,
        "name": "Camp Meow",
        "hometown": "Sydney",
        "description": "Camp Meow brings the Stargazer Artcar, Illuminated Trampoline Park  with bouncing foam cubes and LED lighting and spotlights. 15ft Canvas Illuminated Pyramid, Aussie 101 Booth, get an Aussie accent in 5mins, and learn Aussie facts from the natives.",
        "location": {
            "string": "9:00 & J",
            "frontage": "9:00",
            "intersection": "J",
            "intersection_type": "&",
            "gps_latitude": 40.796281355415935,
            "gps_longitude": -119.21955363512441
        },
        "location_string": "9:00 & J"
    },
    {
        "uid": "a1Xd0000001IXl7EAG",
        "year": 2016,
        "name": "Playa Playground",
        "contact_email": "steven.bm2016@gmail.com",
        "hometown": "Southern California",
        "description": "Playa Playground is the family-friendly, Esplanade-facing side of Spanky's Village.  Visit our Gypsy Caravan for Tarot Card reading or a seance. Come play Croquet with bowling balls, or golf with billiard-balls (both at the same time and in the same space).  Get a funny name, and lots more.",
        "location": {
            "string": "Esplanade & 2:30",
            "frontage": "Esplanade",
            "intersection": "2:30",
            "intersection_type": "&",
            "gps_latitude": 40.78297439508715,
            "gps_longitude": -119.19866462296086
        },
        "location_string": "Esplanade & 2:30"
    },
    {
        "uid": "a1Xd0000001IXllEAG",
        "year": 2016,
        "name": "Cosmic Recess",
        "hometown": "Salt Lake City",
        "description": "Cosmic Recess is a Playground with a Space theme.  We believe that interactivity, creativity and play are all necessary components of joy and happiness!  All of our playground elements are original and homemade, most with recycled/reused materials. Please come play with us at the Cosmiquarium Village this year!  We will also host kickball and Volleyball tournaments between other camps and villages, as well as parties and events throughout the week!",
        "location": {
            "string": "Esplanade & 4:00",
            "frontage": "Esplanade",
            "intersection": "4:00",
            "intersection_type": "&",
            "gps_latitude": 40.7797827277492,
            "gps_longitude": -119.20415844356913
        },
        "location_string": "Esplanade & 4:00"
    },
    {
        "uid": "a1Xd0000001IXkdEAG",
        "year": 2016,
        "name": "Black Rock Bakery",
        "url": "https://www.facebook.com/blackrockbakery/",
        "contact_email": "zeinin@gmail.com",
        "hometown": "Los Angeles",
        "description": "The Black Rock Bakery and Ice Cream Parlor is back again! Come by to grab some fresh delights from our dedicated bakers! Along with our usual fare of cookies, wedding cakes, and bread, this year we will also be featuring some unusual taste sensations, including liquid nitrogen-made ice cream, chocolate lava cakes, Dutch poffertjes, and maybe even Cronuts!",
        "location": {
            "string": "Esplanade & 4:30 Portal",
            "frontage": "Esplanade",
            "intersection": "4:30 Portal",
            "intersection_type": "&",
            "gps_latitude": 40.77954932016092,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "Esplanade & 4:30 Portal"
    },
    {
        "uid": "a1Xd0000001IXkEEAW",
        "year": 2016,
        "name": "Silent Ravers",
        "hometown": "Oakland",
        "description": "Silent Ravers Camp (within Hushville).  Never raved?  Always wanted to but 1) didn't know exaclty what \"raving\" was? 2) Feel too old, square, chubby, sober, awkward, midwestern, Presbyterian to truly rave? 3) Always thought \"House\" and \"Techno\" were sure strange names for a band? (hint: they are not bands) ...well load up your MP3 player and head over to the Silent Ravers camp, during, say, a reasonable hour, and dance with us. We hold a week long, drug free if ya want, (or whatever) Silent Rave, just you and your MP3 player.  Lazers and blinkies not even required!  Kick up some dust and sit in the shade and rest.  Raving can be easy, if you pace yourself.",
        "location": {
            "string": "E & 5:15",
            "frontage": "E",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.776525043868155,
            "gps_longitude": -119.21189639030393
        },
        "location_string": "E & 5:15"
    },
    {
        "uid": "a1Xd0000001IXm5EAG",
        "year": 2016,
        "name": "Armone Galaxy",
        "url": "http://www.facebook.com/armonegalaxy",
        "contact_email": "armonegalaxy@nevloproject.com",
        "hometown": "Eureka",
        "description": "Armone Galaxy Camp returns with an increased labyrinth size from 100' to 140' diameter, and the walls are constructed in plywood, improving on last year's design, with a 36' center dome and courtyard containing gymnastic equipment, hammocks, bean bags, cargo net hangout, a 30 foot climb to the crow's nest with a 360 degree view of the city, and workshops on aerial performance, acrobatics, alternative health, eco-sustainable building practices and a generally chill space to hang out.",
        "location": {
            "string": "9:00 & J",
            "frontage": "9:00",
            "intersection": "J",
            "intersection_type": "&",
            "gps_latitude": 40.796281355415935,
            "gps_longitude": -119.21955363512441
        },
        "location_string": "9:00 & J"
    },
    {
        "uid": "a1Xd0000001IXhtEAG",
        "year": 2016,
        "name": "MythMaker",
        "url": "http://www.mythmaker.ca",
        "contact_email": "hjeron@mythmaker.ca",
        "hometown": "Vancouver",
        "description": "MythMaker - The Mytho-Theatrical Sacred Circus Presents: Vikings & Valkyries",
        "location": {
            "string": "G & 6:15",
            "frontage": "G",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.21907490302245
        },
        "location_string": "G & 6:15"
    },
    {
        "uid": "a1Xd0000001IXpYEAW",
        "year": 2016,
        "name": "Cheesehead Camp",
        "hometown": "Madison",
        "description": "Come share all things Wisconsin...cheese, beer, bratwurst and friendly conversation.  Within Fandango!",
        "location": {
            "string": "9:30 & A",
            "frontage": "9:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.79337692443453,
            "gps_longitude": -119.21182077171073
        },
        "location_string": "9:30 & A"
    },
    {
        "uid": "a1Xd0000001IXnDEAW",
        "year": 2016,
        "name": "Camp Gold Star",
        "url": "http://www.camp-gold-star.com",
        "hometown": "Technically based in College Park, Maryland; but we have campers from multiple states.",
        "description": "At Camp Gold Star, we know that inside that sparkle pony facade is a very special snowflake. And we've got everything you need to feed your body and your ego. \r\n\r\nStop by for your daily dose of overenthusiastic personal adulation, participation certificates, trophies, hugs, and snark. After dark, enjoy tasty beverages, broth, TLC, and more awards, you entitled little shits!",
        "location": {
            "string": "F & 4:45",
            "frontage": "F",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20845363458552
        },
        "location_string": "F & 4:45"
    },
    {
        "uid": "a1Xd0000001IXncEAG",
        "year": 2016,
        "name": "La Cabana de Cinnabar",
        "hometown": "Santa Barbara",
        "description": "\"Comfort STOP Station\" for passersby to Stop, Think, Observe and Proceed, providing the opportunity and resources to observe one's current condition and needs, regroup, hydrate, snack, freshen up, apply provided sunscreen, as well as to connect, receive support and encouragement, and exchange hugs and good humor.",
        "location": {
            "string": "E & 5:15",
            "frontage": "E",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.776525043868155,
            "gps_longitude": -119.21189639030393
        },
        "location_string": "E & 5:15"
    },
    {
        "uid": "a1Xd0000001IRtEEAW",
        "year": 2016,
        "name": "Celestial Bodies",
        "url": "http://www.campcelestialbodies.org",
        "contact_email": "coordinator@campcelestialbodies.org",
        "hometown": "San Francisco / Sacramento",
        "description": "Celestial Bodies is your straight-friendly lounge bar in the gayborhood. Join us for daily activities and special events and enjoy one (or several) of our satisfying Playa Cosmo cocktails.",
        "location": {
            "string": "7:30 & E",
            "frontage": "7:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78639914008551,
            "gps_longitude": -119.22061484986375
        },
        "location_string": "7:30 & E"
    },
    {
        "uid": "a1Xd0000001IVsdEAG",
        "year": 2016,
        "name": "Blissfits Village",
        "description": "The Blissfits “Retirement” Village is a motley crew of seasoned playa vets that have been building & contributing to the playa ethos for 10 to 20 years. Blissfits campmates offer a more mellow, “Snarkle Pony”, lighthearted fun, to the event. This year our camp frontage will offer fun games such as Bocci Ball, Shuffle Board as well as plenty of comfy space to hang out and get cozy around a fire. \r\nBlissfits Village is also home to The Cumright Inn, were we offer worthy citizens a variety of treats befitting our fine establishment's name.\r\nAlong with our friendly bar & grilled cheese stand, our village aim’s to please and will take great care of you along your journey!",
        "location": {
            "string": "E & 8:15",
            "frontage": "E",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79048412688384,
            "gps_longitude": -119.21954373981305
        },
        "location_string": "E & 8:15"
    },
    {
        "uid": "a1Xd0000001IXWgEAO",
        "year": 2016,
        "name": "HAVANA NIGHTS",
        "url": "https://www.facebook.com/HavanaNightsParty",
        "hometown": "Miami",
        "description": "Perpetual Cuban-themed sultry Havana Nights dance party with a laid-back Miami feel. Lighted, inflatable palm trees will surround the perimeter of a large shaded and lighted dance floor.  Large, comfortable, elevated chill pads will be available for guest to relax.  Rhythmic Cuban and energetic Latin bongo beats will play in the background.  Cold Mojitos, Margaritas, and Cuba Libre drinks will be served by camp attendants wearing guayabera shirts.  Dance lessons hosted once per day.",
        "location": {
            "string": "J & 8:45",
            "frontage": "J",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79490675076163,
            "gps_longitude": -119.22114549753985
        },
        "location_string": "J & 8:45"
    },
    {
        "uid": "a1Xd0000001IODmEAO",
        "year": 2016,
        "name": "Maxa Camp",
        "url": "www.xamanmaxa.com",
        "description": "Maxa Camp was formed by using elements and beliefs of the Huichol Culture and complementing them with contemporary views and grooves (& Mezcal). We promote spreading good vibes and the main objective of our mystical mutant vehicle, the Blue Deer, will be to guide you to fun and new experiences, as the Huichol Maxa guides it’s followers to new and higher perspectives.",
        "location": {
            "string": "K & 8:15",
            "frontage": "K",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79199845038348,
            "gps_longitude": -119.22435685122926
        },
        "location_string": "K & 8:15"
    },
    {
        "uid": "a1Xd0000001IJFQEA4",
        "year": 2016,
        "name": "Totally Legit Camp",
        "url": "http://legit.camp",
        "contact_email": "folks@legit.camp",
        "hometown": "Brooklyn",
        "location": {
            "string": "D & 9:15",
            "frontage": "D",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.794353648046624,
            "gps_longitude": -119.21456958248888
        },
        "location_string": "D & 9:15"
    },
    {
        "uid": "a1Xd0000001IWMZEA4",
        "year": 2016,
        "name": "Bad Asstronauts",
        "url": "http://www.badasstronauts.org",
        "contact_email": "missioncontrol@badasstronauts.org",
        "hometown": "Denver",
        "description": "A space themed camp from Denver Colorado. Come blast off with us!",
        "location": {
            "string": "8:00 & D",
            "frontage": "8:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.78899509186698,
            "gps_longitude": -119.21929538907911
        },
        "location_string": "8:00 & D"
    },
    {
        "uid": "a1Xd0000001IGNREA4",
        "year": 2016,
        "name": "Beans, Beans, the Musical Camp",
        "hometown": "San Francisco",
        "description": "We host daily open jam sessions and serve beans at lunchtime. Don't forget your bowl!",
        "location": {
            "string": "G & 7:45",
            "frontage": "G",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78796556023548,
            "gps_longitude": -119.22221681630182
        },
        "location_string": "G & 7:45"
    },
    {
        "uid": "a1Xd0000001IN8SEAW",
        "year": 2016,
        "name": "Eat Your Veggies",
        "contact_email": "eyvbrc@gmail.com",
        "hometown": "Brooklyn",
        "description": "Eat Your Veggies! believes in naturally occuring nutrients and sheer ridiculousness. Join us for nutritious veggie snacks, drinks + surprises Mon-Fri from 12-4pm!",
        "location": {
            "string": "H & 3:15",
            "frontage": "H",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.776355654907675,
            "gps_longitude": -119.1963226411644
        },
        "location_string": "H & 3:15"
    },
    {
        "uid": "a1Xd0000001IXm0EAG",
        "year": 2016,
        "name": "Soul Garden",
        "contact_email": "dameleas@gmail.com",
        "hometown": "Petaluma",
        "description": "The Soul Garden is a collective of wholesome individuals passionate about creativity, free expression of individuality, and nourishing the body and soul. Come unearth your inner spirit vegetable as we help guide you through the mystical garden to achieve horticultural enlightenment. Our Carrot Dome is perfect for vegging out, laying high, laying low, or getting down in funkytown…so lettuce turnip the beet!",
        "location": {
            "string": "4:30 & H",
            "frontage": "4:30",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.7737399436574,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & H"
    },
    {
        "uid": "a1Xd0000001ISECEA4",
        "year": 2016,
        "name": "White Ocean",
        "url": "https://www.facebook.com/WhiteOceanCamp",
        "hometown": "San Francisco",
        "description": "White Ocean is an immense, immersive sound and art experience, created through the collaboration and passion of many brilliant and dedicated artists. We celebrate the creation of community through music, ideas, and free expression, and are grateful for the opportunity to once again bring our dreams to life in Black Rock City.",
        "location": {
            "string": "2:00 & G",
            "frontage": "2:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.78329254071427,
            "gps_longitude": -119.19118879998587
        },
        "location_string": "2:00 & G"
    },
    {
        "uid": "a1Xd0000002ZRnQEAW",
        "year": 2016,
        "name": "Temple of Annointment",
        "hometown": "San Diego",
        "description": "Temple of Anointment - please join us for blowjobs, lotion, tattoos and drinks. We have blowers to blow the sand off you and misters to clean and cool your bodies. We have suntan lotions and tattoos to protect and adorn your body. Frozen drinks such as  mudslides, margaritas, and daiquiris will cool you on even the hottest days..",
        "location": {
            "string": "D & 6:15",
            "frontage": "D",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.780290026048306,
            "gps_longitude": -119.21700375742115
        },
        "location_string": "D & 6:15"
    },
    {
        "uid": "a1Xd0000001INW0EAO",
        "year": 2016,
        "name": "Burner Express Bus Camping aka HOVerlandia",
        "location": {
            "string": "J & 6:15",
            "frontage": "J",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77789139813902,
            "gps_longitude": -119.22114174558
        },
        "location_string": "J & 6:15"
    },
    {
        "uid": "a1Xd0000001IJzLEAW",
        "year": 2016,
        "name": "Burner Express Depot  (BxB Depot)",
        "location": {
            "string": "6:00 & K",
            "frontage": "6:00",
            "intersection": "K",
            "intersection_type": "&",
            "gps_latitude": 40.77605206370598,
            "gps_longitude": -119.22016376106598
        },
        "location_string": "6:00 & K"
    },
    {
        "uid": "a1Xd0000001IWU4EAO",
        "year": 2016,
        "name": "Formosa Express",
        "contact_email": "formosa@mirpartners.com",
        "hometown": "San Francisco",
        "description": "Formosa Express - sharing a taste of Taiwan on the Playa.  Come visit.",
        "location": {
            "string": "A & 7:15",
            "frontage": "A",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.785344061740865,
            "gps_longitude": -119.21704843724241
        },
        "location_string": "A & 7:15"
    },
    {
        "uid": "a1Xd0000001IXBFEA4",
        "year": 2016,
        "name": "Sake II Mi",
        "hometown": "San Francisco",
        "description": "Sake II Mi Camp is bringing the first and only combined Sumo Wrestling Arena and 16th Century Rubenesque photo stage to BRC. Come wrestle, pose, and participate in pure EurAsian hilarity!",
        "location": {
            "string": "7:00 & A",
            "frontage": "7:00",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.784314394456956,
            "gps_longitude": -119.2167775389316
        },
        "location_string": "7:00 & A"
    },
    {
        "uid": "a1Xd0000001ISMBEA4",
        "year": 2016,
        "name": "Playa Name Help",
        "url": "http://playanamehelp.info/",
        "hometown": "Seattle, Portland, Chicago and NYC",
        "description": "PLAYA NAME HELP provides meaningful Playa Names for Black Rock City citizens.  We provide a playafied version of psychoanalysis and are interactive in both directions; we don't just name people, we provide space and support for others to be namers as well.  \r\nhttps://www.facebook.com/PlayaNameHelp/",
        "location": {
            "string": "I & 4:15",
            "frontage": "I",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77319619060326,
            "gps_longitude": -119.20420459530268
        },
        "location_string": "I & 4:15"
    },
    {
        "uid": "a1Xd0000001IRxpEAG",
        "year": 2016,
        "name": "Thumper",
        "url": "http://www.facebook.com/thumpercamp",
        "contact_email": "thumpercamp@gmail.com",
        "hometown": "DC",
        "description": "Thumper aims to create the kind of music and dance experience we ourselves were seeking out: a lounge vibe that's friendly, welcoming, fun, inclusive, with the best possible sound.",
        "location": {
            "string": "2:00 & J",
            "frontage": "2:00",
            "intersection": "J",
            "intersection_type": "&",
            "gps_latitude": 40.782781531823574,
            "gps_longitude": -119.18867202753226
        },
        "location_string": "2:00 & J"
    },
    {
        "uid": "a1Xd0000001IPMREA4",
        "year": 2016,
        "name": "Funkcadia Inconvenience Store",
        "hometown": "Leucadia",
        "description": "Forget your sunscreen, banana hammock or just feel like some good old-fashioned heckling? Come on down to the Funkcadia Inconvenience Store. We probably don't have what you need, but it's bound to be an inconvenient time! Sorry, we're open!",
        "location": {
            "string": "B & 2:15",
            "frontage": "B",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78306073698514,
            "gps_longitude": -119.19586992770513
        },
        "location_string": "B & 2:15"
    },
    {
        "uid": "a1Xd0000001ICQxEAO",
        "year": 2016,
        "name": "OHM HOME",
        "hometown": "Laguna Beach",
        "description": "OHM HOME",
        "location": {
            "string": "L & 9:45",
            "frontage": "L",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.800526522970046,
            "gps_longitude": -119.21422997199771
        },
        "location_string": "L & 9:45"
    },
    {
        "uid": "a1Xd0000001IV4LEAW",
        "year": 2016,
        "name": "Heroes and Super Villains (HSV)",
        "url": "http://www.heroesandsupervillains.com/",
        "contact_email": "andrew@heroesandsupervillains.com",
        "hometown": "New York and Los Angeles",
        "description": "We are a community of like minded people. Our activities are intentional performance art from craft cocktails at the bar to curated DJ music, art activities, soul power wash and of course our Friday Soul Brunch. It's not a free for all, but rather an intentional community with lots of wisdom and planning along with lessons learned. Past campers have paid it forward to provide this year's amazing camp. Our planning and structure provide a grounding and safe foundation amongst all the fun and chaos.",
        "location": {
            "string": "E & 6:15",
            "frontage": "E",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77988938361873,
            "gps_longitude": -119.21769250845776
        },
        "location_string": "E & 6:15"
    },
    {
        "uid": "a1Xd0000001IXmjEAG",
        "year": 2016,
        "name": "17 Virgins",
        "hometown": "Toronto",
        "description": "17 Virgins: get transported through BRC in our sensory Portal, and come recharge, re-nourish, or rest during Hammocks, Hookahs, and Hot-Dogs in our Zen Den.",
        "location": {
            "string": "B & 8:45",
            "frontage": "B",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79170076257172,
            "gps_longitude": -119.21563500580646
        },
        "location_string": "B & 8:45"
    },
    {
        "uid": "a1Xd0000001IWRKEA4",
        "year": 2016,
        "name": "Slushious",
        "url": "https://www.facebook.com/letsgetslushie/",
        "contact_email": "kj.glynn@gmail.com",
        "hometown": "San Francisco",
        "description": "We herald from all corners of our wonderful globe.  As with voltron when our powers combine we becomes greater than the sum of it's parts.  Enter Slushious an oasis for the weary travelers!",
        "location": {
            "string": "J & 9:15",
            "frontage": "J",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79748687476975,
            "gps_longitude": -119.21773832223408
        },
        "location_string": "J & 9:15"
    },
    {
        "uid": "a1Xd0000001IBSkEAO",
        "year": 2016,
        "name": "Flamingo Camp",
        "hometown": "Reno",
        "description": "Flamingo Camp",
        "location": {
            "string": "3:30 & A",
            "frontage": "3:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.77942283122764,
            "gps_longitude": -119.20118034618002
        },
        "location_string": "3:30 & A"
    },
    {
        "uid": "a1Xd0000001IWknEAG",
        "year": 2016,
        "name": "ShangriLa",
        "url": "http://shangrila.heavenlyyoga.us/",
        "contact_email": "petralikesyoga@gmail.com",
        "hometown": "Morrison",
        "description": "ShangriLa - Wine Camp with a Yoga Problem! LaLas are back with yoga, meditation, handjobs, and wine tastings to enjoy! We even sing with you this year and plan to give you a good spanking if you behave ~"
    },
    {
        "uid": "a1Xd0000001IKe4EAG",
        "year": 2016,
        "name": "IN DUST WE TRUST",
        "hometown": "Santa Rosa",
        "description": "IN DUST WE TRUST\r\nWander in,enjoy the chill space, choose some sexy lingerie,exchange stories. Get that playa hair braided with some fancy adornments. Stay awhile, connect, have a laugh. Nothin but FUN!",
        "location": {
            "string": "C & 5:15",
            "frontage": "C",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77774041281025,
            "gps_longitude": -119.21123222480414
        },
        "location_string": "C & 5:15"
    },
    {
        "uid": "a1Xd0000001IR4zEAG",
        "year": 2016,
        "name": ")*(Aloha = H'Aloha",
        "contact_email": "inceptus.ph@gmail.com",
        "hometown": "Orange",
        "description": "A Playanesian Paradise of endless Aloha KaKou\r\nKomo mai e inu ka wai, e noho, wala'au",
        "location": {
            "string": "I & 4:45",
            "frontage": "I",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77319619060326,
            "gps_longitude": -119.20879540469736
        },
        "location_string": "I & 4:45"
    },
    {
        "uid": "a1Xd0000001IEHrEAO",
        "year": 2016,
        "name": "PaintingWallofGreenPeaceEvolves",
        "hometown": "Moss Beach",
        "description": "The Painting Wall of Green Peace. Encourages radical self express with our paints and canvases.",
        "location": {
            "string": "G & 4:15",
            "frontage": "G",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20443126133077
        },
        "location_string": "G & 4:15"
    },
    {
        "uid": "a1Xd0000001IRJsEAO",
        "year": 2016,
        "name": "Vines Without Borders",
        "url": "http://www.vineswithoutborders.com",
        "contact_email": "cmframe@gmail.com",
        "hometown": "Menlo Park",
        "description": "Vines Without Borders (Vines) is an international wine bar with people and wines from around the world. We create a true wine bar and lounge experience every night of the week serving from 6:00pm until we can't anymore.",
        "location": {
            "string": "C & 4:45",
            "frontage": "C",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.7771083101538,
            "gps_longitude": -119.20811387231836
        },
        "location_string": "C & 4:45"
    },
    {
        "uid": "a1Xd0000001IGa2EAG",
        "year": 2016,
        "name": "Wonder Camp",
        "url": "https://www.facebook.com/departmentofwonder/",
        "contact_email": "artwonderbus@gmail.com",
        "hometown": "Lakebay",
        "description": "\"Wonder Camp\" is where we fix the broken burner and all their stuff. You can also get your tee shirt silk screened at \"Splinter the Printer\" and your attitude adjusted at the \"Siren Salon\"!",
        "location": {
            "string": "4:30 & J",
            "frontage": "4:30",
            "intersection": "J",
            "intersection_type": "&",
            "gps_latitude": 40.77242461312829,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & J"
    },
    {
        "uid": "a1Xd0000001IWCUEA4",
        "year": 2016,
        "name": "SNAP Camp & Cafe",
        "url": "http://campsnap.wix.com/snap",
        "contact_email": "campsnap@gmail.com",
        "hometown": "San Francisco",
        "description": "SNAP Camp & Cafe provides Playa members a chill place to relax and participate in life sized and regular board games of all types. We offer yoga classes, poi, and a cafe with daily brewed iced and hot tea, coffee, and yerba mate.",
        "location": {
            "string": "4:30 Plaza @ 9:15",
            "frontage": "4:30 Plaza",
            "intersection": "9:15",
            "intersection_type": "@",
            "gps_latitude": 40.77444208933958,
            "gps_longitude": -119.20694805344318
        },
        "location_string": "4:30 Plaza @ 9:15"
    },
    {
        "uid": "a1Xd0000001IXI6EAO",
        "year": 2016,
        "name": "Camp Validation - We Validate!",
        "contact_email": "zenfulldog@comcast.net",
        "hometown": "San Francisco",
        "description": "Wondering if your butt cheeks look alright in those booties shorts? Hoping that someone will see just how AMAZING you really are (bootie shorts or not)? Wonder no more. Come on down to Camp Validation where our highly skilled team of validators will clear away any lingering insecurities & fill you up with all the validation you deserve."
    },
    {
        "uid": "a1Xd0000001IRrfEAG",
        "year": 2016,
        "name": "Hanging Gardens of BRC",
        "url": "https://www.facebook.com/HangingGardensBRC",
        "contact_email": "hanginggardensbrc@gmail.com",
        "hometown": "Los Angeles",
        "description": "The Hanging Gardens is  an all-inclusive space - male, female, gay and straight - that celebrates the beauty of our interconnectedness, serendipity and  of their intersection. Visiting The Hanging Gardens means opening yourself up to the possibilities of chance meetings and unexpected adventures.",
        "location": {
            "string": "B & 7:15",
            "frontage": "B",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78525786330597,
            "gps_longitude": -119.21790952809974
        },
        "location_string": "B & 7:15"
    },
    {
        "uid": "a1Xd0000001IJKQEA4",
        "year": 2016,
        "name": "Burner Buddies",
        "url": "https://www.facebook.com/groups/335223049922711/",
        "contact_email": "burnerbuddies@gmail.com",
        "hometown": "Palm Springs",
        "description": "Who's your Burner Buddie?\r\n\r\nEver have someone say you were gonna lose your Gay Card only to realize you don't have one? Get one at Burner Buddies.",
        "location": {
            "string": "4:30 & J",
            "frontage": "4:30",
            "intersection": "J",
            "intersection_type": "&",
            "gps_latitude": 40.77242461312829,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & J"
    },
    {
        "uid": "a1Xd0000001IXg7EAG",
        "year": 2016,
        "name": "Honey Puddle",
        "url": "http://www.honeypuddle.info/",
        "location": {
            "string": "4:30 Portal & 4:30 Portal",
            "frontage": "4:30 Portal",
            "intersection": "4:30 Portal",
            "intersection_type": "&"
        },
        "location_string": "4:30 Portal & 4:30 Portal"
    },
    {
        "uid": "a1Xd0000001IX6tEAG",
        "year": 2016,
        "name": "STRANGELOVE",
        "hometown": "San Francisco",
        "location": {
            "string": "F & 4:45",
            "frontage": "F",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20845363458552
        },
        "location_string": "F & 4:45"
    },
    {
        "uid": "a1Xd0000001IWYLEA4",
        "year": 2016,
        "name": "Red NOse District",
        "url": "https://www.facebook.com/groups/152872281529293/",
        "contact_email": "rednosedistrictinc@gmail.com",
        "hometown": "Los Angeles, Portland, Reno",
        "description": "Red NOse District is your Go~To STILT BAR & Front Stoop~like Entertainment & Kick Back Zone. Come to us to; learn to Walk Tall & get high  to get drunk or get real low to get tipsy @ our Big & Small Top Bars for Sunset Themed Costume Cocktail Parties....be fully entertained by professionals or throw down DIY style on our Stage in front of our Gong Show Lounge Crew....snuggle up by our Fire Sculpture Garden...or Kick Dawn's Balls in a game of Whiskey Sunrise Kick Ball...",
        "location": {
            "string": "Esplanade & 4:45",
            "frontage": "Esplanade",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.7796078276107,
            "gps_longitude": -119.20767973147856
        },
        "location_string": "Esplanade & 4:45"
    },
    {
        "uid": "a1Xd0000001IVHbEAO",
        "year": 2016,
        "name": "Chomp and Stomp",
        "hometown": "Atlanta",
        "description": "Chomp and Stomp - a team of makers and shakers. Find us in camp for decadent leisure, merry making and bloody marys.",
        "location": {
            "string": "5:00 & E",
            "frontage": "5:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77607703461826,
            "gps_longitude": -119.21015262425809
        },
        "location_string": "5:00 & E"
    },
    {
        "uid": "a1Xd0000001IWNIEA4",
        "year": 2016,
        "name": "Kaleidoscope Collective",
        "hometown": "Sacramento, London",
        "description": "Kaleidoscope means \"the observation of beautiful forms\", but we know you look into a kaleidoscope and see a beautiful mess. That's just what we are. We bring people together through the power of stories and art (and monkey bars). Kaleidoscope Collective.  Share a story, spin a yarn, tell a tale.  We're all ears.",
        "location": {
            "string": "D & 5:15",
            "frontage": "D",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77713272797879,
            "gps_longitude": -119.21156430775099
        },
        "location_string": "D & 5:15"
    },
    {
        "uid": "a1Xd0000001IVjCEAW",
        "year": 2016,
        "name": "Lazy Skool Daze",
        "url": "https://www.facebook.com/LazySkoolDaze/",
        "contact_email": "lazyskooldaze@gmail.com",
        "hometown": "Boston",
        "description": "Lazy Skool Daze is an intellectual and artistic haven for the sharing of knowledge, love, and adventure. We present a creative, welcoming space where playa-mavens can come to teach and learn, to perform and observe, to show and tell.",
        "location": {
            "string": "4:30 & E",
            "frontage": "4:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77571293945105,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & E"
    },
    {
        "uid": "a1Xd0000001IXhZEAW",
        "year": 2016,
        "name": "Helios Camp",
        "hometown": "New York City",
        "location": {
            "string": "8:15 & H",
            "frontage": "8:15",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.791243763698084,
            "gps_longitude": -119.22194901027675
        },
        "location_string": "8:15 & H"
    },
    {
        "uid": "a1Xd0000001IGb0EAG",
        "year": 2016,
        "name": "Sunset Lounge and Bar",
        "hometown": "Santa Clarita",
        "description": "Sunset Bar and Lounge is BRC's favorite meeting spot. Live acts and daily events!",
        "location": {
            "string": "E & 9:15",
            "frontage": "E",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79487521198001,
            "gps_longitude": -119.2150987488738
        },
        "location_string": "E & 9:15"
    },
    {
        "uid": "a1Xd0000001IXO4EAO",
        "year": 2016,
        "name": "Rock Bottom Ranch",
        "contact_email": "christiancrynes@gmail.com",
        "hometown": "San Francisco",
        "description": "From Rock Bottom, there is only one direction you can go."
    },
    {
        "uid": "a1Xd0000001IWTVEA4",
        "year": 2016,
        "name": "Awesomesauce",
        "url": "http://www.campawesomesauce.org",
        "hometown": "Bozeman",
        "description": "Do you ever wonder what the ball feels like when you're watching the game?  Now's your chance to find out!  Come join us for Awesomeball in 2016 and strap in for a game of soccer like you've never played it before.  When you're safe inside a cushioned see through sphere you'll find whole new ways to gain ground and score for your team.  Be The Ball - Awesomeball at Camp Awesomesauce",
        "location": {
            "string": "C & 6:45",
            "frontage": "C",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.782808722545894,
            "gps_longitude": -119.21793232467711
        },
        "location_string": "C & 6:45"
    },
    {
        "uid": "a1Xd0000001IVx9EAG",
        "year": 2016,
        "name": "Pineapple Motel",
        "contact_email": "riwaharfoush@gmail.com",
        "hometown": "Globe",
        "description": "The Pineapple Motel invites you to take a load-off and come lounge with us. Our dusty oasis offers all-day-cereal, coconut water, relaxed jams, games, loungers and more.",
        "location": {
            "string": "E & 4:45",
            "frontage": "E",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77580421451263,
            "gps_longitude": -119.20834038050907
        },
        "location_string": "E & 4:45"
    },
    {
        "uid": "a1Xd0000001IR83EAG",
        "year": 2016,
        "name": "Moaning Lisa",
        "contact_email": "fonzcad3@gmail.com",
        "hometown": "San Francisco",
        "description": "The Moaning Lisa is a wine bar, tasting room (Food!), and gallery. Stop by and get some wine, cheese, and art!",
        "location": {
            "string": "C & 8:15",
            "frontage": "C",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.78998145273607,
            "gps_longitude": -119.2179383169208
        },
        "location_string": "C & 8:15"
    },
    {
        "uid": "a1Xd0000001IOtBEAW",
        "year": 2016,
        "name": "The Thrill Chill Cult",
        "contact_email": "fishface@thrillchillcult.com",
        "hometown": "Chicago/L.A./Knoxville",
        "description": "Need some energy for your nighttime adventures?  Those who dare to join the Thrill Chill Cult will be rewarded with tasty coffee and visual treats.",
        "location": {
            "string": "D & 9:15",
            "frontage": "D",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.794353648046624,
            "gps_longitude": -119.21456958248888
        },
        "location_string": "D & 9:15"
    },
    {
        "uid": "a1Xd0000001IBUqEAO",
        "year": 2016,
        "name": "Synapse Conduit",
        "contact_email": "mikechip@yahoo.com",
        "hometown": "Oakland",
        "description": "Synapse Conduit is a place where you will interact with a number of Burners who will tell your fortune, read your tarot,  play mind games and interact in a fun and silly manner. While you imbibe in one of our daily signature alcoholic concoctions we will help you relax from the pressures of the playa, discuss the hip happenings of life and ensure you leave with a smile on your face or in your mind.",
        "location": {
            "string": "H & 9:15",
            "frontage": "H",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79644345068721,
            "gps_longitude": -119.21668043777967
        },
        "location_string": "H & 9:15"
    },
    {
        "uid": "a1Xd0000001IRIuEAO",
        "year": 2016,
        "name": "BRC MoIST",
        "hometown": "SF Bay Area",
        "description": "Black Rock City Museum of Industry, Science and Technology.  Learn the history behind the things that make life at Black Rock City possible.  Are the stories true?  You decide!",
        "location": {
            "string": "J & 9:15",
            "frontage": "J",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79748687476975,
            "gps_longitude": -119.21773832223408
        },
        "location_string": "J & 9:15"
    },
    {
        "uid": "a1Xd0000001IOynEAG",
        "year": 2016,
        "name": "While You're Up",
        "contact_email": "hold@tbd.com",
        "hometown": "San Francisco",
        "description": "Camp While You're Up...I mean, you're already up so you might as well. You won't regret it. We promise!",
        "location": {
            "string": "9:00 & K",
            "frontage": "9:00",
            "intersection": "K",
            "intersection_type": "&",
            "gps_latitude": 40.79674632413234,
            "gps_longitude": -119.22016801956524
        },
        "location_string": "9:00 & K"
    },
    {
        "uid": "a1Xd0000001IW3mEAG",
        "year": 2016,
        "name": "Deus Ex Detective Agency",
        "hometown": "Seattle / Portland / San Francisco",
        "description": "Stop by the Deus Ex Detective Agency to bask in the gritty noir ambience and crack a case.",
        "location": {
            "string": "E & 9:15",
            "frontage": "E",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79487521198001,
            "gps_longitude": -119.2150987488738
        },
        "location_string": "E & 9:15"
    },
    {
        "uid": "a1Xd0000001IIsDEAW",
        "year": 2016,
        "name": "The Donner Party",
        "contact_email": "thedonnerpartycamp@gmail.com",
        "hometown": "Donner Summit",
        "description": "The Donner Party would love to meat you.",
        "location": {
            "string": "D & 8:45",
            "frontage": "D",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79250090223318,
            "gps_longitude": -119.21701391692622
        },
        "location_string": "D & 8:45"
    },
    {
        "uid": "a1Xd0000001IXeQEAW",
        "year": 2016,
        "name": "Desperados",
        "hometown": "Santa Cruz, Oakland, LA",
        "description": "We offer the kind of haggard mental and emotional support you get from folks like your uncle Larry. The one who taught you how to roll a cigarette and never to worry about growing up. Who always had the most worn in, dusty, comfy couches, who never seemed to care if you had rips in your clothes or blood on your knees, and whose bar was always open and magically full of whiskey. And who, of course, was a creative genius with a blubbery sensitive streak. Ask your dad if you can hang out at uncle Larry's again this weekend. If you can find him. Check over at that run down old western Desperados dive bar down the road.",
        "location": {
            "string": "8:30 & H",
            "frontage": "8:30",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.792729122999106,
            "gps_longitude": -119.22098190395288
        },
        "location_string": "8:30 & H"
    },
    {
        "uid": "a1Xd0000001IFurEAG",
        "year": 2016,
        "name": "XPAT ALIEN",
        "contact_email": "host@xpatalien.com",
        "hometown": "Denver",
        "description": "The number of Aliens choosing Earth as their permanent residence is growing. XPAT ALIEN has been smoothing the transition to Earth based partying since 2008. Come share a ice-filled, sweet, cosmic beverage, swap intergalactic tales with fellow XPATs, and levitate on our bartop anti-gravity poles at the Crop Circle Cantina. Look for the blue and silver, alien circus spaceship.",
        "location": {
            "string": "7:30 Portal & A",
            "frontage": "7:30 Portal",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.78639951132433,
            "gps_longitude": -119.21714042532156
        },
        "location_string": "7:30 Portal & A"
    },
    {
        "uid": "a1Xd0000001IVrpEAG",
        "year": 2016,
        "name": "THE LAST SUPPER",
        "hometown": "San Francisco",
        "description": "THE LAST SUPPER by the Order of the Dusty Phoenix",
        "location": {
            "string": "L & 2:15",
            "frontage": "L",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78054699343649,
            "gps_longitude": -119.1878438109233
        },
        "location_string": "L & 2:15"
    },
    {
        "uid": "a1Xd0000001IXIQEA4",
        "year": 2016,
        "name": "Camp 451",
        "contact_email": "louismr1950@gmail.com",
        "hometown": "Woodacre-Seattle",
        "location": {
            "string": "H & 5:45",
            "frontage": "H",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.776355654907675,
            "gps_longitude": -119.21667735883563
        },
        "location_string": "H & 5:45"
    },
    {
        "uid": "a1Xd0000001IWQREA4",
        "year": 2016,
        "name": "Jake's Tent Charcuterie",
        "contact_email": "ash_wilkes@msn.com",
        "hometown": "Salt Lake City",
        "description": "Who doesn't love wine, meat, and cheese?  We've got that Manchego you've been dreaming of.  Come on by and relax in our pillow pools, enjoy a delicious glass of vino, or tuck in to some aged Jamon Serrano.  Everyone is welcome to partake, no strings attached!",
        "location": {
            "string": "C & 9:15",
            "frontage": "C",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79383208574335,
            "gps_longitude": -119.21404041775784
        },
        "location_string": "C & 9:15"
    },
    {
        "uid": "a1Xd0000001IWvgEAG",
        "year": 2016,
        "name": "U.F.O.",
        "url": "http://www.facebook.com/uforesponseteamBM",
        "contact_email": "campufo.hq@gmail.com",
        "hometown": "San Francisco",
        "description": "UFO = U Figure it Out! We take many forms: Ultimate Futon Organization, uproarious Flame Orchestra, Ur a Fabulous Organism, Umbrella Festival Operation, Unwavering Freshness Obsession, etc.\r\ncampufo.hq@gmail.com"
    },
    {
        "uid": "a1Xd0000001IXbCEAW",
        "year": 2016,
        "name": "Equilibrium",
        "location": {
            "string": "C & 8:45",
            "frontage": "C",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.792100831597146,
            "gps_longitude": -119.21632445997854
        },
        "location_string": "C & 8:45"
    },
    {
        "uid": "a1Xd0000001ISvQEAW",
        "year": 2016,
        "name": "Camp Get Nailed",
        "hometown": "Sonoma",
        "description": "Camp Get Nailed is an interactive, participatory, performance art destination about getting nailed! \r\n\r\n1. Camp visitors can climb up on our 10' crucifix to \"Get Nailed\" by hanging from the spike/handles we have secured to the cross \r\n\r\n2. Enter our 12'x10' church to Get Nailed physically or spiritually by meditation, confession, kneeling in worship or fellatio or put trust in God and get nailed for full spiritual and physical release.\r\n\r\nChurch open 24 hrs."
    },
    {
        "uid": "a1Xd0000001IVvNEAW",
        "year": 2016,
        "name": "Catmandu",
        "url": "http://www.campcatmandu.com",
        "hometown": "San Francisco",
        "location": {
            "string": "4:00 & E",
            "frontage": "4:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77607703461826,
            "gps_longitude": -119.20284737574195
        },
        "location_string": "4:00 & E"
    },
    {
        "uid": "a1Xd0000001IHSCEA4",
        "year": 2016,
        "name": "Barbots",
        "url": "https://www.facebook.com/volterrathecyborg",
        "hometown": "Santa Barbara",
        "description": "The Barbots are back with Volterra, the Playa's beloved robot bartender! Skip or stumble your way to the Barbot playground, where cyborg Volterra slings cocktails like a boss. Happy hour and yard games will get you smiling!",
        "location": {
            "string": "E & 6:45",
            "frontage": "E",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78230469594509,
            "gps_longitude": -119.21953682219086
        },
        "location_string": "E & 6:45"
    },
    {
        "uid": "a1Xd0000001IBhhEAG",
        "year": 2016,
        "name": "Dusty Nuts Tavern",
        "contact_email": "dustynutstavern@gmail.com",
        "hometown": "Sunnyvale",
        "description": "Come meet Remix, The Master, Top Noodle, Douchebag Undecided, Pulled Pork, Tigerlily, and Dusty Nuts himself everyday 5-7pm for Happy Hour.  Sit on our Throne of Lies, chill out in the chill dome, or get/give massages.",
        "location": {
            "string": "H & 2:45",
            "frontage": "H",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77869228660995,
            "gps_longitude": -119.19323614115217
        },
        "location_string": "H & 2:45"
    },
    {
        "uid": "a1Xd0000001ISNOEA4",
        "year": 2016,
        "name": "Kin-Dza-Dza!",
        "url": "https://sites.google.com/site/campkzz/",
        "hometown": "New York",
        "description": "Camp Kin-Dza-Dza!, Space-junk dystopia and tea, since 2006!",
        "location": {
            "string": "B & 9:45",
            "frontage": "B",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79444946765153,
            "gps_longitude": -119.21090843559313
        },
        "location_string": "B & 9:45"
    },
    {
        "uid": "a1Xd0000001IOxBEAW",
        "year": 2016,
        "name": "Rootpile",
        "url": "http://www.rootpile.com",
        "contact_email": "fixxer@rootpile.com",
        "hometown": "Boone",
        "description": "Rootpile is a camp made up of professional and semi professional Bluegrass Music musicians and fans whose mission is to bring live Bluegrass Music, music instrument workshops and emergency stringed instrument repair to the Playa. We have nightly concerts, from 10 pm to midnight, often with hillbilly food and drink, and daily instrument workshops from 11am to 1pm on banjo, mandolin, guitar and fiddle, and we supply those instruments for people to play and we have several professional luthiers on hand to fix your stringed musical instruments, should you have a problem.",
        "location": {
            "string": "6:00 Public Plaza @ 11:00",
            "frontage": "6:00 Public Plaza",
            "intersection": "11:00",
            "intersection_type": "@",
            "gps_latitude": 40.792472680485126,
            "gps_longitude": -119.21420190914193
        },
        "location_string": "6:00 Public Plaza @ 11:00"
    },
    {
        "uid": "a1Xd0000001IX5qEAG",
        "year": 2016,
        "name": "Hammer And Cyclery",
        "url": "http://hammerandcyclery.com",
        "hometown": "Minneapolis",
        "description": "We are a full service bicycle repair shop (limited parts) with all of the tools and talent to help Burners everywhere have the smoothest, safest (reddest) week possible on their Burning Man bike. We are open from 10am to 6pm every day (Monday to Sunday).\r\nwww.HammerAndCyclery.com",
        "location": {
            "string": "3:00 & I",
            "frontage": "3:00",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.77698228119831,
            "gps_longitude": -119.19406426804439
        },
        "location_string": "3:00 & I"
    },
    {
        "uid": "a1Xd0000001IOxpEAG",
        "year": 2016,
        "name": "Lustre Village",
        "contact_email": "jainesy@yahoo.com",
        "hometown": "San Francisco",
        "description": "Lustre Village returns!  Tazii will provide Moroccan chill space and top-shelf bar.  Glittercamp will make the masses shiny and glittery, as nature intended, with our special glitter-slather concoction.  New this year will be live music, including our house David Bowie cover band!",
        "location": {
            "string": "3:30 & D",
            "frontage": "3:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.77771409960112,
            "gps_longitude": -119.19987774416956
        },
        "location_string": "3:30 & D"
    },
    {
        "uid": "a1Xd0000001IEQXEA4",
        "year": 2016,
        "name": "Camp Sweaty Betty",
        "contact_email": "mburback@comcast.net",
        "hometown": "Seattle, Ventura, Ithaca",
        "description": "Friendly neighborhood misting Parlor, hair washing, Spa and Bike Repair. Stop in and experience an overall cooling sensation from head to foot as you stroll through the mist. Got crunchy hair, feeling a bit beat...You may qualify for an emergency hair wash; perhaps there is an opening in the massage room...Stop in and chill. Got a flat, derailleur doesn't work, chain broke, we can fix that also. You might even get lucky and be gifted a bike. \r\nOpen 11:00 to 4:00. Volunteer opportunities.",
        "location": {
            "string": "C & 7:15",
            "frontage": "C",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78517166496261,
            "gps_longitude": -119.21877061804274
        },
        "location_string": "C & 7:15"
    },
    {
        "uid": "a1Xd0000001IXIaEAO",
        "year": 2016,
        "name": "The Hangry Bishop",
        "url": "https://www.facebook.com/groups/1461548064153619/",
        "hometown": "San Francisco",
        "description": "The Hangry Bishop is a Medieval diner and roadside inn, founded around the time Cheddar Cheese was invented in 1300s England.   \r\n\r\nSince 2015, we have invited dusty pilgrims of BRC into our household to serve Grilled Cheeses and Virgin Mary's.  We only use top shelf Cheddar to prepare a holy trinity of gooey deliciousness, the Grilled Cheeses.\r\n\r\nAt our Holy Grill in BRC, we serve Dinner at nones, every day at 2 pm.",
        "location": {
            "string": "2:30 & D",
            "frontage": "2:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.781384734418374,
            "gps_longitude": -119.1950292825442
        },
        "location_string": "2:30 & D"
    },
    {
        "uid": "a1Xd0000001IIa4EAG",
        "year": 2016,
        "name": "EBB and Glow",
        "hometown": "East Bay - SF Bay Area",
        "description": "EBB and Glow Village encompasses art, architecture, activities and assistance.  Situated around the bold Pavilion of DREAMS and its rooftop deck, you will encounter:  the Burning DREAMS Stage, a magnet for live music and performance; the amazing Magic Lantern tent, filled with curiosities, old books, conversation games and the unique Trading Booth; Cranky and Sons Bike Repair, providing instruction, tools and help as needed; the Photo Studio, shooting quality portraits of you in your dusty finery; the Glowwind Sculpture Garden, a quiet place to wander; and So So Cupid, the playa's most adequate dating service.",
        "location": {
            "string": "3:00 & I",
            "frontage": "3:00",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.77698228119831,
            "gps_longitude": -119.19406426804439
        },
        "location_string": "3:00 & I"
    },
    {
        "uid": "a1Xd0000001IWXSEA4",
        "year": 2016,
        "name": "Fusion Valley",
        "url": "http://www.fusionvalley.org",
        "contact_email": "fv-camp@torche.com",
        "hometown": "Gerlach",
        "description": "Welcome to Fusion Valley! Stop on by at our Internet Cafe. We're your basic chill space that has mellow music (FM station 95.7 DJ's!), phones, public computers & much more under our carpeted shade. Into board games? So are we! There is often a Cards A.H. game going on, so stop on by and join in! At night we have a drive-in theater, and possibly something spooky! Take a load off and say hi to some long time BM staff & burners.",
        "location": {
            "string": "C & 3:15",
            "frontage": "C",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.778962057935686,
            "gps_longitude": -119.19897050537821
        },
        "location_string": "C & 3:15"
    },
    {
        "uid": "a1Xd0000001IVJrEAO",
        "year": 2016,
        "name": "Blood, Rust & Whiskey",
        "hometown": "los angeles",
        "description": "Oil your hinges and lift your spirits at Blood, Rust & Whiskey. Give us your dusty, your rusty, your randy souls yearning to be free! Rest your engine in the Ironika lounge.  Toast to the beauty of passers-by from the comfort of our No-Snark Compliments booth.  Heat up your blood daily with Tea and Erotica.  Write a dirty hymnal to sing loud and proud to the Holy Spirit in our glorious Yurtthedral, then rise to the heavens on the Playa Cloud swing.  If you're lucky, you might even catch a glimpse of the magnificent Lady Whiskey herself when she comes home to rest after a long night on the Playa.",
        "location": {
            "string": "C & 3:45",
            "frontage": "C",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.77774041281026,
            "gps_longitude": -119.20176777519588
        },
        "location_string": "C & 3:45"
    },
    {
        "uid": "a1Xd0000001IRniEAG",
        "year": 2016,
        "name": "Speakcheasy",
        "url": "https://www.facebook.com/speakcheasy/",
        "contact_email": "gingersnapjenn@gmail.com",
        "hometown": "Northern CA and Oklahoma",
        "description": "We are an eclectic group of California and Oklahoma Burners who wanted to be the Grapes of Wrath Camp but there was copyright infringement so we went with Speakcheasy! Come and get some cheesy snack, Sangria, a Mimosa, some conversation and shade during the day. We would love for you to stop by! Figure out the camp password and get past the big burly doorman and get something fun to cherish forever. Look for our daily happy hour or brunch in the What Where When.",
        "location": {
            "string": "4:00 & C",
            "frontage": "4:00",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.777347559648916,
            "gps_longitude": -119.20329686823338
        },
        "location_string": "4:00 & C"
    },
    {
        "uid": "a1Xd0000001IVV5EAO",
        "year": 2016,
        "name": "SNaughty Naked Neti Camp",
        "hometown": "Coos Bay",
        "description": "We are a nude friendly camp offering Neti Pots to the masses, cleaning dusty nasal passages, and now poly-minded talks and meditations!",
        "location": {
            "string": "E & 3:15",
            "frontage": "E",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77791815912868,
            "gps_longitude": -119.19791375737117
        },
        "location_string": "E & 3:15"
    },
    {
        "uid": "a1Xd0000001IV4VEAW",
        "year": 2016,
        "name": "La Fortezza di Tranquilitta",
        "hometown": "San Francisco",
        "description": "La Fotrezza di Tranquillita - Vitruvian Massage. A style of bodywork, customized for every different body that comes our way",
        "location": {
            "string": "G & 5:45",
            "frontage": "G",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.77687746108339,
            "gps_longitude": -119.21614874066034
        },
        "location_string": "G & 5:45"
    },
    {
        "uid": "a1Xd0000001IFgSEAW",
        "year": 2016,
        "name": "Freedom Lounge",
        "hometown": "Winnemucca",
        "description": "Freedom Lounge is a mystical day spa for the soul. Dreams interpretations, destiny readings and healing through sound. Home of the Burning Man organic spiritual alignment and cleansing.",
        "location": {
            "string": "F & 3:15",
            "frontage": "F",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77739621183719,
            "gps_longitude": -119.19738538550564
        },
        "location_string": "F & 3:15"
    },
    {
        "uid": "a1Xd0000001IWXwEAO",
        "year": 2016,
        "name": "Camp Morning Cookie",
        "contact_email": "campmorningcookie@gmail.com",
        "hometown": "San Jose/Oakland/Berkeley",
        "description": "A congregation of misfits serving cookies and conversation on playa since 2010!\r\n\r\nWe hail from the North, South & East Bay Areas!  We got all the bays in our camp! :)",
        "location": {
            "string": "6:00 Public Plaza @ 6:15",
            "frontage": "6:00 Public Plaza",
            "intersection": "6:15",
            "intersection_type": "@",
            "gps_latitude": 40.792832848233445,
            "gps_longitude": -119.21491426366346
        },
        "location_string": "6:00 Public Plaza @ 6:15"
    },
    {
        "uid": "a1Xd0000001IEoDEAW",
        "year": 2016,
        "name": "The Burning Globe",
        "url": "http://www.facebook.com/burningglobepublic",
        "contact_email": "burningglobepublic@gmail.com",
        "hometown": "San Francisco",
        "description": "We want to bring a reimagined Globe Theatre to the Playa and fill it with people witnessing one another speak Shakespeare language with joy, passion, abandon, specificity, imagination, irreverence, humor and pathos.",
        "location": {
            "string": "H & 5:45",
            "frontage": "H",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.776355654907675,
            "gps_longitude": -119.21667735883563
        },
        "location_string": "H & 5:45"
    },
    {
        "uid": "a1Xd0000001IKXXEA4",
        "year": 2016,
        "name": "Uniclan's Merry Playgoud",
        "hometown": "Margaretville",
        "description": "Uniclan is a fantastic gypsy band of quirky characters - heckling peddlers, fortune tellers, eccentric inventors, artists, talented freaks and beauties from far-away lands, led to Black Rock City by their mysterious leader, Margaret.\r\n\r\nCome have your fortune read, experience the bass-chair, spin the Wheel of Thought, burn your cash, and meet our cult leader Margaret at our communal psychedelic supper!",
        "location": {
            "string": "2:30 & E",
            "frontage": "2:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78105582486477,
            "gps_longitude": -119.19427716487334
        },
        "location_string": "2:30 & E"
    },
    {
        "uid": "a1Xd0000001ISvGEAW",
        "year": 2016,
        "name": "VW Bus Camp",
        "url": "http://vwbuscamp.com",
        "contact_email": "campinfo@vwbuscamp.com",
        "hometown": "Tucson",
        "description": "Our 19th Burn on the Playa, VW Bus Camp will share the Vitruvian Van, your opportunity to learn about the proportions and function of the VW Bus, this light and once inexpensive, ubiquitous utility van, one of the world's only vehicles that can carry its own weight and travel over any road, repurposed here for magic. VW Bus Camp is returning with our greatest ever Leopard Lounge and Day Spa, Grateful Dyed tie dye Party, Hoop Jam, games, lectures, vehicle repair and much, much, more!",
        "location": {
            "string": "H & 3:15",
            "frontage": "H",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.776355654907675,
            "gps_longitude": -119.1963226411644
        },
        "location_string": "H & 3:15"
    },
    {
        "uid": "a1Xd0000001IVnYEAW",
        "year": 2016,
        "name": "Milk & Honey",
        "url": "http://www.milkandhoney.camp",
        "hometown": "Oakland",
        "description": "Milk + Honey is excited to offer our ninth Playa Shabbat service and dinner which draw on secular and spiritual traditions for the creative expression and collective healing of  individuals and communities. We nourish the hearts, spirits, and bodies of all who find themselves wandering in the desert!",
        "location": {
            "string": "B & 6:45",
            "frontage": "B",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.783060736985135,
            "gps_longitude": -119.2171300722949
        },
        "location_string": "B & 6:45"
    },
    {
        "uid": "a1Xd0000001IR8DEAW",
        "year": 2016,
        "name": "The Fur Village",
        "contact_email": "cindysmith9999@yahoo.com",
        "hometown": "Stockton",
        "description": "TheBootCamp by Cindy and Chris",
        "location": {
            "string": "B & 3:45",
            "frontage": "B",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.77834809836258,
            "gps_longitude": -119.20209985853667
        },
        "location_string": "B & 3:45"
    },
    {
        "uid": "a1Xd0000001IX4sEAG",
        "year": 2016,
        "name": "Salon Soleil",
        "url": "http://www.salonsoleil.org/",
        "contact_email": "salonsoleil@gmail.com",
        "hometown": "San Francisco",
        "description": "Salon Soleil is a welcoming space for personal exploration, self-expression, and interaction with other beings. We invite the Black Rock City community to visit our friendly, comfy quadruple Do-Me Domes any time, stop by for our Royal Jam De Funk dance party in honor of funk and rock royalty, Black Rock Chamber Music Festival, or enjoy one of our Healing Faires offering massage, readings, or relationship counseling.  Also, come feed your power hungry devices and fill depleted batteries at our solar charging station!",
        "location": {
            "string": "6:00 Public Plaza @ 2:45",
            "frontage": "6:00 Public Plaza",
            "intersection": "2:45",
            "intersection_type": "@",
            "gps_latitude": 40.792289864784486,
            "gps_longitude": -119.21491380853163
        },
        "location_string": "6:00 Public Plaza @ 2:45"
    },
    {
        "uid": "a1Xd0000001IUzXEAW",
        "year": 2016,
        "name": "Palm Tree Country Club",
        "contact_email": "camppalmtree@outlook.com",
        "hometown": "San Francisco",
        "description": "Relax in the comfort of lawn chairs under shady palm trees after you visit our nightly (9pm-10pm) boxed wine and string cheese bar to socialize with other high-class guests like yourself. If you're feeling energetic you can find a tee time at our challenging and memorable par-5 3-hole golf course, where you can even decorate (and keep) your own golf ball!",
        "location": {
            "string": "G & 7:15",
            "frontage": "G",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78483230749839,
            "gps_longitude": -119.22221607478929
        },
        "location_string": "G & 7:15"
    },
    {
        "uid": "a1Xd0000001IMNDEA4",
        "year": 2016,
        "name": "Golden Net, The",
        "contact_email": "thegoldennetcamp2016@gmail.com",
        "hometown": "NYC-  SEATTLE - LA - AUSTRALIA",
        "description": "Come on down to The Golden Net: Hang out in our gigantic hammock(the safety net), escape the heat in our safety tree, and connect with yourself in our temple. We have an almost perfect ratio of daily themes, activities, iced coffee & tea: all we are missing is you! Yeah you! Come make us golden.",
        "location": {
            "string": "7:00 & B",
            "frontage": "7:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.78414410068907,
            "gps_longitude": -119.21761649320165
        },
        "location_string": "7:00 & B"
    },
    {
        "uid": "a1Xd0000001IOqREAW",
        "year": 2016,
        "name": "Paradise Motel",
        "url": "http://desertparadise.org",
        "contact_email": "contact@desertparadise.org",
        "hometown": "San Francisco / Los Angeles",
        "description": "Come experience the American Dream that is Paradise Motel, the most garish of roadside motels, yet the best of the \"no-tel\" genre; located in the heart of the Gayborhood and established in 2008 with a diverse group of folks hailing from our Default World locales of SF and LA.  We welcome weary wanderers to stop in for a snow cone and enjoy some progressive beats while you lounge in the shade by the \"pool\" and create your own Vitruvian Person drawing every afternoon; awaken your spirit with sunrise Vinyasa Yoga every morning; come to our Tuesday special event: \"DaVinci's Twerk-Shop, a Sunset Masquerade\" and enjoy our evening bonfire featuring \"Cocoa and Cabernet Cabaret\".  Visit our Concierge Desk to discover the local attractions and to sign up for guided tours.",
        "location": {
            "string": "B & 7:45",
            "frontage": "B",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78753266605781,
            "gps_longitude": -119.21791137024913
        },
        "location_string": "B & 7:45"
    },
    {
        "uid": "a1Xd0000001IXHhEAO",
        "year": 2016,
        "name": "BRC3PO (3:00 Post Office)",
        "url": "https://www.facebook.com/BRC3PO",
        "hometown": "Sonoma County and Los Angeles",
        "description": "Set in a giant rural postbox, the Black Rock City 3:00 Post Office (BRC3PO) provides postal services up to 24 hours per day that include authentic one-on-one interactions that can range from the supremely silly to the sublime. You never know what will happen next at BRC3PO -- YOU could be what will happen next at BRC3PO, if you pay us a visit!",
        "location": {
            "string": "3:00 Public Plaza @ 11:45",
            "frontage": "3:00 Public Plaza",
            "intersection": "11:45",
            "intersection_type": "@",
            "gps_latitude": 40.79235302975767,
            "gps_longitude": -119.21428040345448
        },
        "location_string": "3:00 Public Plaza @ 11:45"
    },
    {
        "uid": "a1Xd0000001ISN4EAO",
        "year": 2016,
        "name": "Backfire",
        "hometown": "San Francisco",
        "description": "An community of inspired Artists and Makers sharing the Deaf sensory experience with the entire community!",
        "location": {
            "string": "C & 7:15",
            "frontage": "C",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78517166496261,
            "gps_longitude": -119.21877061804274
        },
        "location_string": "C & 7:15"
    },
    {
        "uid": "a1Xd0000001IOXNEA4",
        "year": 2016,
        "name": "The Other Camp",
        "hometown": "San Fransisco, Boise and NYC",
        "description": "The Other Camp",
        "location": {
            "string": "4:00 & D",
            "frontage": "4:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.776712297351594,
            "gps_longitude": -119.20307211983851
        },
        "location_string": "4:00 & D"
    },
    {
        "uid": "a1Xd0000001IViTEAW",
        "year": 2016,
        "name": "CAMP THREAT",
        "hometown": "Daly City, California",
        "description": "CAMP THREAT; The warning, not the example. Nothing fancy.",
        "location": {
            "string": "G & 6:15",
            "frontage": "G",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.21907490302245
        },
        "location_string": "G & 6:15"
    },
    {
        "uid": "a1Xd0000001IUpwEAG",
        "year": 2016,
        "name": "Northern Lights Nordic Camp",
        "hometown": "Stockholm, Malmö, Göteborg, Oslo, Copenhagen, Helsinki",
        "description": "Pagan Midsummer will breath new life into a deserted sea. Join us for fika, snaps and body paint around the ritualistic midsummer pole and dance until your body is filled with ancient energy.",
        "location": {
            "string": "F & 3:15",
            "frontage": "F",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77739621183719,
            "gps_longitude": -119.19738538550564
        },
        "location_string": "F & 3:15"
    },
    {
        "uid": "a1Xd0000001IQeoEAG",
        "year": 2016,
        "name": "Burning Man Bike Course",
        "url": "https://www.facebook.com/Bike-Course-220060528027398",
        "contact_email": "bman@ackmedia.com",
        "hometown": "Truckee/Reno",
        "description": "Come ride the many exciting, fun and challenging features at the Burning Man Bike Course! We'll have a rhythm course, teeter totters, bridges, tunnels and boardwalks for riders of all abilities!",
        "location": {
            "string": "3:00 & D",
            "frontage": "3:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.77930776797406,
            "gps_longitude": -119.19713449128632
        },
        "location_string": "3:00 & D"
    },
    {
        "uid": "a1Xd0000001IXACEA4",
        "year": 2016,
        "name": "Vaude VIlle",
        "url": "http://www.facebook.com/FriendziedSerenity",
        "contact_email": "friendziedserenity@gmail.com",
        "hometown": "Vancouver/Louisville",
        "description": "A Chill Artsy Village in the Suburbs\r\nCome visit Friendzied Serenity, Front Porch Sitters and the GILF in Vaude Ville, relax in the shade, participate in one of our many events and try one of the special \"Kiwi\" drinks away from the hustle & bustle of the Esplanade. In addition to minor bike repairs, we will help you pimp your bike seat! We will have foam, fabric and accessories to help you make your bike seat more comfortable.",
        "location": {
            "string": "I & 7:45",
            "frontage": "I",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78813699883062,
            "gps_longitude": -119.22393925217301
        },
        "location_string": "I & 7:45"
    },
    {
        "uid": "a1Xd0000001IBUgEAO",
        "year": 2016,
        "name": "Tiki Bar & Hammocks Theme Camp",
        "contact_email": "kendrick_peter@yahoo.ca",
        "hometown": "Reno",
        "description": "Tiki Bar Hammock Camp - come visit neighbors and fellow burners, enjoy a fresh cool island drink and swing in our hammocks with us.",
        "location": {
            "string": "3:00 & J",
            "frontage": "3:00",
            "intersection": "J",
            "intersection_type": "&",
            "gps_latitude": 40.77651717407934,
            "gps_longitude": -119.19345024919038
        },
        "location_string": "3:00 & J"
    },
    {
        "uid": "a1Xd0000001ISs2EAG",
        "year": 2016,
        "name": "CampDIY",
        "url": "http://www.campdiy.com",
        "contact_email": "kstratton575@gmail.com",
        "hometown": "Silver City",
        "description": "CampDIY is an assemblage of thinkers, tinkers, makers and dreamers.  We welcome all visitors particularly those with a preference to self reliance and self sufficiency.",
        "location": {
            "string": "H & 5:45",
            "frontage": "H",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.776355654907675,
            "gps_longitude": -119.21667735883563
        },
        "location_string": "H & 5:45"
    },
    {
        "uid": "a1Xd0000001IXEsEAO",
        "year": 2016,
        "name": "Playa Glass",
        "url": "http://capeandislands.org/post/breaking-down-dust",
        "contact_email": "glass@adaptiveexperience.com",
        "hometown": "New York",
        "description": "Ever wonder what's in playa dust?  The special formula is just right for some solar glass making.  Grab a pair of our welding goggles, and we'll set you up at a Fresnel lens station where you'll raise the temperature of the dust to over 1000F and melt it in to black glass.  Turn it in to a wearable pendant at the craft table, and you'll have an easier-than-a-bag-of-dust way to take the playa back to the default world.\r\nEver wonder what's in playa dust?  The special formula is just right for some solar glass making.  Grab a pair of our welding goggles, and we'll set you up at a Fresnel lens station where you'll raise the temperature of the dust to over 1000F and melt it in to black glass.  Turn it in to a wearable pendant at the craft table, and you'll have an easier-than-a-bag-of-dust way to take the playa back to the default world.",
        "location": {
            "string": "G & 7:15",
            "frontage": "G",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78483230749839,
            "gps_longitude": -119.22221607478929
        },
        "location_string": "G & 7:15"
    },
    {
        "uid": "a1Xd0000001ISKtEAO",
        "year": 2016,
        "name": "Couch Burners",
        "url": "https://www.facebook.com/groups/1522655671378629/",
        "contact_email": "couchburnerscamp@gmail.com",
        "hometown": "Seattle",
        "description": "CouchBurners, a cross section of CouchSurfers and BRC inhabitants, welcome weary, wild, and wondrous travelers alike to chat, relax, perform, interact, and play some international games and sports. Come learn tips and suggestions on successful international travel, converse in your original language, relax in our lounge and bar, watch or play some bocce,vollyeball, or giant pool. Or come at night, get some chips in exchange for drinking at our bar, and play Poker, Slots, Roulette or Blackjack at the CouchBurners Casino.",
        "location": {
            "string": "6:00 & J",
            "frontage": "6:00",
            "intersection": "J",
            "intersection_type": "&",
            "gps_latitude": 40.77651717407934,
            "gps_longitude": -119.21954975080966
        },
        "location_string": "6:00 & J"
    },
    {
        "uid": "a1Xd0000001IFIwEAO",
        "year": 2016,
        "name": "Curiouser & Curiouser",
        "hometown": "San Luis Obipso",
        "description": "This curio of a circus camp can convoke a craving so completely curious, crowds can't contain acclamation . Come play with us on our aerial rig, or relax with us in our Rabbit Hole.",
        "location": {
            "string": "3:00 & D",
            "frontage": "3:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.77930776797406,
            "gps_longitude": -119.19713449128632
        },
        "location_string": "3:00 & D"
    },
    {
        "uid": "a1Xd0000001IIhKEAW",
        "year": 2016,
        "name": "SIZE DOESN'T MATTER",
        "contact_email": "rebecca@fatbug.com",
        "hometown": "Reno",
        "description": "Size Doesn't Matter-  a small camp for ALL.",
        "location": {
            "string": "B & 3:45",
            "frontage": "B",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.77834809836258,
            "gps_longitude": -119.20209985853667
        },
        "location_string": "B & 3:45"
    },
    {
        "uid": "a1Xd0000001IRMDEA4",
        "year": 2016,
        "name": "BELLIGERENT GAP",
        "hometown": "Our campmates hail primarily from: San Francisco, Seattle, Louisville, Tolendo, Toronto, Vegas and Southern California",
        "description": "THE BELLIGERENT GAP is a Western-themed, homebrew camp dispensing cold beer daily (from high noon to whenever we want), served up by the most lovable assholes this side of the 6 o'clock suburbs.",
        "location": {
            "string": "G & 5:45",
            "frontage": "G",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.77687746108339,
            "gps_longitude": -119.21614874066034
        },
        "location_string": "G & 5:45"
    },
    {
        "uid": "a1Xd0000001IOABEA4",
        "year": 2016,
        "name": "Dusty Goats",
        "hometown": "Vail",
        "description": "Dusty Goats- Come and get f***ked up like a goat with dancing in our dome and showing us your goat golfing skills.  Stick around and recover with our yoga sessions, massage and rest your hooves under our huge shade structure. Come by and have a goat-tastic time!",
        "location": {
            "string": "G & 9:45",
            "frontage": "G",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.797488604582114,
            "gps_longitude": -119.21256733476802
        },
        "location_string": "G & 9:45"
    },
    {
        "uid": "a1Xd0000001IVv8EAG",
        "year": 2016,
        "name": "Cult of the Magic Lady",
        "url": "https://www.facebook.com/CultOfTheMagicLady/",
        "contact_email": "nresonbrown@gmail.com",
        "hometown": "Alameda",
        "description": "Enjoy jelloshot abortions, deep fried tofu, mylar shielded hammocks, and luxurious hang out spaces in Cult of the Magic Lady's promenade of amusements!",
        "location": {
            "string": "B & 6:45",
            "frontage": "B",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.783060736985135,
            "gps_longitude": -119.2171300722949
        },
        "location_string": "B & 6:45"
    },
    {
        "uid": "a1Xd0000001IIlbEAG",
        "year": 2016,
        "name": "New York Dangerous",
        "url": "https://www.facebook.com/groups/NYDangerous/",
        "contact_email": "bringheat@aol.com",
        "hometown": "New York",
        "description": "Our camp specializes in things of which your mother would not approve!\r\n\r\nTalking To Strangers - Daily \"TED Talk\"-style lectures from 12-2 every day in our communal space.\r\nStrangers With Candy - a free 24-hour unwrapped hard candy vending machine for passersby.\r\nPlaying With Fire - use our magnifying glasses and the sun's rays to burn designs onto balsa-wood necklace pendants.\r\n\"You'll Put Your Eye Out!\" Shooting Gallery - plastic bows and foam arrows allow participants to shoot hanging targets and win NYD leather necklaces!\r\nRunning With Scissors - our annual huge team relay race on Wed at 3pm, exactly what it sounds like. Winners get ice cream!\r\nDangerous Liaisons - an oversized cuddle yurt filled with pillows, stuffed animals, air mattresses, and a power charging station, open 24/7 as a chill space, a retreat from the noise and the dust, and maybe some frisky business.  Whatever happens in the DL, stays on the DL.",
        "location": {
            "string": "6:30 & G",
            "frontage": "6:30",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.780397991108615,
            "gps_longitude": -119.22022704812237
        },
        "location_string": "6:30 & G"
    },
    {
        "uid": "a1Xd0000001IX1FEAW",
        "year": 2016,
        "name": "Shady Waffle",
        "url": "http://shadywaffle.org/",
        "contact_email": "info@shadywaffle.org",
        "hometown": "San Francisco",
        "description": "Shady Waffle is a full-service breakfast restaurant in a brilliantly colored elliptical dome. Our dome is a well known landmark, a machine that converts cranky hippies into happy hippies. Come eat, cool off, relax, and make a stranger even stranger.",
        "location": {
            "string": "7:30 Plaza @ 5:30",
            "frontage": "7:30 Plaza",
            "intersection": "5:30",
            "intersection_type": "@",
            "gps_latitude": 40.77406672632104,
            "gps_longitude": -119.20638305204996
        },
        "location_string": "7:30 Plaza @ 5:30"
    },
    {
        "uid": "a1Xd0000001IGU8EAO",
        "year": 2016,
        "name": "Battle Born Burners",
        "hometown": "Carson City",
        "description": "Battle Born Burner Bar Come hang out and enjoy a cool drink with us and experiance some \"Nevadatude\".  Home means Nevada on the Playa!",
        "location": {
            "string": "H & 6:15",
            "frontage": "H",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77869228660995,
            "gps_longitude": -119.21976385884787
        },
        "location_string": "H & 6:15"
    },
    {
        "uid": "a1Xd0000001IO9DEAW",
        "year": 2016,
        "name": "Playground - Perky Parts",
        "url": "https://www.facebook.com/PlayGroundExperience/?fref=ts",
        "hometown": "Melbourne",
        "location": {
            "string": "2:00 & D",
            "frontage": "2:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.78380349492602,
            "gps_longitude": -119.19370561116553
        },
        "location_string": "2:00 & D"
    },
    {
        "uid": "a1Xd0000001IWYVEA4",
        "year": 2016,
        "name": "AquaZone Healing Oasis Water Bar",
        "url": "http://smartloftstudio.com/aquazone/",
        "contact_email": "aquazone-2016@usa.net",
        "hometown": "Berkeley",
        "description": "Come witness the magic of Positive Intention through the simple act of Drinking Love Infused Water, revel in the heft of a replenished water bottle at our Self-serve Water Buffet, marvel at the healing powers of our Reiki Masters, succumb to the gentle ministrations of our Massage Magicians, and recharge your Cell Phone Addiction through the Power and Mystery of the Very Sun Above! The magic happens when YOU show up.",
        "location": {
            "string": "3:00 & E",
            "frontage": "3:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77884267712845,
            "gps_longitude": -119.19652042944098
        },
        "location_string": "3:00 & E"
    },
    {
        "uid": "a1Xd0000001IXGPEA4",
        "year": 2016,
        "name": "MindShark",
        "url": "https://www.facebook.com/Mindshark/",
        "hometown": "Burlington",
        "description": "MindShark is a community of neuroscientists, engineers, and artists who have pledged their crotches and cerebral cortices to stoke the eternal flame that blazes at the core of every individual, friend, and stranger. We all come to Burning Man to explore our inner selves; let MindShark guide your awakening with gifts of science, fire, and light. Enjoy the coldest beer on the playa at our bar, watch hippies burn on our interactive fire displays, and blow your mind(s) under our amazing neural network light shows.",
        "location": {
            "string": "3:30 & C",
            "frontage": "3:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.77828367843735,
            "gps_longitude": -119.20031193739376
        },
        "location_string": "3:30 & C"
    },
    {
        "uid": "a1Xd0000001IMUsEAO",
        "year": 2016,
        "name": "Apollo One",
        "url": "http://www.facebook.com/apollo.oneBM",
        "contact_email": "greg.moonlight@gmail.com",
        "hometown": "Bozeman",
        "description": "Apollo One is striving to take you to the Moon once again! Specializing in the bass heaviest forms of aural pleasures, come dance the night away or sit back with a drink as the bass consumes you.",
        "location": {
            "string": "2:00 & H",
            "frontage": "2:00",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.783122210492735,
            "gps_longitude": -119.19034987153162
        },
        "location_string": "2:00 & H"
    },
    {
        "uid": "a1Xd0000001IIh5EAG",
        "year": 2016,
        "name": "Planned Playahood",
        "url": "http://debocceri.com",
        "contact_email": "plannedplayahood@gmail.com",
        "hometown": "San Francisco, Seattle, Vancouver, Los Angeles, Salt Lake City",
        "description": "We are Planned Playahood! We offer pregnancy testing, fornication counseling, bicycle repair, a playground and other \"second aid\" services to UN-FUCK YOUR BURN. Let's face it, sometimes your Burn gets fucked and we are here to un-fuck it for you.",
        "location": {
            "string": "7:00 & B",
            "frontage": "7:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.78414410068907,
            "gps_longitude": -119.21761649320165
        },
        "location_string": "7:00 & B"
    },
    {
        "uid": "a1Xd0000001ISGrEAO",
        "year": 2016,
        "name": "bEEcHARGE!!!",
        "url": "http://www.beecharge.com",
        "contact_email": "klausthepd@gmail.com",
        "hometown": "San Francisco",
        "description": "The bEES are cHARGING!!!  We wear the bLACK and yELLOW.  In all kinds of awesome ways.  We bUZZZZZZZZ.   We sWARM!  Once again we will sWARM the mAN! Wednesday at sixish. Before that, at 2, YOU bEE up and come to our camp for lABEETOS:  Honey kISSED Mojitos.  yES and wAGGLE-dANCE oFF!!!  wE lOVE newbEES!!!!  Think aHEAD:  bLACK and yELLOW...  Come bEE with us, find a new way of bEEING:  bEEUTIFUL bEEING!!!! bUZZZZZZZZZZZZZ!!!!!",
        "location": {
            "string": "C & 7:45",
            "frontage": "C",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78761815118928,
            "gps_longitude": -119.21877261481393
        },
        "location_string": "C & 7:45"
    },
    {
        "uid": "a1Xd0000001ISs7EAG",
        "year": 2016,
        "name": "Yabba Dabba Do Me",
        "hometown": "South Reno",
        "description": "Fun times on a unique play apparatus. Every action has a reaction, every motion has an emotion.",
        "location": {
            "string": "3:00 & I",
            "frontage": "3:00",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.77698228119831,
            "gps_longitude": -119.19406426804439
        },
        "location_string": "3:00 & I"
    },
    {
        "uid": "a1Xd0000001IJYJEA4",
        "year": 2016,
        "name": "S.A.T.B. (Singers At The Burn)",
        "contact_email": "madis_service@yahoo.com",
        "hometown": "OAKLAND",
        "description": "Connect with the Something Other often overlooked at Burning Man. Your Playa Choir welcomes all Burners to come and participate in a fun 4-part harmony of classic sacred and secular songs. Rehearsals are Tuesday through Saturday 11:00 a.m. to 1:00 p.m. To listen, please join us for the Sunday SUNRISE Performance at the Temple, or the Full Choir non-denominational, non-religious but entirely welcoming, spiritual and moving \"service\" at 11:00 a.m. in our Dome. Singers of all skill levels, and persuasions are welcome :) Also looking for Musicians! Contact madis_service@yahoo.com for more information or swing by our camp on the playa!",
        "location": {
            "string": "6:00 Public Plaza @ 7:30",
            "frontage": "6:00 Public Plaza",
            "intersection": "7:30",
            "intersection_type": "@",
            "gps_latitude": 40.792904020985894,
            "gps_longitude": -119.2146389114525
        },
        "location_string": "6:00 Public Plaza @ 7:30"
    },
    {
        "uid": "a1Xd0000001IDKPEA4",
        "year": 2016,
        "name": "Cosmicopia & The Spoke Collective",
        "contact_email": "cosmicopia2016@gmail.com",
        "hometown": "San Francisco",
        "description": "Cosmicopia and The Spoke Collective are a group of graduate students and professors from the San Francisco Bay Area and the UK who have been a theme camp since 2010, offering archetypal astrology readings, talks and workshops on philosophy, cosmology, and the healing arts. The Spoke Collective offers workshops, pop-up auditions, theatrical and interactive performances on our camp stage and out on the playa.",
        "location": {
            "string": "H & 5:45",
            "frontage": "H",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.776355654907675,
            "gps_longitude": -119.21667735883563
        },
        "location_string": "H & 5:45"
    },
    {
        "uid": "a1Xd0000001IVsiEAG",
        "year": 2016,
        "name": "Shamandome Camp",
        "url": "http://shamandome.org",
        "contact_email": "barnabyruhe@gmail.com",
        "hometown": "New York City",
        "description": "SHAMANDOME CAMP birthed out of Heebeegeebee Healers Camp in 2006.  40 workshops, healing 1200 burners by core shamanism drumming journies. Our Find Your Power Animal workshop twice daily across the week  trances to DIRECT ACCESS TO SOURCE. and Wake Up the Shaman in You. We address sustainability, individual crises, harem management, soulretrival, extraction of neg energies, by CHANGING YOUR DREAM. We get you back on playa reopened to receive the  epiphanies you flew in for.  Shamandome.org",
        "location": {
            "string": "G & 6:45",
            "frontage": "G",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78180595810437,
            "gps_longitude": -119.22114438293958
        },
        "location_string": "G & 6:45"
    },
    {
        "uid": "a1Xd0000001IORFEA4",
        "year": 2016,
        "name": "Destiny Lounge",
        "url": "http://www.facebook.com/groups/destinylounge",
        "contact_email": "bigbludog1@gmail.com",
        "hometown": "Pasadena",
        "description": "Destiny Lounge returns to challenge you with Rock Yer Balls, our large two player game, give you Free Blowjobs on a warm afternoon (all ages and genders welcome), and completely confuse you with the Vortex of Destiny! Enjoy our comfy lounge, completely surrounded by amazing 3D artwork!",
        "location": {
            "string": "F & 3:15",
            "frontage": "F",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77739621183719,
            "gps_longitude": -119.19738538550564
        },
        "location_string": "F & 3:15"
    },
    {
        "uid": "a1Xd0000001IXSoEAO",
        "year": 2016,
        "name": "Iglooniverse",
        "hometown": "San Fran and LA",
        "description": "The Iglooniverse is a rich lit-up world of color and art!  Come enjoy and experience everything the Iglooniverse has to offer!",
        "location": {
            "string": "4:30 & I",
            "frontage": "4:30",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.77308227839284,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & I"
    },
    {
        "uid": "a1Xd0000001IQhxEAG",
        "year": 2016,
        "name": "Merkabah",
        "url": "http://campmerkabah.com/",
        "hometown": "New York",
        "description": "Camp Merkabah is a tribe committed to curate transformational experiences on and off the Playa.  All that we do as a community is in service to the expansion of each and every human at every moment by means of nurturing love, compassion and peace. The modalities of our tribal members include workshops on: meditation, energy medicine, ceremony, sacred dance, sound healing, yoga; talks on: the human body, biological systems, stewardship, health, wellness, movement, consciousness, and healing through food.",
        "location": {
            "string": "4:00 & G",
            "frontage": "4:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.77480650784362,
            "gps_longitude": -119.20239790044295
        },
        "location_string": "4:00 & G"
    },
    {
        "uid": "a1Xd0000001IX4TEAW",
        "year": 2016,
        "name": "Monkey Pirate Pirate Monkeys",
        "hometown": "Boise",
        "description": "All ye banana swashbucklers are again welcome to share in the plentiful bacon, beats, brews and booty brought by the Monkey Pirate Pirate Monkeys.  Plop ye tired bones down with a cocktail and enjoy the cool ocean breeze from our swamp coolers as you plot your next plundering adventure.  At night our giant glowing double pyramids will remind you exactly where you buried your treasure.  \"Stop with the rhymes, I'm not fakin!\"  \"Anybody want another piece of Bacon?\"",
        "location": {
            "string": "D & 4:45",
            "frontage": "D",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.776456262296946,
            "gps_longitude": -119.20822712642001
        },
        "location_string": "D & 4:45"
    },
    {
        "uid": "a1Xd0000001IWD8EAO",
        "year": 2016,
        "name": "Dessert Dwellers",
        "url": "https://www.facebook.com/DessertDwellers",
        "hometown": "Portland",
        "description": "Dessert Dwellers is a place to come enjoy the sweeter things in life: gourmet desserts by day and decadent drinks by night. Enjoy your dessert inside a cozy cupcake!",
        "location": {
            "string": "B & 4:15",
            "frontage": "B",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77776035808324,
            "gps_longitude": -119.20499938179593
        },
        "location_string": "B & 4:15"
    },
    {
        "uid": "a1Xd0000001IKoHEAW",
        "year": 2016,
        "name": "Conscious Dreamers",
        "description": "Conscious Dreamers Camp welcomes you! Please stop by and have your fortune told by Mojo Hand, if you dare. Or, catch a ride on the Mystic Dream Circus and make a new friend.",
        "location": {
            "string": "G & 5:15",
            "frontage": "G",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77531107774246,
            "gps_longitude": -119.21256530891797
        },
        "location_string": "G & 5:15"
    },
    {
        "uid": "a1Xd0000001IWOLEA4",
        "year": 2016,
        "name": "Elliot's Bicycle Service",
        "url": "http://www.elliotsbikes.org",
        "contact_email": "elliotsbikes@outlook.com",
        "hometown": "Clearlake",
        "description": "Elliot's Bicycle Service & Piano Bar offers full service bicycle repair daily Noon to 6 p.m., and Do-It-Yourself repair 24/8 -- please bring your own parts if possible. We also offer a variety of Healing Arts for the bicycles' owners, mostly Noon to 6 also, and you are invited to play our piano any time you like.",
        "location": {
            "string": "4:30 Plaza @ 8:00",
            "frontage": "4:30 Plaza",
            "intersection": "8:00",
            "intersection_type": "@",
            "gps_latitude": 40.77422617138798,
            "gps_longitude": -119.2068915743526
        },
        "location_string": "4:30 Plaza @ 8:00"
    },
    {
        "uid": "a1Xd0000001IBNQEA4",
        "year": 2016,
        "name": "Drankin’ Dragons",
        "location": {
            "string": "4:30 & K",
            "frontage": "4:30",
            "intersection": "K",
            "intersection_type": "&",
            "gps_latitude": 40.77176694786373,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & K"
    },
    {
        "uid": "a1Xd0000001IOwhEAG",
        "year": 2016,
        "name": "Cabana Club",
        "url": "https://www.facebook.com/BlackRockCabanas/",
        "contact_email": "blackrockcabanas@gmail.com",
        "hometown": "San Francisco",
        "description": "Come and enjoy The Favorite Vacation Destination for the hard working citizens of Black Rock City!  The Cabana Club is an oasis of hospitality and friendship. We serve up a refreshing array of nosh and cocktails for your Afternoon Delight daily.",
        "location": {
            "string": "4:30 & A",
            "frontage": "4:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.77834360050925,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & A"
    },
    {
        "uid": "a1Xd0000001IXLyEAO",
        "year": 2016,
        "name": "Mystikal Misfits / Naarsfortown",
        "url": "http://mystikalmisfits.com",
        "contact_email": "contact@mystikalmisfits.com",
        "hometown": "Los Angeles",
        "description": "Shame exorcism with a touch of derp.  Also, butt rubs.",
        "location": {
            "string": "4:30 & B",
            "frontage": "4:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.7776859352447,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & B"
    },
    {
        "uid": "a1Xd0000001IWX8EAO",
        "year": 2016,
        "name": "Porta Party",
        "url": "www.campportaparty.com",
        "contact_email": "portaparty@kaweh.com",
        "hometown": "Carmel",
        "description": "Porta Party",
        "location": {
            "string": "D & 9:45",
            "frontage": "D",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79566449547131,
            "gps_longitude": -119.21157386741038
        },
        "location_string": "D & 9:45"
    },
    {
        "uid": "a1Xd0000001IXKbEAO",
        "year": 2016,
        "name": "Time Ninja Syndicate",
        "hometown": "Portland",
        "description": "The nexus of time has opened and various heroes from various dimensions have poured through.",
        "location": {
            "string": "2:30 & D",
            "frontage": "2:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.781384734418374,
            "gps_longitude": -119.1950292825442
        },
        "location_string": "2:30 & D"
    },
    {
        "uid": "a1Xd0000001IXmtEAG",
        "year": 2016,
        "name": "Birds Nest Village",
        "contact_email": "dimonds@campminderaser.com",
        "hometown": "SF",
        "description": "Birds Nest Village, Home to Black Bird & Draco Rojo art cars. Come lounge, play, clear your mind and join in on the mischief.",
        "location": {
            "string": "10:00 & I",
            "frontage": "10:00",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.7992638417704,
            "gps_longitude": -119.21105332133216
        },
        "location_string": "10:00 & I"
    },
    {
        "uid": "a1Xd0000001IQfhEAG",
        "year": 2016,
        "name": "Run Free Camp",
        "url": "http://www.runfreecamp.com",
        "contact_email": "kickstand@phoenixreborn.com",
        "hometown": "San Francisco / Los Angeles and Cities Across US and Abroad",
        "description": "Run Free is a clean and sober Burning Man camp for folks whose common goal is enlargement of spiritual life through new adventures in being human and living life to the fullest. Run Free: One incredibly fucking amazing day at a time.",
        "location": {
            "string": "B & 7:15",
            "frontage": "B",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78525786330597,
            "gps_longitude": -119.21790952809974
        },
        "location_string": "B & 7:15"
    },
    {
        "uid": "a1Xd0000001IXGKEA4",
        "year": 2016,
        "name": "Pollen Nation",
        "hometown": "Denver",
        "description": "Buzz buzz and welcome to Pollen Nation, hailing from Denver Colorado. Come by and check out our Buzz Bar, sculpture garden, fire performance, and interactive games.",
        "location": {
            "string": "7:00 & G",
            "frontage": "7:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.78329254071427,
            "gps_longitude": -119.22181120001417
        },
        "location_string": "7:00 & G"
    },
    {
        "uid": "a1Xd0000001IWH0EAO",
        "year": 2016,
        "name": "STREET LIFE",
        "url": "https://www.facebook.com/Street-Life-Hiphop-Comes-to-the-Playa-152087438167309/?fref=nf",
        "contact_email": "streetlifecamp@gmail.com",
        "hometown": "New York",
        "location": {
            "string": "C & 8:45",
            "frontage": "C",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.792100831597146,
            "gps_longitude": -119.21632445997854
        },
        "location_string": "C & 8:45"
    },
    {
        "uid": "a1Xd0000001IOsDEAW",
        "year": 2016,
        "name": "DuckPond",
        "url": "https://www.facebook.com/groups/DuckPondBRC/",
        "contact_email": "duckpondcrew@gmail.com",
        "hometown": "San Francisco",
        "location": {
            "string": "9:00 & I",
            "frontage": "9:00",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.79581638344092,
            "gps_longitude": -119.21893925928977
        },
        "location_string": "9:00 & I"
    },
    {
        "uid": "a1Xd0000001IWKYEA4",
        "year": 2016,
        "name": "Sparkle Camels Costume Bazaar",
        "hometown": "San Francisco",
        "description": "Need to update your playa look?  Come by Sparkle Camels Costume Bazaar for unique items and festive photos in our studio.",
        "location": {
            "string": "G & 8:45",
            "frontage": "G",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79370590997052,
            "gps_longitude": -119.21907767038495
        },
        "location_string": "G & 8:45"
    },
    {
        "uid": "a1Xd0000001IQjKEAW",
        "year": 2016,
        "name": "Asparagus Forest",
        "url": "https://www.facebook.com/asparagusforest/",
        "contact_email": "info@asparagusforest.com",
        "hometown": "Bay Area",
        "description": "Our camp is a calm shelter from the rigours of the burn. We aim to provide a chill place where people can rest and socialize between adventures.",
        "location": {
            "string": "D & 9:15",
            "frontage": "D",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.794353648046624,
            "gps_longitude": -119.21456958248888
        },
        "location_string": "D & 9:15"
    },
    {
        "uid": "a1Xd0000001IXCXEA4",
        "year": 2016,
        "name": "Gymnasium",
        "url": "https://activenaturists.net/gymnasium-camp",
        "description": "We want to recreate the atmosphere of the gymnasium in its original, Ancient Greek meaning, as a facility for training and competition in public games, as well a place for socializing and engaging in intellectual pursuits. The term originates from the word [gymnós] meaning \"naked\", because historically in Ancient Greece one exercised naked, and we would like to revive this aspect too, as we think that by doing athletic and fun activities naked, participants will experience bonding aspect of such events stronger.",
        "location": {
            "string": "D & 8:15",
            "frontage": "D",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79023278937556,
            "gps_longitude": -119.21874102697954
        },
        "location_string": "D & 8:15"
    },
    {
        "uid": "a1Xd0000001IWKOEA4",
        "year": 2016,
        "name": "Playa Court",
        "hometown": "Long Beach",
        "description": "Playa Court is back in session!  Come argue, laugh, judge and imbibe with us.  Bring your baggage with you!  Playa Court adult lemonade for all 21 and over burners in attendance.  Court will be in session from about 12pm-2pm M-F!!",
        "location": {
            "string": "H & 8:15",
            "frontage": "H",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.791243763698084,
            "gps_longitude": -119.22194901027675
        },
        "location_string": "H & 8:15"
    },
    {
        "uid": "a1Xd0000001IVmaEAG",
        "year": 2016,
        "name": "Salón at the Oasis",
        "contact_email": "lea@goodsellgroup.com",
        "hometown": "Palm Springs",
        "description": "Visit our Renaissance Salón and expand your knowledge of yourself and the world by checking out a human from our library M/W 5-7pm or volunteer yourself as a library acquisition; and/or channel your inner orator/actor by participating in Literoke Tues. 5-7pm. Wine will be served during all scheduled activities.",
        "location": {
            "string": "D & 8:15",
            "frontage": "D",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79023278937556,
            "gps_longitude": -119.21874102697954
        },
        "location_string": "D & 8:15"
    },
    {
        "uid": "a1Xd0000001IWKiEAO",
        "year": 2016,
        "name": "Cat's Meow Neon Bar",
        "url": "https://www.facebook.com/groups/CatsMeowNeonBar/",
        "contact_email": "catsmeowcamp@gmail.com",
        "hometown": "Rocklin, CA",
        "description": "The Cat's Meow Neon Bar is a Burning Man theme camp that is meant to make you cozy like a kitty!! Bar, lounge, blacklights, pillows, hammocks, hoops, swing set ~ come play with us!",
        "location": {
            "string": "9:00 & E",
            "frontage": "9:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.793956462957034,
            "gps_longitude": -119.21648184200953
        },
        "location_string": "9:00 & E"
    },
    {
        "uid": "a1Xd0000001IX9OEAW",
        "year": 2016,
        "name": "Cirque Gitane",
        "contact_email": "lauren@cirquegitane.com",
        "hometown": "West Hollywood",
        "description": "Cirque Gitane is an intergalactic, nomadic traveling circus comprised of dreamers from all over the globe who create for a living and who support the creative arts. Visit our air conditioned 19th century circus tent for a cocktail and live musical performance, or take in an aerial view of the Playa with a ride on our DaVinci Air Screw.",
        "location": {
            "string": "8:30 & D",
            "frontage": "8:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.7914141295786,
            "gps_longitude": -119.21797244993033
        },
        "location_string": "8:30 & D"
    },
    {
        "uid": "a1Xd0000001INLWEA4",
        "year": 2016,
        "name": "Camp Permagrin",
        "url": "https://www.facebook.com/groups/326584260786536/",
        "hometown": "Bend",
        "description": "Do you have a smile? Do you like to smile? Then come to camp Permagrin and get a permanent one. Our eclectic group of friends will leave you wanting more.",
        "location": {
            "string": "E & 8:15",
            "frontage": "E",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79048412688384,
            "gps_longitude": -119.21954373981305
        },
        "location_string": "E & 8:15"
    },
    {
        "uid": "a1Xd0000001IRqSEAW",
        "year": 2016,
        "name": "Pairadice@The End of The Universe",
        "url": "https://www.facebook.com/goodtimesforsure/",
        "hometown": "Smartsville",
        "description": "Come relax at the bamboo bar or party in the fish tank. It's paradise at the end of this universe!",
        "location": {
            "string": "9:00 & K",
            "frontage": "9:00",
            "intersection": "K",
            "intersection_type": "&",
            "gps_latitude": 40.79674632413234,
            "gps_longitude": -119.22016801956524
        },
        "location_string": "9:00 & K"
    },
    {
        "uid": "a1Xd0000001IWC0EAO",
        "year": 2016,
        "name": "DESERT PEARL CANTINA",
        "hometown": "Oakland, CA",
        "description": "Homemade, handcrafted, upcycled and repurposed. Our camp style, architecture and activities are informed by some core values: Keep it simple|Keep it clean|Form AND function|Monochromatic|Natural fibers|High quality artifacts in all mediums – music, sculpture, fashion, food, connection|Low tech efficiency|Smart solutions to desert living|Strip poker.",
        "location": {
            "string": "H & 6:15",
            "frontage": "H",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77869228660995,
            "gps_longitude": -119.21976385884787
        },
        "location_string": "H & 6:15"
    },
    {
        "uid": "a1Xd0000001IOs8EAG",
        "year": 2016,
        "name": "Portside Locos",
        "contact_email": "lightwave198622@yahoo.com",
        "hometown": "Santa Fe",
        "description": "Portside Locos: A ragtag group of drummers and noisemakers. Come relax and rehydrate in our Oasis and bang out a rhythm on our drums.",
        "location": {
            "string": "6:00 & G",
            "frontage": "6:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.77791248567272,
            "gps_longitude": -119.2177076684539
        },
        "location_string": "6:00 & G"
    },
    {
        "uid": "a1Xd0000001IXnNEAW",
        "year": 2016,
        "name": "Mellow Mountain",
        "description": "Mellow Mountain offers you a big, misted swing set next to our tented social carousel, bar, and cafe tables.\r\nHere you will be served early afternoon drinks weekdays and smooches from the Kissy Fish art car.",
        "location": {
            "string": "A & 9:45",
            "frontage": "A",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79384195510268,
            "gps_longitude": -119.21057572042989
        },
        "location_string": "A & 9:45"
    },
    {
        "uid": "a1Xd0000001IRBXEA4",
        "year": 2016,
        "name": "Rock Star (Camp Rock Star)",
        "url": "https://www.facebook.com/burningmanrockstar/",
        "hometown": "New York",
        "description": "Camp Rock Star hosts multimedia rock concerts complete with a magical stage, great lighting and, of course, incredible musicians and bands. Our goal is to infuse the Playa with the incomparable energy of the live concert experience, and inspire other burners to take the stage.",
        "location": {
            "string": "C & 2:15",
            "frontage": "C",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.782808722545894,
            "gps_longitude": -119.1950676753229
        },
        "location_string": "C & 2:15"
    },
    {
        "uid": "a1Xd0000001IXhAEAW",
        "year": 2016,
        "name": "Dust Monkeys",
        "hometown": "San Francisco",
        "description": "The Dust Monkeys' revolutionary Fauxtobooth is guaranteed to make you smile and will always capture your good side. Don your best duds and come on down to experience the mystical power of fauxtography first hand!",
        "location": {
            "string": "D & 4:45",
            "frontage": "D",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.776456262296946,
            "gps_longitude": -119.20822712642001
        },
        "location_string": "D & 4:45"
    },
    {
        "uid": "a1Xd0000001IWR0EAO",
        "year": 2016,
        "name": "Cafe Diem",
        "url": "https://www.facebook.com/CafeDiemBRC",
        "hometown": "North Lake Tahoe",
        "description": "We can make you almost any coffee or tea drink imaginable and we strive to make it the best you've ever had. We serve turkish coffee, matcha, masala chai, yerba mate, espresso, pour-over, and a wide array of teas from around the world.",
        "location": {
            "string": "D & 5:15",
            "frontage": "D",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77713272797879,
            "gps_longitude": -119.21156430775099
        },
        "location_string": "D & 5:15"
    },
    {
        "uid": "a1Xd0000001IX8fEAG",
        "year": 2016,
        "name": "Raised by Wolves",
        "url": "http://rxwburn.com",
        "hometown": "Portland",
        "description": "Raised By Wolves is a transcontinental pack of artists, healers, performers, and builders who are inspired and impassioned by the classic story of feral children and their wolf pack families. Each year we bring our\r\nuntamed energy to the Black Rock desert through play, performance and art.\r\n\r\nOur gifts this year include our cold-brew coffee Cafe, a Dark n' Stormy Hip-Hop dance party and Ziza the Roving Tea Truck. We'll also host a yoga class every day in our Wolf Den.",
        "location": {
            "string": "8:30 & B",
            "frontage": "8:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.79075660354997,
            "gps_longitude": -119.2164677676208
        },
        "location_string": "8:30 & B"
    },
    {
        "uid": "a1Xd0000001IXgHEAW",
        "year": 2016,
        "name": "Harmonic Convergence Camp",
        "url": "https://www.facebook.com/HarmonicConvergenceCamp/",
        "contact_email": "pumamarco@me.com",
        "hometown": "Santa Monica",
        "description": "Harmonic Convergence is an intimate, spiritually-focused camp, highlighted by the Harmonic Cafe (which serves the best cappuccinos on the Playa).",
        "location": {
            "string": "5:00 & E",
            "frontage": "5:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77607703461826,
            "gps_longitude": -119.21015262425809
        },
        "location_string": "5:00 & E"
    },
    {
        "uid": "a1Xd0000001IWjLEAW",
        "year": 2016,
        "name": "Bright Cider Life",
        "hometown": "Pilton, Bath",
        "description": "Bright Cider of Life\r\n\r\nA celebration of everything relating to the cider; one of the greatest elixirs of life.\r\nCome and join us for cider sharing and quintessentially english games.\r\nSpot us around the playa in our apple suits and come home to find us\r\nOur motto \"Always Look On The Bright Cider of Life\"",
        "location": {
            "string": "F & 9:15",
            "frontage": "F",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79539677754363,
            "gps_longitude": -119.21562791691271
        },
        "location_string": "F & 9:15"
    },
    {
        "uid": "a1Xd0000001IWQWEA4",
        "year": 2016,
        "name": "Camp Lip Service",
        "hometown": "Salt Lake City",
        "description": "BURN THE MAN, NOT YOUR LIPS!  \r\nWhen the harsh playa takes its toll on psyche, your soul and your lips, come see Lip Service.  We've got just what you need... soothing Lip Balm, really Bad Advice, cool beverages, great beats, some shade and a chill area to rest, day or night.",
        "location": {
            "string": "8:30 & C",
            "frontage": "8:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.791085369007384,
            "gps_longitude": -119.21722010505046
        },
        "location_string": "8:30 & C"
    },
    {
        "uid": "a1Xd0000001IPdPEAW",
        "year": 2016,
        "name": "Black Rock Center for Unlearning",
        "url": "https://www.facebook.com/groups/BRCU1/",
        "contact_email": "whatsunspoken@gmail.com",
        "hometown": "Reno",
        "description": "B.R.C.U. Black Rock Center for Unlearning: Washing all that knowledge right out of your head since 2009.",
        "location": {
            "string": "C & 4:15",
            "frontage": "C",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.7771083101538,
            "gps_longitude": -119.20488612768166
        },
        "location_string": "C & 4:15"
    },
    {
        "uid": "a1Xd0000001IOxVEAW",
        "year": 2016,
        "name": "Le Kafe",
        "hometown": "We have three main hometowns for Le Kafe: San Francisco/Denver/Paris.",
        "description": "Coffee. Warm.  Pastries.  Music. Loving.  Tea.  Peaceful.  Sexy.  Shade.  Lounge. Home.  Le Kafé may be the coziest landing spot on playa at any hour in 9 o'clock sector. \r\n\r\nMorning: Bring a cup and enjoy organic coffee and tea along with pastries and biscotti.  Sit down in shade and jump start your body and mind.  \r\nAfternoon: shady napping abounds in our \"flounge\" (lounge of many futons).  Cool off in our yurt, large hammock or porch swing.  Down tempo grooves provide a gentle backdrop day and night.  Relax.  Sip a cold one.  Get a back rub.  Soak your feet in a cool medicinal bath.  \r\nEvening: sunset transforms Le Kafe into an informal cocktail lounge where you can enjoy playing with our many lighted toys or our 7-circuit lighted labyrinth.  Late night fires warm your bones as you stumble back to town.   After playa nights, blankets and pillows abound in the lounge. Snuggle. Slumber.  Repeat.\r\nCome see how we provide one of the best landing pads in Black Rock City.",
        "location": {
            "string": "9:00 & H",
            "frontage": "9:00",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.79535140820743,
            "gps_longitude": -119.21832489206119
        },
        "location_string": "9:00 & H"
    },
    {
        "uid": "a1Xd0000001IVUMEA4",
        "year": 2016,
        "name": "Habitat for Insanity",
        "contact_email": "teppy@egenesis.com",
        "hometown": "Pittsburgh",
        "description": "Habitat for Insanity cultivates novel Burner technology, interactive art, and unique food. We're a warm and welcoming group of veterans and new people from around the world.",
        "location": {
            "string": "4:30 Plaza @ 4:00",
            "frontage": "4:30 Plaza",
            "intersection": "4:00",
            "intersection_type": "@",
            "gps_latitude": 40.774226171387944,
            "gps_longitude": -119.20610842564747
        },
        "location_string": "4:30 Plaza @ 4:00"
    },
    {
        "uid": "a1Xd0000001IXKREA4",
        "year": 2016,
        "name": "Art of Such n Such",
        "url": "http://www.sparseland.com",
        "hometown": "Atlanta",
        "description": "Art of Such n Such - Home of The Kitty Roaster, The High Striker, & Infanity Fire Cauldron\r\nConfidential Paternity Testing Station, warm late night/ early morning fires & some Bad Advice for your burn",
        "location": {
            "string": "Esplanade & 4:15",
            "frontage": "Esplanade",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.7796078276107,
            "gps_longitude": -119.20532026852145
        },
        "location_string": "Esplanade & 4:15"
    },
    {
        "uid": "a1Xd0000001IWTfEAO",
        "year": 2016,
        "name": "Pepperland",
        "url": "https://www.facebook.com/groups/198208360209399/",
        "contact_email": "gerflash@socal.rr.com",
        "hometown": "Fountain Valley, Orange County",
        "description": "If you're an accomplished or aspiring artist, cartoonist, singer, comic, improv maven, or game enthusiast, on-stage model, dancer, or dramatic reader, Pepperland has much for you in Leonardo's Workshop on the Playa.  If you need/want a massage or something to drink or eat, our renaissance men and women are here to serve you, and with Laughter Yoga plus Longevity Stick exercises to get your Xi flowing like the Playa wind blows - - and so much more.  It's our ninth year on Playa, and with our new name.  Formerly \"Cartoon Commune,\" we felt inspired by DaVinci's inventiveness to blend his genius with that of the Fab Four.  No kidding!  You'll see our \"hill\" where you can be a fool on it; maybe even a periscope for peering out at octopuses and who knows what else at BRC.  The third dimension is yours; we've got the glasses for it - and the views to go with 'em.  Our week will include over 50 hours of interactive, inventive entertainment.  Need a home at home?  Check us out.",
        "location": {
            "string": "6:30 & E",
            "frontage": "6:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78105582486477,
            "gps_longitude": -119.21872283512668
        },
        "location_string": "6:30 & E"
    },
    {
        "uid": "a1Xd0000001IX8QEAW",
        "year": 2016,
        "name": "Wiener Zoo",
        "url": "http://www.wienerzoo.com",
        "contact_email": "wienerzoo@gmail.com",
        "hometown": "Salt Lake City",
        "description": "We gift to those in need of nourishment, whether it be physical, emotional, or inspirational. Our trademark gift is a hotdog (Wiener!) and we are always willing to give to those in need of sustenance in any form.",
        "location": {
            "string": "C & 7:45",
            "frontage": "C",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78761815118928,
            "gps_longitude": -119.21877261481393
        },
        "location_string": "C & 7:45"
    },
    {
        "uid": "a1Xd0000001ILkzEAG",
        "year": 2016,
        "name": "Plug n Play",
        "hometown": "Sparks",
        "description": "Bring your iPad, iPod, cell phone, or any small hand-held electronic device to Plug n Play Camp for a recharge utilizing our camp's solar-powered battery charging device. Have a cold beer or vodka-based mixed drink on us while playing Connect Four and listening to chill and deep house electronic dance music while you wait.",
        "location": {
            "string": "H & 7:15",
            "frontage": "H",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78474634492448,
            "gps_longitude": -119.22307720812522
        },
        "location_string": "H & 7:15"
    },
    {
        "uid": "a1Xd0000001IXVsEAO",
        "year": 2016,
        "name": "Swamp Fuckits",
        "hometown": "New Orleans",
        "description": "Rag tag group of New Orleans architects, lovers, dancers, djs, cooks, artists and friends- expert at bringing our laissez les bons temps rouler attitudes from the swamp to the desert.  Come meet us!",
        "location": {
            "string": "F & 8:45",
            "frontage": "F",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.7933010483374,
            "gps_longitude": -119.21839283914905
        },
        "location_string": "F & 8:45"
    },
    {
        "uid": "a1Xd0000001IMTGEA4",
        "year": 2016,
        "name": "Random Pants",
        "contact_email": "dapete@hotmail.com",
        "hometown": "Jackson",
        "description": "You never really appreciate pants until they're missing...AMIRIGHT?  If you need pants or if you've got an extra pair, come on by Random Pants!  \r\n\r\n10am Yodel Dance™ daily",
        "location": {
            "string": "G & 6:45",
            "frontage": "G",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78180595810437,
            "gps_longitude": -119.22114438293958
        },
        "location_string": "G & 6:45"
    },
    {
        "uid": "a1Xd0000001IVFfEAO",
        "year": 2016,
        "name": "Camp Woo Woo",
        "hometown": "Sunnyvale",
        "description": "Camp Woo Woo - delivering happiness and spankings since 2012!"
    },
    {
        "uid": "a1Xd0000001IX8zEAG",
        "year": 2016,
        "name": "CAMP SPACE MONKEYS",
        "hometown": "Forestville",
        "description": "CAMP SPACE MONKEY"
    },
    {
        "uid": "a1Xd0000001IRLAEA4",
        "year": 2016,
        "name": "Strange Gardens Bear Magical Frui",
        "hometown": "New York City",
        "description": "NYC, Reno, and Vancouver Island represent! We give you \"It's PlayaTime!\" The Gameshow that tests your Burning Man knowledge and skills. Also the home of Misssus, the alien mutant vehicle looking for a new home. Did we mention the pizza? We have pizza ovens, and we will use them by golly!  Be one of the lucky few to enjoy our full service sit down Nostalgia Pizza Cafe with delicious pizza and decor that will bring you back in time to Burning Man's early years in the 1970's when it was held on the Jersey Shore.",
        "location": {
            "string": "6:30 & G",
            "frontage": "6:30",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.780397991108615,
            "gps_longitude": -119.22022704812237
        },
        "location_string": "6:30 & G"
    },
    {
        "uid": "a1Xd0000001IC2JEAW",
        "year": 2016,
        "name": "Soul(ar) Society",
        "hometown": "Seattle",
        "description": "We are Soul(ar) Society - Dedicated to providing Black Rock City with solar energy and workshops for individual growth and freedom of expression. Our objective is to create an environment that is fun and educates the community about the importance of sustainability for earth, body, and soul.",
        "location": {
            "string": "F & 9:15",
            "frontage": "F",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79539677754363,
            "gps_longitude": -119.21562791691271
        },
        "location_string": "F & 9:15"
    },
    {
        "uid": "a1Xd0000001IVEIEA4",
        "year": 2016,
        "name": "Oh No You Didn't",
        "url": "https://www.facebook.com/camp.oh.no.you.didnt",
        "hometown": "Santa Rosa",
        "description": "Be our guest and get it off you chest at our playa confessional lounge, featuring libelous libations and scornful judgment by our panel of experts.  Commiserate with the best as we help keep your shame in perspective.",
        "location": {
            "string": "A & 8:45",
            "frontage": "A",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.791300695156856,
            "gps_longitude": -119.21494555440992
        },
        "location_string": "A & 8:45"
    },
    {
        "uid": "a1Xd0000001IR7FEAW",
        "year": 2016,
        "name": "Bunny Meth Lab",
        "hometown": "Denver",
        "location": {
            "string": "A & 9:15",
            "frontage": "A",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79278896602692,
            "gps_longitude": -119.21298209325717
        },
        "location_string": "A & 9:15"
    },
    {
        "uid": "a1Xd0000001IEWGEA4",
        "year": 2016,
        "name": "Sun Guardians 2.ooooommm",
        "url": "http://www.sunguardians.net",
        "contact_email": "info@sunguardians.net",
        "hometown": "San Francisco",
        "description": "Sun Guardians 2.oooommmm with the Rootiest Lounge and Hanuman's House of Tea and Ramen to kick-start your spiritual and sense of adventure. We will have yoga all through the week and special services for tea and ramen! The Rootist Lounge will present entertainment, bar and a place to chill. Come by any time, check out our posted schedule, and hang out for a while.",
        "location": {
            "string": "F & 7:45",
            "frontage": "F",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.7878746073425,
            "gps_longitude": -119.22135635615312
        },
        "location_string": "F & 7:45"
    },
    {
        "uid": "a1Xd0000001INGREA4",
        "year": 2016,
        "name": "Sharkey's Bar and Lounge",
        "url": "https://www.facebook.com/groups/sharkeysbarandlounge/",
        "hometown": "Los Angeles, San Francisco and all corners of the globe",
        "location": {
            "string": "8:00 & D",
            "frontage": "8:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.78899509186698,
            "gps_longitude": -119.21929538907911
        },
        "location_string": "8:00 & D"
    },
    {
        "uid": "a1Xd0000001IVDyEAO",
        "year": 2016,
        "name": "Trip and Fall",
        "hometown": "Venice Beach",
        "description": "Trip and Fall featuring the \"Shockatorium Emporium\" and solar power experiments.",
        "location": {
            "string": "G & 5:15",
            "frontage": "G",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77531107774246,
            "gps_longitude": -119.21256530891797
        },
        "location_string": "G & 5:15"
    },
    {
        "uid": "a1Xd0000001IOvAEAW",
        "year": 2016,
        "name": "Glowskull Asylum Int'l",
        "hometown": "Tallinn",
        "description": "Come hang out with our team of misfits from the US, Italy, Norway, Estonia, and Canada. Our lounge and art car \"Castle Glowskull\" will be hosting mischief, mistings, and METAL (and other forms of rock) daily!",
        "location": {
            "string": "2:30 & E",
            "frontage": "2:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78105582486477,
            "gps_longitude": -119.19427716487334
        },
        "location_string": "2:30 & E"
    },
    {
        "uid": "a1Xd0000001IBnGEAW",
        "year": 2016,
        "name": "Sideshow",
        "contact_email": "brcsideshow@gmail.com",
        "hometown": "Reno",
        "description": "BEHOLD! SIDESHOW returns to the playa in 2016 with an assemblage of freaks, oddities, magicians extraordinaire, and a real-life strong woman, all in the greatest old time tradition of the Circus sideshow.We offer an open invitation for you to drop by and share your talents",
        "location": {
            "string": "Esplanade & 3:00 Portal",
            "frontage": "Esplanade",
            "intersection": "3:00 Portal",
            "intersection_type": "&",
            "gps_latitude": 40.781555661173314,
            "gps_longitude": -119.2001025780959
        },
        "location_string": "Esplanade & 3:00 Portal"
    },
    {
        "uid": "a1Xd0000001IVUbEAO",
        "year": 2016,
        "name": "Kosmik Dust Pedal Pub Camp",
        "contact_email": "dirk611@gmail.com",
        "hometown": "LAS VEGAS with global input",
        "description": "Kosmik Dust abounds with interactivity day and night. Whether you like to interact with our friendly, knowledgeable veteran burners or prefer a technological experience, we have it all. Look for the star tunnel for sun tea, lemonade and cookies, play in our motion activated installations, ride the human-powered eight passenger pedal pub, and enjoy browsing the Djinn Exchange.",
        "location": {
            "string": "7:00 & A",
            "frontage": "7:00",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.784314394456956,
            "gps_longitude": -119.2167775389316
        },
        "location_string": "7:00 & A"
    },
    {
        "uid": "a1Xd0000001IVpjEAG",
        "year": 2016,
        "name": "Black Rock Disc Golf Club",
        "url": "https://www.facebook.com/groups/blackrockcitydiscgolf/",
        "contact_email": "blackrockdiscgolfclub@gmail.com",
        "hometown": "Santa Cruz",
        "description": "This year we're bringing the disc golf course to a whole new level and will be building out the psychedelic forest to incorporate some trippy art and oomfy shade structures for the community to enjoy. As burners begin or end their adventure into open playa, they can stop by the disc golf course 24/7 to throw some discs through our glowing nine-hole disc golf, trip out under our 10' tall mushrooms, or grab a drink and relax in the Gopher's Hole during happy hour.\r\n\r\nWe'll be constructing a trippy forest to act as obstacles for the 9-hole disc golf course. The disc course will be open for play all of the burn, with LED discs for night play. The forest will be made different fun obstacles and will include 15' tall tye-dye trees to 10' tall mushrooms to dozens of 3' mushrooms, all of which will  light up bright for the fairies to prance through deep into the night.",
        "location": {
            "string": "2:30 & G",
            "frontage": "2:30",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.780397991108615,
            "gps_longitude": -119.19277295187766
        },
        "location_string": "2:30 & G"
    },
    {
        "uid": "a1Xd0000001IVKaEAO",
        "year": 2016,
        "name": "Intergalactic Sasquatch Village",
        "contact_email": "intergalacticsasquatch@gmail.com",
        "hometown": "Mt Shasta",
        "description": "Come join us wayward star traveller for a refreshing herbal infused iced beverage, comfy seat, and good vibrations in our Copper and Crystal Cantina.  We're like the Cantina from Star Wars, but a lot less Cutty and a lot more Loveeeeeee!",
        "location": {
            "string": "2:30 & A",
            "frontage": "2:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.78237143378006,
            "gps_longitude": -119.19728568024945
        },
        "location_string": "2:30 & A"
    },
    {
        "uid": "a1Xd0000001IXYcEAO",
        "year": 2016,
        "name": "Parea",
        "location": {
            "string": "G & 9:45",
            "frontage": "G",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.797488604582114,
            "gps_longitude": -119.21256733476802
        },
        "location_string": "G & 9:45"
    },
    {
        "uid": "a1Xd0000001IYGrEAO",
        "year": 2016,
        "name": "Camp Armageddon - Bike Love",
        "url": "https://www.facebook.com/Camp-Armageddon-51276852446/?fref=ts",
        "contact_email": "janinerood@sbcglobal.net",
        "hometown": "Chico",
        "description": "Armageddon - it's not the end of the world, it's the Safe Word! Come to Camp Armageddon for bike repair, yoga, music or just to 'set a spell' in our community dome! We offer professional bike repair daily, serving the 3:00 sector for 10 years. Morning yoga classes in our dome are the best way to start the day! And our dome is a great place to hang out and watch the world go by, at any time of day. Come for a visit!",
        "location": {
            "string": "3:30 & B",
            "frontage": "3:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.778853255646204,
            "gps_longitude": -119.20074613806385
        },
        "location_string": "3:30 & B"
    },
    {
        "uid": "a1Xd0000001IOV2EAO",
        "year": 2016,
        "name": "Cyberia",
        "url": "http://www.campcyberia.org",
        "contact_email": "campcyberia@gmail.com",
        "hometown": "Los Angeles",
        "description": "Cyberia - the coolest place on the playa! Come join us for daily meditation, yoga, and Shibari classes. We are also serving Korean iced-coffee to help beat the heat!",
        "location": {
            "string": "C & 9:45",
            "frontage": "C",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79505698110772,
            "gps_longitude": -119.21124115125328
        },
        "location_string": "C & 9:45"
    },
    {
        "uid": "a1Xd0000001IC32EAG",
        "year": 2016,
        "name": "Between a Rock and a Weird Place",
        "hometown": "Tahoe",
        "description": "BetWeeN A RocK aNd a WeiRd PlaCe is exactly were you'll find yourself when you come to rest your dusty souls at our home.  Enjoy our entertaining residence, tasty bar treats, comfy lounge area, delectable tunes, and daily activities when you visit us!",
        "location": {
            "string": "D & 2:45",
            "frontage": "D",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78029002604831,
            "gps_longitude": -119.19599624257887
        },
        "location_string": "D & 2:45"
    },
    {
        "uid": "a1Xd0000001ILn5EAG",
        "year": 2016,
        "name": "Smiley Grrrlz",
        "hometown": "Brooklyn/Austin/NorCal",
        "description": "Smiley Grrrlz welcomes you to our Chai Tea Lounge! Come warm your bellies and hearts with delicious, home-made, herbal organic chai tea. Relax in our tea lounge while connecting with Smiley Grrrlz and each other.",
        "location": {
            "string": "C & 9:45",
            "frontage": "C",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79505698110772,
            "gps_longitude": -119.21124115125328
        },
        "location_string": "C & 9:45"
    },
    {
        "uid": "a1Xd0000001IFWwEAO",
        "year": 2016,
        "name": "Funky Monkey Camp",
        "hometown": "Truckee, CA Portland, OR, Durango, CO, Los Angeles, CA, Reno, NV, Oakland, CA, San Diego, CA, Kyoto, Japan, Byron Bay, Australia, Seattle, WA, Costa Rica,",
        "description": "Funky Monkey Camp - Furthering Funky Merriment of Maniacal Monkeys Everywhere!",
        "location": {
            "string": "4:00 & G",
            "frontage": "4:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.77480650784362,
            "gps_longitude": -119.20239790044295
        },
        "location_string": "4:00 & G"
    },
    {
        "uid": "a1Xd0000001IROYEA4",
        "year": 2016,
        "name": "Grease Fairies - Local 77",
        "hometown": "Portland",
        "location": {
            "string": "D & 9:45",
            "frontage": "D",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79566449547131,
            "gps_longitude": -119.21157386741038
        },
        "location_string": "D & 9:45"
    },
    {
        "uid": "a1Xd0000001IVA6EAO",
        "year": 2016,
        "name": "DUSTFISH Village",
        "url": "https://www.facebook.com/dustfishlovesyou/",
        "contact_email": "opalminded@gmail.com",
        "hometown": "San Francisco",
        "description": "Fire art as community service - we provide high pressure vaporized propane to art cars with flame effects, so they can burn as hotter, brighter & crazier!",
        "location": {
            "string": "Esplanade & 7:00",
            "frontage": "Esplanade",
            "intersection": "7:00",
            "intersection_type": "&",
            "gps_latitude": 40.78462658391771,
            "gps_longitude": -119.21523944492934
        },
        "location_string": "Esplanade & 7:00"
    },
    {
        "uid": "a1Xd0000001IWVvEAO",
        "year": 2016,
        "name": "1001 Nights",
        "contact_email": "bdahleh@gmail.com",
        "hometown": "Dubai",
        "description": "1001 Nights is a camp that offers a day oriental lounge to collect love and support MaKaTeeB (Arabic for letters) from burners reaching 1001 MakToob (singular for MaKaTeeB) in the 7 nights of the burning man experience. Spreading the MaKaTeeB nurturing the energy that connects us and spreading love and support: important pillars to the survival of our community. \r\n\r\nThe camp also offers a \"Majlis\" experience with Arabic coffee and sweets served during the day. The lounge will have suspended fabric for shade, floor carpet and seating, playa furniture, in addition to suspended chair hammocks.. The space is open at night for public use with the starry and dreamy lights.\r\n\r\nFlow artists are welcome to flow in our space for jams on our flow tunes along with world renowned hoopers.",
        "location": {
            "string": "C & 9:45",
            "frontage": "C",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79505698110772,
            "gps_longitude": -119.21124115125328
        },
        "location_string": "C & 9:45"
    },
    {
        "uid": "a1Xd0000001IXZzEAO",
        "year": 2016,
        "name": "Naked Rainbow",
        "hometown": "Los Angeles + San Francisco",
        "description": "Naked Rainbow, the Strip Club for your Soul. All week - FIRE SPINNING after dark, PICNIC TABLE ART CAR shenanigans at random. ;) TUESDAY 10PM - Come dance in your favorite animal onesie to 90's throwbacks, deep house, Disney tunes, gospel dubstep and more. Sip on jungle juice and unicorn blood all night! THURSDAY 5:30PM - A magical happy hour of live painting, dancing, spinning (contact staff, dragon staff, poi, hoop), lights, essential oils, drums, and more to deep meditative flow music, with a fire spinning circle to an electric violin performance at sunset. Bring your toys and come play!! ART INSTALLATIONS - A life-sized Pyramid shell that incorporates the golden ratio of sacred geometry and sound healing frequencies, is designed to drop bass and sync light to your heartbeat when the glowing core is touched. Also come hang your aspirations and prayers on the Tree of Hope. It will swell throughout the week as individuals leave pieces of themselves to this collective consciousness.",
        "location": {
            "string": "D & 2:45",
            "frontage": "D",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78029002604831,
            "gps_longitude": -119.19599624257887
        },
        "location_string": "D & 2:45"
    },
    {
        "uid": "a1Xd0000001IKiCEAW",
        "year": 2016,
        "name": "Booty Hunters",
        "url": "https://www.facebook.com/BootyHunterCamp",
        "hometown": "San Francisco / Los Angeles",
        "location": {
            "string": "I & 2:45",
            "frontage": "I",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.77829184442306,
            "gps_longitude": -119.19254719363302
        },
        "location_string": "I & 2:45"
    },
    {
        "uid": "a1Xd0000001IXY3EAO",
        "year": 2016,
        "name": "Avant Yard",
        "hometown": "New York",
        "description": "We are a family of artists, dreamers, poets, and gnomes. Join us in creating and discovering the story of connective collective human potential.",
        "location": {
            "string": "H & 5:45",
            "frontage": "H",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.776355654907675,
            "gps_longitude": -119.21667735883563
        },
        "location_string": "H & 5:45"
    },
    {
        "uid": "a1Xd0000001IVCREA4",
        "year": 2016,
        "name": "gNarnia",
        "contact_email": "mihart87@gmail.com",
        "hometown": "Los Angeles",
        "description": "gNarnia is a small cozy camp offering cold brew coffee or matcha green tea from 9am to noon, Monday-Friday. Come find your way through the wardrobe and into our shade structure (please remember your cup). Guided yoga on Tuesday and Thursday from 10am-11am.",
        "location": {
            "string": "9:30 & F",
            "frontage": "9:30",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.79622457844993,
            "gps_longitude": -119.21399283663455
        },
        "location_string": "9:30 & F"
    },
    {
        "uid": "a1Xd0000001IOTuEAO",
        "year": 2016,
        "name": "Dare to be Rare",
        "url": "http://www.daretoberare.rocks/",
        "contact_email": "daretoberarecamp@gmail.com",
        "hometown": "Bay Area,Portland, Denver & Jacksonville",
        "description": "Dare to be Rare is a meat inspired camp party day camp. We love our meat especially on playa. We run events all week so stop by early to get the inside scope. Don't miss our Playa acclaimed Wed BBQ. The only camp on playa that serves 180lbs of TriTip, awesome DJ's and loads of adult games. Meet our Meat Priest & Naughty Nun, give our  Meat Alter boys & girls something to remember. Take our meat like good boys & girls. Confess your sins at the Meat Alter or try your luck at our Glory Glory Hallelujah Hole. Dont forget to get tanked at Tanked Twister or Truth or Dare Jenga. Check out our board for other fun events all week.",
        "location": {
            "string": "A & 2:15",
            "frontage": "A",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78331275218366,
            "gps_longitude": -119.19667218250439
        },
        "location_string": "A & 2:15"
    },
    {
        "uid": "a1Xd0000001IVBdEAO",
        "year": 2016,
        "name": "Camp Walter",
        "url": "http://walterthebus.org",
        "hometown": "Phoenix",
        "description": "As immense as Walter is, he represents something even bigger. The power of imagination, the joy of discovery, and the spirit of service in which we undertake every project. Walter's story has a message for us all: there are second chances in life, your past doesn't determine your future, you are capable of more than you might think, and we can all do so much more together than we ever could on our own.",
        "location": {
            "string": "Esplanade & 10:00",
            "frontage": "Esplanade",
            "intersection": "10:00",
            "intersection_type": "&",
            "gps_latitude": 40.79301722491078,
            "gps_longitude": -119.20884202311616
        },
        "location_string": "Esplanade & 10:00"
    },
    {
        "uid": "a1Xd0000001IVGxEAO",
        "year": 2016,
        "name": "Loquacious and Lovely Camp",
        "contact_email": "lnl@kapamaki.net",
        "hometown": "New York / Zurich",
        "description": "Loquacious and Lovely Camp came into existence in 2015 to support an art project, and continues on as a random amalgamation of artists from all over the world.",
        "location": {
            "string": "D & 2:15",
            "frontage": "D",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78255670886589,
            "gps_longitude": -119.19426542535763
        },
        "location_string": "D & 2:15"
    },
    {
        "uid": "a1Xd0000001IWtLEAW",
        "year": 2016,
        "name": "VooDoo Soup",
        "description": "Hot soup Live music",
        "location": {
            "string": "C & 3:15",
            "frontage": "C",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.778962057935686,
            "gps_longitude": -119.19897050537821
        },
        "location_string": "C & 3:15"
    },
    {
        "uid": "a1Xd0000001IWMAEA4",
        "year": 2016,
        "name": "Bacon Oasis",
        "hometown": "Tucson",
        "description": "The Bacon Oasis is once again serving morsels of freshly cooked, deliciously sweet and spicy, finger sticking bacon.  Stop by the Bacon Oasis Workshop between 10am and noon, on Monday, Wednesday and Friday to taste our delectable delights.",
        "location": {
            "string": "D & 2:15",
            "frontage": "D",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.78255670886589,
            "gps_longitude": -119.19426542535763
        },
        "location_string": "D & 2:15"
    },
    {
        "uid": "a1Xd0000001IVptEAG",
        "year": 2016,
        "name": "Luxurious Vagrants",
        "hometown": "San Francisco",
        "description": "Lux Vag is where sandy bodies come to get fancy! Enter our parlor to try on tattoos, bedazzle your bodies, and leave feeling special. Stop by the adjacent Lux Cafe for coffee and yoga during the day + dancing and interactive visualizations in the evening.",
        "location": {
            "string": "B & 7:45",
            "frontage": "B",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78753266605781,
            "gps_longitude": -119.21791137024913
        },
        "location_string": "B & 7:45"
    },
    {
        "uid": "a1Xd0000001IAvzEAG",
        "year": 2016,
        "name": "EleVant Rising",
        "url": "http://www.elevantrising.com",
        "hometown": "Lake Tahlent",
        "description": "Delicious on-Playa dinner and dessert; reservations taken daily, limited seating available.  Come enjoy the best meal of your life!",
        "location": {
            "string": "C & 2:15",
            "frontage": "C",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.782808722545894,
            "gps_longitude": -119.1950676753229
        },
        "location_string": "C & 2:15"
    },
    {
        "uid": "a1Xd0000001IBumEAG",
        "year": 2016,
        "name": "404: Village Not Found",
        "hometown": "N/A too many to list",
        "description": "404:Village not Found, Come here to get lost.\r\nThe last place you're looking for.",
        "location": {
            "string": "C & 2:45",
            "frontage": "C",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.78069066990527,
            "gps_longitude": -119.19668499606931
        },
        "location_string": "C & 2:45"
    },
    {
        "uid": "a1Xd0000001IWwtEAG",
        "year": 2016,
        "name": "Risa",
        "url": "https://www.flickr.com/photos/9027688@N04/15244009895/in/album-72157651347177088/",
        "contact_email": "brcrogman@yahoo.com",
        "hometown": "Carson City",
        "description": "RISA is a resort planet, renowned for its breezes, beaches and friendly atmosphere. Our main attraction at RISA during the afternoon is our Snow Cones. Evening Mutant Vehicle rides on the Dancing Peacock.",
        "location": {
            "string": "G & 3:45",
            "frontage": "G",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.77531107774246,
            "gps_longitude": -119.20043469108207
        },
        "location_string": "G & 3:45"
    },
    {
        "uid": "a1Xd0000001IX6KEAW",
        "year": 2016,
        "name": "Wickedland",
        "url": "http://www.wickedland.camp",
        "contact_email": "wickedland.playa@gmail.com",
        "hometown": "Los Angeles",
        "description": "Have you ever wondered what happened to your childhood fairytale heroes after you left their lands? WICKEDLAND brings you face-to-face with them: all grown up, distorted and oh-so-very twisted. How have YOU changed?\r\n\r\nWICKEDLAND brings your favorite childhood fairytale heroes and their archetypal stories back to life. But something has changed – this world isn't nearly as innocent as it was when you were younger, because you are it.\r\n\r\nIf you want to dig deeper through the world of twisted fairytales, you are welcome to sit with a book in our cozy lounge. Or climb up the castle towers that adorn the entrance to our camp. You can be transformed to the damsel in distress of your choice. Will you be Snow White today, or maybe Rapuntzel?\r\nBut be warned – a transformation lingers behind every page you turn. If you're not careful, you may leave WICKEDLAND as Gay Donald Duck or Nymphomaniac Snow White.\r\n\r\nThere are no observers here, come party like the Princess or Dragon that you are!",
        "location": {
            "string": "B & 9:45",
            "frontage": "B",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79444946765153,
            "gps_longitude": -119.21090843559313
        },
        "location_string": "B & 9:45"
    },
    {
        "uid": "a1Xd0000001IVHqEAO",
        "year": 2016,
        "name": "Camp Be Bothered",
        "contact_email": "brianolver@gmail.com",
        "hometown": "Los Angeles",
        "description": "We Camp Be Bothered to fill this out.",
        "location": {
            "string": "I & 7:45",
            "frontage": "I",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78813699883062,
            "gps_longitude": -119.22393925217301
        },
        "location_string": "I & 7:45"
    },
    {
        "uid": "a1Xd0000001IVKfEAO",
        "year": 2016,
        "name": "Atom Cult",
        "url": "http://www.atomcult.com/",
        "contact_email": "atomcultcamp@gmail.com",
        "hometown": "SD-OC-LA-SF",
        "description": "The Most Radiant Camp at Burning Man. Come taste our fusion pancakes with hot tea and coffee at 8 AM and fission ice cream at 3 PM. Enjoy the magnificent views of BRC and bounce off the trampoline at the top of our 30' tall Clock Tower.",
        "location": {
            "string": "C & 6:45",
            "frontage": "C",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.782808722545894,
            "gps_longitude": -119.21793232467711
        },
        "location_string": "C & 6:45"
    },
    {
        "uid": "a1Xd0000001IXK2EAO",
        "year": 2016,
        "name": "Snowflake Village",
        "hometown": "MILWAUKEE",
        "description": "Snowflake Village has it all! Go to Speed Dating, have a drink, participate in a movie, play in your own band, and project your face 20 feet tall. Open day and night.",
        "location": {
            "string": "Esplanade & 6:45",
            "frontage": "Esplanade",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78377478201974,
            "gps_longitude": -119.21485701075231
        },
        "location_string": "Esplanade & 6:45"
    },
    {
        "uid": "a1Xd0000001IXOTEA4",
        "year": 2016,
        "name": "Camp Camp Camp",
        "contact_email": "planetawesomeccc@gmail.com",
        "hometown": "San Diego",
        "description": "Camp Camp Camp - Silly people with style, smiles, hospitality, and funky jams.  Welcome to Planet Awesome!",
        "location": {
            "string": "6:30 & B",
            "frontage": "6:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.78204253887612,
            "gps_longitude": -119.21646645976782
        },
        "location_string": "6:30 & B"
    },
    {
        "uid": "a1Xd0000001IOlFEAW",
        "year": 2016,
        "name": "Camp Touch This",
        "hometown": "Truckee",
        "description": "Stop by to climb the scaffolding and gain a different perspective on your day - or maybe your life, lock up a naughty friend in our camp jail, or dance it out with us at one of our afternoon frozen drink parties.",
        "location": {
            "string": "D & 9:45",
            "frontage": "D",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79566449547131,
            "gps_longitude": -119.21157386741038
        },
        "location_string": "D & 9:45"
    },
    {
        "uid": "a1Xd0000001IOaWEAW",
        "year": 2016,
        "name": "Freaks",
        "hometown": "Toronto",
        "description": "Freaks - Escape the mid-day heat and get an aromatherapist spritz, an impromptu make-over session, a game of Giant Jenga a hug and a chat. Stop in to our advice booth,  check out our Drawers of Mystery or sit and chill. All freaks are welcome.",
        "location": {
            "string": "D & 7:15",
            "frontage": "D",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78508546671077,
            "gps_longitude": -119.21963170707147
        },
        "location_string": "D & 7:15"
    },
    {
        "uid": "a1Xd0000001IVyXEAW",
        "year": 2016,
        "name": "Black Rock Down",
        "hometown": "Reno",
        "description": "Located next to the crashed Black Rock City organization's helicopter, we welcome you to stop by our bar and commiserate and celebrate the last year of burning man!",
        "location": {
            "string": "7:30 & D",
            "frontage": "7:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.78639924266466,
            "gps_longitude": -119.21974624373193
        },
        "location_string": "7:30 & D"
    },
    {
        "uid": "a1Xd0000001IWkiEAG",
        "year": 2016,
        "name": "Trifucta",
        "url": "http://www.trifucta.com",
        "contact_email": "camptrifucta@gmail.com",
        "hometown": "New York City",
        "description": "Trifucta was born after three people in separate RV's decided to create community space by parking them in the shape of a triangle. From that small act, a community comprised of artists, builders, fashion designers and welders joined together to create connectivity through a common space that engages the playful creativity and expression inside each participant.",
        "location": {
            "string": "Esplanade & 7:45",
            "frontage": "Esplanade",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78729045887197,
            "gps_longitude": -119.21547118423358
        },
        "location_string": "Esplanade & 7:45"
    },
    {
        "uid": "a1Xd0000001IWOfEAO",
        "year": 2016,
        "name": "WMICC Organic Fruit & Veggie Bar",
        "url": "https://curiousadventure.com/wmicc/",
        "contact_email": "iheartwmicc@gmail.com",
        "hometown": "San Diego",
        "description": "The juiciest camp on the playa - providing endless organic fruits and veggies to dusty burners daily since 2011.",
        "location": {
            "string": "3:00 & K",
            "frontage": "3:00",
            "intersection": "K",
            "intersection_type": "&",
            "gps_latitude": 40.77605206370598,
            "gps_longitude": -119.19283623893406
        },
        "location_string": "3:00 & K"
    },
    {
        "uid": "a1Xd0000001IXKvEAO",
        "year": 2016,
        "name": "Camp EAT Me",
        "hometown": "San Francisco",
        "description": "Camp EAT Me is excited to bring the ultimate waffle experience to the playa in 2016!",
        "location": {
            "string": "D & 3:45",
            "frontage": "D",
            "intersection": "3:45",
            "intersection_type": "&",
            "gps_latitude": 40.777132727978795,
            "gps_longitude": -119.20143569224902
        },
        "location_string": "D & 3:45"
    },
    {
        "uid": "a1Xd0000001IWmPEAW",
        "year": 2016,
        "name": "Hope",
        "url": "http://www.camphope.rocks",
        "hometown": "Brooklyn, San Francisco, Boulder, Sydney, Paris, Tel Aviv, Hamburg, Berlin",
        "description": "Camp Hope offers coffee, cocktails, cookies, and chill space. Come inhabit our YOUTRUVIAN interactive sculpture and help us playfully implode the false notion of \"a perfect man\" by collectively declaring \"we are ALL perfect…perfect by virtue of our imperfections, our nuances, our very differences.\" Join our Self Love Ceremony on Thursday at dusk and commit to treating yourself with loving kindness. Or, stop by for some Bad Advice and Mediocre Booze with our international family!",
        "location": {
            "string": "B & 9:45",
            "frontage": "B",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79444946765153,
            "gps_longitude": -119.21090843559313
        },
        "location_string": "B & 9:45"
    },
    {
        "uid": "a1Xd0000001IXGFEA4",
        "year": 2016,
        "name": "Guildsville",
        "hometown": "All over the USA and Beyond",
        "description": "GuildsVille is where the doers and makers of the Renaissance reside.  We are the creators and operators of the Guild Work Shops.",
        "location": {
            "string": "B & 5:15",
            "frontage": "B",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77834809836258,
            "gps_longitude": -119.21090014146336
        },
        "location_string": "B & 5:15"
    },
    {
        "uid": "a1Xd0000001IV17EAG",
        "year": 2016,
        "name": "Queen Dick",
        "hometown": "London via SF",
        "description": "Lost? Tired? Thirsty? Looking for some company? Fancy a chin-wag? Want a good old knees-up? Don't know what knees-up means? Doesn't matter, step out of the desert and into our marvelous time and mind bending new-age-old-fashioned boozer the Queen Dick, and its village green, where anything and everything could happen, and maybe more.",
        "location": {
            "string": "F & 7:15",
            "frontage": "F",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.784913070481615,
            "gps_longitude": -119.22135388238645
        },
        "location_string": "F & 7:15"
    },
    {
        "uid": "a1Xd0000001IGZsEAO",
        "year": 2016,
        "name": "Abstininthe",
        "url": "http://abstininthe.tribe.net",
        "hometown": "Bay Area / Seattle",
        "description": "Abstininthe is the friendly bar on the playa, providing our special drink to the thirsty of BRC since the last millennium. Come try our many flavors and enjoy the music, ambiance and conversation of our neighborhood bar.",
        "location": {
            "string": "7:30 Plaza @ 3:30",
            "frontage": "7:30 Plaza",
            "intersection": "3:30",
            "intersection_type": "@",
            "gps_latitude": 40.77430877078314,
            "gps_longitude": -119.20606317181323
        },
        "location_string": "7:30 Plaza @ 3:30"
    },
    {
        "uid": "a1Xd0000001IX4dEAG",
        "year": 2016,
        "name": "SPANK-N-SPRAY",
        "hometown": "Santa Rosa",
        "description": "CAMP SPANK N SPRAY",
        "location": {
            "string": "7:30 & F",
            "frontage": "7:30",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.786399030993394,
            "gps_longitude": -119.2214834559928
        },
        "location_string": "7:30 & F"
    },
    {
        "uid": "a1Xd0000001IRM3EAO",
        "year": 2016,
        "name": "Shantitown",
        "description": "Shantitown delivers steaming hot, freshly baked pizzas directly to you. Simply call us on 1 (800) - PLAYA - PIZZA or  look out for one of our trusty delivery fairies to place your order and we'll deliver a piping hot pizza pie right to your doorstep. If you're of the cooking disposition and would like to help bake pizzas to make hungry tummies happy, come join us in the kitchen where, as Uncle Mario always says, \"It's-a-always-a-party-a-in-a-here!\".",
        "location": {
            "string": "J & 5:45",
            "frontage": "J",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775312035320134,
            "gps_longitude": -119.21773457027408
        },
        "location_string": "J & 5:45"
    },
    {
        "uid": "a1Xd0000001IREWEA4",
        "year": 2016,
        "name": "Heavy Metal Recess",
        "url": "https://www.facebook.com/groups/963233730438770/",
        "hometown": "Reno",
        "description": "Heavy Metal Recess - not what you are expecting (hopefully)",
        "location": {
            "string": "5:30 & Rod's Road",
            "frontage": "5:30",
            "intersection": "Rod's Road",
            "intersection_type": "&",
            "gps_latitude": 40.778986645391214,
            "gps_longitude": -119.21529477892375
        },
        "location_string": "5:30 & Rod's Road"
    },
    {
        "uid": "a1Xd0000001IVJwEAO",
        "year": 2016,
        "name": "Lovepusher",
        "hometown": "Oakland",
        "description": "Love Potion + Airpusher",
        "location": {
            "string": "7:00 & D",
            "frontage": "7:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.78380349492602,
            "gps_longitude": -119.21929438883451
        },
        "location_string": "7:00 & D"
    },
    {
        "uid": "a1Xd0000001ISyKEAW",
        "year": 2016,
        "name": "HeeBeeGeeBee Healers",
        "url": "http://www.heebeegeebeehealers.org",
        "contact_email": "scooter80302@yahoo.com",
        "hometown": "Boulder, SFO, NYC",
        "description": "BRC's premier healing oasis for 17 years.  Escape the chaos and take care of yourself with our staff of conventional and alternative healers - massage, acupuncture, chiropractic, energy and tantra.",
        "location": {
            "string": "6:00 & E",
            "frontage": "6:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77884267712845,
            "gps_longitude": -119.21647957055906
        },
        "location_string": "6:00 & E"
    },
    {
        "uid": "a1Xd0000001IQhsEAG",
        "year": 2016,
        "name": "Electro-Therapy Camp",
        "hometown": "Drums",
        "description": "Electro-Therapy Camp is a theme camp offering solar recharging services to the Black Roch City community during the Burning Man festival. Recharging services will be available 24/7 while we are on the playa.",
        "location": {
            "string": "H & 5:45",
            "frontage": "H",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.776355654907675,
            "gps_longitude": -119.21667735883563
        },
        "location_string": "H & 5:45"
    },
    {
        "uid": "a1Xd0000001IM5EEAW",
        "year": 2016,
        "name": "Dome on the Range",
        "url": "http://www.domeontherangecamp.com/",
        "contact_email": "domeontherange2015@gmail.com",
        "hometown": "San Francisco",
        "description": "Dome on the Range - you're local waterin' hole and \"Saloon'O'Sorts\", slangin' dancin' and dranks everyday from noon till sundown! Saddle up and come on down for an ol'fashioned Porch Party! The beer is cold, the jams are live, and we got a spot on The Stoop waitin for ya. Yeehaw!",
        "location": {
            "string": "6:30 & D",
            "frontage": "6:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.781384734418374,
            "gps_longitude": -119.21797071745584
        },
        "location_string": "6:30 & D"
    },
    {
        "uid": "a1Xd0000001IAytEAG",
        "year": 2016,
        "name": "DISCOnnect",
        "hometown": "Reno",
        "description": "As camp DISCOnect, we seek to derail people from their everyday routines through excessive socialization, delicious food, and light-hearted spanking. Spanks, Dranks, and Pancakes to start your mornings!",
        "location": {
            "string": "I & 6:15",
            "frontage": "I",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77829184442306,
            "gps_longitude": -119.22045280636702
        },
        "location_string": "I & 6:15"
    },
    {
        "uid": "a1Xd0000001IXmKEAW",
        "year": 2016,
        "name": "Camp Little Bitty",
        "hometown": "Santa Cruz",
        "description": "Smile like a child again! Come play with our grown-up sized version of popular children's toys, and relax in our pre-school!!!",
        "location": {
            "string": "J & 5:45",
            "frontage": "J",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775312035320134,
            "gps_longitude": -119.21773457027408
        },
        "location_string": "J & 5:45"
    },
    {
        "uid": "a1Xd0000001IXe6EAG",
        "year": 2016,
        "name": "Flying Puzzle",
        "url": "https://facebook.com/TheFlyingPuzzle/",
        "description": "This camp is about something...we're just not sure what. Come help us figure it out and be showered with hugs, hammock cuddles, drinks and beats. Let's do things together. Also, best kisser drinks for free!",
        "location": {
            "string": "J & 5:45",
            "frontage": "J",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775312035320134,
            "gps_longitude": -119.21773457027408
        },
        "location_string": "J & 5:45"
    },
    {
        "uid": "a1Xd0000001IXBZEA4",
        "year": 2016,
        "name": "GLAMCOCKS",
        "url": "http://www.glamcocks.com",
        "contact_email": "muffy@glamcocks.com",
        "hometown": "Seattle",
        "description": "We are a global gay family, driven by our boundless love for each other, our passion to create and give to others, and our celebration of life with a spirit of GLAM!",
        "location": {
            "string": "7:30 & B",
            "frontage": "7:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.786399428284064,
            "gps_longitude": -119.21800903146068
        },
        "location_string": "7:30 & B"
    },
    {
        "uid": "a1Xd0000001IYSoEAO",
        "year": 2016,
        "name": "BLD",
        "hometown": "San Francisco",
        "description": "The BLD Village",
        "location": {
            "string": "D & 5:45",
            "frontage": "D",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.77844010782815,
            "gps_longitude": -119.21455786933802
        },
        "location_string": "D & 5:45"
    },
    {
        "uid": "a1Xd0000001IMprEAG",
        "year": 2016,
        "name": "No Bikini Atoll",
        "url": "https://youtu.be/88QOmxSa-IE",
        "hometown": "Big Island of Hawaii",
        "description": "We offer passion fruit juice parties, elaborate dance performances, and morning meditations.  We enjoy sustaining and supporting our little tribe and the people around us. \r\n\r\n*Please note: At No Bikini Atoll we are against bikinis and we are against nuclear testing.  Did you know Bikini Atoll is the home to seven nuclear test sites? We say NO! And, if you come to our camp you don't need a bikini. You don't need a bikini at all.",
        "location": {
            "string": "G & 7:45",
            "frontage": "G",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78796556023548,
            "gps_longitude": -119.22221681630182
        },
        "location_string": "G & 7:45"
    },
    {
        "uid": "a1Xd0000001IYBFEA4",
        "year": 2016,
        "name": "Bliss Bucket",
        "url": "http://goo.gl/O8zyGX",
        "contact_email": "blissbucket@gmail.com",
        "hometown": "San Francisco",
        "description": "Find us out on the playa with our mobile ball pit party! If you don't see us, shout out RONNIE as loud as you can and we'll hear you.",
        "location": {
            "string": "J & 5:45",
            "frontage": "J",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775312035320134,
            "gps_longitude": -119.21773457027408
        },
        "location_string": "J & 5:45"
    },
    {
        "uid": "a1Xd0000001IXDGEA4",
        "year": 2016,
        "name": "Bat Carnival",
        "url": "http://www.facebook.com/TheBatCarnival",
        "contact_email": "beckinstein@gmail.com",
        "hometown": "Vallejo",
        "description": "Our camp is one part motley stable of stick ponies and one part ooky-spooky carnival games of chance. We have have bats in our belfry and tricks up our sleeves.",
        "location": {
            "string": "5:30 & H",
            "frontage": "5:30",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.775435767983616,
            "gps_longitude": -119.21485895427396
        },
        "location_string": "5:30 & H"
    },
    {
        "uid": "a1Xd0000001IXFREA4",
        "year": 2016,
        "name": "Mansonian Institute Urban Studies",
        "contact_email": "mansonian@att.net",
        "hometown": "San Francisco",
        "description": "The Mansonian Institute of Urban Studies celebrates the history of the Man through humorous art and charts depicting current and previous themes with information.  Stop by to learn Burningman history and see our take on its many varied themes.",
        "location": {
            "string": "6:30 & E",
            "frontage": "6:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.78105582486477,
            "gps_longitude": -119.21872283512668
        },
        "location_string": "6:30 & E"
    },
    {
        "uid": "a1Xd0000001IWmeEAG",
        "year": 2016,
        "name": "Filthiest Camp Alive",
        "hometown": "San Francisco / The World",
        "description": "We're here to steal the headline of most filthy camp. We're disgustingly dirty...in the best ways.",
        "location": {
            "string": "I & 6:15",
            "frontage": "I",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77829184442306,
            "gps_longitude": -119.22045280636702
        },
        "location_string": "I & 6:15"
    },
    {
        "uid": "a1Xd0000001IXFbEAO",
        "year": 2016,
        "name": "Camp Canadianderthal",
        "contact_email": "benjaminstrub@gmail.com",
        "hometown": "Winnipeg",
        "description": "PHISH phrenzy! We're back for our fourth year with an all new set list. Join us in our piano lounge on Thursday at 1:00 p.m. for an epic live Phish jam. Pound your Northern neighbors in our life-size Whack-Ca-Nuck game (you know you always wanted to). Need a hat? Pick out a dandy from our Chapeaupourri. Contribute to the Tattletale Project - tell us when \"telling\" is responsible and when it's just straight-up tattling.",
        "location": {
            "string": "I & 5:45",
            "frontage": "I",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775833846319884,
            "gps_longitude": -119.21720596870679
        },
        "location_string": "I & 5:45"
    },
    {
        "uid": "a1Xd0000001ISNEEA4",
        "year": 2016,
        "name": "Irrelephant Bird Camp",
        "url": "https://www.facebook.com/elephantbirdcamp/?fref=ts",
        "contact_email": "spirit_tamer@chakras.horse",
        "hometown": "Bay Area",
        "description": "From the dust and destruction of Elephant Bird Camp and Grandma's Camp comes Irrelephant Bird Camp. Grahama's last, dying wish was for Elephant Bird Camp to return to the playa and with it bring dorkier, sillier, funkier, messier, and even more friendly-er people and events, but with more Irr than ever before.",
        "location": {
            "string": "7:00 & B",
            "frontage": "7:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.78414410068907,
            "gps_longitude": -119.21761649320165
        },
        "location_string": "7:00 & B"
    },
    {
        "uid": "a1Xd0000001IMUnEAO",
        "year": 2016,
        "name": "Pookah Lounge",
        "hometown": "LosGatosSantaCruzRenoCanadaTexasMacedoniaHawaii",
        "description": "POOKAH LOUNGE: GET UP! GET DOWN! GET SNAFUBARRRED... RINSE & REPEAT!",
        "location": {
            "string": "G & 7:15",
            "frontage": "G",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78483230749839,
            "gps_longitude": -119.22221607478929
        },
        "location_string": "G & 7:15"
    },
    {
        "uid": "a1Xd0000001IXFgEAO",
        "year": 2016,
        "name": "Giraffe Family",
        "contact_email": "familyofgiraffes@gmail.com",
        "hometown": "San Francisco",
        "description": "Giraffe Family is back this year with our Savannah Gym, a 20' steel cube for free climbing day and night, a cuddle puddle net suspended 15' in the air, and a misting system beneath it to cool off. Come by and grab a drink at our craft beer watering hole to quench your thirst in the loftiest way possible.",
        "location": {
            "string": "D & 6:45",
            "frontage": "D",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78255670886589,
            "gps_longitude": -119.2187345746424
        },
        "location_string": "D & 6:45"
    },
    {
        "uid": "a1Xd0000001IVndEAG",
        "year": 2016,
        "name": "Skrambles**!*",
        "hometown": "Champaign (but relocating to DC in late Sept.)",
        "description": "Born from confusion and tempered by mild incompetence. Home of the world famous \"Now we dance! Now we fight!\" Dance/Fight party. Absolutely no eggs. All hail String.",
        "location": {
            "string": "A & 8:45",
            "frontage": "A",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.791300695156856,
            "gps_longitude": -119.21494555440992
        },
        "location_string": "A & 8:45"
    },
    {
        "uid": "a1Xd0000001IJTdEAO",
        "year": 2016,
        "name": "Burntown Snuff Guild",
        "url": "http://burntown.ajpn.com/",
        "contact_email": "rojoboy@hotmail.com",
        "hometown": "Auburn/Grass Valley",
        "description": "Burntown Snuff Guild offers fine nasal snuffs, DRY CLEANING, and a trip across our Rope Bridge of Death....and, a Corner Store that is not to be missed!  All day, some late nights...come find out what tobacco and other non-tobacco snuff can do for your burn!",
        "location": {
            "string": "7:30 Plaza @ 6:30",
            "frontage": "7:30 Plaza",
            "intersection": "6:30",
            "intersection_type": "@",
            "gps_latitude": 40.77406672632106,
            "gps_longitude": -119.2066169479502
        },
        "location_string": "7:30 Plaza @ 6:30"
    },
    {
        "uid": "a1Xd0000001IXLKEA4",
        "year": 2016,
        "name": "Mamasaurus",
        "hometown": "San Francisco",
        "description": "A technicolor land before time, featuring an interactive Mamasaurus sculpture, a jurassic chill area, and beats. Come relax in our dino pit, complete with giant plush dino eggs, or check out our annual \"Dino Eats, Beats, and Drinks\" party.",
        "location": {
            "string": "A & 4:15",
            "frontage": "A",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77841240608523,
            "gps_longitude": -119.20511263592279
        },
        "location_string": "A & 4:15"
    },
    {
        "uid": "a1Xd0000001IXM3EAO",
        "year": 2016,
        "name": "ABR (Actually Being Renamed)",
        "contact_email": "abralaplaya@googlegroups.com",
        "hometown": "San Francisco/Oakland",
        "description": "ABR is a tight-knit group of weird people whose values stem from a strong foundation of cooperative living, self-reliance, and responsibility. Our camp encourages playfulness, creativity, and exploration, and provides a casual social space for burners old and new alike.",
        "location": {
            "string": "H & 4:15",
            "frontage": "H",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77384823164088,
            "gps_longitude": -119.20431792720447
        },
        "location_string": "H & 4:15"
    },
    {
        "uid": "a1Xd0000001IXDaEAO",
        "year": 2016,
        "name": "Time To Burn",
        "url": "https://www.facebook.com/TimeToBurnApp/",
        "contact_email": "timetoburnapp@gmail.com",
        "hometown": "San Diego",
        "description": "The \"Must Have App\" camp returns for high-tech workshops, gifting, and shenanigans.  Come by and get a PIPSIE!"
    },
    {
        "uid": "a1Xd0000001IVIjEAO",
        "year": 2016,
        "name": "Arrow Dynamic",
        "contact_email": "snugglefacechelsea@gmail.com",
        "hometown": "Grass Valley",
        "description": "Come enjoy our bar during the day! We have a confessional where you can come confess your dirty secrets and spin the wheel to receive your fate. Come hang out! We will have lots of random entertainment. We supply welding services and bike repair, as well.",
        "location": {
            "string": "9:30 & A",
            "frontage": "9:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.79337692443453,
            "gps_longitude": -119.21182077171073
        },
        "location_string": "9:30 & A"
    },
    {
        "uid": "a1Xd0000001IUyPEAW",
        "year": 2016,
        "name": "Enchanted Booty Village",
        "hometown": "Los Angeles",
        "description": "The Enchanted Booty Forest delivers exactly what it promises: enchantment, relaxing shade, and gloriously heavenly booty.",
        "location": {
            "string": "E & 9:45",
            "frontage": "E",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79627201074232,
            "gps_longitude": -119.21190658406445
        },
        "location_string": "E & 9:45"
    },
    {
        "uid": "a1Xd0000001IXUaEAO",
        "year": 2016,
        "name": "Camp88",
        "hometown": "Washington",
        "description": "\"88\" is inspired by the many traditions that have found meaning in the number eight: the Buddhist eight-fold path toward the end of suffering; the Judeo-Christian notion that 7+1= a new paradigm, a call to move our planet in a better direction; the universal and mathematical symbol for infinity—if you flip that 8 on the side, you've got infinite possibilities... nothing can hold us back. Why two 8's? Because you can never achieve monumental changes on your own."
    },
    {
        "uid": "a1Xd0000001ISkIEAW",
        "year": 2016,
        "name": "Boonville Cabaret",
        "hometown": "Boonville",
        "description": "Boonville Cabaret.  Your destination for spontaneous theatrical performance. A small venue for you to realize your fabulous talents. Come visit daytime and/or Thursday eve at sunset. Intimate stage and appreciative audience provided.",
        "location": {
            "string": "B & 8:45",
            "frontage": "B",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79170076257172,
            "gps_longitude": -119.21563500580646
        },
        "location_string": "B & 8:45"
    },
    {
        "uid": "a1Xd0000001IOAfEAO",
        "year": 2016,
        "name": "BuddhaCamp at the Lotus Dome",
        "url": "https://buddhacamp.wordpress.com/",
        "contact_email": "bccruisedirector@gmail.com",
        "hometown": "Seattle",
        "description": "Every human being can manifest their ultimate potential and live a life of true happiness through chanting Nam Myoho Renge Kyo. Come learn and play with us at the Lotus Dome.\r\n\r\nEveryone is invited to stretch their body in yoga class, their mind in discussion, and their spirit in chanting. Enjoy fresh roasted espresso or cold herbal iced tea in our Moroccan cafe, and while away your day in the shade as you find your inner Buddha.",
        "location": {
            "string": "5:00 & E",
            "frontage": "5:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77607703461826,
            "gps_longitude": -119.21015262425809
        },
        "location_string": "5:00 & E"
    },
    {
        "uid": "a1Xd0000001IOwmEAG",
        "year": 2016,
        "name": "Camp Hot Mayo",
        "url": "https://www.facebook.com/Camp-Hot-Mayo-283651174985176/",
        "contact_email": "badassmotherucker@yahoo.com",
        "hometown": "We are based out of Sparks, Nevada.  Most of our camp mates live in this region.  We have several other camp mates from around the world to include, Australia, New Zealand, England, Japan other cities within the United States.",
        "description": "Camp Hot Mayo is ready for another wonderful year at Burning Man.  Please come by for a beer or Daily Drinks at our glorious bar.  We will be serving canned Beer everyday and a Daily Drink (usually something tied to the theme of the day).  Our annual Irish Car Bomb party will be mobile this year.  We plan on taking it our on the playa for the first time ever.  Also, our annual Sangria party on Friday will be as big as ever.  Come by to play some Basketball or Dirty Jenga or join in our first ever Horse Race, by either betting on the race or being a part of the race.",
        "location": {
            "string": "5:00 & D",
            "frontage": "5:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.776712297351594,
            "gps_longitude": -119.20992788016152
        },
        "location_string": "5:00 & D"
    },
    {
        "uid": "a1Xd0000001IXIBEA4",
        "year": 2016,
        "name": "Awesome!(ville)",
        "hometown": "Lake Tahoe",
        "description": "The home of spontaneous Awesome!(ness) and upcycling craftyness, providing and inviting music, art, performances, and good times.  Come for the daily happy hour, and don't miss the Tahoe Block Party on Thursday!",
        "location": {
            "string": "D & 8:45",
            "frontage": "D",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79250090223318,
            "gps_longitude": -119.21701391692622
        },
        "location_string": "D & 8:45"
    },
    {
        "uid": "a1Xd0000001IQJfEAO",
        "year": 2016,
        "name": "Camp Brewhaha",
        "description": "Kamp BrewHaha - from 7-11 each morning we provide freshly brewed coffee, banter, good humor and even better people; old school coffee house of the first order, out in the peaceful suburbs of BRC.",
        "location": {
            "string": "I & 5:45",
            "frontage": "I",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.775833846319884,
            "gps_longitude": -119.21720596870679
        },
        "location_string": "I & 5:45"
    },
    {
        "uid": "a1Xd0000001IWOaEAO",
        "year": 2016,
        "name": "Camp Bang Bang",
        "url": "http://www.campbangbang.com",
        "contact_email": "campbangbang@gmail.com",
        "hometown": "Sydney",
        "description": "Camp Bang Bang is a community of open hearted and open armed adventurers from Australia and around the Globe. We welcome you to our playground of Wild & Risky casino games, music, dancing, Aussie-ness and Kaleidoscopes. Scale our Viewing Tower, Climb into our Harmony Hammocks, zone out in our Kaleidoscope and Chill Room, dare to RISK something at our 'daily' Casino Saloon and Cocktail Lounge or just come for a boogie at our Wednesday Wild Animal Party. Miss that? Friday \"Its Everyones Birthday on the Playa\"  'Canez and Zimmerframes' party.",
        "location": {
            "string": "9:00 & J",
            "frontage": "9:00",
            "intersection": "J",
            "intersection_type": "&",
            "gps_latitude": 40.796281355415935,
            "gps_longitude": -119.21955363512441
        },
        "location_string": "9:00 & J"
    },
    {
        "uid": "a1Xd0000001IXRXEA4",
        "year": 2016,
        "name": "Burnstream Court",
        "url": "http://www.burnstreamcourt.com",
        "contact_email": "burnstreamcourt@gmail.com",
        "hometown": "Grass Valley CA (Also Weed CA, Portland OR, Reno NV, San Anselmo CA, Kerrville TX, San Jose CA, high up in the Rockies in CO, plus more)",
        "description": "Burnstream Court's 14th year on the playa is dedicated to Airstream affectionados!\r\nWe have Airstream tours, photos opps, art tours for the disabled (in our open trailer), fun & games & grilled cheese LOVE!\r\nWe would love to have you hang out with us in our trailer park, burner-style.",
        "location": {
            "string": "K & 3:15",
            "frontage": "K",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77479022190847,
            "gps_longitude": -119.19473683646231
        },
        "location_string": "K & 3:15"
    },
    {
        "uid": "a1Xd0000001IWQlEAO",
        "year": 2016,
        "name": "Camp Fuck Yeah",
        "hometown": "Lake Tahoe",
        "location": {
            "string": "E & 8:45",
            "frontage": "E",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.792900974479906,
            "gps_longitude": -119.21770337664968
        },
        "location_string": "E & 8:45"
    },
    {
        "uid": "a1Xd0000001IX31EAG",
        "year": 2016,
        "name": "Camp Hellnback",
        "url": "http://www.camphellnback.com/",
        "contact_email": "claymore@camphellnback.com",
        "hometown": "Gerlach",
        "description": "Camp Hellnback- Military veterans use art and discussion to share their stories, and perspective of combat and their transition home. Visitors are welcome to pull up a chair and join the conversation.",
        "location": {
            "string": "9:00 & D",
            "frontage": "9:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.79349147469058,
            "gps_longitude": -119.215867509203
        },
        "location_string": "9:00 & D"
    },
    {
        "uid": "a1Xd0000001IX1oEAG",
        "year": 2016,
        "name": "Flirt Camp",
        "url": "http://www.flirtcampsf.com",
        "contact_email": "campmaster@flirtcampsf.com",
        "hometown": "San Francisco",
        "description": "Flirt Camp is back!\r\nCome by and chill in our lounge and enjoy the flirty energy that just keeps getting better and better!!",
        "location": {
            "string": "F & 9:15",
            "frontage": "F",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79539677754363,
            "gps_longitude": -119.21562791691271
        },
        "location_string": "F & 9:15"
    },
    {
        "uid": "a1Xd0000001IXPvEAO",
        "year": 2016,
        "name": "Home Rule Village",
        "hometown": "Washington",
        "description": "Now in our sixth year on playa, Home Rule Village is committed to engaging BRC denizens in novel forms of expression, exploration, relaxation and connection. Six unique camps combine to offer a wildly diverse experience, including an array of workshops, seminars, dance parties, vaudeville shows, improve comedy classes, holistic healing, diversity-awareness events, yoga practice, body painting classes, blind taste-testing dinners, fire spinning and more!",
        "location": {
            "string": "F & 4:45",
            "frontage": "F",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.775152166800886,
            "gps_longitude": -119.20845363458552
        },
        "location_string": "F & 4:45"
    },
    {
        "uid": "a1Xd0000001INXmEAO",
        "year": 2016,
        "name": "Geisha House",
        "hometown": "Oakland",
        "description": "Evening ramen and midnight coffee - our traditional geisha house relaxation any time you like!",
        "location": {
            "string": "C & 8:15",
            "frontage": "C",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.78998145273607,
            "gps_longitude": -119.2179383169208
        },
        "location_string": "C & 8:15"
    },
    {
        "uid": "a1Xd0000001IQlUEAW",
        "year": 2016,
        "name": "Home Camp presents Laserbrite",
        "hometown": "San Franscisco",
        "description": "Home Camp presents: Laser Brite\r\nAn amazing laser light experience in a space that feels like coming )^(ome. Play with the giant Lite Brite, chill to dreamy music and laser light shows and ride the magic carpet art car - need we say more?",
        "location": {
            "string": "G & 9:15",
            "frontage": "G",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79592173502304,
            "gps_longitude": -119.21615150802292
        },
        "location_string": "G & 9:15"
    },
    {
        "uid": "a1Xd0000001IXWlEAO",
        "year": 2016,
        "name": "HomeSlice",
        "url": "http://www.camphomeslice.org/",
        "hometown": "Altadena",
        "description": "Drop in for a cheerful \"Slice of Home\"—Playa-style.  Participate in our comfort-food cook-offs, climb the sky-high HomeSlice Tower's inverted pyramids, or re-engineer your Playa duds and gear at our Radical Alteration clinics.",
        "location": {
            "string": "4:30 Plaza @ 3:15",
            "frontage": "4:30 Plaza",
            "intersection": "3:15",
            "intersection_type": "@",
            "gps_latitude": 40.77435275514857,
            "gps_longitude": -119.20605201176389
        },
        "location_string": "4:30 Plaza @ 3:15"
    },
    {
        "uid": "a1Xd0000001IWUYEA4",
        "year": 2016,
        "name": "Dragon Clan",
        "contact_email": "dragonclanbrc@gmail.com",
        "hometown": "San Francisco to Santa Cruz, Built in Redwood City, CA",
        "description": "Dragon Clan is a camp themed on fire and flight.  Join us to practice and perform fire arts in our performance space, learn about the joy and experience of ultralite flight, or just seek shelter beneath the wings of our dragon, climb up into our nest or just hang with us in our lizard lounge.",
        "location": {
            "string": "5:00 & G",
            "frontage": "5:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.77480650784362,
            "gps_longitude": -119.2106020995571
        },
        "location_string": "5:00 & G"
    },
    {
        "uid": "a1Xd0000001IXKWEA4",
        "year": 2016,
        "name": "Champagne Campaign",
        "contact_email": "champagnecampaigncamp@gmail.com",
        "hometown": "Seattle",
        "description": "Champagne Campaign will be hosting daily debates on diverse and fun topics while providing champagne! We also invite you to swing by before sunrise and fill up on champagne before joining us in front of the temple for a sunrise toast to the new day!",
        "location": {
            "string": "D & 8:15",
            "frontage": "D",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79023278937556,
            "gps_longitude": -119.21874102697954
        },
        "location_string": "D & 8:15"
    },
    {
        "uid": "a1Xd0000001IMTaEAO",
        "year": 2016,
        "name": "Declusterfuqerization v3",
        "hometown": "Reno, Nevada (mostly), with a couple from Salt Lake City, Utah, and California",
        "description": "Say hello to Declusterfuqerization v3! We are back and better than ever with a revamped climbing wall, a trampoline, slacklines, and a bar serving the best Not-Piss on the playa!  Come boogie, scramble, and make questionable decisions with your favorite fuqs!",
        "location": {
            "string": "G & 2:45",
            "frontage": "G",
            "intersection": "2:45",
            "intersection_type": "&",
            "gps_latitude": 40.7790927246996,
            "gps_longitude": -119.1939250969776
        },
        "location_string": "G & 2:45"
    },
    {
        "uid": "a1Xd0000001IC9kEAG",
        "year": 2016,
        "name": "Get-Your-Hair-Did Café & Products",
        "hometown": "New York",
        "description": "A place for people of all ages, ethnicities and lifestyles to sit for a spell and have an alcoholic or non-alcoholic drink! Also, we are giving away hair products for Black People! All others are encouraged to bring your own hair products and use our mirrors to create fabulous hairstyles. We encourage conversation and meeting new people, and obviously, interesting hair.",
        "location": {
            "string": "4:00 & B",
            "frontage": "4:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.77798282151022,
            "gps_longitude": -119.20352162092674
        },
        "location_string": "4:00 & B"
    },
    {
        "uid": "a1Xd0000001IQRoEAO",
        "year": 2016,
        "name": "Let it Go",
        "contact_email": "bniemi03@gmail.com",
        "hometown": "Seattle",
        "description": "At \"Let it Go\" we would like to provide a space where people can feel comfortable to let go regardless of their cultural background or spiritual beliefs.  Come to our tea lounge and let go of that which does not serve you.  We offer a variety of meditation, martial arts, dance, reiki, arts & crafts, and flow classes, come visit our camp for an up to date schedule of our workshops.  Need a place to reconnect with the infinite?  Come visit our lotus dome.",
        "location": {
            "string": "D & 5:15",
            "frontage": "D",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77713272797879,
            "gps_longitude": -119.21156430775099
        },
        "location_string": "D & 5:15"
    },
    {
        "uid": "a1Xd0000001IXB5EAO",
        "year": 2016,
        "name": "Mirage Garage",
        "url": "https://www.facebook.com/psycloneloveswhensquiddiessheikdjibouti/",
        "hometown": "New York",
        "description": "Mirage Garage is an interactive, futuristic mechanic's den looming up out of a vision in the desert. Discover the secrets of invention and reinvention in an imaginative cabinet of curiosities.",
        "location": {
            "string": "9:00 Public Plaza & 8:45",
            "frontage": "9:00 Public Plaza",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79283288692738,
            "gps_longitude": -119.21436354175313
        },
        "location_string": "9:00 Public Plaza & 8:45"
    },
    {
        "uid": "a1Xd0000001IDLmEAO",
        "year": 2016,
        "name": "Vamp Camp",
        "url": "https://www.facebook.com/groups/VampCamp/",
        "hometown": "Gardnerville",
        "description": "Vamp Camp. A classic tradition of vamp juice, music, burn barrel and if deserved, a vamp stamp! We only come out at night. (unless we wake up early) No schedules, No commitments.",
        "location": {
            "string": "4:30 Plaza @ 7:00",
            "frontage": "4:30 Plaza",
            "intersection": "7:00",
            "intersection_type": "@",
            "gps_latitude": 40.77410089048719,
            "gps_longitude": -119.20672596719892
        },
        "location_string": "4:30 Plaza @ 7:00"
    },
    {
        "uid": "a1Xd0000001IQRPEA4",
        "year": 2016,
        "name": "The Hunting Party",
        "url": "http://thehuntingparty.us",
        "contact_email": "jnguyen72086@gmail.com",
        "hometown": "Boulder",
        "description": "A\r\nHunting party\r\nSometimes has a greater chance\r\nOf flushing love and God\r\nOut into the open\r\nThan a warrior\r\nAll\r\nAlone.\r\n\r\n-  Hafiz\r\n\r\nThe Hunting Party is where movement and magic swirl wild forms in the dust. Exploring the mystical realms within and without, we stalk the many-faced prey of the One - we are the flock and the fledging, the church and the people, the dungeon and the steeple. We explore the ever-emerging edge of intimate truth and togetherness. Before, during, and after, we dance.\r\n\r\nBy day, we play with reverent abandon and reckless devotion in honor of each other - and what we create when we turn our heartbeams to a dynamic and fluid center. We serve homemade kimchi by the arched fingerful and deliver fresh, happy juices into keen mouths. By night, we play with spontaneity and serendipity, drunk only on the magic of connection and juice. The dome becomes a place to mellow out and venture into the frontierlands of mind, body, and spirit where we, the Hunting Party seek the We in You.",
        "location": {
            "string": "C & 3:15",
            "frontage": "C",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.778962057935686,
            "gps_longitude": -119.19897050537821
        },
        "location_string": "C & 3:15"
    },
    {
        "uid": "a1Xd0000001IXFlEAO",
        "year": 2016,
        "name": "Nakked Zebra Bazaar",
        "hometown": "Rocklin",
        "description": "Nakked Zebra Bazaar costumer and chill party zone.",
        "location": {
            "string": "3:00 & K",
            "frontage": "3:00",
            "intersection": "K",
            "intersection_type": "&",
            "gps_latitude": 40.77605206370598,
            "gps_longitude": -119.19283623893406
        },
        "location_string": "3:00 & K"
    },
    {
        "uid": "a1Xd0000001IV6gEAG",
        "year": 2016,
        "name": "Parasol Mafia",
        "url": "https://www.facebook.com/ParasolMafia/",
        "contact_email": "parasolmafia.inc@gmail.com",
        "hometown": "Portland / Eugene  / Seattle",
        "description": "Parasol Mafia is dedicated to helping you energize and sustain your body, heart, and mind. Enjoy our 24-hour Self Care Emporium with essentials like sunscreen, earplugs, chilled water, and other sustenance; groove with us at our reggae/ska happy hours; decorate and keep a parasol; revitalize yourself in our covered domes with guided workshops and comfortable seating; get funky at our night time dance parties. Love yourself, it's an offer you can't refuse!",
        "location": {
            "string": "4:00 & F",
            "frontage": "4:00",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.77544177144894,
            "gps_longitude": -119.20262263594348
        },
        "location_string": "4:00 & F"
    },
    {
        "uid": "a1Xd0000001IWQbEAO",
        "year": 2016,
        "name": "OKNOTOK",
        "url": "http://oknotok.com",
        "contact_email": "info@oknotok.com",
        "hometown": "Los Angeles",
        "description": "OKNOTOK is a playa social club featuring a wide range of events happening all day and night, every day and night. Our 30 foot tall Human Tower offer great views with great seating.",
        "location": {
            "string": "3:00 & D",
            "frontage": "3:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.77930776797406,
            "gps_longitude": -119.19713449128632
        },
        "location_string": "3:00 & D"
    },
    {
        "uid": "a1Xd0000001IRIpEAO",
        "year": 2016,
        "name": "Toxic Disco Clam",
        "hometown": "San Francisco",
        "description": "In the default world, the Toxic Disco Clam is a real aquatic creature - it uses a sparkling lighted exterior to attract other fish... and then it immobilizes them with acidic snot. We're pretty much the same: we draw you in with dazzling lights and entertaining activities, we ply you with our intoxicating beverages, and we hope you never leave (we promise less snot).",
        "location": {
            "string": "C & 4:15",
            "frontage": "C",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.7771083101538,
            "gps_longitude": -119.20488612768166
        },
        "location_string": "C & 4:15"
    },
    {
        "uid": "a1Xd0000001IWTBEA4",
        "year": 2016,
        "name": "White Trash Superstars",
        "url": "https://www.facebook.com/White-Trash-Superstars-174384205941598/",
        "contact_email": "white_trash_superstars@yahoo.com",
        "hometown": "Reno",
        "description": "We are your BRC neighborhood dive bar. Come join us for some drinks in the shade with some different tunes and fun games.  Bring your own cup for pimp-my-cup, and a a t-shirt for White Trash Screen Printing!  You might even get some of our awesome White Trash Swag.\r\n\r\nThis is our vacation too, so our bartenders are not always on their best behavior. This makes everything so much more fun! Besides drinks, we serve anything from love to snarky attitude, so you never know what you are going to get!",
        "location": {
            "string": "Esplanade & 3:00 Portal",
            "frontage": "Esplanade",
            "intersection": "3:00 Portal",
            "intersection_type": "&",
            "gps_latitude": 40.781555661173314,
            "gps_longitude": -119.2001025780959
        },
        "location_string": "Esplanade & 3:00 Portal"
    },
    {
        "uid": "a1Xd0000001IWFOEA4",
        "year": 2016,
        "name": "Illumination Village",
        "url": "http://www.illuminationvillage.org",
        "hometown": "San Francisco",
        "description": "\"A Drinking Village with a Fire Problem:\" Celebrating 20 continuous years in 2016, Illumination Village is one of BRC's oldest villages, bringing classic fire art to the esplanade, and total mayhem to the people of Burning Man!",
        "location": {
            "string": "Esplanade & 3:30",
            "frontage": "Esplanade",
            "intersection": "3:30",
            "intersection_type": "&",
            "gps_latitude": 40.78046704889989,
            "gps_longitude": -119.20197641373306
        },
        "location_string": "Esplanade & 3:30"
    },
    {
        "uid": "a1Xd0000001IM4aEAG",
        "year": 2016,
        "name": "The Princess Palace",
        "hometown": "Denver, CO",
        "description": "Come and gather at the Princess Palace. Our camp hosts Wedding Dress Wednesday with the Princess. We invite everyone to come play dress-up with Prince S. Stephanie.  We bring a closet of over 500+ wedding dresses for you to choose from.   We also host a Pink Panty and Pink Lemonade Bar where you can get a new pair of pink panties.  Or please choose to relax with one of our Morning Yoga Sessions.  Our camp is also home to the Steampunk Airplane Art Car \"Deep Cycle\".   Stop by only during the day.. because at night we are out dancing.",
        "location": {
            "string": "I & 6:15",
            "frontage": "I",
            "intersection": "6:15",
            "intersection_type": "&",
            "gps_latitude": 40.77829184442306,
            "gps_longitude": -119.22045280636702
        },
        "location_string": "I & 6:15"
    },
    {
        "uid": "a1Xd0000001IWOQEA4",
        "year": 2016,
        "name": "Rainbow OASIS",
        "hometown": "San Francisco",
        "description": "RAINBOW OASIS: where every color of the rainbow comes to relax, rewind, and refresh!  Come straight, come gay, we don't care just come thirsty!",
        "location": {
            "string": "B & 8:15",
            "frontage": "B",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.78973011696535,
            "gps_longitude": -119.21713560963664
        },
        "location_string": "B & 8:15"
    },
    {
        "uid": "a1Xd0000001IWXrEAO",
        "year": 2016,
        "name": "Sunset Trip",
        "contact_email": "info@campcharlie.org",
        "hometown": "Los Angeles",
        "description": "The Sunset Trip is a mashup of 3 Los Angeles based camps with a concurrent theme of getting together and throwing epic parties. We are all vastly different in what we provide to the world, yet share the same values and deep rooted awesomeness that bring us together year after year. We bring the Dirty, Sparkle and Bad.",
        "location": {
            "string": "8:30 & G",
            "frontage": "8:30",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.79240038197383,
            "gps_longitude": -119.22022952927168
        },
        "location_string": "8:30 & G"
    },
    {
        "uid": "a1Xd0000001IWRAEA4",
        "year": 2016,
        "name": "¡Playasos!",
        "url": "http://www.playasos.com",
        "hometown": "San Francisco",
        "description": "Welcome to ¡Playasos!, a light-hearted and inclusive community with a love for play, spontaneity, and exploration. Come experience Señor Snail von Slidesmouth, the Tunnel of Snailscendence, Chez 'Cargot, and Electric Stationary Joust. Fun for all ages.",
        "location": {
            "string": "9:00 Portal & 9:00 Portal",
            "frontage": "9:00 Portal",
            "intersection": "9:00 Portal",
            "intersection_type": "&"
        },
        "location_string": "9:00 Portal & 9:00 Portal"
    },
    {
        "uid": "a1Xd0000001IEHhEAO",
        "year": 2016,
        "name": "Nipple Crime",
        "url": "https://www.facebook.com/groups/1597975180414108/?ref=br_tf",
        "contact_email": "reece1019@gmail.com",
        "hometown": "Reno",
        "description": "Nipple Crime is a interactive sexy camp that brings old and young alike together for one hellofva experience.",
        "location": {
            "string": "I & 9:15",
            "frontage": "I",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.796965163936136,
            "gps_longitude": -119.21720937584996
        },
        "location_string": "I & 9:15"
    },
    {
        "uid": "a1Xd0000001IXNfEAO",
        "year": 2016,
        "name": "Salty",
        "url": "http://www.campsalty.com",
        "hometown": "SF, LA, Boise, Seattle, NYC",
        "description": "Camp Salty:  Day and night we are the local deep dive bar of the 9:00 neighborhood.  Nautical, underwater themed, we are your safe haven from the fervor of the playa playing R&B, Soul, Blues, Electro-swing, Hip Hop, and Disco.",
        "location": {
            "string": "9:00 & E",
            "frontage": "9:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.793956462957034,
            "gps_longitude": -119.21648184200953
        },
        "location_string": "9:00 & E"
    },
    {
        "uid": "a1Xd0000001IX7IEAW",
        "year": 2016,
        "name": "Zero Fucks",
        "contact_email": "info@zerofucks.de",
        "hometown": "San Francisco",
        "description": "Shed every last fuck you have with us at Camp Zero Fucks, hang your fuck for all to see, and shake off any residual worries you have on our shaded dance floor.",
        "location": {
            "string": "8:30 & A",
            "frontage": "8:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.79042783320644,
            "gps_longitude": -119.2157154376413
        },
        "location_string": "8:30 & A"
    },
    {
        "uid": "a1Xd0000001IT9kEAG",
        "year": 2016,
        "name": "Swing City",
        "url": "http://scbrc.us/",
        "contact_email": "swingcityops@gmail.com",
        "hometown": "Santa Monica",
        "description": "Direct from the Original Muscle Beach in Santa Monica California for the 7th year we provide the playground you provide the fun!",
        "location": {
            "string": "9:00 Public Plaza @ 1:30",
            "frontage": "9:00 Public Plaza",
            "intersection": "1:30",
            "intersection_type": "@",
            "gps_latitude": 40.79221895577871,
            "gps_longitude": -119.21463882744881
        },
        "location_string": "9:00 Public Plaza @ 1:30"
    },
    {
        "uid": "a1Xd0000001IVE3EAO",
        "year": 2016,
        "name": "Red Lightning",
        "url": "http://www.redlightning.org",
        "contact_email": "registration@redlightning.org",
        "hometown": "Los Angeles",
        "description": "Red Lightning - Civilization like it's never been done before\r\n\r\nRed Lightning 2016 is a sublime, sacred space supporting You to align your mind, body, soul and spirit with the greater evolutionary intelligence of Gaia.  As a chosen family, we believe in our power to co-create civilization like it's never been done before.  \r\n\r\nIn the last 7 years, we have created a template for a new paradigm of human relationship, spirituality and creativity.  This year, we bring our focus to the architecture of an enlightened civilization, activating the New Story that is waiting to be lived by humanity at this time.  We stand for lasting systemic change in alignment with the Ancient Future.  We invite all co-creators of evolutionary relationship, community, technology, economy, spirituality and culture to join us in the Great Work of building a more beautiful world together.",
        "location": {
            "string": "Esplanade & 8:15",
            "frontage": "Esplanade",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.78901800366581,
            "gps_longitude": -119.2148612873982
        },
        "location_string": "Esplanade & 8:15"
    },
    {
        "uid": "a1Xd0000001IV7eEAG",
        "year": 2016,
        "name": "Servants of the Secret Fire",
        "url": "http://se.cretfi.re",
        "hometown": "San Francisco",
        "description": "\"You cannot pass,\" he said. \"I am a servant of the Secret Fire, wielder of the flame of Anor. You cannot pass. The dark fire will not avail you, flame of Udûn. Go back to the Shadow! You cannot pass.\" \r\n\r\nJoin our community of wizards for magical potions, acquire mystical knowledge, and  learn to wield the power of fire!",
        "location": {
            "string": "B & 9:15",
            "frontage": "B",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.793310525070154,
            "gps_longitude": -119.21351125468065
        },
        "location_string": "B & 9:15"
    },
    {
        "uid": "a1Xd0000001IXSZEA4",
        "year": 2016,
        "name": "The Weta Cave & Insect Repository",
        "contact_email": "contact@giantweta.nz",
        "hometown": "Auckland",
        "description": "Home of The Giant Weta, we will bring you all things New Zealand so you can immerse yourself in iconic kiwi culture and heritage and we'll collect all your insects while we're at it. Bring any insect you find while exploring the Playa and we will attempt to identify, classify, preserve and display it in our repository.",
        "location": {
            "string": "H & 8:45",
            "frontage": "H",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.794106194335654,
            "gps_longitude": -119.21976693779182
        },
        "location_string": "H & 8:45"
    },
    {
        "uid": "a1Xd0000001IJYYEA4",
        "year": 2016,
        "name": "The Yard",
        "url": "https://www.facebook.com/theyardvillage",
        "contact_email": "the.yard.village@gmail.com",
        "hometown": "Vancouver",
        "description": "Our big ass board games bring all the burners to the yard, and they're like, \"hey, this is pretty fun.\" Come for the games, stay to get schooled in DJing, juggling, and the fine art of hula hoop. Don't worry, we always make time for recess.",
        "location": {
            "string": "8:30 & G",
            "frontage": "8:30",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.79240038197383,
            "gps_longitude": -119.22022952927168
        },
        "location_string": "8:30 & G"
    },
    {
        "uid": "a1Xd0000001IXFqEAO",
        "year": 2016,
        "name": "Renegade Kitties",
        "url": "https://www.facebook.com/GipsyKitty/",
        "contact_email": "sventhecat@gmail.com",
        "hometown": "Vashon Island",
        "description": "VIrgine Delle Rocce translated Virgin of the Rocks Speakeasy by the Renegade Gypsy Kitties.  Come visit our renaissance-styled tavern with our mechanical bartender Wheel of wine and drink.  We have an assortment of experimental kinetic sculptures based on Leonardo's designs and drawings. We encourage visitors to bring a bottle of wine or liquor to contribute to our mechanical bartender wheel, bring a classical musical instrument to strum or toot with others  and enjoy late night conversation  and merriment both around our fire or in our tavern. We are only open mid day and late night, classic speakeasy hrs when we are there. Please have your id (photo copies ok we are 21+",
        "location": {
            "string": "G & 8:15",
            "frontage": "G",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.790992190347644,
            "gps_longitude": -119.22114640878951
        },
        "location_string": "G & 8:15"
    },
    {
        "uid": "a1Xd0000001IVnxEAG",
        "year": 2016,
        "name": "Sparkle Donkey Village",
        "hometown": "Oakland",
        "description": "Sparkle Donkey Village is a collection of interactive camps based around service, entertainment, education, and community building",
        "location": {
            "string": "9:00 Portal & A",
            "frontage": "9:00 Portal",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.79209649034368,
            "gps_longitude": -119.21402456241272
        },
        "location_string": "9:00 Portal & A"
    },
    {
        "uid": "a1Xd0000001IVtCEAW",
        "year": 2016,
        "name": "The Hive",
        "hometown": "Boston",
        "description": "A buzzing mass of madness from the East descends upon the desert, full of burning light and energy. Is the Hive full of honey, or stings? Bathe in our glow, and discover!",
        "location": {
            "string": "Esplanade & 8:30",
            "frontage": "Esplanade",
            "intersection": "8:30",
            "intersection_type": "&",
            "gps_latitude": 40.78982507488664,
            "gps_longitude": -119.21433618536174
        },
        "location_string": "Esplanade & 8:30"
    },
    {
        "uid": "a1Xd0000001IN4XEAW",
        "year": 2016,
        "name": "Pretty Pickle Camp",
        "url": "http://www.prettypicklecamp.tk/",
        "contact_email": "prettypicklecamp@p1r8.net",
        "hometown": "Black Rock City",
        "description": "Pretty Pickle Camp: A relaxed outpost on the road to nowhere featuring cold pickle service to passers by 12:00 pm - 2:30 pm daily. Also offering hand-crafted pickle warmers, pickle pasties, and pickle rings, stickers, and bottle cap pins while supplies last!",
        "location": {
            "string": "F & 9:15",
            "frontage": "F",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79539677754363,
            "gps_longitude": -119.21562791691271
        },
        "location_string": "F & 9:15"
    },
    {
        "uid": "a1Xd0000002VWxEEAW",
        "year": 2016,
        "name": "Got Framed",
        "url": "https://www.instagram.com/got_framed/",
        "contact_email": "gotframed2015@gmail.com",
        "hometown": "Los Angeles",
        "description": "Got Framed is an inviting, playful, highly interactive art piece that supports and promotes community participation by encouraging passersby to BE THE ART. To step up, climb on, take a photograph...to 'monkey around', change the image, and invite others to join in...to have fun interacting with large scale art and make a memory to take with them. To say out loud \"I Am A Masterpiece!",
        "location": {
            "string": "D & 8:15",
            "frontage": "D",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79023278937556,
            "gps_longitude": -119.21874102697954
        },
        "location_string": "D & 8:15"
    },
    {
        "uid": "a1Xd0000001IV7ZEAW",
        "year": 2016,
        "name": "Amber Dust",
        "hometown": "Los Angeles",
        "description": "Come in to make your own amber pendant, have some morning yoga, enjoy high noon tea, and have a sip or two of some delicious mead.",
        "location": {
            "string": "H & 7:15",
            "frontage": "H",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78474634492448,
            "gps_longitude": -119.22307720812522
        },
        "location_string": "H & 7:15"
    },
    {
        "uid": "a1Xd0000001IRrzEAG",
        "year": 2016,
        "name": "LED Dinosaur",
        "url": "https://www.facebook.com/LEDDinosaur",
        "hometown": "San Francisco",
        "description": "LED Dinosaur is Burning Man's best preparty destination.  Come by at sunset to grab some LEDs & drinks while you dance in our giant dinosaur.",
        "location": {
            "string": "9:30 & A",
            "frontage": "9:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.79337692443453,
            "gps_longitude": -119.21182077171073
        },
        "location_string": "9:30 & A"
    },
    {
        "uid": "a1Xd0000001IWnDEAW",
        "year": 2016,
        "name": "Pallet Palace",
        "contact_email": "ashleyeorr@hotmail.com",
        "hometown": "South Lake Tahoe",
        "description": "Pallet Palace- inspiring others to up-cycle, recycle and re-use."
    },
    {
        "uid": "a1Xd0000001IOpxEAG",
        "year": 2016,
        "name": "Camp Questionmark",
        "url": "http://campquestionmark.com",
        "hometown": "bae area",
        "description": "▶What The F* Is Really Going On?!◀\r\n\r\n\"A questioning mind does not always find satisfaction in what is effortlessly presented in mass...it seeks out what is needed for true fulfillment\"  ~?\r\n \r\nInstead of bringing a regular cluby feeling to the Black Rock City playa, we are here to summon up a true desert experience. Filled with the collective creative energy of the burn. Music & creativity born from & inspired by the atmosphere of the desert. Something different & unique to this place specifically )?( \r\n\r\n+++Interesting Desert Music Day & Night from Tues till BurnNight+++\r\n\r\nCome (((feel))) the difference & Seek the answer...\r\n\r\n▲  )?(  ▲ \r\n    ◢◣",
        "location": {
            "string": "Esplanade & 2:00",
            "frontage": "Esplanade",
            "intersection": "2:00",
            "intersection_type": "&",
            "gps_latitude": 40.78462658391771,
            "gps_longitude": -119.1977605550707
        },
        "location_string": "Esplanade & 2:00"
    },
    {
        "uid": "a1Xd0000001IWCZEA4",
        "year": 2016,
        "name": "Vulcan Empire",
        "hometown": "Oakland",
        "description": "Come learn to spin (and juggle) all the things! Take a workshop (poi, hoop, staff, fans and more)  or just come by to play in the shade!",
        "location": {
            "string": "6:00 & D",
            "frontage": "6:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.77930776797406,
            "gps_longitude": -119.21586550871372
        },
        "location_string": "6:00 & D"
    },
    {
        "uid": "a1Xd0000001IWO1EAO",
        "year": 2016,
        "name": "BERIMBAU",
        "url": "http://www.brazilianburners.com/",
        "contact_email": "danieldevas@hotmail.com",
        "hometown": "RIO DE JANEIRO",
        "description": "We are the Brazilian Burners !"
    },
    {
        "uid": "a1Xd0000001IX3fEAG",
        "year": 2016,
        "name": "Black Rock University",
        "url": "https://www.facebook.com/BlackRockUniversity/",
        "hometown": "Orlando",
        "description": "Black Rock University (BRU) is a free university following the 10 principles of burning man to expose all to the benefits of higher education through interactive participation and experiential learning."
    },
    {
        "uid": "a1Xd0000001IW41EAG",
        "year": 2016,
        "name": "Love Beet Fluffing Camp",
        "contact_email": "lovebeets@nakedjen.com",
        "hometown": "Salt Lake City",
        "description": "The LoveBeets are a worldwide group of self proclaimed Fluffers whose greatest pleasure is to spread love & to really help others wherever they happen to go. We are a very special mobile fluffing camp that arrives fresh and ready to relieve workers in various camps all over the playa by providing their builders with delicious food, water, caffeine, electrolytes, massages, sunblock, building assistance, unloading assistance, hugs, smiles, shade & any other relief we can to lighten everyone's loads and lift everyone's spirits while our love literally BEETS across the playa.",
        "location": {
            "string": "9:30 & C",
            "frontage": "9:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.79451599092807,
            "gps_longitude": -119.21268957532055
        },
        "location_string": "9:30 & C"
    },
    {
        "uid": "a1Xd0000001IOQREA4",
        "year": 2016,
        "name": "The Dragon's Lay-Her",
        "contact_email": "gr8fdead@gmail.com",
        "hometown": "Costa Mesa, CA",
        "description": "The Dragon's Lay-Her is an fun filled Grateful Dead Experience.\r\nCome by ride the Casting Couch & Puff the Magic Dragon!",
        "location": {
            "string": "A & 7:45",
            "frontage": "A",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.787447181052784,
            "gps_longitude": -119.2170501269583
        },
        "location_string": "A & 7:45"
    },
    {
        "uid": "a1Xd0000001IXEdEAO",
        "year": 2016,
        "name": "Campo de' Fiori",
        "hometown": "Rome",
        "location": {
            "string": "E & 4:15",
            "frontage": "E",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77580421451263,
            "gps_longitude": -119.20465961949094
        },
        "location_string": "E & 4:15"
    },
    {
        "uid": "a1Xd0000001IXOOEA4",
        "year": 2016,
        "name": "Burners Without Borders (BWB)",
        "url": "http://www.burnerswithoutborders.org",
        "contact_email": "info@burnerswithoutborders.org",
        "hometown": "San Francisco",
        "description": "Burners Without Borders (BWB) Camp returns to BRC-2016 celebrating the work of our community around the world and taking a look at the world refugee crisis and how burners, and burner prototypes are shaping the field.\r\nCome and join us for music, making, speakers, art and service offerings designed to leave you refreshed & inspired.",
        "location": {
            "string": "Esplanade & 3:15",
            "frontage": "Esplanade",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.780962879726395,
            "gps_longitude": -119.20099595499615
        },
        "location_string": "Esplanade & 3:15"
    },
    {
        "uid": "a1Xd0000001IVIAEA4",
        "year": 2016,
        "name": "Awkward & Tawdry Lounge",
        "url": "http://049events.com/AwkwardAndTawdry/",
        "hometown": "Sacramento, San Francisco and LA",
        "description": "Many years ago, a snake oil salesman by the name Dr. LeTawdry traveled the swamps of Louisiana in search of fabled elixirs. Many of his potions were wildly successful, but it was his mixture for lovesickness that backfired and lead to tragedy: awkward hugs. \r\n\r\nNow, Dr. LeTawdry urges you to come to Awkward and Tawdry Lounge to find the cure! He offers many treatments: moving pictures, musical sing-alongs, breakfast with questionable cartoons, easy listening and lemonade, dancing, drinking and overall merriment.",
        "location": {
            "string": "B & 6:45",
            "frontage": "B",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.783060736985135,
            "gps_longitude": -119.2171300722949
        },
        "location_string": "B & 6:45"
    },
    {
        "uid": "a1Xd0000001IRoREAW",
        "year": 2016,
        "name": "Camp Wish Maker",
        "url": "https://www.facebook.com/BMwishmaker/",
        "contact_email": "wishmakercamp@gmail.com",
        "hometown": "Austin, TX",
        "description": "Come visit us at Wish Maker!  Come sit with us and make a dedication, an affirmation, a release, say goodbye, an offering of love....or anything you need and want. Our space is welcoming and peaceful and here for you. \r\n\r\nSunday 3pm: Bike Decorating Party; please bring your own lights, all other materials available.\r\n\r\nMon-Sat: 3-6pm Crafting tables and public lounge open. Burnable craft supplies and station set up for the construction of burnable offerings. Shaded space to rest, share stories, relax.\r\n\r\nWed & Thurs 3pm: 60 minute Vinyasa designed to keep you out of the dust. All levels welcome.\r\n\r\nWednesday 4:15pm: 30 minute Chakra meditation designed to deepen your connection to the earth and sky.  All levels welcome.\r\n\r\nThursday 4:15:-60 minute restorative Yin yoga. All levels welcome. \r\n\r\nPlease join us for any and all events! And of course, come by any time you can to leave your wish on the wall. We look forward to sharing, laughing and  burning with you!",
        "location": {
            "string": "E & 7:45",
            "frontage": "E",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.787789121831615,
            "gps_longitude": -119.22049510776583
        },
        "location_string": "E & 7:45"
    },
    {
        "uid": "a1Xd0000001IAsbEAG",
        "year": 2016,
        "name": "Popo Ville",
        "hometown": "San Ramon",
        "description": "Popo Ville is about honoring our patron saint Popo, and how we contribute to making the world a better place one burn at a time.  We invite our fellow burners, new and returning, to join us for drinks, music, games body art and friendship.",
        "location": {
            "string": "H & 5:15",
            "frontage": "H",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.774703456388195,
            "gps_longitude": -119.21289759609604
        },
        "location_string": "H & 5:15"
    },
    {
        "uid": "a1Xd0000001IW2PEAW",
        "year": 2016,
        "name": "Quixotes Cabaret Club and Bar",
        "url": "http://www.qccb.org",
        "contact_email": "paul@qccb.org",
        "hometown": "London (UK)",
        "description": "Quixotes' Cabraet returns to the playa  in 2015 to present Our gift to the desert is a Cabaret venue where we invite anyone with any entertaining act, no matter how bad or amateur to perform! Everyone is welcome to join us for a tasty cold beverage and enjoy the show either as a performer or expectant participant  just arrived to be awed by our performers.",
        "location": {
            "string": "D & 8:15",
            "frontage": "D",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79023278937556,
            "gps_longitude": -119.21874102697954
        },
        "location_string": "D & 8:15"
    },
    {
        "uid": "a1Xd0000001IXkTEAW",
        "year": 2016,
        "name": "Major Tom's Flying Circus",
        "contact_email": "xtremepaddy@gmail.com",
        "hometown": "Aspen",
        "description": "Join Major Tom's Flying Circus to experience Black Rock City from the air in one of our micro-light aircraft. Flying weather permitting Tuesday, Thursday and Saturday 8 a.m. to 11 a.m. Meet us at the Ground Control Departure Lounge at BRC Airport.",
        "location": {
            "string": "G & 4:45",
            "frontage": "G",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20856873866927
        },
        "location_string": "G & 4:45"
    },
    {
        "uid": "a1Xd0000001IXAMEA4",
        "year": 2016,
        "name": "Kamp Karaoke",
        "hometown": "Davis, California",
        "description": "Kamp Karaoke--Our live band will joyfully back you up on the microphone, or you may select from thousands of karaoke songs as you release your inner superstar. Licensed counselors help the shy overcome their barriers to radical self expression.",
        "location": {
            "string": "F & 3:15",
            "frontage": "F",
            "intersection": "3:15",
            "intersection_type": "&",
            "gps_latitude": 40.77739621183719,
            "gps_longitude": -119.19738538550564
        },
        "location_string": "F & 3:15"
    },
    {
        "uid": "a1Xd0000001IXXjEAO",
        "year": 2016,
        "name": "Monkey Love",
        "hometown": "NYC",
        "location": {
            "string": "2:00 & I",
            "frontage": "2:00",
            "intersection": "I",
            "intersection_type": "&",
            "gps_latitude": 40.78295187419581,
            "gps_longitude": -119.18951094738038
        },
        "location_string": "2:00 & I"
    },
    {
        "uid": "a1Xd0000001IXCrEAO",
        "year": 2016,
        "name": ")'(anadu",
        "contact_email": "campxanadu@gmail.com",
        "hometown": "Orange County",
        "description": "Care to stretch out after a long day? Why not slip into something more comfortable and relax at Camp )'(anadu, a meeting place for Spandex lovers far and wide. Stop by anytime at our Spandex Annex to make your own sexy outfit, or get a photo of your naked silhouette pressed against our giant life-size \"Moan-A- Loosa\" stretched spandex picture frame. Add some matching neon body paint, and then light yourself up under our open-air shade structure during one of our black light deep house parties or live music sessions.",
        "location": {
            "string": "C & 9:45",
            "frontage": "C",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79505698110772,
            "gps_longitude": -119.21124115125328
        },
        "location_string": "C & 9:45"
    },
    {
        "uid": "a1Xd0000001IV3hEAG",
        "year": 2016,
        "name": "FUR",
        "url": "http://furryburners.com",
        "hometown": "Oakland",
        "description": "FUR is a theme camp of furries from all over, who come together to collaborate in the shared theme of Anthropomorphic Art, Costuming, and Culture.",
        "location": {
            "string": "A & 6:45",
            "frontage": "A",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.783312752183654,
            "gps_longitude": -119.21632781749565
        },
        "location_string": "A & 6:45"
    },
    {
        "uid": "a1Xd0000001IKhJEAW",
        "year": 2016,
        "name": "Anat's Love Camp",
        "url": "http://anatslovecamp.org",
        "contact_email": "anatomi@earthlink.net",
        "hometown": "Berkeley",
        "description": "It's Anat's 22 year at Burning Man, our Love Camp family will feature live music and stage performances, Brazilian Samba dance lessons, Brazilian cocktails, fire dance performance, live video art production, a line up of DJ dance music, and a holistic healing center. Come for an event, stay for the Love.",
        "location": {
            "string": "6:00 Public Plaza @ 9:30",
            "frontage": "6:00 Public Plaza",
            "intersection": "9:30",
            "intersection_type": "@",
            "gps_latitude": 40.792732604037916,
            "gps_longitude": -119.2142469393728
        },
        "location_string": "6:00 Public Plaza @ 9:30"
    },
    {
        "uid": "a1Xd0000001IVGiEAO",
        "year": 2016,
        "name": "ExCappa",
        "url": "http://www.facebook.com/excappa",
        "hometown": "Seattle, San Francisco, and LA",
        "description": "Are you clever enough to be a part of Leonardo's secret society? Come solve our room escape and find out! Never done a room escape? No problem! It's an adventure in which you are locked in a room and have to use elements of the room to solve a series of puzzles and escape the room within a set time. If you can find the clues and exit Leonardo's workshop, a glorious reward awaits!",
        "location": {
            "string": "I & 4:15",
            "frontage": "I",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77319619060326,
            "gps_longitude": -119.20420459530268
        },
        "location_string": "I & 4:15"
    },
    {
        "uid": "a1Xd0000001IX99EAG",
        "year": 2016,
        "name": "Adult Playspace",
        "contact_email": "1derful@adultplayspace.org",
        "hometown": "San Fra",
        "description": "Come play with yourself or others, make a new friend or maybe even join in with somebody already playing.  We've got toys to share!",
        "location": {
            "string": "H & 8:45",
            "frontage": "H",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.794106194335654,
            "gps_longitude": -119.21976693779182
        },
        "location_string": "H & 8:45"
    },
    {
        "uid": "a1Xd0000001IVpAEAW",
        "year": 2016,
        "name": "Bar X (X is Roman numeral for 10)",
        "hometown": "San Francisco",
        "description": "Bar X, a one-man quest to serve his body weight in delicious alcoholic drinks to commemorate his 10th consecutive Burn.",
        "location": {
            "string": "H & 5:15",
            "frontage": "H",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.774703456388195,
            "gps_longitude": -119.21289759609604
        },
        "location_string": "H & 5:15"
    },
    {
        "uid": "a1Xd0000001IOshEAG",
        "year": 2016,
        "name": "7 Siren's Cove",
        "url": "http://www.7sirenscove.com",
        "contact_email": "beth.pferd@gmail.com",
        "hometown": "San Francisco",
        "description": "A pirate bohemia where merrymaking, gypsy lounging, dancing rhythms and mischief run aground.  Beware, it is futile to resist the 7 Siren's call!",
        "location": {
            "string": "7:30 Portal & A",
            "frontage": "7:30 Portal",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.78639951132433,
            "gps_longitude": -119.21714042532156
        },
        "location_string": "7:30 Portal & A"
    },
    {
        "uid": "a1Xd0000001IX6oEAG",
        "year": 2016,
        "name": "8-bit Bunny",
        "contact_email": "david@8-bitbunny.com",
        "hometown": "San Francisco and Los Angeles",
        "description": "Come spin the wheel at 8-bit Bunny. Play our bunny themed games and win drinks!",
        "location": {
            "string": "F & 7:45",
            "frontage": "F",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.7878746073425,
            "gps_longitude": -119.22135635615312
        },
        "location_string": "F & 7:45"
    },
    {
        "uid": "a1Xd0000001IX7XEAW",
        "year": 2016,
        "name": "Camp Beaverton",
        "url": "http://www.campbeaverton.org",
        "contact_email": "campbeaverton@gmail.com",
        "hometown": "Oakland",
        "description": "Camp Beaverton is an intentional, experimental, and experiential Burning Man community theme camp. Our goal is to provide a safe space for queer women on and off-Playa. We encourage education, participation, inquiry, conversation, and self-reflection on what it means to be \"a Beaver\". We extend our goals to the greater Black Rock community by hosting workshops and social events.",
        "location": {
            "string": "F & 7:45",
            "frontage": "F",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.7878746073425,
            "gps_longitude": -119.22135635615312
        },
        "location_string": "F & 7:45"
    },
    {
        "uid": "a1Xd0000001IAzrEAG",
        "year": 2016,
        "name": "Alternative Energy Zone",
        "url": "http://www.aez.green",
        "contact_email": "aez@nometer.com",
        "hometown": "Reno",
        "description": "The AEZ is the place to camp without generators. Friendly folks that can show you how to build an alternative energy system for yourself.",
        "location": {
            "string": "4:00 & E",
            "frontage": "4:00",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.77607703461826,
            "gps_longitude": -119.20284737574195
        },
        "location_string": "4:00 & E"
    },
    {
        "uid": "a1Xd0000001IVqcEAG",
        "year": 2016,
        "name": "Anarchist Cabaret",
        "contact_email": "bjblitz@aol.com",
        "hometown": "New York",
        "description": "Hungry for food or attention? Thirsty, tired or bored? Drop into the anarchy cabaret sing us a song, tell some jokes, do a little dance, no matter if you make us cheer or jeer you get to join the audience after you perform and enjoy refreshments and whatever talent walks in.  Coffee and Breakfast goodies served 9AM till noon  The fun resumes 6PM and carries on with cocktails tasty things to eat. being Anarchists thats as specific as we dare get",
        "location": {
            "string": "6:30 & H",
            "frontage": "6:30",
            "intersection": "H",
            "intersection_type": "&",
            "gps_latitude": 40.780069066906286,
            "gps_longitude": -119.22097914344731
        },
        "location_string": "6:30 & H"
    },
    {
        "uid": "a1Xd0000001IMQvEAO",
        "year": 2016,
        "name": "7 Sins Lounge",
        "contact_email": "campmaster@pacbell.net",
        "hometown": "Sacramento",
        "description": "Come Embrace the Heat as the Playa's Friendliest Little Slice of Hell returns for the 16th straight year!\r\n\r\nDaytime brings what Sinners need - shade, chill music and slushy drinks. But NIGHT brings what Sinners want - Flaming Libations and the ever popular WHEEL of SINS! Our highly skilled and dedicated staff will happily deliver absolution & encouragement with a FIRM hand!\r\n\r\nSo come earn your \"Get Out of HELL Free\" card and remember:\r\nStart your SINS at 7!",
        "location": {
            "string": "8:30 & A",
            "frontage": "8:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.79042783320644,
            "gps_longitude": -119.2157154376413
        },
        "location_string": "8:30 & A"
    },
    {
        "uid": "a1Xd0000001IXHmEAO",
        "year": 2016,
        "name": "Black Rock Power CO-OP",
        "contact_email": "gt350jack@aol.com",
        "hometown": "Oakland",
        "description": "Black Rock Power COOP is a collection of nine camps that share a common power grid. There is something for everyone and plenty of electricity for those needing a recharge of their batteries or simply a place to rest for a while.",
        "location": {
            "string": "4:30 & D",
            "frontage": "4:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.776370604715595,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 & D"
    },
    {
        "uid": "a1Xd0000001IWSXEA4",
        "year": 2016,
        "name": "Brulee",
        "url": "http://brulee.co",
        "contact_email": "daniel@brulee.co",
        "hometown": "Denver",
        "description": "Brûlée is a kinky circus camp.  We host champagne bacon brunch daily at 11a, and nightly dance parties, fun bar with a piano, fetish play, and an air conditioned lounge.",
        "location": {
            "string": "Esplanade & 7:30 Portal",
            "frontage": "Esplanade",
            "intersection": "7:30 Portal",
            "intersection_type": "&",
            "gps_latitude": 40.7863996466492,
            "gps_longitude": -119.21554798072792
        },
        "location_string": "Esplanade & 7:30 Portal"
    },
    {
        "uid": "a1Xd0000001IXBKEA4",
        "year": 2016,
        "name": "Dante’s InFURno",
        "url": "http://www.dantesinfurno.com",
        "contact_email": "info@dantesinfurno.com",
        "hometown": "Vancouver",
        "description": "Visit the raunchy side of the Furries at Dante's InFURno bar and strip club.  Drinks are on us, cuddles are on you!",
        "location": {
            "string": "7:00 & A",
            "frontage": "7:00",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.784314394456956,
            "gps_longitude": -119.2167775389316
        },
        "location_string": "7:00 & A"
    },
    {
        "uid": "a1Xd0000001IVCHEA4",
        "year": 2016,
        "name": "Camp Upsie Dasium",
        "url": "https://www.facebook.com/campud",
        "contact_email": "bluethistle@sbcglobal.net",
        "hometown": "Corralitos",
        "description": "Rising Up out of the Chaos of the Default World comes your Beacon of Hope:  Camp Upsie Dasium!  Featuring a 45 foot high climbable Tower, Silhouette Theater, over 1500 sq ft of Shade, Live Music and Tastings. Come Climb the Tower and Enjoy the View of BRC. We are open to Burners who want to use our camp for small events.",
        "location": {
            "string": "7:30 & A",
            "frontage": "7:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.78639951132433,
            "gps_longitude": -119.21714042532156
        },
        "location_string": "7:30 & A"
    },
    {
        "uid": "a1Xd0000001IVujEAG",
        "year": 2016,
        "name": "Camp Half-Ass",
        "url": "http://www.camphalfass.com",
        "hometown": "Palo Alto",
        "description": "Camp Half-Ass is a group of fun loving individuals that has been bringing Peace, Love, and Laughter to the Playa since 2006. Come enjoy our GIANT SWING, infamous Bike Bar, Art Installations, and afternoon Beer Garden Parties.",
        "location": {
            "string": "I & 8:45",
            "frontage": "I",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.794506474599395,
            "gps_longitude": -119.22045621351006
        },
        "location_string": "I & 8:45"
    },
    {
        "uid": "a1Xd0000001IOqCEAW",
        "year": 2016,
        "name": "Dark Sparkle",
        "contact_email": "campdarksparkle@gmail.com",
        "hometown": "Davis",
        "description": "Dark Sparkle is the potent mix of the mysterious and the dangerous that makes something irresistibly attractive.  It's what causes people to push their limits to the point of insanity, what spurs exploration of territories both physical and metaphysical,, that unexplainable quality which arouses curiosity in the dark side. Some days, Dark Sparkle is your alter-ego; other days it is your most natural feeling form. Dark Sparkle is Mona Lisa's smile, tarot cards at prom, mother's milk, the apocalypse. Dark Sparkle is an adventurous way of life--audacious and bold as BRC itself.",
        "location": {
            "string": "C & 9:15",
            "frontage": "C",
            "intersection": "9:15",
            "intersection_type": "&",
            "gps_latitude": 40.79383208574335,
            "gps_longitude": -119.21404041775784
        },
        "location_string": "C & 9:15"
    },
    {
        "uid": "a1Xd0000001IWB7EAO",
        "year": 2016,
        "name": "DICKSTRACTED CAMP",
        "url": "http://dickstractedcamp.tumblr.com/",
        "contact_email": "vart41@gmail.com",
        "hometown": "los angeles",
        "description": "The Dickstracted Camp is and adult-gay oriented camp emphasized on bringing exhibitionism and voyeurism to the playa.",
        "location": {
            "string": "F & 7:15",
            "frontage": "F",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.784913070481615,
            "gps_longitude": -119.22135388238645
        },
        "location_string": "F & 7:15"
    },
    {
        "uid": "a1Xd0000001IT0GEAW",
        "year": 2016,
        "name": "Center 4 Research & Development",
        "url": "http://www.instagram.com/center4rnd",
        "contact_email": "center4rnd@gmail.com",
        "hometown": "Los Angeles",
        "description": "We observe the peculiarities of humanity in the most fascinating environment: Black Rock City, the petri dish in the desert. Experiments are typically performed through the ancient scientific methods of light, sound, and libations.",
        "location": {
            "string": "G & 5:15",
            "frontage": "G",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.77531107774246,
            "gps_longitude": -119.21256530891797
        },
        "location_string": "G & 5:15"
    },
    {
        "uid": "a1Xd0000001IWUdEAO",
        "year": 2016,
        "name": "Detroit: (Black) Rock City",
        "contact_email": "toby@mctvnetwork.com",
        "hometown": "Detroit... I bet you knew that",
        "description": "Detroit: (Black) Rock City.  Home of the Michigangsters and \r\nOfficial Honeymoon Destination of The Burn.",
        "location": {
            "string": "F & 8:45",
            "frontage": "F",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.7933010483374,
            "gps_longitude": -119.21839283914905
        },
        "location_string": "F & 8:45"
    },
    {
        "uid": "a1Xd0000001IXhoEAG",
        "year": 2016,
        "name": "Comfort and Joy",
        "url": "http://www.playajoy.org",
        "contact_email": "touch@playajoy.org",
        "hometown": "San Francisco",
        "description": "Restore your body and lift your spirits at Comfort & Joy, a gay\r\ncommunity oasis offering a fully functioning Gym, colorful art\r\ninstallations and daily events including yoga classes,  inspiring performances, & quite queer nightlife.",
        "location": {
            "string": "8:00 & F",
            "frontage": "8:00",
            "intersection": "F",
            "intersection_type": "&",
            "gps_latitude": 40.78933532694866,
            "gps_longitude": -119.22097354706476
        },
        "location_string": "8:00 & F"
    },
    {
        "uid": "a1Xd0000001IXDfEAO",
        "year": 2016,
        "name": "Cirque de Licious",
        "url": "https://www.facebook.com/CirqueDeLiciousProductions/",
        "contact_email": "regionalchaos@gmail.com",
        "hometown": "Eugene",
        "description": "Cirque de Licious is proud to bring you a healthy dose of Eugene's vibrant art community.  Over a dozen artists have collaborated on a dome full of amazing paintings, watch as they move, morph and combine under the color changing LED lights!\r\n\r\nWomen experiencing hysteria on the playa, we truly feel for your discomfort!  We've dedicated our playa experience to your satisfaction and relief!  Please come visit and explore our Victorian area contraption, the Freudian Manipulator MK.1! The Manipulator is a steampunk medical electrical-mechanical apparatus for the treatment of Hysteria, a once common medical diagnosis that women suffered during the Victorian era. (http://steamworksresearchlabs.com)",
        "location": {
            "string": "G & 8:45",
            "frontage": "G",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79370590997052,
            "gps_longitude": -119.21907767038495
        },
        "location_string": "G & 8:45"
    },
    {
        "uid": "a1Xd0000001IFkFEAW",
        "year": 2016,
        "name": "Down Low Club",
        "url": "https://www.facebook.com/groups/557666564336453/",
        "contact_email": "billybob91354@hotmail.com",
        "hometown": "Los Angeles",
        "description": "An enclosed, discreet and air-conditioned play space for adult men of the Playa seeking to meet other adult men and/or engage in tactile and erotic manplay. Whether self-identified as gay, bi, trans, questioning, curious or straight, this non-judgmental and away-from-prying eyes space is open 24/7 all week to adult men.",
        "location": {
            "string": "E & 7:45",
            "frontage": "E",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.787789121831615,
            "gps_longitude": -119.22049510776583
        },
        "location_string": "E & 7:45"
    },
    {
        "uid": "a1Xd0000001IMotEAG",
        "year": 2016,
        "name": "Ignited States",
        "hometown": "Phoenix",
        "description": "Ignited States welcomes one and all to refresh their creative selves!\r\nBring out your inner Mona Lisa, play our Leonardo games, drink a shot, or just hang out and chill.\r\nWe offer comfort and shade, inside the Ignite Your State Workshop & Lounge or outside on our Front Porch.",
        "location": {
            "string": "G & 4:15",
            "frontage": "G",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.774500272567614,
            "gps_longitude": -119.20443126133077
        },
        "location_string": "G & 4:15"
    },
    {
        "uid": "a1Xd0000001IAxbEAG",
        "year": 2016,
        "name": "fINK yOU fREAKY",
        "hometown": "Northern California",
        "description": "We fINK yOU fREAKY and like you a lot!",
        "location": {
            "string": "D & 8:45",
            "frontage": "D",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79250090223318,
            "gps_longitude": -119.21701391692622
        },
        "location_string": "D & 8:45"
    },
    {
        "uid": "a1Xd0000001INq4EAG",
        "year": 2016,
        "name": "Genital Portrait Studio",
        "url": "http://www.genitalportraitstudio.org",
        "contact_email": "gimmethoseshoes@yahoo.com",
        "hometown": "San Francisco",
        "description": "Genital Portrait Studio, the playa's premier genital photography studio since 2000, celebrates genitalia as glorious and beautiful. Welcoming to all genders, we invite you to capture your most intimate side in a keepsake laminated ID Badge.",
        "location": {
            "string": "7:30 & B",
            "frontage": "7:30",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.786399428284064,
            "gps_longitude": -119.21800903146068
        },
        "location_string": "7:30 & B"
    },
    {
        "uid": "a1Xd0000001IERVEA4",
        "year": 2016,
        "name": "Gender Blender",
        "url": "http://www.genderblenders.org",
        "contact_email": "info@genderblenders.org",
        "hometown": "Bay Area, California",
        "description": "Boy? Girl? Ze? Unidentified? You decide. Gender Blender is a safe haven for those bending and blending gender norms. We create safer spaces for Trans, genderqueers, & gender non-conformers. We provide a welcoming place for those curious about gender play, mixing up one's gender for the first time, and general discussions on how gender impacts our lives. We are a gender conscious open loving community that loves sparkles, theatrics, drag, running anti-oppression workshops, and making queer smoothies on playa.",
        "location": {
            "string": "F & 7:45",
            "frontage": "F",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.7878746073425,
            "gps_longitude": -119.22135635615312
        },
        "location_string": "F & 7:45"
    },
    {
        "uid": "a1Xd0000001IQfrEAG",
        "year": 2016,
        "name": "Dr. Realz' Steampunk Sideshow",
        "hometown": "Everywhere",
        "description": "Come one and all to Dr. Realz Steampunk Sideshow! Are we for Realz? Are we Steampunk? Are we a Sideshow? No! But when has that ever stopped us?",
        "location": {
            "string": "H & 4:15",
            "frontage": "H",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.77384823164088,
            "gps_longitude": -119.20431792720447
        },
        "location_string": "H & 4:15"
    },
    {
        "uid": "a1Xd0000001IXWbEAO",
        "year": 2016,
        "name": "Inflatable Wildlife Safari",
        "contact_email": "inflatablewildlifesafari@gmail.com",
        "hometown": "New York City",
        "description": "Nants Ingonyama Bagithi Baba! Join us and our menagerie of inflatable animals for Safari Tours, Nerf shooting range, Plush Lagoon, and Open Bars! Mingle, Lounge, Dance- Inflatable Wildlife Safari brings the Jungle to you!",
        "location": {
            "string": "H & 7:15",
            "frontage": "H",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78474634492448,
            "gps_longitude": -119.22307720812522
        },
        "location_string": "H & 7:15"
    },
    {
        "uid": "a1Xd0000001IVbmEAG",
        "year": 2016,
        "name": "DISORIENT",
        "url": "http://disorient.com",
        "hometown": "New York, Dubai, San Francisco, Hong Kong",
        "description": "Too Much Is Rarely Enough.\r\nWelcome to Disorient...",
        "location": {
            "string": "Esplanade & 4:00",
            "frontage": "Esplanade",
            "intersection": "4:00",
            "intersection_type": "&",
            "gps_latitude": 40.7797827277492,
            "gps_longitude": -119.20415844356913
        },
        "location_string": "Esplanade & 4:00"
    },
    {
        "uid": "a1Xd0000001IWlCEAW",
        "year": 2016,
        "name": "Furry Gorilla Warefare",
        "hometown": "Costa Mesa",
        "description": "Furry Gorilla Warfare is in full effect in our city of dreams in the high desert plain. Come play with us! We are fire spinners from the Orange County Ca and we'd love to get our freak on with you.",
        "location": {
            "string": "C & 9:45",
            "frontage": "C",
            "intersection": "9:45",
            "intersection_type": "&",
            "gps_latitude": 40.79505698110772,
            "gps_longitude": -119.21124115125328
        },
        "location_string": "C & 9:45"
    },
    {
        "uid": "a1Xd0000001IWNhEAO",
        "year": 2016,
        "name": "Questionable Behavior?",
        "hometown": "Austin",
        "location": {
            "string": "9:30 & E",
            "frontage": "9:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.79565505090518,
            "gps_longitude": -119.21355840874297
        },
        "location_string": "9:30 & E"
    },
    {
        "uid": "a1Xd0000001IXV4EAO",
        "year": 2016,
        "name": "Menagerie",
        "contact_email": "menagerie-village@googlegroups.com",
        "hometown": "New York, Reno, Winemucca, SF, LA, The Dakotas, Portland, Seattle, Somewhere in Wyoming, Somewhere in CT, Somewhere in VA, Philly, Boston, Atlanta, Toronto, London",
        "description": "A unique collection of carefully and principled curated characters make up the Menagerie; a village of unique and fun participants with the excitement and open eyes that Burning Man freely unbosoms. With virgins, fresh, new and open to experiences, next to slightly-experienced and partially-wise veterans and many transitioning between condition make a spectacular experience ready for all who arrive in Black Rock City wandering the rudimentary playa. Menagerie is curated to create, expose and enjoy from the primitive, gruff and young, to the mature and refined, sophisticated taste of a discerning wanderer.",
        "location": {
            "string": "8:30 & C",
            "frontage": "8:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.791085369007384,
            "gps_longitude": -119.21722010505046
        },
        "location_string": "8:30 & C"
    },
    {
        "uid": "a1Xd0000001IOqHEAW",
        "year": 2016,
        "name": "Lip Bomb",
        "url": "http://www.lipbomb.me",
        "contact_email": "lipbomb69@yahoo.com",
        "hometown": "Temecula",
        "description": "Visit our secured website for all things related to our occupation of the desert! \r\n**NSFW**",
        "location": {
            "string": "7:30 & C",
            "frontage": "7:30",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.78639933873083,
            "gps_longitude": -119.2188776375975
        },
        "location_string": "7:30 & C"
    },
    {
        "uid": "a1Xd0000001IGYAEA4",
        "year": 2016,
        "name": "Nothing Butt Art",
        "hometown": "Reno",
        "description": "We supply the canvas and paint, you supply the cheeks, together, we will create nothing butt art! (Complimentary T-shirts provided to participants). We also feature body stamp temporary tattoos . Stop by, make some art and get a tramp stamp.",
        "location": {
            "string": "H & 5:15",
            "frontage": "H",
            "intersection": "5:15",
            "intersection_type": "&",
            "gps_latitude": 40.774703456388195,
            "gps_longitude": -119.21289759609604
        },
        "location_string": "H & 5:15"
    },
    {
        "uid": "a1Xd0000001IXlMEAW",
        "year": 2016,
        "name": "ORPHAN ASYLUM",
        "contact_email": "oddosan@aol.com",
        "hometown": "Los Angeles",
        "description": "Orphan Asylum\r\nAll welcome to our Asylum of Education and Entertainment.",
        "location": {
            "string": "C & 7:15",
            "frontage": "C",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78517166496261,
            "gps_longitude": -119.21877061804274
        },
        "location_string": "C & 7:15"
    },
    {
        "uid": "a1Xd0000001IAt0EAG",
        "year": 2016,
        "name": "Pussy Day Spa",
        "contact_email": "galaleo7@gmail.com",
        "hometown": "Redwood City",
        "description": "We will amuse, entertain, and exhilarate you as well as compliment your shoes.  We are the perfect place for your pussy to visit to be styled, pampered, refreshed, stimulated, and relaxed.",
        "location": {
            "string": "8:30 & E",
            "frontage": "8:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.791742885263474,
            "gps_longitude": -119.21872480226047
        },
        "location_string": "8:30 & E"
    },
    {
        "uid": "a1Xd0000001ILemEAG",
        "year": 2016,
        "name": "Playfully Yours Village",
        "contact_email": "jdf2401@aol.com",
        "hometown": "Monterey, San Jose, Reno",
        "description": "Playfully Yours Village includes Playfully Yours Dungeon, Mist'R Cool, Bare Naked Tramps Portrait Studio and The Burner Marshmallow Lounge. The Village is a play area and meeting place for all adult burners. The dungeon is very well equipped and focused on the beginners and those curious about BDSM play. We'll have private and open dungeon play areas. We offer daily classes with demonstration and participation, as well as, supervision, and facilitation of play. We have many outdoor activities to include a misting booth, large puzzles, an outdoor dungeon, stripper pole, corn hole game, spanking bike, and petting zoo. We have 2 lounge areas, one for the dungeon area with a spinning wheel and cherry bombs and the Burner Marshmallow Lounge that will have theme parties such as \"Shaken Not Stirred\"  and \"The British Invasion\" for groovy 60's tunes. Our Bare Naked Tramps Photo Booth is a great place to spin the wheel of chance to determine the provocative pose for the photo shoot.",
        "location": {
            "string": "7:30 & D",
            "frontage": "7:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.78639924266466,
            "gps_longitude": -119.21974624373193
        },
        "location_string": "7:30 & D"
    },
    {
        "uid": "a1Xd0000001IO7REAW",
        "year": 2016,
        "name": "PlayaSkool",
        "url": "http://www.playaskool.com",
        "contact_email": "playaskool@gmail.com",
        "hometown": "Zephyr Cove",
        "description": "We are Play)A(Skool - an international group of movers and shakers dedicated to creating a learning and experiential platform for citizens to Black Rock City to participate in.  We are the home of TEDxBlackRockCity and proud to host the 5th annual TEDx on playa. In addition, we host Black Rock City Art Forum where the makers, designers and operators of Art Cars share their stories with all.  We host Fuck Up Fridays where you can share you story of your greatest fuck up and what you learned from it.  On Saturday we are all things Burning Man and we feature speakers from different areas of Burning Man to share their stories with you.   In addition, we have some pretty legendary parties . . . our Tuesday Homecoming Party is always a great way to start your Burn.  On Friday night we feature some of the best up and coming International DJ's.  At Play)A(Skool we believe that sharing leads to learning.  And learning leads to personal growth.  And personal growth -- helps us evolve.",
        "location": {
            "string": "10:00 & G",
            "frontage": "10:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.797993346845956,
            "gps_longitude": -119.2106035320494
        },
        "location_string": "10:00 & G"
    },
    {
        "uid": "a1Xd0000001IVG4EAO",
        "year": 2016,
        "name": "Porn And Donuts",
        "url": "http://www.pornanddonuts.com",
        "contact_email": "info@pornanddonuts.com",
        "hometown": "Black Rock City",
        "description": "Serving deliciously decadent donut delights late at night, along with a serving of porn.",
        "location": {
            "string": "3:00 Public Plaza @ 9:15",
            "frontage": "3:00 Public Plaza",
            "intersection": "9:15",
            "intersection_type": "@",
            "gps_latitude": 40.792769675614515,
            "gps_longitude": -119.21428012726606
        },
        "location_string": "3:00 Public Plaza @ 9:15"
    },
    {
        "uid": "a1Xd0000001IQcnEAG",
        "year": 2016,
        "name": "Kamp Suckie Fuckaye",
        "url": "http://kampsuckiefuckaye.com",
        "contact_email": "info@kampsuckiefuckaye.com",
        "hometown": "Portland",
        "description": "Kamp Suckie Fuckaye; home of the Official Black Rock City Garnish, the Infamous Suck 'N Fuck saloon, Toolsday! Ground Zero for the, Rehydrate Lake Lohantan By Electing Neptune for Mayor campaign!",
        "location": {
            "string": "4:30 Portal & A",
            "frontage": "4:30 Portal",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.77834360050925,
            "gps_longitude": -119.20650000000002
        },
        "location_string": "4:30 Portal & A"
    },
    {
        "uid": "a1Xd0000001IUacEAG",
        "year": 2016,
        "name": "ReFOAMation",
        "hometown": "San Diego",
        "description": "Rennaissance burners, get schooled by ReFOAMation foamie homies in the ways of foamy love and regenerative choice.  1 to 4:20 Tues thru Sat.  Also hosting MAPS and psychedelic friends talking mad smack at Mystic Theatre @ Camp Mystic.",
        "location": {
            "string": "E & 2:15",
            "frontage": "E",
            "intersection": "2:15",
            "intersection_type": "&",
            "gps_latitude": 40.7823046959451,
            "gps_longitude": -119.19346317780918
        },
        "location_string": "E & 2:15"
    },
    {
        "uid": "a1Xd0000001IOpnEAG",
        "year": 2016,
        "name": "Slutgarden",
        "url": "http://www.slutgarden.net/",
        "contact_email": "tammy@slutgarden.net",
        "hometown": "Portland",
        "description": "Cum suck down our Slut juice, wrap your body in our love and pound your hips to the rhythms of the playa.",
        "location": {
            "string": "Esplanade & 8:30",
            "frontage": "Esplanade",
            "intersection": "8:30",
            "intersection_type": "&",
            "gps_latitude": 40.78982507488664,
            "gps_longitude": -119.21433618536174
        },
        "location_string": "Esplanade & 8:30"
    },
    {
        "uid": "a1Xd0000001IPj3EAG",
        "year": 2016,
        "name": "Slutt Putt",
        "contact_email": "wereinbusiness@gmail.com",
        "hometown": "Tucson",
        "description": "The Slutt Putt is a mini-putt course complete with a clubhouse! Come enjoy a refreshing Arnold Palmer and play a few rounds!",
        "location": {
            "string": "4:30 Portal & 4:30 Portal",
            "frontage": "4:30 Portal",
            "intersection": "4:30 Portal",
            "intersection_type": "&"
        },
        "location_string": "4:30 Portal & 4:30 Portal"
    },
    {
        "uid": "a1Xd0000001IOU4EAO",
        "year": 2016,
        "name": "Retrofrolic",
        "url": "http://www.retrofrolic.com",
        "contact_email": "info@retrofrolic.com",
        "hometown": "Ventura",
        "description": "Retrofrolic's LGBTQ friendly BDSM dungeon is open for sensual exploration. Spanking Benches, Massage Tables, St. Andrew's Cross', Suspension Point, Sex Swing and their famous PONY are available for play day and night. Colored lighting and music for every taste rounds out the ambiance enjoyed along with our TWENTY play spaces! Scheduled educational programs daily!  Get that certification you never sought and get your feet washed and massaged!  While you're there, ask for the special!",
        "location": {
            "string": "E & 6:45",
            "frontage": "E",
            "intersection": "6:45",
            "intersection_type": "&",
            "gps_latitude": 40.78230469594509,
            "gps_longitude": -119.21953682219086
        },
        "location_string": "E & 6:45"
    },
    {
        "uid": "a1Xd0000001IXLZEA4",
        "year": 2016,
        "name": "Shots for Shocks!",
        "contact_email": "shotsforshocks@gmail.com",
        "hometown": "Seattle",
        "description": "An electrical tasting bar: We zap you with a shock, you get a shot!",
        "location": {
            "string": "E & 7:15",
            "frontage": "E",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78499926855044,
            "gps_longitude": -119.220492795186
        },
        "location_string": "E & 7:15"
    },
    {
        "uid": "a1Xd0000001IHWJEA4",
        "year": 2016,
        "name": "Rat Trap",
        "hometown": "West Coast U.S.A",
        "description": "The bar that never closes. Come join us day or night in pursuit of radical self stupidity.",
        "location": {
            "string": "2:00 & C",
            "frontage": "2:00",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.783973800845395,
            "gps_longitude": -119.19454455683072
        },
        "location_string": "2:00 & C"
    },
    {
        "uid": "a1Xd0000001IVmkEAG",
        "year": 2016,
        "name": "SizzleVille",
        "hometown": "South Bay Area",
        "description": "Scoot on over for that extra Sizzle!! Revel in your Dusty Bumm under hundreds of G-strings while taking a snowboardski or 3, immerse yourself in fur in our Hooka Lounge, Play some giant Beer Pong or Jenga, Relax in our mulitple Cuddle Puddles, Jump on some trampolines, or get your nails done! You'll feel at home while you get to know your fellow South Bay burners, or perhaps just monkey around at the Primate Playground while fizzing up your drink at the Bubbletron!  Official kickoff spot of the Busty Bacon Brigade and the Home Brew Tour.  We're here to cook you up some goodtimes!! )'(",
        "location": {
            "string": "7:00 & D",
            "frontage": "7:00",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.78380349492602,
            "gps_longitude": -119.21929438883451
        },
        "location_string": "7:00 & D"
    },
    {
        "uid": "a1Xd0000001IWEfEAO",
        "year": 2016,
        "name": "Sin City",
        "url": "https://www.facebook.com/SinCityVillage/",
        "contact_email": "sincitybrc@gmail.com",
        "hometown": "Las Vegas",
        "description": "Sin City is a place where freedom of expression is embraced and \"What happens in Sin City stays in Sin City.\"\r\n\r\nThere is always something happening and there are many things to see and do at the clothing optional Party Naked Tiki Bar, Black Rock City Airbrush, Sin City Day Spa, Sin City Photography Studio, Sin City Art Center, photo opportunities and much more.",
        "location": {
            "string": "8:00 & C",
            "frontage": "8:00",
            "intersection": "C",
            "intersection_type": "&",
            "gps_latitude": 40.78882496520954,
            "gps_longitude": -119.21845631653528
        },
        "location_string": "8:00 & C"
    },
    {
        "uid": "a1Xd0000001IWY1EAO",
        "year": 2016,
        "name": "School of Consensual Kink",
        "url": "http://www.blackrocksock.com",
        "contact_email": "campinfo@blackrocksock.com",
        "hometown": "Seattle and San Francisco",
        "description": "All the classes you wish were available when you were in school -- Black Rock School of Consensual Kink (S.O.C.K.) offers a variety of classes and BDSM tastings by our faculty of trained kinksters. The kink curious of all genders, orientations, and identities (18+) are welcome, see you in class!",
        "location": {
            "string": "3:30 & E",
            "frontage": "3:30",
            "intersection": "E",
            "intersection_type": "&",
            "gps_latitude": 40.777144519137565,
            "gps_longitude": -119.19944355839093
        },
        "location_string": "3:30 & E"
    },
    {
        "uid": "a1Xd0000001ISfXEAW",
        "year": 2016,
        "name": "Seattle's Breast Coffee",
        "hometown": "Seattle",
        "description": "Seattle's Breast Coffee",
        "location": {
            "string": "8:30 & D",
            "frontage": "8:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.7914141295786,
            "gps_longitude": -119.21797244993033
        },
        "location_string": "8:30 & D"
    },
    {
        "uid": "a1Xd0000001IWPxEAO",
        "year": 2016,
        "name": "Things That Swing",
        "url": "http://www.things-that-swing.org",
        "contact_email": "thingsthatswing@gmail.com",
        "hometown": "Brooklyn",
        "description": "You know you're curious. Don't be scared. We swing, but we won't bite. Unless you ask us to. Nicely.",
        "location": {
            "string": "D & 4:15",
            "frontage": "D",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.776456262296946,
            "gps_longitude": -119.20477287358
        },
        "location_string": "D & 4:15"
    },
    {
        "uid": "a1Xd0000001IPMWEA4",
        "year": 2016,
        "name": "Spaghetti Taco Camp",
        "contact_email": "spaghettitacocamp@gmail.com",
        "hometown": "Albuquerque",
        "description": "International hospitality camp specializing in virgin coaching and glamping. Come swing from our chandelier under an oasis of shade featuring music, dancing, SPA-ghetti taco treatments, and spankings all the time!",
        "location": {
            "string": "6:00 & G",
            "frontage": "6:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.77791248567272,
            "gps_longitude": -119.2177076684539
        },
        "location_string": "6:00 & G"
    },
    {
        "uid": "a1Xd0000001IWnmEAG",
        "year": 2016,
        "name": "Termination Dust Hole",
        "hometown": "Homer",
        "description": "A rowdy rabble of Alaskans hailing down from the north, here to meet, greet and eat all of you.",
        "location": {
            "string": "5:00 & A",
            "frontage": "5:00",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.77861808293547,
            "gps_longitude": -119.20925362208132
        },
        "location_string": "5:00 & A"
    },
    {
        "uid": "a1Xd0000001ID49EAG",
        "year": 2016,
        "name": "Titicaca",
        "url": "http://camptiticaca.com",
        "hometown": "Black Rock City",
        "description": "Mysterious, exotic, remote...like the great Andean lake, this is Titicaca!",
        "location": {
            "string": "E & 4:45",
            "frontage": "E",
            "intersection": "4:45",
            "intersection_type": "&",
            "gps_latitude": 40.77580421451263,
            "gps_longitude": -119.20834038050907
        },
        "location_string": "E & 4:45"
    },
    {
        "uid": "a1Xd0000001IIl7EAG",
        "year": 2016,
        "name": "Spanky's Village (and Wine Bar)",
        "url": "http://www.spankyswinebar.com",
        "contact_email": "jimhillas_gc@yahoo.com",
        "hometown": "Sacramento",
        "description": "The Infamous Crown-Jewel of Burningman Bars.  \"Your heart may belong to The Man... but your ASS belongs to Spanky's\"",
        "location": {
            "string": "Esplanade & 2:30",
            "frontage": "Esplanade",
            "intersection": "2:30",
            "intersection_type": "&",
            "gps_latitude": 40.78297439508715,
            "gps_longitude": -119.19866462296086
        },
        "location_string": "Esplanade & 2:30"
    },
    {
        "uid": "a1Xd0000001IXFMEA4",
        "year": 2016,
        "name": "Thunder Gumbo / 16 Inches of Joy",
        "contact_email": "brucebeese@gmail.com",
        "hometown": "Brooklyn, NY",
        "description": "16 Inches of Joy provides vital hospitality services: Fresh baked pizza cafe and delivery via art car, and a classy love hotel. \r\nThunder Gumbo camp supports the Thunderius Gumbonium Lahontanii art car, a mulit-level dance party updated as a replica of a mysterious skeletal whale.",
        "location": {
            "string": "K & 8:15",
            "frontage": "K",
            "intersection": "8:15",
            "intersection_type": "&",
            "gps_latitude": 40.79199845038348,
            "gps_longitude": -119.22435685122926
        },
        "location_string": "K & 8:15"
    },
    {
        "uid": "a1Xd0000001IKoCEAW",
        "year": 2016,
        "name": "Spank Bank",
        "contact_email": "guernsey65@msn.com",
        "hometown": "Hood River",
        "description": "(Spank Bank) Have you been naughty or would you like to be? We are the playful, sensual playa spanking experience designed to warm your bottoms, tease your minds, and satisfy your.....um......thirst, with a cold cocktail in one of our commemorative cups!",
        "location": {
            "string": "D & 8:45",
            "frontage": "D",
            "intersection": "8:45",
            "intersection_type": "&",
            "gps_latitude": 40.79250090223318,
            "gps_longitude": -119.21701391692622
        },
        "location_string": "D & 8:45"
    },
    {
        "uid": "a1Xd0000001IWSmEAO",
        "year": 2016,
        "name": "The Lost Penguin",
        "url": "http://www.thelostpenguincafe.com/",
        "contact_email": "info@lostpenguincafe.com",
        "hometown": "Toronto",
        "description": "What could be more lost than a Penguin in the desert? Drop in to our hospitality oasis where we offer comforts such as shade, couches, wine, lemonade, chocolate, snow cones, friendly people, and live entertainment.  Day or night, get up on stage for asshole theatre, watch some bands, dance to DJs or take a workshop. Join us as we navigate surprises all week!  Or just sit and we will engage you in conversation as you watch the playa float by.",
        "location": {
            "string": "3:00 Portal & A",
            "frontage": "3:00 Portal",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.78070302098065,
            "gps_longitude": -119.19897672841634
        },
        "location_string": "3:00 Portal & A"
    },
    {
        "uid": "a1Xd0000001IIpsEAG",
        "year": 2016,
        "name": "Suspended Animation",
        "url": "http://suspendedanimationcrew.com",
        "contact_email": "info@suspendedanimationcrew.com",
        "hometown": "Seattle",
        "description": "Experience full-suspension erotic rope bondage: part kinetic art, part thrill ride, part endorphin rush. Our crew of expert riggers offers bondage and BDSM rides, workshops for all levels, breathtaking performances, and night time play parties. We also rove the playa and build impromptu bondage sculpture!",
        "location": {
            "string": "7:00 & B",
            "frontage": "7:00",
            "intersection": "B",
            "intersection_type": "&",
            "gps_latitude": 40.78414410068907,
            "gps_longitude": -119.21761649320165
        },
        "location_string": "7:00 & B"
    },
    {
        "uid": "a1Xd0000001IXfdEAG",
        "year": 2016,
        "name": "Wasabi Kisses",
        "hometown": "Oakland",
        "description": "Wasabi Kisses is a safer social space for queer and trans* burners.",
        "location": {
            "string": "G & 7:45",
            "frontage": "G",
            "intersection": "7:45",
            "intersection_type": "&",
            "gps_latitude": 40.78796556023548,
            "gps_longitude": -119.22221681630182
        },
        "location_string": "G & 7:45"
    },
    {
        "uid": "a1Xd0000001IWNXEA4",
        "year": 2016,
        "name": "Tsunami Camp",
        "contact_email": "gr8r8yw8@yahoo.com",
        "hometown": "Los Angeles",
        "description": "Tsunami Camp welcomes YOU to stop by for a frosty snow cone, a playa fashion makeover, a puppet show, or other performance.  Our daily schedule is posted next to the stage for your convenience.",
        "location": {
            "string": "4:00 & A",
            "frontage": "4:00",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.77861808293547,
            "gps_longitude": -119.20374637791872
        },
        "location_string": "4:00 & A"
    },
    {
        "uid": "a1Xd0000001IWAxEAO",
        "year": 2016,
        "name": "Uli Baba & the Horny Thieves",
        "url": "http://www.ulibabas.com/",
        "hometown": "San Diego",
        "description": "O illustrious merchants of the flesh and pillagers of the wealth of man. Our glorious master, Uli Baba, he who is magnificent and just, commands your presence at his Slave Auctions and other debauched and glorious events.",
        "location": {
            "string": "C & 4:15",
            "frontage": "C",
            "intersection": "4:15",
            "intersection_type": "&",
            "gps_latitude": 40.7771083101538,
            "gps_longitude": -119.20488612768166
        },
        "location_string": "C & 4:15"
    },
    {
        "uid": "a1Xd0000001IGbeEAG",
        "year": 2016,
        "name": "Yahhhsss, Kween!",
        "url": "https://www.facebook.com/yahhhssskween",
        "hometown": "San Francisco",
        "description": "Yahhhsss, Kween!\r\n\r\nFostering community by hosting happy hour events full of goodwill, silliness and snark.",
        "location": {
            "string": "B & 7:15",
            "frontage": "B",
            "intersection": "7:15",
            "intersection_type": "&",
            "gps_latitude": 40.78525786330597,
            "gps_longitude": -119.21790952809974
        },
        "location_string": "B & 7:15"
    },
    {
        "uid": "a1Xd0000001IVpUEAW",
        "year": 2016,
        "name": "Bobitoz",
        "contact_email": "bobitoz@hotmail.com",
        "hometown": "Los Angeles",
        "description": "Coffee and Tea Respite.",
        "location": {
            "string": "Rod's Road @ 7:15",
            "frontage": "Rod's Road",
            "intersection": "7:15",
            "intersection_type": "@",
            "gps_latitude": 40.78049759628541,
            "gps_longitude": -119.21662954660144
        },
        "location_string": "Rod's Road @ 7:15"
    },
    {
        "uid": "a1Xd0000001IVuKEAW",
        "year": 2016,
        "name": "Bioluminati / Bike Mutation",
        "url": "http://www.bioluminati.org/help/public/bikemutation/",
        "contact_email": "contact@bioluminati.org",
        "hometown": "Berkeley",
        "description": "Bioluminati has been illuminating BRC for 20 years with art, quests and\r\nthe BIKE MUTATION STATION (formerly Pimp Yr Bike); the mutation/decoration\r\nstation where Black Rock Citizens can mutate/decorate their rides with\r\nthat extra get-up-and-glow. Open daily. Donors of non-moopy craft\r\nmaterials get VIP access!",
        "location": {
            "string": "Rod's Road @ 5:45",
            "frontage": "Rod's Road",
            "intersection": "5:45",
            "intersection_type": "@",
            "gps_latitude": 40.77913581737129,
            "gps_longitude": -119.21558992380405
        },
        "location_string": "Rod's Road @ 5:45"
    },
    {
        "uid": "a1Xd0000001INQ2EAO",
        "year": 2016,
        "name": "ARTery",
        "hometown": "San Francisco",
        "description": "Burning Man's Art Headquarters on Playa",
        "location": {
            "string": "Esplanade & 6:30",
            "frontage": "Esplanade",
            "intersection": "6:30",
            "intersection_type": "&",
            "gps_latitude": 40.78297439508715,
            "gps_longitude": -119.21433537703916
        },
        "location_string": "Esplanade & 6:30"
    },
    {
        "uid": "a1Xd0000001IVtMEAW",
        "year": 2016,
        "name": "Black Rock Boutique",
        "url": "https://www.facebook.com/groups/47192458518/",
        "contact_email": "esteindler@gmail.com",
        "hometown": "Portland",
        "description": "We provide funky and fabulous fashions to the citizens of Black Rock City. Open daily from 12-4pm, come on into the boutique and let our fashionistas slip you into something a little more questionable.   Playa wear donations and volunteers always welcome.",
        "location": {
            "string": "Center Camp Plaza @ 3:45",
            "frontage": "Center Camp Plaza",
            "intersection": "3:45",
            "intersection_type": "@",
            "gps_latitude": 40.780209915515925,
            "gps_longitude": -119.2136344450907
        },
        "location_string": "Center Camp Plaza @ 3:45"
    },
    {
        "uid": "a1Xd0000001IOJVEA4",
        "year": 2016,
        "name": "Arctica Ice Sales",
        "contact_email": "gentle@burningman.org",
        "hometown": "Iceland",
        "description": "Arctica Ice Sales is your downtown resource for ice.  Crushed and block ice are available for $3 each or a 6-pack of crushed for $18.  During the event, ice sales hours (at this location) are Mon-Sat 9am-6pm, Sun Noon-6pm and 10am-Noon on Labor Day.  \r\n\r\nPre-event sales are Thurs-Sun Noon-6pm at this location only.",
        "location": {
            "string": "Center Camp Plaza @ 8:45",
            "frontage": "Center Camp Plaza",
            "intersection": "8:45",
            "intersection_type": "@",
            "gps_latitude": 40.7811336797547,
            "gps_longitude": -119.21457074605829
        },
        "location_string": "Center Camp Plaza @ 8:45"
    },
    {
        "uid": "a1Xd0000001IXCmEAO",
        "year": 2016,
        "name": "Black Rock Beacon",
        "url": "http://blackrockbeacon.org/",
        "contact_email": "questions@blackrockbeacon.org",
        "hometown": "San Francisco",
        "description": "We produce a daily newspaper for Black Rock City with a mix of fun articles and serious news. Our Press Club & News Room provide shade and refreshment for ourselves as well as other members of the press, bacon-bearing volunteers, and interested Burners Lux Veritas Lardum!",
        "location": {
            "string": "Center Camp Plaza @ 1:15",
            "frontage": "Center Camp Plaza",
            "intersection": "1:15",
            "intersection_type": "@",
            "gps_latitude": 40.78084532927058,
            "gps_longitude": -119.21314944215487
        },
        "location_string": "Center Camp Plaza @ 1:15"
    },
    {
        "uid": "a1Xd0000001IOBTEA4",
        "year": 2016,
        "name": "Arte della Lana",
        "hometown": "San Francisco",
        "location": {
            "string": "Esplanade & 6:00 Portal",
            "frontage": "Esplanade",
            "intersection": "6:00 Portal",
            "intersection_type": "&"
        },
        "location_string": "Esplanade & 6:00 Portal"
    },
    {
        "uid": "a1Xd0000001IOvoEAG",
        "year": 2016,
        "name": "Black Rock City Hardware Shoppe",
        "url": "http://www.brchardware.org",
        "contact_email": "marc17phone@gmail.com",
        "hometown": "Seattle",
        "description": "The name says it all. Black Rock City Hardware Shoppe will be on-site with a variety of tools and supplies to help build or repair just about anything on the playa. We are proud to have spent over 15 years serving Black Rock City in this capacity.\r\nWe have hand tools, power tools, nails, nuts, bolts, tape, string, wire, paint, bike tools, automotive tools, glue, rivets, and whatever else we can manage to fit on the truck. We enjoy helping people work on art projects and helping camps who have suffered structural difficulties, but we also help with minor automotive problems, generator issues, and fix an inordinate amount of bikes. Whatever people bring us, we'll try and fix if we can. We do not have lots of raw building materials, like 2x4s, PVP pipes, or plywood, but do have a need/want bulletin board to connect gifts with needs. The Playa often provides!",
        "location": {
            "string": "Center Camp Plaza @ 9:15",
            "frontage": "Center Camp Plaza",
            "intersection": "9:15",
            "intersection_type": "@",
            "gps_latitude": 40.78124504684503,
            "gps_longitude": -119.21442383866737
        },
        "location_string": "Center Camp Plaza @ 9:15"
    },
    {
        "uid": "a1Xd0000001IV6HEAW",
        "year": 2016,
        "name": "Black Rock City Post Office",
        "contact_email": "brcpo@yahoo.com",
        "hometown": "Portland, OR",
        "description": "2016\r\nThere's no team in Fuck You! We provide service and delivery of your U.S. and playa mail, on and off the playa. Come trade post cards, stamps, stories and deliver the mail. We provide performance art, socialization, integration, certified documentation and citizenship for your trip to BRC!",
        "location": {
            "string": "Center Camp Plaza @ 3:15",
            "frontage": "Center Camp Plaza",
            "intersection": "3:15",
            "intersection_type": "@",
            "gps_latitude": 40.78028849669451,
            "gps_longitude": -119.21345451270028
        },
        "location_string": "Center Camp Plaza @ 3:15"
    },
    {
        "uid": "a1Xd0000001IMkSEAW",
        "year": 2016,
        "name": "BRC WEEKLY newspaper",
        "url": "http://brcweekly.com",
        "contact_email": "brcweekly@brcweekly.com",
        "hometown": "San Francisco",
        "description": "BRC WEEKLY -- Black Rock City's alternative newsweekly, publishing since 1995\r\n\r\nhttp://BRCWeekly.com",
        "location": {
            "string": "6:30 & Esplanade",
            "frontage": "6:30",
            "intersection": "Esplanade",
            "intersection_type": "&",
            "gps_latitude": 40.78297439508715,
            "gps_longitude": -119.21433537703916
        },
        "location_string": "6:30 & Esplanade"
    },
    {
        "uid": "a1Xd0000001IMzmEAG",
        "year": 2016,
        "name": "Burning Man Information Radio",
        "url": "http://www.bmir.org",
        "contact_email": "bmir@burningman.org",
        "hometown": "San Francisco",
        "description": "BMIR - Burning Man Information Radio\r\nBroadcasting on the playa at n94.5 FM and streaming at BMIR.org",
        "location": {
            "string": "Esplanade & 5:45",
            "frontage": "Esplanade",
            "intersection": "5:45",
            "intersection_type": "&"
        },
        "location_string": "Esplanade & 5:45"
    },
    {
        "uid": "a1Xd0000001IN6TEAW",
        "year": 2016,
        "name": "Burning Man DMV",
        "contact_email": "dmv@burningman.org",
        "hometown": "San Francisco",
        "description": "This is the official Burning Man DMV.  All mutant vehicles and disabled persons with vehicles must come to the DMV for licensing.",
        "location": {
            "string": "Esplanade & 6:00 Portal",
            "frontage": "Esplanade",
            "intersection": "6:00 Portal",
            "intersection_type": "&"
        },
        "location_string": "Esplanade & 6:00 Portal"
    },
    {
        "uid": "a1Xd0000001IVENEA4",
        "year": 2016,
        "name": "Costco Soulmate Trading Outlet",
        "description": "Costco Soulmate Trading Outlet is Black Rock City’s leading supplier of high-quality, low-cost soulmates since 1998. We offer quality name brand and private-label soulmates at substantially lower prices than can be found through conventional wholesale source",
        "location": {
            "string": "Rod's Road @ 3:30",
            "frontage": "Rod's Road",
            "intersection": "3:30",
            "intersection_type": "@",
            "gps_latitude": 40.77898664539121,
            "gps_longitude": -119.21258288879693
        },
        "location_string": "Rod's Road @ 3:30"
    },
    {
        "uid": "a1Xd0000001IMh4EAG",
        "year": 2016,
        "name": "Center Camp Cafe",
        "url": "http://burningman.org/event/black-rock-city-guide/infrastructure/center-camp-cafe/",
        "hometown": "Black Rock City"
    },
    {
        "uid": "a1Xd0000001IStoEAG",
        "year": 2016,
        "name": "Champagne Lounge",
        "url": "https://www.facebook.com/Champagnelounge/",
        "contact_email": "champagneloungebrc@gmail.com",
        "hometown": "Reno and San Francisco",
        "description": "Come by the Champagne Lounge for your daily dose of bubbly fun! The Champagne Lounge will be quenching your midday thirst with happy hours featuring ice-cold champagne. Not in the mood for bubbles?  Grab some friends and take a shotski! Bring your own cup, and be ready for booze, live music, and fun! Also check out Champagne Lounge Audio Programing, or the C.L.A.P, on your radio at 99.9 fm!",
        "location": {
            "string": "Rod's Road @ 5:30",
            "frontage": "Rod's Road",
            "intersection": "5:30",
            "intersection_type": "@",
            "gps_latitude": 40.778986645391214,
            "gps_longitude": -119.21529477892375
        },
        "location_string": "Rod's Road @ 5:30"
    },
    {
        "uid": "a1Xd0000001IRKREA4",
        "year": 2016,
        "name": "Children of Chaos",
        "url": "https://chaoscamp.wordpress.com",
        "contact_email": "captvic4@gmail.com",
        "hometown": "Portland",
        "description": "Chaos, joy, good conversation, parades and motherly advice.  Gold parade Wednesday at 6:00 pm, cocktails after the parade.  Also, meet the Jewish mother you never had - mothering in your choice of English, Yiddish, or Hebrew.  For good conversation, try our bar.",
        "location": {
            "string": "6:30 & Esplanade",
            "frontage": "6:30",
            "intersection": "Esplanade",
            "intersection_type": "&",
            "gps_latitude": 40.78297439508715,
            "gps_longitude": -119.21433537703916
        },
        "location_string": "6:30 & Esplanade"
    },
    {
        "uid": "a1Xd0000001IXBtEAO",
        "year": 2016,
        "name": "Camp PlayApology",
        "contact_email": "campplayapology@gmail.com",
        "hometown": "L.A. and Tucson",
        "description": "Black Rock City's first \"Custom Apology Delivery Service\" offers Playa-friendly flowers, Burner-centric cards, and singing \"SorryGrams\" for BRC residents who wish to make playAmends for missteps and misdeeds. Send out a card or two, decorate your own card, relax in our comfy, breezy shade structure or have a shot of artisanal, home-infused vodka. Check Playa Events for Sorry Soirees, vod tastings and other activities.",
        "location": {
            "string": "9:00 Plaza @ 1:00",
            "frontage": "9:00 Plaza",
            "intersection": "1:00",
            "intersection_type": "@",
            "gps_latitude": 40.79223061265241,
            "gps_longitude": -119.21452184853834
        },
        "location_string": "9:00 Plaza @ 1:00"
    },
    {
        "uid": "a1Xd0000001IN2MEAW",
        "year": 2016,
        "name": "Census",
        "url": "http://journal.burningman.org/census/",
        "contact_email": "census@burningman.org",
        "hometown": "Los Angeles",
        "description": "The Census has been collecting information about the population of Black Rock City since 2002. The results of the Census from previous years will be on display at the Census camp. The 2016 results of the Census will be presented in the Afterburn report accessible through the Burning Man website.",
        "location": {
            "string": "Center Camp Plaza @ 11:30",
            "frontage": "Center Camp Plaza",
            "intersection": "11:30",
            "intersection_type": "@",
            "gps_latitude": 40.78128891262729,
            "gps_longitude": -119.21354043127307
        },
        "location_string": "Center Camp Plaza @ 11:30"
    },
    {
        "uid": "a1Xd0000001IXY8EAO",
        "year": 2016,
        "name": "Contradance Community Camp",
        "url": "http://burningmancontradance.com",
        "contact_email": "mkstowegnv@gmail.com",
        "hometown": "Gainesville",
        "description": "Easy to learn (no footwork necessary) contradancing to live music (looped/ traditional/ celtic/ fusion/ techno); with a caller who instructs (but with room for dancers to improvise and embellish) on three evenings and three mornings under our dance tent as well as daytime workshops, jams, dances and concerts. Half the moves are with your partner, half with everyone else, resulting in a tribal vibe (with stomping, clapping, and hooting), where the Zen is flow, synchrony, bonding, playfulness, and inclusion (appropriate for all ages and possible for many disabled), NOT competition or perfection - if you are smiling, you are doing it right, and everyone who shows up can have fun.",
        "location": {
            "string": "Rod's Road @ 2:15",
            "frontage": "Rod's Road",
            "intersection": "2:15",
            "intersection_type": "@",
            "gps_latitude": 40.77997939554123,
            "gps_longitude": -119.21143191558795
        },
        "location_string": "Rod's Road @ 2:15"
    },
    {
        "uid": "a1Xd0000001IMoZEAW",
        "year": 2016,
        "name": "D.P.W. Ghetto",
        "description": "Home of Black Rock City's Department of Public Works.",
        "location": {
            "string": "5:30 & D",
            "frontage": "5:30",
            "intersection": "D",
            "intersection_type": "&",
            "gps_latitude": 40.77771409960112,
            "gps_longitude": -119.21312225583048
        },
        "location_string": "5:30 & D"
    },
    {
        "uid": "a1Xd0000001IUe0EAG",
        "year": 2016,
        "name": "Dr Playa's Ear Nose&Throat Clinic",
        "hometown": "Reno",
        "description": "Pesky playa dust packed into those openings in your head? We can help with that!\r\nOur  NON MEDICAL staff is available Mon -Friday from 1-3 PM",
        "location": {
            "string": "Rod's Road @ 9:15",
            "frontage": "Rod's Road",
            "intersection": "9:15",
            "intersection_type": "@",
            "gps_latitude": 40.78239678455273,
            "gps_longitude": -119.21559226504021
        },
        "location_string": "Rod's Road @ 9:15"
    },
    {
        "uid": "a1Xd0000001IORjEAO",
        "year": 2016,
        "name": "EGGS Bar",
        "url": "https://www.facebook.com/groups/499722046857896/",
        "hometown": "Alameda",
        "description": "EGGS Bar is returning to Burning Man 2016, after a 3 year hiatus, with much anticipation!\r\nBuilding on years of well-honed playa experience, EGGS Bar crew of veteran burners will again create a welcoming venue of the deepest interaction.  A jewel on the playa; it is a beautifully designed bar with amazing artifacts. While disguised as a friendly tavern, the space we create will be so much more than a place to grab a drink... storytelling station, meeting place of the minds, incubator of adventures, spontaneous dance party spot, Burning Man debate forum. All that and more,  we are YOUR neighborhood bar on the playa!",
        "location": {
            "string": "Center Camp Plaza @ 8:00",
            "frontage": "Center Camp Plaza",
            "intersection": "8:00",
            "intersection_type": "@",
            "gps_latitude": 40.7809226723979,
            "gps_longitude": -119.21470796748386
        },
        "location_string": "Center Camp Plaza @ 8:00"
    },
    {
        "uid": "a1Xd0000001IM7oEAG",
        "year": 2016,
        "name": "Cotton Candy Camp",
        "hometown": "Boulder",
        "description": "We serve pink, sticky, delicious cotton candy every day during the event!!!!\r\nIt's neat, it's sweet, it's gonna rot your teeth!!!!",
        "location": {
            "string": "Center Camp Plaza @ 10:00",
            "frontage": "Center Camp Plaza",
            "intersection": "10:00",
            "intersection_type": "@",
            "gps_latitude": 40.78134924141075,
            "gps_longitude": -119.21414510254817
        },
        "location_string": "Center Camp Plaza @ 10:00"
    },
    {
        "uid": "a1Xd0000001IMzNEAW",
        "year": 2016,
        "name": "Everywhere Pavilion",
        "url": "http://www.burningman.org",
        "hometown": "Everywhere but Black Rock City",
        "description": "The Everywhere Pavilion serves as a point of connection between Black Rock Citizens and off-playa, worldwide Burning Man-related projects and culture. Come learn about and connect with off-playa Art and Civic Engagement programs, the Regionals Network, Burners Without Borders, and Black Rock Solar as well as meet other like-minded burners to discuss year-round efforts to bring Burning Man culture to the rest of the world.",
        "location": {
            "string": "Esplanade & 6:15",
            "frontage": "Esplanade",
            "intersection": "6:15",
            "intersection_type": "&"
        },
        "location_string": "Esplanade & 6:15"
    },
    {
        "uid": "a1Xd0000001IUqLEAW",
        "year": 2016,
        "name": "Desert Morning",
        "url": "http://www.desertmorning.org",
        "contact_email": "info@desertmorning.org",
        "hometown": "Leucadia (San Diego)",
        "description": "Desert Morning: Home of the Lovin' Oven: Greet the morning, and let the smell of our freshly baked bread draw you into our oasis, where we will will soothe your soul and nourish your body.  Since 2011 we've been serving hungry, dusty, lovely Burners hot Tuscan Flatbread, organic jams and fresh mint tea and entertainment with funky DJs and eclectic performances. Our bread is lovingly baked by our campmates in our beautiful wood-fired Lovin' Oven. In the middle of the desert: hot, dry and dusty, we bake bread. Every morning. Just for you! Performers needing a space or anyone wanting to use the oven, please drop by and see us or email us in advance.",
        "location": {
            "string": "Center Camp Plaza @ 4:45",
            "frontage": "Center Camp Plaza",
            "intersection": "4:45",
            "intersection_type": "@",
            "gps_latitude": 40.78016925789012,
            "gps_longitude": -119.21404264150277
        },
        "location_string": "Center Camp Plaza @ 4:45"
    },
    {
        "uid": "a1Xd0000001IWWZEA4",
        "year": 2016,
        "name": "Crossroads & The MoonCheese Grill",
        "url": "https://www.facebook.com/CrossroadsLiveExperience",
        "hometown": "San Francisco",
        "description": "Crossroads pumps out the best live music on the playa, verified by gods and science. Moon Cheese is the best grilled cheese camp on the playa according to YOUR MOUTH. Get down with our nightly live music shows featuring a 20+ piece band, dancers, performers, and people wearing nothing but aprons covered in grill marks. Get a grilled cheese sandwich, a drink at the bar, dance your dusty self to sheer exhaustion and then snag some downtime in our sparkly star chill dome before it all disappears. You'll never know whether it was real or just a greasy, funktastic dream so intense it made Mona Lisa blush.",
        "location": {
            "string": "9:00 Plaza @ 10:30",
            "frontage": "9:00 Plaza",
            "intersection": "10:30",
            "intersection_type": "@",
            "gps_latitude": 40.79256133313418,
            "gps_longitude": -119.2141864372901
        },
        "location_string": "9:00 Plaza @ 10:30"
    },
    {
        "uid": "a1Xd0000001IMS8EAO",
        "year": 2016,
        "name": "Earth Guardians",
        "url": "http://www.earthguardians.net",
        "contact_email": "earthguardians@burningman.org",
        "hometown": "Nevada City",
        "description": "We inspire, inform and encourage our fellow Black Rock City citizens to apply the Green & Leave No Trace principles and practices to life in our temporary desert home and to leave positive traces in our desert home. Come, volunteer and participate in our daily talks about Black Rock and Leave No Trace or just grab a MOOP bag!",
        "location": {
            "string": "Esplanade & 5:30",
            "frontage": "Esplanade",
            "intersection": "5:30",
            "intersection_type": "&",
            "gps_latitude": 40.78046704889989,
            "gps_longitude": -119.21102358626698
        },
        "location_string": "Esplanade & 5:30"
    },
    {
        "uid": "a1Xd0000001IHW4EAO",
        "year": 2016,
        "name": "Fire Conclave Convergence",
        "hometown": "Reno",
        "description": "Fire Conclave Convergence is where fire performers who have been accepted to dance in the Great Circle come to check in and get updated information.  Also where you can post and find fire performance happenings Hours: Monday-Friday 10-6.",
        "location": {
            "string": "6:00 Portal & 6:00 Portal",
            "frontage": "6:00 Portal",
            "intersection": "6:00 Portal",
            "intersection_type": "&"
        },
        "location_string": "6:00 Portal & 6:00 Portal"
    },
    {
        "uid": "a1Xd0000001IGXHEA4",
        "year": 2016,
        "name": "Free Photography Zone",
        "url": "johnbrennanphoto.com",
        "contact_email": "johnbrennanphoto@yahoo.com",
        "hometown": "Santa Clara",
        "description": "Free Photography Zone, for 20 years photographing in a professional studio environment and giving prints to the participants of Burning Man.  Come by, be photographed in all your Burning Man splendor  and take the photograph home with you.",
        "location": {
            "string": "A & 5:45",
            "frontage": "A",
            "intersection": "5:45",
            "intersection_type": "&"
        },
        "location_string": "A & 5:45"
    },
    {
        "uid": "a1Xd0000001IMSXEA4",
        "year": 2016,
        "name": "Greeters Camp",
        "contact_email": "toplessdeb@burningman.org",
        "hometown": "Los Angeles",
        "description": "Greeters Camp.",
        "location": {
            "string": "Rod's Road @ 6:15",
            "frontage": "Rod's Road",
            "intersection": "6:15",
            "intersection_type": "@",
            "gps_latitude": 40.779514898665546,
            "gps_longitude": -119.21609110732814
        },
        "location_string": "Rod's Road @ 6:15"
    },
    {
        "uid": "a1Xd0000001IG3UEAW",
        "year": 2016,
        "name": "Hang-Out, the",
        "url": "https://www.facebook.com/groups/150704538339546/",
        "contact_email": "satyr.wells@facebook.com",
        "hometown": "chico",
        "description": "After a long night of hunting vampires and dodging intergalactic marauders in the seedy spaceport known to some as BRC.  The glowing crystals that illuminate the city begin to fade as the Day Star climbs above the mountains.  It is time to rest.  From high and low, everyone knows that there is no better way to chill on the playa than a cool, shaded hammock.  Come ye unto the Hang Out.\r\n\r\nThe playa is a heavy load to carry, we know.  There is much work to do.  Inter-dimensional neverlands of sublime witchery don't just dance themselves into existence.  Someone has to stack the vibes.  Someone has to wire skulls onto shit.  And after a day/night/day of labors, you need to recharge.  Come ye then unto the Hang Out.\r\n\r\nThe hammock is an ancient technology, simple and perfect.  Tension, elevation, motion.  Perfect harmony between ground and air.  A dusty burrito drifting through the continuum.  The crucible wherein soulmates are alloyed.  A great place to take a nap.  Come ye unto the Hang Out.",
        "location": {
            "string": "Center Camp Plaza @ 7:00",
            "frontage": "Center Camp Plaza",
            "intersection": "7:00",
            "intersection_type": "@",
            "gps_latitude": 40.78061061305432,
            "gps_longitude": -119.21470773450295
        },
        "location_string": "Center Camp Plaza @ 7:00"
    },
    {
        "uid": "a1Xd0000001IIudEAG",
        "year": 2016,
        "name": "Homebrew 4A Homebrew",
        "url": "https://www.facebook.com/groups/476024835926123/",
        "contact_email": "homebrew4ahomebrew@yahoo.com",
        "hometown": "Sparks",
        "description": "A Home Brewers community hub where brewers of the Playa come to meet and share. Enjoy a cold home brewed beer, mead or soda served daily from noon into the dark. We have a pool table, games and daily events including our world famous pickle party! Bring your keg and we will refrigerate and tap it.",
        "location": {
            "string": "Center Camp Plaza @ 2:30",
            "frontage": "Center Camp Plaza",
            "intersection": "2:30",
            "intersection_type": "@",
            "gps_latitude": 40.78046523615859,
            "gps_longitude": -119.21324958814462
        },
        "location_string": "Center Camp Plaza @ 2:30"
    },
    {
        "uid": "a1Xd0000001INDbEAO",
        "year": 2016,
        "name": "Lamplighter Chapel",
        "url": "http://burningman.org/event/volunteering/teams/lamplighters/",
        "location": {
            "string": "Center Camp Plaza @ 5:15",
            "frontage": "Center Camp Plaza",
            "intersection": "5:15",
            "intersection_type": "@",
            "gps_latitude": 40.780209915515925,
            "gps_longitude": -119.21424322262997
        },
        "location_string": "Center Camp Plaza @ 5:15"
    },
    {
        "uid": "a1Xd0000001IYBeEAO",
        "year": 2016,
        "name": "Healing Foot Wash",
        "url": "http://healingfootwash.org",
        "contact_email": "gserafini@gmail.com",
        "hometown": "Oakland",
        "description": "Come experience a new level of relaxation and conversation in Healing Foot Wash at one of our 16 comfortable foot wash stations.  Come back every day and participate once you've had your feet washed!",
        "location": {
            "string": "Rod's Road @ 8:30",
            "frontage": "Rod's Road",
            "intersection": "8:30",
            "intersection_type": "@",
            "gps_latitude": 40.78179351483209,
            "gps_longitude": -119.21629015337197
        },
        "location_string": "Rod's Road @ 8:30"
    },
    {
        "uid": "a1Xd0000001IWEQEA4",
        "year": 2016,
        "name": "Hack-a-Cola",
        "hometown": "San Francisco",
        "description": "Hack-a-Cola will provide a meeting place for residents of BRC to congregate over cold hand crafted sodas during the hot sunny days and then warm themselves at night around our lounge area with a cup of hot cocoa.",
        "location": {
            "string": "3:00 Plaza @ 5:45",
            "frontage": "3:00 Plaza",
            "intersection": "5:45",
            "intersection_type": "@",
            "gps_latitude": 40.78002943094825,
            "gps_longitude": -119.1980042923349
        },
        "location_string": "3:00 Plaza @ 5:45"
    },
    {
        "uid": "a1Xd0000001IV3NEAW",
        "year": 2016,
        "name": "ILLUMINUS",
        "url": "http://facebook.com/theilluminus",
        "contact_email": "scarabin@gmail.com",
        "hometown": "Los Angeles",
        "description": "We are the illuminauts. Masters of dark and wielders of light; we march to the furthest reaches of the desert, illuminating the way with the fires of our creative spirit. Join us in igniting the hearts and minds of those along the way.",
        "location": {
            "string": "Rod's Road @ 3:45",
            "frontage": "Rod's Road",
            "intersection": "3:45",
            "intersection_type": "@",
            "gps_latitude": 40.778867924617295,
            "gps_longitude": -119.2129011462326
        },
        "location_string": "Rod's Road @ 3:45"
    },
    {
        "uid": "a1Xd0000001IV46EAG",
        "year": 2016,
        "name": "Kentucky Fried Camp",
        "url": "http://kentuckyfriedcamp.com",
        "hometown": "Lexington",
        "description": "Bringing a hot breakfast of bourbon, fried baloney sandwiches, and Kentucky hospitality to the playa since 2007. KFC, it's what's for breakfast.",
        "location": {
            "string": "3:00 Plaza @ 12:15",
            "frontage": "3:00 Plaza",
            "intersection": "12:15",
            "intersection_type": "@",
            "gps_latitude": 40.78050933848554,
            "gps_longitude": -119.198637917266
        },
        "location_string": "3:00 Plaza @ 12:15"
    },
    {
        "uid": "a1Xd0000001IXjfEAG",
        "year": 2016,
        "name": "Kanuckistan Duello",
        "url": "http://kanuckistan.ca/",
        "contact_email": "core@kanuckistan.ca",
        "hometown": "Calgary",
        "description": "BLASTO Duello ray gun blaster shooting range, now with dueling and more balls of fire. 100% eyesafe. Home of the Old Country Vodka Snorting Bar, 12th annual Xeni Cup street hockey game, knife sharpening services, and Brain Gym.",
        "location": {
            "string": "Rod's Road @ 4:00",
            "frontage": "Rod's Road",
            "intersection": "4:00",
            "intersection_type": "@",
            "gps_latitude": 40.77878166352722,
            "gps_longitude": -119.21323707449336
        },
        "location_string": "Rod's Road @ 4:00"
    },
    {
        "uid": "a1Xd0000001IV1WEAW",
        "year": 2016,
        "name": "Icy Hands CHILLZONE",
        "url": "https://www.facebook.com/groups/IcyHands/",
        "contact_email": "alotofur-ontheplaya@yahoo.com",
        "hometown": "San Pedro, California 90731",
        "description": "Chill out with the Icy Hands crew as they defrost between midday mercy missions: share cool stories, images and video of those touched by icy hands under the sizzling playa sun.  Learn how to turn a simple block of ice into smiles, goosebumps and a truly incredible shared experience!",
        "location": {
            "string": "6:00 & Center Camp Plaza",
            "frontage": "6:00",
            "intersection": "Center Camp Plaza",
            "intersection_type": "&",
            "gps_latitude": 40.78034044307817,
            "gps_longitude": -119.21450146744877
        },
        "location_string": "6:00 & Center Camp Plaza"
    },
    {
        "uid": "a1Xd0000001IJgEEAW",
        "year": 2016,
        "name": "Mobility Camp",
        "url": "http://www.mobilitycamp.org",
        "contact_email": "brcaccessibility@gmail.com",
        "hometown": "Hesperia",
        "description": "Wheelchair accessible Camp, Art Tours into the Deep Playa Art 4 times a Day, Worst Come, first served:),Able bodied welcome if space allows. Mobility equipment loan on site and Information on wheelchair prep on our website.",
        "location": {
            "string": "Center Camp Plaza @ 7:30",
            "frontage": "Center Camp Plaza",
            "intersection": "7:30",
            "intersection_type": "@",
            "gps_latitude": 40.78076664108206,
            "gps_longitude": -119.21473497925402
        },
        "location_string": "Center Camp Plaza @ 7:30"
    },
    {
        "uid": "a1Xd0000001IVuyEAG",
        "year": 2016,
        "name": "Midnight Poutine",
        "url": "http://www.midnightpoutine.org",
        "contact_email": "info@midnightpoutine.org",
        "hometown": "Montreal",
        "description": "Bonsoir ! Come and sample Québec's favourite late night snack at Midnight Poutine. Learn the awesome power of french fries, cheese curds and hot gravy. Embrace the joie de vivre of our bilingual Canadian camp.  Lâche pas la patate!",
        "location": {
            "string": "Rod's Road @ 7:15",
            "frontage": "Rod's Road",
            "intersection": "7:15",
            "intersection_type": "@",
            "gps_latitude": 40.78049759628541,
            "gps_longitude": -119.21662954660144
        },
        "location_string": "Rod's Road @ 7:15"
    },
    {
        "uid": "a1Xd0000001IV6vEAG",
        "year": 2016,
        "name": "MINSTREL CrAMP",
        "contact_email": "mayorbaka@ojaiconcertseries.com",
        "hometown": "Ojai and Ventura",
        "description": "Feeling the need to fiddle about? \r\nTo blow, beat or stroke on something? \r\nCome to MINSTREL CrAMP and get your creative \"musical juices\" flowing. \r\nStop in, \r\nListen in , \r\nJoin in, to some great live acoustic, jamming with our house band \"THE BURNING SENSATIONS\".\r\nThis year we feature a day of Celtic music, and afternoon of belly dancing and more\r\nCheck the schedule board out front to see what's happening or sign-up for a slot to perform with your own band (or ours) \r\nIt's all good! \r\nListeners welcome!\r\nPS: We do have a large selection of legitimate \"menstrual cramp\" supplies if you have a special need.",
        "location": {
            "string": "Rod's Road @ 2:00",
            "frontage": "Rod's Road",
            "intersection": "2:00",
            "intersection_type": "@",
            "gps_latitude": 40.780233937746324,
            "gps_longitude": -119.2113175879733
        },
        "location_string": "Rod's Road @ 2:00"
    },
    {
        "uid": "a1Xd0000001IKBfEAO",
        "year": 2016,
        "name": "Nose Fish",
        "contact_email": "retrorider2992-nosefish@yahoo.com",
        "hometown": "Silicon Valley, Pai (Thailand)",
        "description": "Come to Caffè Leonardo for a delicious cup of freshly brewed coffee in the mornings.  Afternoons will feature Leonardo's Workshop for Electronic (EL Wire and LED) and Bicycle Repair with hands-on teaching.  Evenings enjoy the MEZ interactive video screen and dance the night away.",
        "location": {
            "string": "Rod's Road @ 4:15",
            "frontage": "Rod's Road",
            "intersection": "4:15",
            "intersection_type": "@",
            "gps_latitude": 40.77872931197351,
            "gps_longitude": -119.21358494336906
        },
        "location_string": "Rod's Road @ 4:15"
    },
    {
        "uid": "a1Xd0000001IX5bEAG",
        "year": 2016,
        "name": "Pickle Joint",
        "url": "http://www.facebook.com/picklejoint",
        "hometown": "Los Angeles",
        "description": "Our noble studs and saucy wenches have been serving you pickles and spicy pickletinis since 2003. Join us for all of the usual mayhem as we celebrate with good vibe socials like Banjos & Whiskey and Madonnapocalypse, a never ending supply of cold, crisp, brisk pickles, plus the selfless, charming, and tireless service we live to provide to you, the people of Black Rock City.",
        "location": {
            "string": "Center Camp Plaza @ 8:15",
            "frontage": "Center Camp Plaza",
            "intersection": "8:15",
            "intersection_type": "@",
            "gps_latitude": 40.78099734998075,
            "gps_longitude": -119.21467455264099
        },
        "location_string": "Center Camp Plaza @ 8:15"
    },
    {
        "uid": "a1Xd0000001IXByEAO",
        "year": 2016,
        "name": "Nacho Campo",
        "contact_email": "nachocampodusto@gmail.com",
        "hometown": "Portland",
        "description": "Nacho Campo, our campo es tu campo. Create, Celebrate, Relax and Wrestle,",
        "location": {
            "string": "3:00 Plaza @ 1:00",
            "frontage": "3:00 Plaza",
            "intersection": "1:00",
            "intersection_type": "@",
            "gps_latitude": 40.780568783815816,
            "gps_longitude": -119.19847979727713
        },
        "location_string": "3:00 Plaza @ 1:00"
    },
    {
        "uid": "a1Xd0000001IXeaEAG",
        "year": 2016,
        "name": "People of Color Camp",
        "url": "https://www.facebook.com/People-Of-Color-at-Burning-Man-586227634754548/?ref=aymt_homepage_panel",
        "contact_email": "egophobia@hotmail.com",
        "hometown": "New York City",
        "description": "People of Color Camp is a space for art, open talks on social justice and exercises in community building. All are welcome!",
        "location": {
            "string": "Rod's Road @ 9:30",
            "frontage": "Rod's Road",
            "intersection": "9:30",
            "intersection_type": "@",
            "gps_latitude": 40.78254632595307,
            "gps_longitude": -119.21529702799528
        },
        "location_string": "Rod's Road @ 9:30"
    },
    {
        "uid": "a1Xd0000001IXTrEAO",
        "year": 2016,
        "name": "PO9",
        "url": "http://twitter.com/brcpo9",
        "hometown": "Worldwide",
        "description": "We connect you with the world; USPS to the Playa, Playa to any international address, WiFi, and friendly (and not-so-friendly) posties: stand in line, and fill out your form... in triplicate... with crayon.",
        "location": {
            "string": "9:00 Plaza @ 8:45",
            "frontage": "9:00 Plaza",
            "intersection": "8:45",
            "intersection_type": "@",
            "gps_latitude": 40.79283288692738,
            "gps_longitude": -119.21436354175313
        },
        "location_string": "9:00 Plaza @ 8:45"
    },
    {
        "uid": "a1Xd0000001IOxfEAG",
        "year": 2016,
        "name": "Pollination",
        "url": "http://www.dangsweet.com",
        "contact_email": "camp@dangsweet.com",
        "hometown": "Santa Cruz",
        "description": "Full service Instant Weddings performed under whimsical floral art in Pollination's Love Chapel. Enter into a life long union on a whim. You probably might not be sorry.",
        "location": {
            "string": "9:00 Plaza @ 5:45",
            "frontage": "9:00 Plaza",
            "intersection": "5:45",
            "intersection_type": "@",
            "gps_latitude": 40.79276962520508,
            "gps_longitude": -119.21499766263501
        },
        "location_string": "9:00 Plaza @ 5:45"
    },
    {
        "uid": "a1Xd0000001ISq6EAG",
        "year": 2016,
        "name": "Playa Jazz Cafe",
        "url": "https://www.facebook.com/PlayaJazzCafe/",
        "contact_email": "neilsjazz@hotmail.com",
        "hometown": "San Francisco, Santa Cruz, San Jose",
        "description": "Playa Jazz Cafe",
        "location": {
            "string": "Center Camp Plaza @ 6:15",
            "frontage": "Center Camp Plaza",
            "intersection": "6:15",
            "intersection_type": "@",
            "gps_latitude": 40.78039969385459,
            "gps_longitude": -119.21457016989547
        },
        "location_string": "Center Camp Plaza @ 6:15"
    },
    {
        "uid": "a1Xd0000001IJgJEAW",
        "year": 2016,
        "name": "Planet Earth",
        "url": "https://www.facebook.com/PEatBM/",
        "contact_email": "vennp@hotmail.com",
        "hometown": "San Francisco",
        "description": "Black Rock Cities \"Music with words\" Indoor Night Club.  \r\nOpen every day from 4pm to 4am, offering 3 distinct themes per day.",
        "location": {
            "string": "9:00 Plaza @ 2:30",
            "frontage": "9:00 Plaza",
            "intersection": "2:30",
            "intersection_type": "@",
            "gps_latitude": 40.79226475521312,
            "gps_longitude": -119.21486486101998
        },
        "location_string": "9:00 Plaza @ 2:30"
    },
    {
        "uid": "a1Xd0000001IVF6EAO",
        "year": 2016,
        "name": "Playasophy",
        "hometown": "Seattle",
        "description": "Welcome to Playasophy, a space to rest and reflect in the excitement of the carnival. Come in the mornings for coffee to start off your day, and in the afternoons sit around a hookah, enjoy a beverage and share stories and experiences with both our members and other travelers! In the evenings, enjoy the splendor of the Wonderdome, a fully controllable immersive light display while resting in the House of Soft. We hope to see you soon!",
        "location": {
            "string": "3:00 Plaza @ 3:15",
            "frontage": "3:00 Plaza",
            "intersection": "3:15",
            "intersection_type": "@",
            "gps_latitude": 40.78044607680099,
            "gps_longitude": -119.19800391419895
        },
        "location_string": "3:00 Plaza @ 3:15"
    },
    {
        "uid": "a1Xd0000001IXimEAG",
        "year": 2016,
        "name": "Que Viva! Camp",
        "url": "https://www.facebook.com/QueVivaCamp",
        "hometown": "San Francisco Bay Area",
        "description": "Que Viva is a Burning Man camp of activists, artists and allies celebrating diversity, justice, and enlightenment through the power of interactive art and joyful action. We are dedicated to social justice and radical inclusion, bringing issues like immigration and racial justice to the playa in a celebratory, magical, Burning Man way. Our camp leads hands on art workshops for Burners of all ages, hosts compelling art installations about human rights issues, facilitates workshops and group discussions about race and inclusion, and serves as a relaxing chill space for Burners.\r\n\r\nYou can find us on: www.facebook.com/QueVivaCamp",
        "location": {
            "string": "Rod's Road @ 9:45",
            "frontage": "Rod's Road",
            "intersection": "9:45",
            "intersection_type": "@",
            "gps_latitude": 40.782665414439855,
            "gps_longitude": -119.21497846300686
        },
        "location_string": "Rod's Road @ 9:45"
    },
    {
        "uid": "a1Xd0000001IOeTEAW",
        "year": 2016,
        "name": "Playa Bike Repair",
        "url": "http://playabikerepair.com/",
        "contact_email": "info@playabikerepair.com",
        "hometown": "San Francisco",
        "description": "\"Playa Bike Repair\" is both a service and a theme camp. ON-Playa:  We run a \"Bike Lounge,\" with a bar, music, shade, and tools. Mechanics drop in. Friendly, nurturing, and supportive, they will gladly help you fix your bike! Last year, we helped over 4000 people fix their bikes! PRE-Playa, we offer bike rentals and transport; your support funds Playa Bike Repair.  Volunteers, mechanics, and campmates wanted.",
        "location": {
            "string": "9:00 Plaza @ 6:15",
            "frontage": "9:00 Plaza",
            "intersection": "6:15",
            "intersection_type": "@",
            "gps_latitude": 40.792832848233445,
            "gps_longitude": -119.21491426366346
        },
        "location_string": "9:00 Plaza @ 6:15"
    },
    {
        "uid": "a1Xd0000001IXAqEAO",
        "year": 2016,
        "name": "Porch Times",
        "url": "http://www.porchtimes.com",
        "contact_email": "jessebek@gmail.com",
        "hometown": "Los Angeles, Portland, Seattle",
        "description": "Come relax with us on the Back Porch to the Esplanade! Stick around for our events, stories and see why we are such a close camp. And don't forget, maintain thigh contact!",
        "location": {
            "string": "3:00 Plaza @ 6:15",
            "frontage": "3:00 Plaza",
            "intersection": "6:15",
            "intersection_type": "@",
            "gps_latitude": 40.779966316357076,
            "gps_longitude": -119.19808775256541
        },
        "location_string": "3:00 Plaza @ 6:15"
    },
    {
        "uid": "a1Xd0000001IMT6EAO",
        "year": 2016,
        "name": "Ranger Headquarters",
        "location": {
            "string": "Esplanade & 5:45",
            "frontage": "Esplanade",
            "intersection": "5:45",
            "intersection_type": "&"
        },
        "location_string": "Esplanade & 5:45"
    },
    {
        "uid": "a1Xd0000001IMzwEAG",
        "year": 2016,
        "name": "Media Mecca",
        "url": "http://burningman.org/network/about-us/press-media/media_mecca/",
        "contact_email": "media-mecca@burningman.org",
        "hometown": "Black Rock City",
        "description": "Media Mecca is Black Rock City's home to storytellers, journalists, and media. All media projects must register at Mecca prior to beginning in BRC.",
        "location": {
            "string": "Center Camp Plaza @ 10:45",
            "frontage": "Center Camp Plaza",
            "intersection": "10:45",
            "intersection_type": "@",
            "gps_latitude": 40.78136465876285,
            "gps_longitude": -119.21383480368873
        },
        "location_string": "Center Camp Plaza @ 10:45"
    },
    {
        "uid": "a1Xd0000001IG6EEAW",
        "year": 2016,
        "name": "SwagMart",
        "hometown": "Nevada City California",
        "description": "SwagMart is an Oasis of creativity located in the Heart of the Black Rock Desert. Our Swag Pins, Earrings, Necklaces, Playa Post cards,\r\nare collected and cherished each year while our nightly Branding of your .Belts, Boots, Hats etc. are a must have of the Playa.Special Swag trophies for our Costume Appreciation. Stop by for a creative fun\r\npositive experience and meet Burners fro all over the Planet.Free \r\nCoffee and Hot Chocolate this year. SwagMart is celebrating our 8th\r\nyear always close to Center Camp.",
        "location": {
            "string": "Center Camp Plaza @ 4:30",
            "frontage": "Center Camp Plaza",
            "intersection": "4:30",
            "intersection_type": "@",
            "gps_latitude": 40.7801641095488,
            "gps_longitude": -119.21393883386034
        },
        "location_string": "Center Camp Plaza @ 4:30"
    },
    {
        "uid": "a1Xd0000001IKm6EAG",
        "year": 2016,
        "name": "The Black Hole",
        "url": "http://gate.burningman.com",
        "contact_email": "buckdown@burningman.org",
        "hometown": "Black Rock City",
        "description": "Home of the BRC Gate, Perimeter & Exodus Dept.  If you are looking for one of us, this is where we are. If you wanna be one of us - this is where you stay.",
        "location": {
            "string": "E & 5:45",
            "frontage": "E",
            "intersection": "5:45",
            "intersection_type": "&",
            "gps_latitude": 40.77791815912868,
            "gps_longitude": -119.21508624262886
        },
        "location_string": "E & 5:45"
    },
    {
        "uid": "a1Xd0000001IQI8EAO",
        "year": 2016,
        "name": "Tango'd Up In Blues",
        "url": "http://bluestango.com",
        "contact_email": "tangoedupinblues@gmail.com",
        "hometown": "Eugene",
        "description": "Discover what it's like to hold a dance partner in your arms and move to the music.  Tango. Blues Dance.  Join us in re-popularizing partner dance in America.",
        "location": {
            "string": "Center Camp Plaza @ 4:00",
            "frontage": "Center Camp Plaza",
            "intersection": "4:00",
            "intersection_type": "@",
            "gps_latitude": 40.78018461265025,
            "gps_longitude": -119.21373298432496
        },
        "location_string": "Center Camp Plaza @ 4:00"
    },
    {
        "uid": "a1Xd0000001IXTNEA4",
        "year": 2016,
        "name": "The Dump",
        "url": "http://www.saloonensemble.com",
        "contact_email": "audiowells@gmail.com",
        "hometown": "Portland",
        "description": "Where the worlds most fabulous musicians and dancers from MarchFourth Marching Band, The Saloon Ensemble, Love-Bomb Go-Go Marching Band, Trashcan Joe, and The Ukeladies are dumped and recycled to endlessly create music from a by-gone era.  Come sing, dance, play our piano, and join-in as we all share in electronic-free acoustic joy! Lyrics included!",
        "location": {
            "string": "Center Camp Plaza @ 2:00",
            "frontage": "Center Camp Plaza",
            "intersection": "2:00",
            "intersection_type": "@",
            "gps_latitude": 40.78061061305432,
            "gps_longitude": -119.21316993321771
        },
        "location_string": "Center Camp Plaza @ 2:00"
    },
    {
        "uid": "a1Xd0000001IVywEAG",
        "year": 2016,
        "name": "The Breakfast Club",
        "url": "https://www.facebook.com/groups/218549604961632/",
        "contact_email": "scarbuttscafe@gmail.com",
        "hometown": "Oakland",
        "description": "The Breakfast Club village is home to Pancake Playhouse and Scarbutts Coffee. Pancake playhouse serves up hot delicious pancakes Monday through Friday 9:00am-12:00 noon\r\nScarbutts Coffee Serves you Hot and iced, cold brewed coffee. Monday through friday 9:00am -12:00 noon\r\nMonday throu",
        "location": {
            "string": "9:00 Plaza @ 3:15",
            "frontage": "9:00 Plaza",
            "intersection": "3:15",
            "intersection_type": "@",
            "gps_latitude": 40.792352979352394,
            "gps_longitude": -119.21499728426735
        },
        "location_string": "9:00 Plaza @ 3:15"
    },
    {
        "uid": "a1Xd0000001IRlSEAW",
        "year": 2016,
        "name": "Temple O'Flying Spaghetti Monster",
        "url": "http://www.fsmtemple.com/",
        "hometown": "Southern California",
        "description": "We are a comfortable neighborhood pub with a rockin' attitude. In honor of his noodley goodness the Friendly Fire Bar will administer ice cold libations and groovin' tunes for your mind, body and spirit. Call almost anywhere in the world on our free public phone or use our free wi-fi hotspot. Test your pole dancing skills at The Stripper Factory. The Flying Spaghetti Monster welcomes all, so stop by and be touched by his noodly appendage.",
        "location": {
            "string": "3:00 Plaza @ 9:15",
            "frontage": "3:00 Plaza",
            "intersection": "9:15",
            "intersection_type": "@",
            "gps_latitude": 40.78002948133456,
            "gps_longitude": -119.19872104027175
        },
        "location_string": "3:00 Plaza @ 9:15"
    },
    {
        "uid": "a1Xd0000001IJfzEAG",
        "year": 2016,
        "name": "Recycle Camp",
        "url": "http://burningman.org/event/black-rock-city-guide/infrastructure/recycle-camp/",
        "contact_email": "recycle@burningman.org",
        "hometown": "San Francisco",
        "location": {
            "string": "Center Camp Plaza @ 5:45",
            "frontage": "Center Camp Plaza",
            "intersection": "5:45",
            "intersection_type": "@",
            "gps_latitude": 40.78028849669452,
            "gps_longitude": -119.2144231550204
        },
        "location_string": "Center Camp Plaza @ 5:45"
    },
    {
        "uid": "a1Xd0000001IIunEAG",
        "year": 2016,
        "name": "Sunrise Diner",
        "hometown": "Seattle",
        "description": "Four score and a couple months ago some Seattle burners brought forth on this playa, a new theme camp, conceived in brunch, and dedicated to the proposition that all burners deserve to be gifted breakfast sandwiches every morning. Also coffee.",
        "location": {
            "string": "3:00 Plaza @ 11:45",
            "frontage": "3:00 Plaza",
            "intersection": "11:45",
            "intersection_type": "@",
            "gps_latitude": 40.78044612719148,
            "gps_longitude": -119.19872131628584
        },
        "location_string": "3:00 Plaza @ 11:45"
    },
    {
        "uid": "a1Xd0000001IMyUEAW",
        "year": 2016,
        "name": "Playa Info",
        "contact_email": "playainfo@burningman.org",
        "hometown": "san francisco",
        "description": "Playa Info which is the information destination  for the playa, consisting of lost and found, oracles, directory services, and selective outside service contacts.",
        "location": {
            "string": "Center Camp Plaza @ 1:00",
            "frontage": "Center Camp Plaza",
            "intersection": "1:00",
            "intersection_type": "@",
            "gps_latitude": 40.7809226723979,
            "gps_longitude": -119.2131697002368
        },
        "location_string": "Center Camp Plaza @ 1:00"
    },
    {
        "uid": "a1Xd0000001IKXcEAO",
        "year": 2016,
        "name": "The Empress",
        "url": "https://sites.google.com/site/empressburn/",
        "hometown": "Victoria/Vancouver",
        "description": "Victorian themed, the Empress provides an elegant escape from the everyday. Every afternoon and evening, our gracious hosts and hostesses wear Victorian or Steampunk costumes and hand-serve  selections from our tea menu along with light snacks - drop by for our daily hours!\r\n\r\nhttps://sites.google.com/site/empressburn/",
        "location": {
            "string": "Rod's Road @ 3:15",
            "frontage": "Rod's Road",
            "intersection": "3:15",
            "intersection_type": "@",
            "gps_latitude": 40.779135817371284,
            "gps_longitude": -119.21228774391663
        },
        "location_string": "Rod's Road @ 3:15"
    },
    {
        "uid": "a1Xd0000001ISNnEAO",
        "year": 2016,
        "name": "V Spot",
        "url": "https://www.facebook.com/VolunteerResourceTeam",
        "contact_email": "vspot@burningman.org",
        "hometown": "San Francisco",
        "description": "If you're at the event, and you (or your friends) get the sudden urge to volunteer on the spot, visit the V-Spot. They'll hook you up with available volunteer opportunities.",
        "location": {
            "string": "6:00 Portal & 6:00 Portal",
            "frontage": "6:00 Portal",
            "intersection": "6:00 Portal",
            "intersection_type": "&"
        },
        "location_string": "6:00 Portal & 6:00 Portal"
    },
    {
        "uid": "a1Xd0000001IWRjEAO",
        "year": 2016,
        "name": "The Neighbourhood",
        "url": "https://www.facebook.com/theneighbourhoodatburningman/",
        "hometown": "Los Angeles/Montréal",
        "description": "We are a Québec/US Burning Man theme camp! Together we create a communal space that celebrates the childlike mastery of the art of play. So come to The Neighborhood, where it's Recess all day! Dance and play your cares away. You can swing on our swings and/or play on our court, from our bridge catch the views,   while your friends all play fort. Dance to some beats, no need to be discreet. We got your back covered from this whimsical heat. Do us a favor...Won't you be our neighbor?",
        "location": {
            "string": "Rod's Road @ 7:15",
            "frontage": "Rod's Road",
            "intersection": "7:15",
            "intersection_type": "@",
            "gps_latitude": 40.78049759628541,
            "gps_longitude": -119.21662954660144
        },
        "location_string": "Rod's Road @ 7:15"
    },
    {
        "uid": "a1Xd0000001IVvIEAW",
        "year": 2016,
        "name": "The Dusty Beavers",
        "url": "https://www.facebook.com/TheDustyBeavers/",
        "contact_email": "contact@dustybeavers.org",
        "hometown": "Montreal",
        "description": "Directly from the Great White North, land of the maple leaf, comes the sugar shack of your dreams. Yes, a sugar shack on the Playa! Maple taffy on snow. Yes, snow on the Playa, in August. We will make it happen. Join us after dark for a taste of sweetly delicious \"tire d'érable sur neige.\" The Dusty Beavers are an international group: Canadians, French and Americans.",
        "location": {
            "string": "Rod's Road @ 7:45",
            "frontage": "Rod's Road",
            "intersection": "7:45",
            "intersection_type": "@",
            "gps_latitude": 40.78103410830745,
            "gps_longitude": -119.21662997140226
        },
        "location_string": "Rod's Road @ 7:45"
    },
    {
        "uid": "a1Xd0000001IBqBEAW",
        "year": 2016,
        "name": "Hair of the Dog  (HOTD)",
        "url": "http://thehotd.com",
        "contact_email": "hotdinfo@gmail.com",
        "hometown": "San Francisco bay area",
        "description": "HOTD provides old school entertainment and cold  drinks on the playa.\r\nYou bring the drinks and music, we'll supply the music and drinks.",
        "location": {
            "string": "Rod's Road & C",
            "frontage": "Rod's Road",
            "intersection": "C",
            "intersection_type": "&"
        },
        "location_string": "Rod's Road & C"
    },
    {
        "uid": "a1Xd0000001IWXIEA4",
        "year": 2016,
        "name": "Black Rock ( Notarious) Notary",
        "hometown": "Woodstock NY to Arcata CA",
        "description": "Black Rock Notary, aka Notarious Notaries are always at your service ! On the playa we can be found in the Guild Pavilion where you will be amazed at what , or where we will notarize for you! Home office at (insert address).",
        "location": {
            "string": "Rod's Road @ 4:45",
            "frontage": "Rod's Road",
            "intersection": "4:45",
            "intersection_type": "@",
            "gps_latitude": 40.77872931683699,
            "gps_longitude": -119.21429272350696
        },
        "location_string": "Rod's Road @ 4:45"
    },
    {
        "uid": "a1Xd0000001IVwQEAW",
        "year": 2016,
        "name": "The Costumery of Awesomeness",
        "contact_email": "costumery@wbecs.com",
        "hometown": "Samobor",
        "description": "From 8pm to Midnight each night the Costumery of Awesomeness will host epic pre-parties where costumeless wonderers as well as costumefull savants will gather to intoxicate, swap tales and costumes and get yourselves ready for what is likely to be one of the best nights of your life.\r\n\r\nFull body painting will also be offered as well as a huge selection of tickle trucks full to the brim of interesting artefacts to share and enjoy.\r\n\r\nWardrobes will be set up and 4 changing rooms will be available. \r\n\r\nWe will have the Wheel of Awesome in the centre of Camp next to the Giant tickle trunk. You spin the whee and it will land on a piece of clothing and IF you have that piece of clothing on you have to swap it for something in the trunk. If you don't have it on you get to pick anything out of the trunk. \r\n\r\nWe also have a giant inflatable twitter that will double as a bouncy dance floor costume off. Winner gets to choose a piece of costumery to swap with the loser.\r\n\r\nEpic times guaranteed.",
        "location": {
            "string": "9:30 & A",
            "frontage": "9:30",
            "intersection": "A",
            "intersection_type": "&",
            "gps_latitude": 40.79337692443453,
            "gps_longitude": -119.21182077171073
        },
        "location_string": "9:30 & A"
    },
    {
        "uid": "a1Xd0000001IWQ7EAO",
        "year": 2016,
        "name": "Big Imagination",
        "url": "http://www.bigimagination.org",
        "contact_email": "info@bigimagination.org",
        "hometown": "Venice",
        "description": "Big Imagination",
        "location": {
            "string": "Esplanade & 9:30",
            "frontage": "Esplanade",
            "intersection": "9:30",
            "intersection_type": "&",
            "gps_latitude": 40.792332774424715,
            "gps_longitude": -119.21102439458956
        },
        "location_string": "Esplanade & 9:30"
    },
    {
        "uid": "a1Xd0000001IRzqEAG",
        "year": 2016,
        "name": "Blackrock Yearbook",
        "url": "http://www.blackrockyearbook.com",
        "hometown": "Los Angeles",
        "description": "Are you ready for your Yearbook Photo?  Get your best playa wear on and come by!  You won't want to miss being in our annual Black Rock Yearbook we release every spring.",
        "location": {
            "string": "Rod's Road @ 2:45",
            "frontage": "Rod's Road",
            "intersection": "2:45",
            "intersection_type": "@",
            "gps_latitude": 40.77951489866554,
            "gps_longitude": -119.21178656039253
        },
        "location_string": "Rod's Road @ 2:45"
    },
    {
        "uid": "a1Xd0000001IRmaEAG",
        "year": 2016,
        "name": "Ashram Galactica, The Grand Hotel",
        "url": "http://ashramgalactica.com",
        "contact_email": "info@ashramgalactica.com",
        "hometown": "Los Angeles",
        "description": "Ashram Galactica - The Grand Hotel | Your Home Away From Home Away From Home",
        "location": {
            "string": "6:00 & G",
            "frontage": "6:00",
            "intersection": "G",
            "intersection_type": "&",
            "gps_latitude": 40.77791248567272,
            "gps_longitude": -119.2177076684539
        },
        "location_string": "6:00 & G"
    },
    {
        "uid": "a1Xd0000001IUg6EAG",
        "year": 2016,
        "name": "Roko's Basilica",
        "url": "http://metaversescholars.com",
        "contact_email": "roko@metaversescholars.com",
        "hometown": "San Francisco",
        "description": "Ready to be immerse yourself and embrace Roko?  From Virtual Reality to hookah and everything in-between, prepare to never be the same again.",
        "location": {
            "string": "3:00 Plaza @ 8:45",
            "frontage": "3:00 Plaza",
            "intersection": "8:45",
            "intersection_type": "@",
            "gps_latitude": 40.779966355006465,
            "gps_longitude": -119.19863759550043
        },
        "location_string": "3:00 Plaza @ 8:45"
    },
    {
        "uid": "a1Xd0000001IXGAEA4",
        "year": 2016,
        "name": "Black Rock City Welding & Repair",
        "hometown": "All over the place",
        "description": "Come to Black Rock City Welding & Repair for all your welding, bicycle and machine repair, and tinkering needs. Enjoy service from one of our Repairians, or use our tools to fix your bike yourself! Already well-adjusted?  \r\nStop by to enjoy a great view from the high couch, jump on our trampoline, or make new friends at the Night-Time Warming Station.   ",
        "location": {
            "string": "3:00 Plaza @ 4:00",
            "frontage": "3:00 Plaza",
            "intersection": "4:00",
            "intersection_type": "@",
            "gps_latitude": 40.780326374930866,
            "gps_longitude": -119.19792563285706
        },
        "location_string": "3:00 Plaza @ 4:00"
    }
]
{
	"art": {"file": "art.json.js",
			"updated": "2016-08-22T12:30:00-07:00"},
	"camps": {"file": "camps.json.js",
			  "updated": "2016-08-22T12:30:00-07:00"},
	"events": {"file": "events.json.js",
			   "updated": "2016-08-22T12:34:00-07:00"},
	"tiles": {"file": "iburn.mbtiles.jar",
			  "updated": "2016-08-16T12:45:00-07:00"},
	"points": {"file": "points.json.js",
			  "updated": "2016-08-16T12:30:00-07:00"}
}